import { defineComponent, ref, computed, withCtx, unref, createVNode, createBlock, createCommentVNode, openBlock, toDisplayString, withModifiers, withDirectives, vModelCheckbox, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderClass, ssrIncludeBooleanAttr, ssrLooseContain, ssrRenderAttr } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "XeroSettings",
  __ssrInlineRender: true,
  props: {
    settings: {}
  },
  setup(__props) {
    const props = __props;
    const syncing = ref(null);
    const form = useForm({
      is_enabled: props.settings.is_enabled,
      client_id: props.settings.client_id || "",
      client_secret: props.settings.client_secret || "",
      sync_customers: props.settings.sync_customers,
      sync_products: props.settings.sync_products,
      sync_invoices: props.settings.sync_invoices,
      sync_customers_to_xero: props.settings.sync_customers_to_xero,
      sync_customers_from_xero: props.settings.sync_customers_from_xero,
      sync_products_to_xero: props.settings.sync_products_to_xero,
      sync_products_from_xero: props.settings.sync_products_from_xero,
      sync_invoices_to_xero: props.settings.sync_invoices_to_xero,
      sync_invoices_from_xero: props.settings.sync_invoices_from_xero
    });
    const statusText = computed(() => {
      if (!form.is_enabled) return "Disabled";
      if (!props.settings.tenant_name) return "Not Connected";
      return "Connected";
    });
    const statusClass = computed(() => {
      if (!form.is_enabled) return "bg-gray-100 text-gray-800";
      if (!props.settings.tenant_name) return "bg-yellow-100 text-yellow-800";
      return "bg-green-100 text-green-800";
    });
    const submit = () => {
      form.put("/administration/xero-settings");
    };
    const authorize = () => {
      window.location.href = "/xero/authorize";
    };
    const disconnect = () => {
      if (confirm("Are you sure you want to disconnect from Xero?")) {
        form.delete("/xero/disconnect");
      }
    };
    const syncCustomers = () => {
      syncing.value = "customers";
      const syncForm = useForm({});
      syncForm.post("/xero/sync/customers", {
        onSuccess: () => {
          syncing.value = null;
        },
        onError: () => {
          syncing.value = null;
        },
        onFinish: () => {
          syncing.value = null;
        }
      });
    };
    const syncProducts = () => {
      syncing.value = "products";
      const syncForm = useForm({});
      syncForm.post("/xero/sync/products", {
        onSuccess: () => {
          syncing.value = null;
        },
        onError: () => {
          syncing.value = null;
        },
        onFinish: () => {
          syncing.value = null;
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="space-y-6"${_scopeId}>`);
            if (_ctx.$page.props.flash?.success) {
              _push2(`<div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded"${_scopeId}>${ssrInterpolate(_ctx.$page.props.flash.success)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (_ctx.$page.props.flash?.warning) {
              _push2(`<div class="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded"${_scopeId}>${ssrInterpolate(_ctx.$page.props.flash.warning)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (_ctx.$page.props.flash?.info) {
              _push2(`<div class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded"${_scopeId}>${ssrInterpolate(_ctx.$page.props.flash.info)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (_ctx.$page.props.flash?.error) {
              _push2(`<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded"${_scopeId}>${ssrInterpolate(_ctx.$page.props.flash.error)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="bg-white shadow rounded-lg p-6"${_scopeId}><div class="flex items-center justify-between mb-6"${_scopeId}><h2 class="text-xl font-semibold text-gray-900"${_scopeId}>Xero Integration Settings</h2><div class="flex items-center space-x-4"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Status:</span><span class="${ssrRenderClass([statusClass.value, "px-2 py-1 rounded-full text-xs font-medium"])}"${_scopeId}>${ssrInterpolate(statusText.value)}</span></div></div><form class="space-y-6"${_scopeId}><div class="flex items-center"${_scopeId}><input id="is_enabled"${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_enabled) ? ssrLooseContain(unref(form).is_enabled, null) : unref(form).is_enabled) ? " checked" : ""} type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"${_scopeId}><label for="is_enabled" class="ml-2 block text-sm text-gray-900"${_scopeId}> Enable Xero Integration </label></div>`);
            if (unref(form).is_enabled) {
              _push2(`<div class="space-y-4 border-t pt-6"${_scopeId}><h3 class="text-lg font-medium text-gray-900"${_scopeId}>OAuth Configuration</h3><div class="grid grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Client ID</label><input${ssrRenderAttr("value", unref(form).client_id)} type="text" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.client_id }, "w-full rounded border px-3 py-2"])}" placeholder="Enter Xero Client ID"${_scopeId}>`);
              if (unref(form).errors.client_id) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.client_id)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Client Secret</label><input${ssrRenderAttr("value", unref(form).client_secret)} type="password" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.client_secret }, "w-full rounded border px-3 py-2"])}" placeholder="Enter Xero Client Secret"${_scopeId}>`);
              if (unref(form).errors.client_secret) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.client_secret)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
              if (unref(form).client_id && unref(form).client_secret) {
                _push2(`<div class="bg-blue-50 border border-blue-200 rounded-lg p-4"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h4 class="text-sm font-medium text-blue-900"${_scopeId}>Authorization Required</h4><p class="text-sm text-blue-700 mt-1"${_scopeId}> Click &quot;Authorize with Xero&quot; to connect your Xero account. </p></div>`);
                if (!_ctx.settings.tenant_name) {
                  _push2(`<button type="button" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"${_scopeId}> Authorize with Xero </button>`);
                } else {
                  _push2(`<div class="text-right"${_scopeId}><p class="text-sm font-medium text-green-700"${_scopeId}>Connected</p><p class="text-xs text-green-600"${_scopeId}>${ssrInterpolate(_ctx.settings.tenant_name)}</p></div>`);
                }
                _push2(`</div></div>`);
              } else {
                _push2(`<!---->`);
              }
              if (_ctx.settings.tenant_name) {
                _push2(`<div class="flex justify-end"${_scopeId}><button type="button" class="text-red-600 hover:text-red-800 text-sm"${_scopeId}> Disconnect from Xero </button></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (unref(form).is_enabled && _ctx.settings.tenant_name) {
              _push2(`<div class="space-y-4 border-t pt-6"${_scopeId}><h3 class="text-lg font-medium text-gray-900"${_scopeId}>Sync Settings</h3><div class="bg-gray-50 rounded-lg p-4"${_scopeId}><div class="flex items-center justify-between mb-3"${_scopeId}><h4 class="font-medium text-gray-900"${_scopeId}>Customers</h4><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).sync_customers) ? ssrLooseContain(unref(form).sync_customers, null) : unref(form).sync_customers) ? " checked" : ""} type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"${_scopeId}></div>`);
              if (unref(form).sync_customers) {
                _push2(`<div class="space-y-2 ml-6"${_scopeId}><label class="flex items-center"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).sync_customers_to_xero) ? ssrLooseContain(unref(form).sync_customers_to_xero, null) : unref(form).sync_customers_to_xero) ? " checked" : ""} type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"${_scopeId}><span class="ml-2 text-sm text-gray-700"${_scopeId}>Sync to Xero</span></label><label class="flex items-center"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).sync_customers_from_xero) ? ssrLooseContain(unref(form).sync_customers_from_xero, null) : unref(form).sync_customers_from_xero) ? " checked" : ""} type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"${_scopeId}><span class="ml-2 text-sm text-gray-700"${_scopeId}>Sync from Xero</span></label></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="bg-gray-50 rounded-lg p-4"${_scopeId}><div class="flex items-center justify-between mb-3"${_scopeId}><h4 class="font-medium text-gray-900"${_scopeId}>Products</h4><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).sync_products) ? ssrLooseContain(unref(form).sync_products, null) : unref(form).sync_products) ? " checked" : ""} type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"${_scopeId}></div>`);
              if (unref(form).sync_products) {
                _push2(`<div class="space-y-2 ml-6"${_scopeId}><label class="flex items-center"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).sync_products_to_xero) ? ssrLooseContain(unref(form).sync_products_to_xero, null) : unref(form).sync_products_to_xero) ? " checked" : ""} type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"${_scopeId}><span class="ml-2 text-sm text-gray-700"${_scopeId}>Sync to Xero</span></label><label class="flex items-center"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).sync_products_from_xero) ? ssrLooseContain(unref(form).sync_products_from_xero, null) : unref(form).sync_products_from_xero) ? " checked" : ""} type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"${_scopeId}><span class="ml-2 text-sm text-gray-700"${_scopeId}>Sync from Xero</span></label></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="bg-gray-50 rounded-lg p-4"${_scopeId}><div class="flex items-center justify-between mb-3"${_scopeId}><h4 class="font-medium text-gray-900"${_scopeId}>Invoices</h4><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).sync_invoices) ? ssrLooseContain(unref(form).sync_invoices, null) : unref(form).sync_invoices) ? " checked" : ""} type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"${_scopeId}></div>`);
              if (unref(form).sync_invoices) {
                _push2(`<div class="space-y-2 ml-6"${_scopeId}><label class="flex items-center"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).sync_invoices_to_xero) ? ssrLooseContain(unref(form).sync_invoices_to_xero, null) : unref(form).sync_invoices_to_xero) ? " checked" : ""} type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"${_scopeId}><span class="ml-2 text-sm text-gray-700"${_scopeId}>Sync to Xero</span></label><label class="flex items-center"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).sync_invoices_from_xero) ? ssrLooseContain(unref(form).sync_invoices_from_xero, null) : unref(form).sync_invoices_from_xero) ? " checked" : ""} type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"${_scopeId}><span class="ml-2 text-sm text-gray-700"${_scopeId}>Sync from Xero (including payment status)</span></label></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex justify-end pt-6 border-t"${_scopeId}><button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(form).processing ? "Saving..." : "Save Settings")}</button></div></form></div>`);
            if (unref(form).is_enabled && _ctx.settings.tenant_name) {
              _push2(`<div class="bg-white shadow rounded-lg p-6"${_scopeId}><h3 class="text-lg font-medium text-gray-900 mb-4"${_scopeId}>Manual Sync</h3><div class="grid grid-cols-1 md:grid-cols-3 gap-4"${_scopeId}>`);
              if (unref(form).sync_customers_to_xero) {
                _push2(`<button${ssrIncludeBooleanAttr(syncing.value) ? " disabled" : ""} class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50"${_scopeId}>${ssrInterpolate(syncing.value === "customers" ? "Syncing..." : "Sync Customers to Xero")}</button>`);
              } else {
                _push2(`<!---->`);
              }
              if (unref(form).sync_products_to_xero) {
                _push2(`<button${ssrIncludeBooleanAttr(syncing.value) ? " disabled" : ""} class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50"${_scopeId}>${ssrInterpolate(syncing.value === "products" ? "Syncing..." : "Sync Products to Xero")}</button>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "space-y-6" }, [
                _ctx.$page.props.flash?.success ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded"
                }, toDisplayString(_ctx.$page.props.flash.success), 1)) : createCommentVNode("", true),
                _ctx.$page.props.flash?.warning ? (openBlock(), createBlock("div", {
                  key: 1,
                  class: "bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded"
                }, toDisplayString(_ctx.$page.props.flash.warning), 1)) : createCommentVNode("", true),
                _ctx.$page.props.flash?.info ? (openBlock(), createBlock("div", {
                  key: 2,
                  class: "bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded"
                }, toDisplayString(_ctx.$page.props.flash.info), 1)) : createCommentVNode("", true),
                _ctx.$page.props.flash?.error ? (openBlock(), createBlock("div", {
                  key: 3,
                  class: "bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded"
                }, toDisplayString(_ctx.$page.props.flash.error), 1)) : createCommentVNode("", true),
                createVNode("div", { class: "bg-white shadow rounded-lg p-6" }, [
                  createVNode("div", { class: "flex items-center justify-between mb-6" }, [
                    createVNode("h2", { class: "text-xl font-semibold text-gray-900" }, "Xero Integration Settings"),
                    createVNode("div", { class: "flex items-center space-x-4" }, [
                      createVNode("span", { class: "text-sm text-gray-500" }, "Status:"),
                      createVNode("span", {
                        class: [statusClass.value, "px-2 py-1 rounded-full text-xs font-medium"]
                      }, toDisplayString(statusText.value), 3)
                    ])
                  ]),
                  createVNode("form", {
                    onSubmit: withModifiers(submit, ["prevent"]),
                    class: "space-y-6"
                  }, [
                    createVNode("div", { class: "flex items-center" }, [
                      withDirectives(createVNode("input", {
                        id: "is_enabled",
                        "onUpdate:modelValue": ($event) => unref(form).is_enabled = $event,
                        type: "checkbox",
                        class: "h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelCheckbox, unref(form).is_enabled]
                      ]),
                      createVNode("label", {
                        for: "is_enabled",
                        class: "ml-2 block text-sm text-gray-900"
                      }, " Enable Xero Integration ")
                    ]),
                    unref(form).is_enabled ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "space-y-4 border-t pt-6"
                    }, [
                      createVNode("h3", { class: "text-lg font-medium text-gray-900" }, "OAuth Configuration"),
                      createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Client ID"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).client_id = $event,
                            type: "text",
                            class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.client_id }],
                            placeholder: "Enter Xero Client ID"
                          }, null, 10, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).client_id]
                          ]),
                          unref(form).errors.client_id ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(form).errors.client_id), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Client Secret"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).client_secret = $event,
                            type: "password",
                            class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.client_secret }],
                            placeholder: "Enter Xero Client Secret"
                          }, null, 10, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).client_secret]
                          ]),
                          unref(form).errors.client_secret ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(form).errors.client_secret), 1)) : createCommentVNode("", true)
                        ])
                      ]),
                      unref(form).client_id && unref(form).client_secret ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "bg-blue-50 border border-blue-200 rounded-lg p-4"
                      }, [
                        createVNode("div", { class: "flex items-center justify-between" }, [
                          createVNode("div", null, [
                            createVNode("h4", { class: "text-sm font-medium text-blue-900" }, "Authorization Required"),
                            createVNode("p", { class: "text-sm text-blue-700 mt-1" }, ' Click "Authorize with Xero" to connect your Xero account. ')
                          ]),
                          !_ctx.settings.tenant_name ? (openBlock(), createBlock("button", {
                            key: 0,
                            type: "button",
                            onClick: authorize,
                            class: "bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                          }, " Authorize with Xero ")) : (openBlock(), createBlock("div", {
                            key: 1,
                            class: "text-right"
                          }, [
                            createVNode("p", { class: "text-sm font-medium text-green-700" }, "Connected"),
                            createVNode("p", { class: "text-xs text-green-600" }, toDisplayString(_ctx.settings.tenant_name), 1)
                          ]))
                        ])
                      ])) : createCommentVNode("", true),
                      _ctx.settings.tenant_name ? (openBlock(), createBlock("div", {
                        key: 1,
                        class: "flex justify-end"
                      }, [
                        createVNode("button", {
                          type: "button",
                          onClick: disconnect,
                          class: "text-red-600 hover:text-red-800 text-sm"
                        }, " Disconnect from Xero ")
                      ])) : createCommentVNode("", true)
                    ])) : createCommentVNode("", true),
                    unref(form).is_enabled && _ctx.settings.tenant_name ? (openBlock(), createBlock("div", {
                      key: 1,
                      class: "space-y-4 border-t pt-6"
                    }, [
                      createVNode("h3", { class: "text-lg font-medium text-gray-900" }, "Sync Settings"),
                      createVNode("div", { class: "bg-gray-50 rounded-lg p-4" }, [
                        createVNode("div", { class: "flex items-center justify-between mb-3" }, [
                          createVNode("h4", { class: "font-medium text-gray-900" }, "Customers"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).sync_customers = $event,
                            type: "checkbox",
                            class: "h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelCheckbox, unref(form).sync_customers]
                          ])
                        ]),
                        unref(form).sync_customers ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "space-y-2 ml-6"
                        }, [
                          createVNode("label", { class: "flex items-center" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).sync_customers_to_xero = $event,
                              type: "checkbox",
                              class: "h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelCheckbox, unref(form).sync_customers_to_xero]
                            ]),
                            createVNode("span", { class: "ml-2 text-sm text-gray-700" }, "Sync to Xero")
                          ]),
                          createVNode("label", { class: "flex items-center" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).sync_customers_from_xero = $event,
                              type: "checkbox",
                              class: "h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelCheckbox, unref(form).sync_customers_from_xero]
                            ]),
                            createVNode("span", { class: "ml-2 text-sm text-gray-700" }, "Sync from Xero")
                          ])
                        ])) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "bg-gray-50 rounded-lg p-4" }, [
                        createVNode("div", { class: "flex items-center justify-between mb-3" }, [
                          createVNode("h4", { class: "font-medium text-gray-900" }, "Products"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).sync_products = $event,
                            type: "checkbox",
                            class: "h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelCheckbox, unref(form).sync_products]
                          ])
                        ]),
                        unref(form).sync_products ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "space-y-2 ml-6"
                        }, [
                          createVNode("label", { class: "flex items-center" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).sync_products_to_xero = $event,
                              type: "checkbox",
                              class: "h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelCheckbox, unref(form).sync_products_to_xero]
                            ]),
                            createVNode("span", { class: "ml-2 text-sm text-gray-700" }, "Sync to Xero")
                          ]),
                          createVNode("label", { class: "flex items-center" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).sync_products_from_xero = $event,
                              type: "checkbox",
                              class: "h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelCheckbox, unref(form).sync_products_from_xero]
                            ]),
                            createVNode("span", { class: "ml-2 text-sm text-gray-700" }, "Sync from Xero")
                          ])
                        ])) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "bg-gray-50 rounded-lg p-4" }, [
                        createVNode("div", { class: "flex items-center justify-between mb-3" }, [
                          createVNode("h4", { class: "font-medium text-gray-900" }, "Invoices"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).sync_invoices = $event,
                            type: "checkbox",
                            class: "h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelCheckbox, unref(form).sync_invoices]
                          ])
                        ]),
                        unref(form).sync_invoices ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "space-y-2 ml-6"
                        }, [
                          createVNode("label", { class: "flex items-center" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).sync_invoices_to_xero = $event,
                              type: "checkbox",
                              class: "h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelCheckbox, unref(form).sync_invoices_to_xero]
                            ]),
                            createVNode("span", { class: "ml-2 text-sm text-gray-700" }, "Sync to Xero")
                          ]),
                          createVNode("label", { class: "flex items-center" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).sync_invoices_from_xero = $event,
                              type: "checkbox",
                              class: "h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelCheckbox, unref(form).sync_invoices_from_xero]
                            ]),
                            createVNode("span", { class: "ml-2 text-sm text-gray-700" }, "Sync from Xero (including payment status)")
                          ])
                        ])) : createCommentVNode("", true)
                      ])
                    ])) : createCommentVNode("", true),
                    createVNode("div", { class: "flex justify-end pt-6 border-t" }, [
                      createVNode("button", {
                        type: "submit",
                        disabled: unref(form).processing,
                        class: "bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
                      }, toDisplayString(unref(form).processing ? "Saving..." : "Save Settings"), 9, ["disabled"])
                    ])
                  ], 32)
                ]),
                unref(form).is_enabled && _ctx.settings.tenant_name ? (openBlock(), createBlock("div", {
                  key: 4,
                  class: "bg-white shadow rounded-lg p-6"
                }, [
                  createVNode("h3", { class: "text-lg font-medium text-gray-900 mb-4" }, "Manual Sync"),
                  createVNode("div", { class: "grid grid-cols-1 md:grid-cols-3 gap-4" }, [
                    unref(form).sync_customers_to_xero ? (openBlock(), createBlock("button", {
                      key: 0,
                      onClick: syncCustomers,
                      disabled: syncing.value,
                      class: "bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50"
                    }, toDisplayString(syncing.value === "customers" ? "Syncing..." : "Sync Customers to Xero"), 9, ["disabled"])) : createCommentVNode("", true),
                    unref(form).sync_products_to_xero ? (openBlock(), createBlock("button", {
                      key: 1,
                      onClick: syncProducts,
                      disabled: syncing.value,
                      class: "bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50"
                    }, toDisplayString(syncing.value === "products" ? "Syncing..." : "Sync Products to Xero"), 9, ["disabled"])) : createCommentVNode("", true)
                  ])
                ])) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/administration/XeroSettings.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
