import Auth from './Auth'
import DashboardController from './DashboardController'
import Settings from './Settings'
import CustomersController from './CustomersController'
import ContactController from './ContactController'
import ProductController from './ProductController'
import CategoryController from './CategoryController'
import JobcardController from './JobcardController'
import QuotesController from './QuotesController'
import InvoicesController from './InvoicesController'
import PaymentsController from './PaymentsController'
import UsersController from './UsersController'
import GroupsController from './GroupsController'
import AdministrationController from './AdministrationController'
import SMSSettingsController from './SMSSettingsController'
import CompanySettingsController from './CompanySettingsController'
import XeroSettingsController from './XeroSettingsController'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
DashboardController: Object.assign(DashboardController, DashboardController),
Settings: Object.assign(Settings, Settings),
CustomersController: Object.assign(CustomersController, CustomersController),
ContactController: Object.assign(ContactController, ContactController),
ProductController: Object.assign(ProductController, ProductController),
CategoryController: Object.assign(CategoryController, CategoryController),
JobcardController: Object.assign(JobcardController, JobcardController),
QuotesController: Object.assign(QuotesController, QuotesController),
InvoicesController: Object.assign(InvoicesController, InvoicesController),
PaymentsController: Object.assign(PaymentsController, PaymentsController),
UsersController: Object.assign(UsersController, UsersController),
GroupsController: Object.assign(GroupsController, GroupsController),
AdministrationController: Object.assign(AdministrationController, AdministrationController),
SMSSettingsController: Object.assign(SMSSettingsController, SMSSettingsController),
CompanySettingsController: Object.assign(CompanySettingsController, CompanySettingsController),
XeroSettingsController: Object.assign(XeroSettingsController, XeroSettingsController),
}

export default Controllers