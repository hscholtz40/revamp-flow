import { defineComponent, watch, computed, unref, withCtx, createTextVNode, createVNode, toDisplayString, withModifiers, createBlock, createCommentVNode, withDirectives, openBlock, Fragment, renderList, vModelSelect, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderClass, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { j as jobcards } from "./_plugin-vue_export-helper-BjD8VFd3.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    jobcard: {},
    customers: {},
    products: {},
    currentCompany: {}
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      customer_id: props.jobcard.customer_id,
      title: props.jobcard.title,
      description: props.jobcard.description || "",
      status: props.jobcard.status,
      start_date: props.jobcard.start_date ? new Date(props.jobcard.start_date).toISOString().split("T")[0] : "",
      due_date: props.jobcard.due_date ? new Date(props.jobcard.due_date).toISOString().split("T")[0] : "",
      completed_date: props.jobcard.completed_date ? new Date(props.jobcard.completed_date).toISOString().split("T")[0] : "",
      tax_rate: props.jobcard.tax_rate,
      discount_amount: props.jobcard.discount_amount || 0,
      discount_percentage: props.jobcard.discount_percentage || 0,
      notes: props.jobcard.notes || "",
      terms_conditions: props.jobcard.terms_conditions || "",
      line_items: props.jobcard.line_items.map((item) => ({
        id: item.id,
        product_id: item.product_id,
        description: item.description,
        quantity: item.quantity,
        unit_price: item.unit_price
      }))
    });
    watch(() => form.discount_amount, (newAmount) => {
      if (newAmount > 0) {
        form.discount_percentage = 0;
      }
    });
    watch(() => form.discount_percentage, (newPercentage) => {
      if (newPercentage > 0) {
        form.discount_amount = 0;
      }
    });
    const addLineItem = () => {
      form.line_items.push({
        id: void 0,
        product_id: null,
        description: "",
        quantity: 1,
        unit_price: 0
      });
    };
    const removeLineItem = (index) => {
      if (form.line_items.length > 1) {
        form.line_items.splice(index, 1);
      }
    };
    const selectProduct = (index, productId) => {
      const item = form.line_items[index];
      if (!item) return;
      item.product_id = productId;
      if (productId) {
        const product = props.products.find((p) => p.id === productId);
        if (product) {
          item.description = product.name || "";
          item.unit_price = product.price || 0;
        }
      } else {
        item.description = "";
        item.unit_price = 0;
      }
    };
    const calculateLineTotal = (item) => {
      const quantity = Number(item.quantity) || 0;
      const unitPrice = Number(item.unit_price) || 0;
      return quantity * unitPrice;
    };
    const subtotal = computed(() => {
      if (!form.line_items || form.line_items.length === 0) return 0;
      const result = form.line_items.reduce((sum, item) => {
        if (!item) return sum;
        return sum + calculateLineTotal(item);
      }, 0);
      return Number(result) || 0;
    });
    const discountAmount = computed(() => {
      const amount = Number(form.discount_amount) || 0;
      const percentage = Number(form.discount_percentage) || 0;
      if (percentage > 0) {
        return subtotal.value * (percentage / 100);
      }
      return amount;
    });
    const taxAmount = computed(() => {
      const rate = Number(form.tax_rate) || 0;
      const subtotalAfterDiscount = subtotal.value - discountAmount.value;
      const result = subtotalAfterDiscount * (rate / 100);
      return Number(result) || 0;
    });
    const total = computed(() => {
      const subtotalAfterDiscount = subtotal.value - discountAmount.value;
      const result = subtotalAfterDiscount + taxAmount.value;
      return Number(result) || 0;
    });
    const submit = () => {
      form.put(jobcards.update(props.jobcard.id).url);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Edit ${props.jobcard.job_number}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Jobcards", href: unref(jobcards).index().url },
          { title: props.jobcard.job_number, href: unref(jobcards).show(props.jobcard.id).url },
          { title: "Edit", href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-blue-50 border-b border-blue-200 px-4 py-3"${_scopeId}><div class="flex items-center gap-2 text-sm text-blue-700"${_scopeId}><span class="font-medium"${_scopeId}>Editing jobcard for:</span><span class="font-semibold"${_scopeId}>${ssrInterpolate(props.currentCompany.name)}</span></div></div><div class="p-4"${_scopeId}><div class="flex items-center justify-between gap-3 mb-6"${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>Edit Jobcard ${ssrInterpolate(props.jobcard.job_number)}</h1></div><form class="space-y-6"${_scopeId}><div class="bg-white rounded-lg border p-6"${_scopeId}><h2 class="text-lg font-semibold text-gray-900 mb-4"${_scopeId}>Basic Information</h2><div class="grid grid-cols-1 md:grid-cols-2 gap-6"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Customer *</label><select class="${ssrRenderClass([{ "border-red-500": unref(form).errors.customer_id }, "w-full rounded border px-3 py-2"])}" required${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(unref(form).customer_id) ? ssrLooseContain(unref(form).customer_id, "") : ssrLooseEqual(unref(form).customer_id, "")) ? " selected" : ""}${_scopeId}>Select a customer</option><!--[-->`);
            ssrRenderList(props.customers, (customer) => {
              _push2(`<option${ssrRenderAttr("value", customer.id)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).customer_id) ? ssrLooseContain(unref(form).customer_id, customer.id) : ssrLooseEqual(unref(form).customer_id, customer.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(customer.name)}</option>`);
            });
            _push2(`<!--]--></select>`);
            if (unref(form).errors.customer_id) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.customer_id)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Title *</label><input${ssrRenderAttr("value", unref(form).title)} type="text" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.title }, "w-full rounded border px-3 py-2"])}" required${_scopeId}>`);
            if (unref(form).errors.title) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.title)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Status *</label><select class="${ssrRenderClass([{ "border-red-500": unref(form).errors.status }, "w-full rounded border px-3 py-2"])}" required${_scopeId}><option value="draft"${ssrIncludeBooleanAttr(Array.isArray(unref(form).status) ? ssrLooseContain(unref(form).status, "draft") : ssrLooseEqual(unref(form).status, "draft")) ? " selected" : ""}${_scopeId}>Draft</option><option value="pending"${ssrIncludeBooleanAttr(Array.isArray(unref(form).status) ? ssrLooseContain(unref(form).status, "pending") : ssrLooseEqual(unref(form).status, "pending")) ? " selected" : ""}${_scopeId}>Pending</option><option value="in_progress"${ssrIncludeBooleanAttr(Array.isArray(unref(form).status) ? ssrLooseContain(unref(form).status, "in_progress") : ssrLooseEqual(unref(form).status, "in_progress")) ? " selected" : ""}${_scopeId}>In Progress</option><option value="completed"${ssrIncludeBooleanAttr(Array.isArray(unref(form).status) ? ssrLooseContain(unref(form).status, "completed") : ssrLooseEqual(unref(form).status, "completed")) ? " selected" : ""}${_scopeId}>Completed</option><option value="cancelled"${ssrIncludeBooleanAttr(Array.isArray(unref(form).status) ? ssrLooseContain(unref(form).status, "cancelled") : ssrLooseEqual(unref(form).status, "cancelled")) ? " selected" : ""}${_scopeId}>Cancelled</option></select>`);
            if (unref(form).errors.status) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.status)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><br${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Start Date</label><input${ssrRenderAttr("value", unref(form).start_date)} type="date" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.start_date }, "w-full rounded border px-3 py-2"])}"${_scopeId}>`);
            if (unref(form).errors.start_date) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.start_date)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Due Date</label><input${ssrRenderAttr("value", unref(form).due_date)} type="date" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.due_date }, "w-full rounded border px-3 py-2"])}"${_scopeId}>`);
            if (unref(form).errors.due_date) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.due_date)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
            if (unref(form).status === "completed") {
              _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Completed Date</label><input${ssrRenderAttr("value", unref(form).completed_date)} type="date" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.completed_date }, "w-full rounded border px-3 py-2"])}"${_scopeId}>`);
              if (unref(form).errors.completed_date) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.completed_date)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="mt-6"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Description</label><textarea rows="3" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.description }, "w-full rounded border px-3 py-2"])}"${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea>`);
            if (unref(form).errors.description) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.description)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="bg-white rounded-lg border p-6"${_scopeId}><div class="flex items-center justify-between mb-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Line Items</h2><button type="button" class="rounded bg-blue-600 px-3 py-2 text-white hover:bg-blue-700"${_scopeId}> Add Item </button></div>`);
            if (unref(form).errors.line_items) {
              _push2(`<div class="text-red-500 text-sm mb-4"${_scopeId}>${ssrInterpolate(unref(form).errors.line_items)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="space-y-4"${_scopeId}><!--[-->`);
            ssrRenderList(unref(form).line_items, (item, index) => {
              _push2(`<div class="grid grid-cols-1 md:grid-cols-6 gap-4 p-4 border rounded-lg"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Product</label><select${ssrRenderAttr("value", item.product_id)} class="w-full rounded border px-3 py-2"${_scopeId}><option value=""${_scopeId}>Custom Item</option><!--[-->`);
              ssrRenderList(props.products, (product) => {
                _push2(`<option${ssrRenderAttr("value", product.id)}${_scopeId}>${ssrInterpolate(product.name)} (${ssrInterpolate(product.type)}) </option>`);
              });
              _push2(`<!--]--></select></div><div class="md:col-span-2"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Description *</label><input${ssrRenderAttr("value", item.description)} type="text" class="${ssrRenderClass([{ "border-red-500": unref(form).errors[`line_items.${index}.description`] }, "w-full rounded border px-3 py-2"])}" required${_scopeId}>`);
              if (unref(form).errors[`line_items.${index}.description`]) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors[`line_items.${index}.description`])}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Quantity *</label><input${ssrRenderAttr("value", item.quantity)} type="number" min="1" class="${ssrRenderClass([{ "border-red-500": unref(form).errors[`line_items.${index}.quantity`] }, "w-full rounded border px-3 py-2"])}" required${_scopeId}>`);
              if (unref(form).errors[`line_items.${index}.quantity`]) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors[`line_items.${index}.quantity`])}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Unit Price *</label><input${ssrRenderAttr("value", item.unit_price)} type="number" step="0.01" min="0" class="${ssrRenderClass([{ "border-red-500": unref(form).errors[`line_items.${index}.unit_price`] }, "w-full rounded border px-3 py-2"])}" required${_scopeId}>`);
              if (unref(form).errors[`line_items.${index}.unit_price`]) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors[`line_items.${index}.unit_price`])}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="flex items-end"${_scopeId}><div class="w-full"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Total</label><div class="w-full rounded border px-3 py-2 bg-gray-50 text-gray-700"${_scopeId}> R${ssrInterpolate(calculateLineTotal(item).toFixed(2))}</div></div><button type="button" class="ml-2 text-red-600 hover:text-red-800"${ssrIncludeBooleanAttr(unref(form).line_items.length === 1) ? " disabled" : ""}${_scopeId}> Remove </button></div></div>`);
            });
            _push2(`<!--]--></div><br${_scopeId}><div class="flex items-center justify-between mb-4"${_scopeId}><button type="button" class="rounded bg-blue-600 px-3 py-2 text-white hover:bg-blue-700"${_scopeId}> + </button></div><div class="mt-6 border-t pt-4"${_scopeId}><div class="flex justify-end"${_scopeId}><div class="w-64 space-y-2"${_scopeId}><div class="flex justify-between"${_scopeId}><span class="text-sm text-gray-600"${_scopeId}>Subtotal:</span><span class="text-sm font-medium"${_scopeId}>R${ssrInterpolate(subtotal.value.toFixed(2))}</span></div><div class="flex justify-between"${_scopeId}><span class="text-sm text-gray-600"${_scopeId}>Discount:</span><span class="text-sm font-medium text-red-600"${_scopeId}>-R${ssrInterpolate(discountAmount.value.toFixed(2))}</span></div><div class="flex justify-between"${_scopeId}><span class="text-sm text-gray-600"${_scopeId}>Tax (${ssrInterpolate(unref(form).tax_rate || 0)}%):</span><span class="text-sm font-medium"${_scopeId}>R${ssrInterpolate(taxAmount.value.toFixed(2))}</span></div><div class="flex justify-between border-t pt-2"${_scopeId}><span class="text-base font-semibold"${_scopeId}>Total:</span><span class="text-base font-semibold"${_scopeId}>R${ssrInterpolate(total.value.toFixed(2))}</span></div></div></div></div></div><div class="bg-white rounded-lg border p-6"${_scopeId}><h2 class="text-lg font-semibold text-gray-900 mb-4"${_scopeId}>Additional Information</h2><div class="space-y-4"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Discount Amount (R)</label><input type="number" step="0.01"${ssrRenderAttr("value", unref(form).discount_amount)} class="${ssrRenderClass([{ "border-red-500": unref(form).errors.discount_amount }, "w-full rounded border px-3 py-2"])}" placeholder="0.00"${_scopeId}>`);
            if (unref(form).errors.discount_amount) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.discount_amount)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Discount Percentage (%)</label><input type="number" step="0.01"${ssrRenderAttr("value", unref(form).discount_percentage)} class="${ssrRenderClass([{ "border-red-500": unref(form).errors.discount_percentage }, "w-full rounded border px-3 py-2"])}" placeholder="0.00"${_scopeId}>`);
            if (unref(form).errors.discount_percentage) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.discount_percentage)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Notes</label><textarea rows="3" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.notes }, "w-full rounded border px-3 py-2"])}"${_scopeId}>${ssrInterpolate(unref(form).notes)}</textarea>`);
            if (unref(form).errors.notes) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.notes)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Terms &amp; Conditions</label><textarea rows="3" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.terms_conditions }, "w-full rounded border px-3 py-2"])}"${_scopeId}>${ssrInterpolate(unref(form).terms_conditions)}</textarea>`);
            if (unref(form).errors.terms_conditions) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.terms_conditions)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="flex items-center justify-end gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(jobcards).show(props.jobcard.id).url,
              class: "rounded bg-gray-500 px-4 py-2 text-white hover:bg-gray-600"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Cancel `);
                } else {
                  return [
                    createTextVNode(" Cancel ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(form).processing ? "Updating..." : "Update Jobcard")}</button></div></form></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-blue-50 border-b border-blue-200 px-4 py-3" }, [
                createVNode("div", { class: "flex items-center gap-2 text-sm text-blue-700" }, [
                  createVNode("span", { class: "font-medium" }, "Editing jobcard for:"),
                  createVNode("span", { class: "font-semibold" }, toDisplayString(props.currentCompany.name), 1)
                ])
              ]),
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "flex items-center justify-between gap-3 mb-6" }, [
                  createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "Edit Jobcard " + toDisplayString(props.jobcard.job_number), 1)
                ]),
                createVNode("form", {
                  onSubmit: withModifiers(submit, ["prevent"]),
                  class: "space-y-6"
                }, [
                  createVNode("div", { class: "bg-white rounded-lg border p-6" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900 mb-4" }, "Basic Information"),
                    createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-6" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Customer *"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => unref(form).customer_id = $event,
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.customer_id }],
                          required: ""
                        }, [
                          createVNode("option", { value: "" }, "Select a customer"),
                          (openBlock(true), createBlock(Fragment, null, renderList(props.customers, (customer) => {
                            return openBlock(), createBlock("option", {
                              key: customer.id,
                              value: customer.id
                            }, toDisplayString(customer.name), 9, ["value"]);
                          }), 128))
                        ], 10, ["onUpdate:modelValue"]), [
                          [vModelSelect, unref(form).customer_id]
                        ]),
                        unref(form).errors.customer_id ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.customer_id), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Title *"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => unref(form).title = $event,
                          type: "text",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.title }],
                          required: ""
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).title]
                        ]),
                        unref(form).errors.title ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.title), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Status *"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => unref(form).status = $event,
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.status }],
                          required: ""
                        }, [
                          createVNode("option", { value: "draft" }, "Draft"),
                          createVNode("option", { value: "pending" }, "Pending"),
                          createVNode("option", { value: "in_progress" }, "In Progress"),
                          createVNode("option", { value: "completed" }, "Completed"),
                          createVNode("option", { value: "cancelled" }, "Cancelled")
                        ], 10, ["onUpdate:modelValue"]), [
                          [vModelSelect, unref(form).status]
                        ]),
                        unref(form).errors.status ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.status), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("br"),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Start Date"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => unref(form).start_date = $event,
                          type: "date",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.start_date }]
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).start_date]
                        ]),
                        unref(form).errors.start_date ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.start_date), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Due Date"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => unref(form).due_date = $event,
                          type: "date",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.due_date }]
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).due_date]
                        ]),
                        unref(form).errors.due_date ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.due_date), 1)) : createCommentVNode("", true)
                      ]),
                      unref(form).status === "completed" ? (openBlock(), createBlock("div", { key: 0 }, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Completed Date"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => unref(form).completed_date = $event,
                          type: "date",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.completed_date }]
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).completed_date]
                        ]),
                        unref(form).errors.completed_date ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.completed_date), 1)) : createCommentVNode("", true)
                      ])) : createCommentVNode("", true)
                    ]),
                    createVNode("div", { class: "mt-6" }, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Description"),
                      withDirectives(createVNode("textarea", {
                        "onUpdate:modelValue": ($event) => unref(form).description = $event,
                        rows: "3",
                        class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.description }]
                      }, null, 10, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).description]
                      ]),
                      unref(form).errors.description ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-red-500 text-sm mt-1"
                      }, toDisplayString(unref(form).errors.description), 1)) : createCommentVNode("", true)
                    ])
                  ]),
                  createVNode("div", { class: "bg-white rounded-lg border p-6" }, [
                    createVNode("div", { class: "flex items-center justify-between mb-4" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Line Items"),
                      createVNode("button", {
                        type: "button",
                        onClick: addLineItem,
                        class: "rounded bg-blue-600 px-3 py-2 text-white hover:bg-blue-700"
                      }, " Add Item ")
                    ]),
                    unref(form).errors.line_items ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "text-red-500 text-sm mb-4"
                    }, toDisplayString(unref(form).errors.line_items), 1)) : createCommentVNode("", true),
                    createVNode("div", { class: "space-y-4" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(form).line_items, (item, index) => {
                        return openBlock(), createBlock("div", {
                          key: index,
                          class: "grid grid-cols-1 md:grid-cols-6 gap-4 p-4 border rounded-lg"
                        }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Product"),
                            createVNode("select", {
                              value: item.product_id,
                              onChange: ($event) => selectProduct(index, $event.target.value ? parseInt($event.target.value) : null),
                              class: "w-full rounded border px-3 py-2"
                            }, [
                              createVNode("option", { value: "" }, "Custom Item"),
                              (openBlock(true), createBlock(Fragment, null, renderList(props.products, (product) => {
                                return openBlock(), createBlock("option", {
                                  key: product.id,
                                  value: product.id
                                }, toDisplayString(product.name) + " (" + toDisplayString(product.type) + ") ", 9, ["value"]);
                              }), 128))
                            ], 40, ["value", "onChange"])
                          ]),
                          createVNode("div", { class: "md:col-span-2" }, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Description *"),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => item.description = $event,
                              type: "text",
                              class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors[`line_items.${index}.description`] }],
                              required: ""
                            }, null, 10, ["onUpdate:modelValue"]), [
                              [vModelText, item.description]
                            ]),
                            unref(form).errors[`line_items.${index}.description`] ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors[`line_items.${index}.description`]), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Quantity *"),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => item.quantity = $event,
                              type: "number",
                              min: "1",
                              class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors[`line_items.${index}.quantity`] }],
                              required: ""
                            }, null, 10, ["onUpdate:modelValue"]), [
                              [
                                vModelText,
                                item.quantity,
                                void 0,
                                { number: true }
                              ]
                            ]),
                            unref(form).errors[`line_items.${index}.quantity`] ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors[`line_items.${index}.quantity`]), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Unit Price *"),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => item.unit_price = $event,
                              type: "number",
                              step: "0.01",
                              min: "0",
                              class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors[`line_items.${index}.unit_price`] }],
                              required: ""
                            }, null, 10, ["onUpdate:modelValue"]), [
                              [
                                vModelText,
                                item.unit_price,
                                void 0,
                                { number: true }
                              ]
                            ]),
                            unref(form).errors[`line_items.${index}.unit_price`] ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors[`line_items.${index}.unit_price`]), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "flex items-end" }, [
                            createVNode("div", { class: "w-full" }, [
                              createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Total"),
                              createVNode("div", { class: "w-full rounded border px-3 py-2 bg-gray-50 text-gray-700" }, " R" + toDisplayString(calculateLineTotal(item).toFixed(2)), 1)
                            ]),
                            createVNode("button", {
                              type: "button",
                              onClick: ($event) => removeLineItem(index),
                              class: "ml-2 text-red-600 hover:text-red-800",
                              disabled: unref(form).line_items.length === 1
                            }, " Remove ", 8, ["onClick", "disabled"])
                          ])
                        ]);
                      }), 128))
                    ]),
                    createVNode("br"),
                    createVNode("div", { class: "flex items-center justify-between mb-4" }, [
                      createVNode("button", {
                        type: "button",
                        onClick: addLineItem,
                        class: "rounded bg-blue-600 px-3 py-2 text-white hover:bg-blue-700"
                      }, " + ")
                    ]),
                    createVNode("div", { class: "mt-6 border-t pt-4" }, [
                      createVNode("div", { class: "flex justify-end" }, [
                        createVNode("div", { class: "w-64 space-y-2" }, [
                          createVNode("div", { class: "flex justify-between" }, [
                            createVNode("span", { class: "text-sm text-gray-600" }, "Subtotal:"),
                            createVNode("span", { class: "text-sm font-medium" }, "R" + toDisplayString(subtotal.value.toFixed(2)), 1)
                          ]),
                          createVNode("div", { class: "flex justify-between" }, [
                            createVNode("span", { class: "text-sm text-gray-600" }, "Discount:"),
                            createVNode("span", { class: "text-sm font-medium text-red-600" }, "-R" + toDisplayString(discountAmount.value.toFixed(2)), 1)
                          ]),
                          createVNode("div", { class: "flex justify-between" }, [
                            createVNode("span", { class: "text-sm text-gray-600" }, "Tax (" + toDisplayString(unref(form).tax_rate || 0) + "%):", 1),
                            createVNode("span", { class: "text-sm font-medium" }, "R" + toDisplayString(taxAmount.value.toFixed(2)), 1)
                          ]),
                          createVNode("div", { class: "flex justify-between border-t pt-2" }, [
                            createVNode("span", { class: "text-base font-semibold" }, "Total:"),
                            createVNode("span", { class: "text-base font-semibold" }, "R" + toDisplayString(total.value.toFixed(2)), 1)
                          ])
                        ])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "bg-white rounded-lg border p-6" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900 mb-4" }, "Additional Information"),
                    createVNode("div", { class: "space-y-4" }, [
                      createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Discount Amount (R)"),
                          withDirectives(createVNode("input", {
                            type: "number",
                            step: "0.01",
                            "onUpdate:modelValue": ($event) => unref(form).discount_amount = $event,
                            class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.discount_amount }],
                            placeholder: "0.00"
                          }, null, 10, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).discount_amount]
                          ]),
                          unref(form).errors.discount_amount ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(form).errors.discount_amount), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Discount Percentage (%)"),
                          withDirectives(createVNode("input", {
                            type: "number",
                            step: "0.01",
                            "onUpdate:modelValue": ($event) => unref(form).discount_percentage = $event,
                            class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.discount_percentage }],
                            placeholder: "0.00"
                          }, null, 10, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).discount_percentage]
                          ]),
                          unref(form).errors.discount_percentage ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(form).errors.discount_percentage), 1)) : createCommentVNode("", true)
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Notes"),
                        withDirectives(createVNode("textarea", {
                          "onUpdate:modelValue": ($event) => unref(form).notes = $event,
                          rows: "3",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.notes }]
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).notes]
                        ]),
                        unref(form).errors.notes ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.notes), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Terms & Conditions"),
                        withDirectives(createVNode("textarea", {
                          "onUpdate:modelValue": ($event) => unref(form).terms_conditions = $event,
                          rows: "3",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.terms_conditions }]
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).terms_conditions]
                        ]),
                        unref(form).errors.terms_conditions ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.terms_conditions), 1)) : createCommentVNode("", true)
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "flex items-center justify-end gap-3" }, [
                    createVNode(unref(Link), {
                      href: unref(jobcards).show(props.jobcard.id).url,
                      class: "rounded bg-gray-500 px-4 py-2 text-white hover:bg-gray-600"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Cancel ")
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode("button", {
                      type: "submit",
                      disabled: unref(form).processing,
                      class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
                    }, toDisplayString(unref(form).processing ? "Updating..." : "Update Jobcard"), 9, ["disabled"])
                  ])
                ], 32)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/jobcards/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
