import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
 * @see routes/xero.php:22
 * @route '/xero/sync/customers'
 */
export const customers = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: customers.url(options),
    method: 'post',
})

customers.definition = {
    methods: ["post"],
    url: '/xero/sync/customers',
} satisfies RouteDefinition<["post"]>

/**
 * @see routes/xero.php:22
 * @route '/xero/sync/customers'
 */
customers.url = (options?: RouteQueryOptions) => {
    return customers.definition.url + queryParams(options)
}

/**
 * @see routes/xero.php:22
 * @route '/xero/sync/customers'
 */
customers.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: customers.url(options),
    method: 'post',
})

    /**
 * @see routes/xero.php:22
 * @route '/xero/sync/customers'
 */
    const customersForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: customers.url(options),
        method: 'post',
    })

            /**
 * @see routes/xero.php:22
 * @route '/xero/sync/customers'
 */
        customersForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: customers.url(options),
            method: 'post',
        })
    
    customers.form = customersForm
/**
 * @see routes/xero.php:40
 * @route '/xero/sync/products'
 */
export const products = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: products.url(options),
    method: 'post',
})

products.definition = {
    methods: ["post"],
    url: '/xero/sync/products',
} satisfies RouteDefinition<["post"]>

/**
 * @see routes/xero.php:40
 * @route '/xero/sync/products'
 */
products.url = (options?: RouteQueryOptions) => {
    return products.definition.url + queryParams(options)
}

/**
 * @see routes/xero.php:40
 * @route '/xero/sync/products'
 */
products.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: products.url(options),
    method: 'post',
})

    /**
 * @see routes/xero.php:40
 * @route '/xero/sync/products'
 */
    const productsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: products.url(options),
        method: 'post',
    })

            /**
 * @see routes/xero.php:40
 * @route '/xero/sync/products'
 */
        productsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: products.url(options),
            method: 'post',
        })
    
    products.form = productsForm
const sync = {
    customers: Object.assign(customers, customers),
products: Object.assign(products, products),
}

export default sync