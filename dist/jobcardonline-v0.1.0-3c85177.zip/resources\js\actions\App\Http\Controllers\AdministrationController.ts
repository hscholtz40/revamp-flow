import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/administration',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const AdministrationController = { index }

export default AdministrationController