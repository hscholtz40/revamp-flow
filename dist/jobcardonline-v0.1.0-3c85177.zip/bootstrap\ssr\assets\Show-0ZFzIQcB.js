import { defineComponent, ref, unref, withCtx, createTextVNode, createVNode, createBlock, createCommentVNode, toDisplayString, openBlock, withModifiers, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1, d as contacts } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link } from "@inertiajs/vue3";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    contact: {}
  },
  setup(__props) {
    const props = __props;
    const showSMSModal = ref(false);
    const showSMSResultModal = ref(false);
    const smsResult = ref(null);
    const smsForm = useForm({
      message: ""
    });
    const openSMSModal = () => {
      smsForm.message = "";
      smsForm.clearErrors();
      showSMSModal.value = true;
    };
    const sendSMS = () => {
      smsForm.post(contacts.sms(props.contact.id).url, {
        onSuccess: (page) => {
          showSMSModal.value = false;
          smsResult.value = {
            success: true,
            message: `SMS sent successfully to ${props.contact.name} at ${props.contact.phone}`
          };
          showSMSResultModal.value = true;
        },
        onError: (errors) => {
          if (errors.message) {
            smsResult.value = {
              success: false,
              message: errors.message
            };
            showSMSModal.value = false;
            showSMSResultModal.value = true;
          }
        }
      });
    };
    const closeSMSResultModal = () => {
      showSMSResultModal.value = false;
      smsResult.value = null;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Contact • ${props.contact.name}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Contacts", href: unref(contacts).index().url },
          { title: props.contact.name, href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="space-y-6 p-4"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 p-6 shadow-sm"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>${ssrInterpolate(props.contact.name)}</h1><p class="text-sm text-gray-500 mt-1"${_scopeId}>Contact Details</p></div><div class="flex items-center gap-2"${_scopeId}>`);
            if (props.contact.phone) {
              _push2(`<button class="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"${_scopeId}> Send SMS </button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(contacts).edit(props.contact.id).url,
              class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Edit `);
                } else {
                  return [
                    createTextVNode(" Edit ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(contacts).index().url,
              class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Back `);
                } else {
                  return [
                    createTextVNode(" Back ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Contact Information</h2><p class="text-sm text-gray-600"${_scopeId}>Personal details and contact methods</p></div><div class="p-6"${_scopeId}><div class="grid gap-6 md:grid-cols-2"${_scopeId}><div class="space-y-4"${_scopeId}><div${_scopeId}><h3 class="text-sm font-medium text-gray-900 mb-3 flex items-center"${_scopeId}><svg class="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"${_scopeId}></path></svg> Personal Details </h3><div class="space-y-3"${_scopeId}><div class="flex items-center"${_scopeId}><span class="text-sm font-medium text-gray-500 w-20"${_scopeId}>Name:</span><span class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.contact.name)}</span></div><div class="flex items-center"${_scopeId}><span class="text-sm font-medium text-gray-500 w-20"${_scopeId}>Position:</span><span class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.contact.position || "-")}</span></div><div class="flex items-center"${_scopeId}><span class="text-sm font-medium text-gray-500 w-20"${_scopeId}>Primary:</span>`);
            if (props.contact.is_primary) {
              _push2(`<span class="inline-flex items-center rounded-full bg-green-100 px-2 py-1 text-xs font-medium text-green-800"${_scopeId}> Yes </span>`);
            } else {
              _push2(`<span class="inline-flex items-center rounded-full bg-gray-100 px-2 py-1 text-xs font-medium text-gray-800"${_scopeId}> No </span>`);
            }
            _push2(`</div></div></div></div><div class="space-y-4"${_scopeId}><div${_scopeId}><h3 class="text-sm font-medium text-gray-900 mb-3 flex items-center"${_scopeId}><svg class="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"${_scopeId}></path></svg> Contact Methods </h3><div class="space-y-3"${_scopeId}><div class="flex items-center"${_scopeId}><span class="text-sm font-medium text-gray-500 w-20"${_scopeId}>Email:</span><span class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.contact.email || "-")}</span></div><div class="flex items-center"${_scopeId}><span class="text-sm font-medium text-gray-500 w-20"${_scopeId}>Phone:</span><span class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.contact.phone || "-")}</span></div></div></div></div></div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Customer Information</h2><p class="text-sm text-gray-600"${_scopeId}>Associated customer details</p></div><div class="p-6"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><div class="flex items-center gap-3"${_scopeId}><div class="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100"${_scopeId}><svg class="h-5 w-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"${_scopeId}></path></svg></div><div${_scopeId}><div class="text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(props.contact.customer.name)}</div><div class="text-sm text-gray-500"${_scopeId}>Customer</div></div></div></div>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: `/customers/${props.contact.customer.id}`,
              class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` View Customer `);
                } else {
                  return [
                    createTextVNode(" View Customer ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div>`);
            if (props.contact.notes) {
              _push2(`<div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Notes</h2><p class="text-sm text-gray-600"${_scopeId}>Additional contact information</p></div><div class="p-6"${_scopeId}><p class="text-gray-700 whitespace-pre-wrap bg-gray-50 p-4 rounded-md"${_scopeId}>${ssrInterpolate(props.contact.notes)}</p></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="rounded-lg bg-gray-50 border border-gray-200 p-4"${_scopeId}><div class="flex items-center justify-between text-sm text-gray-500"${_scopeId}><div class="flex items-center gap-4"${_scopeId}><div class="flex items-center gap-2"${_scopeId}><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"${_scopeId}></path></svg><span${_scopeId}>Created: ${ssrInterpolate(new Date(props.contact.created_at).toLocaleDateString())}</span></div><div class="flex items-center gap-2"${_scopeId}><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"${_scopeId}></path></svg><span${_scopeId}>Updated: ${ssrInterpolate(new Date(props.contact.updated_at).toLocaleDateString())}</span></div></div></div></div></div>`);
            if (showSMSModal.value) {
              _push2(`<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"${_scopeId}><div class="bg-white rounded-lg p-6 w-full max-w-md"${_scopeId}><div class="flex items-center justify-between mb-4"${_scopeId}><h3 class="text-lg font-semibold text-gray-900"${_scopeId}>Send SMS</h3><button class="text-gray-400 hover:text-gray-600"${_scopeId}><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"${_scopeId}></path></svg></button></div><form${_scopeId}><div class="mb-4"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-2"${_scopeId}>To:</label><div class="text-sm text-gray-900 bg-gray-50 p-3 rounded-md"${_scopeId}><div class="font-medium"${_scopeId}>${ssrInterpolate(props.contact.name)}</div><div class="text-gray-600"${_scopeId}>${ssrInterpolate(props.contact.phone)}</div><div class="text-gray-500"${_scopeId}>${ssrInterpolate(props.contact.customer?.name)}</div></div></div><div class="mb-4"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-2"${_scopeId}>Message:</label><textarea rows="4" class="w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" placeholder="Type your message here..." maxlength="160"${_scopeId}>${ssrInterpolate(unref(smsForm).message)}</textarea><div class="text-xs text-gray-500 mt-1"${_scopeId}>${ssrInterpolate(unref(smsForm).message.length)}/160 characters</div>`);
              if (unref(smsForm).errors.message) {
                _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(smsForm).errors.message)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="flex items-center justify-end gap-3"${_scopeId}><button type="button" class="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"${_scopeId}> Cancel </button><button type="submit"${ssrIncludeBooleanAttr(unref(smsForm).processing) ? " disabled" : ""} class="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(smsForm).processing ? "Sending..." : "Send SMS")}</button></div></form></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (showSMSResultModal.value) {
              _push2(`<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"${_scopeId}><div class="bg-white rounded-lg p-6 w-full max-w-md"${_scopeId}><div class="flex items-center mb-4"${_scopeId}>`);
              if (smsResult.value?.success) {
                _push2(`<div class="flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-3"${_scopeId}><svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"${_scopeId}></path></svg></div>`);
              } else {
                _push2(`<div class="flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-3"${_scopeId}><svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"${_scopeId}></path></svg></div>`);
              }
              _push2(`<h3 class="${ssrRenderClass([smsResult.value?.success ? "text-green-800" : "text-red-800", "text-lg font-semibold"])}"${_scopeId}>${ssrInterpolate(smsResult.value?.success ? "SMS Sent Successfully!" : "SMS Failed to Send")}</h3></div><div class="mb-6"${_scopeId}><p class="${ssrRenderClass([smsResult.value?.success ? "text-green-700" : "text-red-700", "text-gray-700"])}"${_scopeId}>${ssrInterpolate(smsResult.value?.message)}</p></div><div class="flex justify-end"${_scopeId}><button class="${ssrRenderClass([smsResult.value?.success ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500", "rounded-md px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2"])}"${_scopeId}> OK </button></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              createVNode("div", { class: "space-y-6 p-4" }, [
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 p-6 shadow-sm" }, [
                  createVNode("div", { class: "flex items-center justify-between" }, [
                    createVNode("div", null, [
                      createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, toDisplayString(props.contact.name), 1),
                      createVNode("p", { class: "text-sm text-gray-500 mt-1" }, "Contact Details")
                    ]),
                    createVNode("div", { class: "flex items-center gap-2" }, [
                      props.contact.phone ? (openBlock(), createBlock("button", {
                        key: 0,
                        onClick: openSMSModal,
                        class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
                      }, " Send SMS ")) : createCommentVNode("", true),
                      createVNode(unref(Link), {
                        href: unref(contacts).edit(props.contact.id).url,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Edit ")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createVNode(unref(Link), {
                        href: unref(contacts).index().url,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Back ")
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ])
                  ])
                ]),
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                  createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Contact Information"),
                    createVNode("p", { class: "text-sm text-gray-600" }, "Personal details and contact methods")
                  ]),
                  createVNode("div", { class: "p-6" }, [
                    createVNode("div", { class: "grid gap-6 md:grid-cols-2" }, [
                      createVNode("div", { class: "space-y-4" }, [
                        createVNode("div", null, [
                          createVNode("h3", { class: "text-sm font-medium text-gray-900 mb-3 flex items-center" }, [
                            (openBlock(), createBlock("svg", {
                              class: "w-4 h-4 mr-2 text-gray-400",
                              fill: "none",
                              stroke: "currentColor",
                              viewBox: "0 0 24 24"
                            }, [
                              createVNode("path", {
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round",
                                "stroke-width": "2",
                                d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                              })
                            ])),
                            createTextVNode(" Personal Details ")
                          ]),
                          createVNode("div", { class: "space-y-3" }, [
                            createVNode("div", { class: "flex items-center" }, [
                              createVNode("span", { class: "text-sm font-medium text-gray-500 w-20" }, "Name:"),
                              createVNode("span", { class: "text-sm text-gray-900" }, toDisplayString(props.contact.name), 1)
                            ]),
                            createVNode("div", { class: "flex items-center" }, [
                              createVNode("span", { class: "text-sm font-medium text-gray-500 w-20" }, "Position:"),
                              createVNode("span", { class: "text-sm text-gray-900" }, toDisplayString(props.contact.position || "-"), 1)
                            ]),
                            createVNode("div", { class: "flex items-center" }, [
                              createVNode("span", { class: "text-sm font-medium text-gray-500 w-20" }, "Primary:"),
                              props.contact.is_primary ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "inline-flex items-center rounded-full bg-green-100 px-2 py-1 text-xs font-medium text-green-800"
                              }, " Yes ")) : (openBlock(), createBlock("span", {
                                key: 1,
                                class: "inline-flex items-center rounded-full bg-gray-100 px-2 py-1 text-xs font-medium text-gray-800"
                              }, " No "))
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "space-y-4" }, [
                        createVNode("div", null, [
                          createVNode("h3", { class: "text-sm font-medium text-gray-900 mb-3 flex items-center" }, [
                            (openBlock(), createBlock("svg", {
                              class: "w-4 h-4 mr-2 text-gray-400",
                              fill: "none",
                              stroke: "currentColor",
                              viewBox: "0 0 24 24"
                            }, [
                              createVNode("path", {
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round",
                                "stroke-width": "2",
                                d: "M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                              })
                            ])),
                            createTextVNode(" Contact Methods ")
                          ]),
                          createVNode("div", { class: "space-y-3" }, [
                            createVNode("div", { class: "flex items-center" }, [
                              createVNode("span", { class: "text-sm font-medium text-gray-500 w-20" }, "Email:"),
                              createVNode("span", { class: "text-sm text-gray-900" }, toDisplayString(props.contact.email || "-"), 1)
                            ]),
                            createVNode("div", { class: "flex items-center" }, [
                              createVNode("span", { class: "text-sm font-medium text-gray-500 w-20" }, "Phone:"),
                              createVNode("span", { class: "text-sm text-gray-900" }, toDisplayString(props.contact.phone || "-"), 1)
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ]),
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                  createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Customer Information"),
                    createVNode("p", { class: "text-sm text-gray-600" }, "Associated customer details")
                  ]),
                  createVNode("div", { class: "p-6" }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", null, [
                        createVNode("div", { class: "flex items-center gap-3" }, [
                          createVNode("div", { class: "flex h-10 w-10 items-center justify-center rounded-full bg-blue-100" }, [
                            (openBlock(), createBlock("svg", {
                              class: "h-5 w-5 text-blue-600",
                              fill: "none",
                              stroke: "currentColor",
                              viewBox: "0 0 24 24"
                            }, [
                              createVNode("path", {
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round",
                                "stroke-width": "2",
                                d: "M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                              })
                            ]))
                          ]),
                          createVNode("div", null, [
                            createVNode("div", { class: "text-sm font-medium text-gray-900" }, toDisplayString(props.contact.customer.name), 1),
                            createVNode("div", { class: "text-sm text-gray-500" }, "Customer")
                          ])
                        ])
                      ]),
                      createVNode(unref(Link), {
                        href: `/customers/${props.contact.customer.id}`,
                        class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" View Customer ")
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ])
                  ])
                ]),
                props.contact.notes ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "rounded-lg bg-white border border-gray-200 shadow-sm"
                }, [
                  createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Notes"),
                    createVNode("p", { class: "text-sm text-gray-600" }, "Additional contact information")
                  ]),
                  createVNode("div", { class: "p-6" }, [
                    createVNode("p", { class: "text-gray-700 whitespace-pre-wrap bg-gray-50 p-4 rounded-md" }, toDisplayString(props.contact.notes), 1)
                  ])
                ])) : createCommentVNode("", true),
                createVNode("div", { class: "rounded-lg bg-gray-50 border border-gray-200 p-4" }, [
                  createVNode("div", { class: "flex items-center justify-between text-sm text-gray-500" }, [
                    createVNode("div", { class: "flex items-center gap-4" }, [
                      createVNode("div", { class: "flex items-center gap-2" }, [
                        (openBlock(), createBlock("svg", {
                          class: "w-4 h-4",
                          fill: "none",
                          stroke: "currentColor",
                          viewBox: "0 0 24 24"
                        }, [
                          createVNode("path", {
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round",
                            "stroke-width": "2",
                            d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                          })
                        ])),
                        createVNode("span", null, "Created: " + toDisplayString(new Date(props.contact.created_at).toLocaleDateString()), 1)
                      ]),
                      createVNode("div", { class: "flex items-center gap-2" }, [
                        (openBlock(), createBlock("svg", {
                          class: "w-4 h-4",
                          fill: "none",
                          stroke: "currentColor",
                          viewBox: "0 0 24 24"
                        }, [
                          createVNode("path", {
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round",
                            "stroke-width": "2",
                            d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                          })
                        ])),
                        createVNode("span", null, "Updated: " + toDisplayString(new Date(props.contact.updated_at).toLocaleDateString()), 1)
                      ])
                    ])
                  ])
                ])
              ]),
              showSMSModal.value ? (openBlock(), createBlock("div", {
                key: 0,
                class: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
              }, [
                createVNode("div", { class: "bg-white rounded-lg p-6 w-full max-w-md" }, [
                  createVNode("div", { class: "flex items-center justify-between mb-4" }, [
                    createVNode("h3", { class: "text-lg font-semibold text-gray-900" }, "Send SMS"),
                    createVNode("button", {
                      onClick: ($event) => showSMSModal.value = false,
                      class: "text-gray-400 hover:text-gray-600"
                    }, [
                      (openBlock(), createBlock("svg", {
                        class: "w-6 h-6",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        createVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M6 18L18 6M6 6l12 12"
                        })
                      ]))
                    ], 8, ["onClick"])
                  ]),
                  createVNode("form", {
                    onSubmit: withModifiers(sendSMS, ["prevent"])
                  }, [
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-2" }, "To:"),
                      createVNode("div", { class: "text-sm text-gray-900 bg-gray-50 p-3 rounded-md" }, [
                        createVNode("div", { class: "font-medium" }, toDisplayString(props.contact.name), 1),
                        createVNode("div", { class: "text-gray-600" }, toDisplayString(props.contact.phone), 1),
                        createVNode("div", { class: "text-gray-500" }, toDisplayString(props.contact.customer?.name), 1)
                      ])
                    ]),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-2" }, "Message:"),
                      withDirectives(createVNode("textarea", {
                        "onUpdate:modelValue": ($event) => unref(smsForm).message = $event,
                        rows: "4",
                        class: "w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500",
                        placeholder: "Type your message here...",
                        maxlength: "160"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(smsForm).message]
                      ]),
                      createVNode("div", { class: "text-xs text-gray-500 mt-1" }, toDisplayString(unref(smsForm).message.length) + "/160 characters", 1),
                      unref(smsForm).errors.message ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-red-600"
                      }, toDisplayString(unref(smsForm).errors.message), 1)) : createCommentVNode("", true)
                    ]),
                    createVNode("div", { class: "flex items-center justify-end gap-3" }, [
                      createVNode("button", {
                        type: "button",
                        onClick: ($event) => showSMSModal.value = false,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, " Cancel ", 8, ["onClick"]),
                      createVNode("button", {
                        type: "submit",
                        disabled: unref(smsForm).processing,
                        class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50"
                      }, toDisplayString(unref(smsForm).processing ? "Sending..." : "Send SMS"), 9, ["disabled"])
                    ])
                  ], 32)
                ])
              ])) : createCommentVNode("", true),
              showSMSResultModal.value ? (openBlock(), createBlock("div", {
                key: 1,
                class: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
              }, [
                createVNode("div", { class: "bg-white rounded-lg p-6 w-full max-w-md" }, [
                  createVNode("div", { class: "flex items-center mb-4" }, [
                    smsResult.value?.success ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-3"
                    }, [
                      (openBlock(), createBlock("svg", {
                        class: "w-6 h-6 text-green-600",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        createVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M5 13l4 4L19 7"
                        })
                      ]))
                    ])) : (openBlock(), createBlock("div", {
                      key: 1,
                      class: "flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-3"
                    }, [
                      (openBlock(), createBlock("svg", {
                        class: "w-6 h-6 text-red-600",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        createVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M6 18L18 6M6 6l12 12"
                        })
                      ]))
                    ])),
                    createVNode("h3", {
                      class: ["text-lg font-semibold", smsResult.value?.success ? "text-green-800" : "text-red-800"]
                    }, toDisplayString(smsResult.value?.success ? "SMS Sent Successfully!" : "SMS Failed to Send"), 3)
                  ]),
                  createVNode("div", { class: "mb-6" }, [
                    createVNode("p", {
                      class: ["text-gray-700", smsResult.value?.success ? "text-green-700" : "text-red-700"]
                    }, toDisplayString(smsResult.value?.message), 3)
                  ]),
                  createVNode("div", { class: "flex justify-end" }, [
                    createVNode("button", {
                      onClick: closeSMSResultModal,
                      class: ["rounded-md px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2", smsResult.value?.success ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500"]
                    }, " OK ", 2)
                  ])
                ])
              ])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/contacts/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
