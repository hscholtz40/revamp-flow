import { defineComponent, ref, computed, unref, withCtx, createVNode, createTextVNode, resolveDynamicComponent, toDisplayString, createBlock, createCommentVNode, openBlock, withDirectives, withKeys, vModelText, vModelSelect, Fragment, renderList, vModelCheckbox, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderVNode, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1, p as products } from "./AppLayout-CmGu2Oww.js";
import { Head, Link, router } from "@inertiajs/vue3";
import { Plus, Filter, Search, Package, Eye, Edit, Trash2, Wrench } from "lucide-vue-next";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    products: {},
    filters: {},
    categories: {},
    currentCompany: {}
  },
  setup(__props) {
    const props = __props;
    const search = ref(props.filters.search || "");
    const typeFilter = ref(props.filters.type || "");
    const categoryFilter = ref(props.filters.category || "");
    const activeOnly = ref(props.filters.active_only || false);
    const filteredProducts = computed(() => props.products.data);
    function applyFilters() {
      const params = {};
      if (search.value && search.value.trim()) params.search = search.value.trim();
      if (typeFilter.value && typeFilter.value.trim()) params.type = typeFilter.value.trim();
      if (categoryFilter.value && categoryFilter.value.trim()) params.category = categoryFilter.value.trim();
      if (activeOnly.value) params.active_only = activeOnly.value;
      router.get(products.index().url, params, {
        preserveState: true,
        replace: true
      });
    }
    function clearFilters() {
      search.value = "";
      typeFilter.value = "";
      categoryFilter.value = "";
      activeOnly.value = false;
      applyFilters();
    }
    function deleteProduct(product) {
      if (confirm(`Are you sure you want to delete "${product.name}"?`)) {
        router.delete(products.destroy(product.id).url);
      }
    }
    function getTypeIcon(type) {
      return type === "product" ? Package : Wrench;
    }
    function getTypeColor(type) {
      return type === "product" ? "text-blue-600" : "text-green-600";
    }
    function getStockStatus(product) {
      if (!product.track_stock) return { text: "N/A", color: "text-gray-500" };
      if (product.stock_quantity <= product.min_stock_level) {
        return { text: "Low Stock", color: "text-red-600" };
      }
      return { text: "In Stock", color: "text-green-600" };
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Products & Services" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, { breadcrumbs: [
        { title: "Products & Services", href: "#" }
      ] }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-blue-50 border-b border-blue-200 px-4 py-3"${_scopeId}><div class="flex items-center gap-2 text-sm text-blue-700"${_scopeId}><span class="font-medium"${_scopeId}>Viewing products for:</span><span class="font-semibold"${_scopeId}>${ssrInterpolate(props.currentCompany.name)}</span></div></div><div class="p-4"${_scopeId}><div class="mb-6 flex items-center justify-between"${_scopeId}><div${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>Products &amp; Services</h1><p class="text-gray-600"${_scopeId}>Manage your product catalog and service offerings</p></div>`);
            if (_ctx.$page.props.auth?.abilities?.products?.create) {
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(products).create().url,
                class: "flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(unref(Plus), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                    _push3(` Add Product/Service `);
                  } else {
                    return [
                      createVNode(unref(Plus), { class: "h-4 w-4" }),
                      createTextVNode(" Add Product/Service ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="mb-6 rounded-lg border bg-white p-4"${_scopeId}><div class="mb-4 flex items-center gap-2"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Filter), { class: "h-4 w-4 text-gray-500" }, null, _parent2, _scopeId));
            _push2(`<span class="font-medium text-gray-700"${_scopeId}>Filters</span></div><div class="grid gap-4 md:grid-cols-2 lg:grid-cols-5"${_scopeId}><div class="relative"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Search), { class: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" }, null, _parent2, _scopeId));
            _push2(`<input${ssrRenderAttr("value", search.value)} type="text" placeholder="Search products..." class="w-full rounded-md border border-gray-300 pl-10 pr-4 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}></div><select class="rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(typeFilter.value) ? ssrLooseContain(typeFilter.value, "") : ssrLooseEqual(typeFilter.value, "")) ? " selected" : ""}${_scopeId}>All Types</option><option value="product"${ssrIncludeBooleanAttr(Array.isArray(typeFilter.value) ? ssrLooseContain(typeFilter.value, "product") : ssrLooseEqual(typeFilter.value, "product")) ? " selected" : ""}${_scopeId}>Products</option><option value="service"${ssrIncludeBooleanAttr(Array.isArray(typeFilter.value) ? ssrLooseContain(typeFilter.value, "service") : ssrLooseEqual(typeFilter.value, "service")) ? " selected" : ""}${_scopeId}>Services</option></select><select class="rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(categoryFilter.value) ? ssrLooseContain(categoryFilter.value, "") : ssrLooseEqual(categoryFilter.value, "")) ? " selected" : ""}${_scopeId}>All Categories</option><!--[-->`);
            ssrRenderList(_ctx.categories, (category) => {
              _push2(`<option${ssrRenderAttr("value", category)}${ssrIncludeBooleanAttr(Array.isArray(categoryFilter.value) ? ssrLooseContain(categoryFilter.value, category) : ssrLooseEqual(categoryFilter.value, category)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(category)}</option>`);
            });
            _push2(`<!--]--></select><label class="flex items-center gap-2"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(activeOnly.value) ? ssrLooseContain(activeOnly.value, null) : activeOnly.value) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"${_scopeId}><span class="text-sm text-gray-700"${_scopeId}>Active Only</span></label><button class="rounded-md border border-gray-300 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"${_scopeId}> Clear Filters </button></div></div>`);
            if (filteredProducts.value.length === 0) {
              _push2(`<div class="rounded-lg border bg-white p-8 text-center"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Package), { class: "mx-auto h-12 w-12 text-gray-400" }, null, _parent2, _scopeId));
              _push2(`<h3 class="mt-2 text-lg font-medium text-gray-900"${_scopeId}>No products found</h3><p class="mt-1 text-gray-500"${_scopeId}>Get started by creating your first product or service.</p><div class="mt-6"${_scopeId}>`);
              if (_ctx.$page.props.auth?.abilities?.products?.create) {
                _push2(ssrRenderComponent(unref(Link), {
                  href: unref(products).create().url,
                  class: "inline-flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(Plus), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                      _push3(` Add Product/Service `);
                    } else {
                      return [
                        createVNode(unref(Plus), { class: "h-4 w-4" }),
                        createTextVNode(" Add Product/Service ")
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            } else {
              _push2(`<div class="grid gap-6 md:grid-cols-2 lg:grid-cols-3"${_scopeId}><!--[-->`);
              ssrRenderList(filteredProducts.value, (product) => {
                _push2(`<div class="rounded-lg border bg-white p-6 shadow-sm hover:shadow-md transition-shadow"${_scopeId}><div class="mb-4 flex items-start justify-between"${_scopeId}><div class="flex items-center gap-3"${_scopeId}>`);
                ssrRenderVNode(_push2, createVNode(resolveDynamicComponent(getTypeIcon(product.type)), {
                  class: ["h-6 w-6", getTypeColor(product.type)]
                }, null), _parent2, _scopeId);
                _push2(`<div${_scopeId}><h3 class="font-semibold text-gray-900"${_scopeId}>${ssrInterpolate(product.name)}</h3><p class="text-sm text-gray-500"${_scopeId}>${ssrInterpolate(product.type.charAt(0).toUpperCase() + product.type.slice(1))}</p></div></div><span class="${ssrRenderClass([
                  "rounded-full px-2 py-1 text-xs font-medium",
                  product.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                ])}"${_scopeId}>${ssrInterpolate(product.is_active ? "Active" : "Inactive")}</span></div><div class="mb-4 space-y-2"${_scopeId}>`);
                if (product.sku) {
                  _push2(`<div class="text-sm text-gray-600"${_scopeId}><span class="font-medium"${_scopeId}>SKU:</span> ${ssrInterpolate(product.sku)}</div>`);
                } else {
                  _push2(`<!---->`);
                }
                if (product.category) {
                  _push2(`<div class="text-sm text-gray-600"${_scopeId}><span class="font-medium"${_scopeId}>Category:</span> ${ssrInterpolate(product.category)}</div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`<div class="text-sm text-gray-600"${_scopeId}><span class="font-medium"${_scopeId}>Price:</span> R${ssrInterpolate(Number(product.price).toFixed(2))} / ${ssrInterpolate(product.unit)}</div>`);
                if (product.track_stock) {
                  _push2(`<div class="text-sm text-gray-600"${_scopeId}><span class="font-medium"${_scopeId}>Stock:</span><span class="${ssrRenderClass(getStockStatus(product).color)}"${_scopeId}>${ssrInterpolate(product.stock_quantity)} (${ssrInterpolate(getStockStatus(product).text)}) </span></div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div>`);
                if (product.description) {
                  _push2(`<p class="mb-4 text-sm text-gray-600 line-clamp-2"${_scopeId}>${ssrInterpolate(product.description)}</p>`);
                } else {
                  _push2(`<!---->`);
                }
                if (product.tags && product.tags.length > 0) {
                  _push2(`<div class="mb-4"${_scopeId}><div class="flex flex-wrap gap-1"${_scopeId}><!--[-->`);
                  ssrRenderList(product.tags.slice(0, 3), (tag) => {
                    _push2(`<span class="rounded-full bg-gray-100 px-2 py-1 text-xs text-gray-600"${_scopeId}>${ssrInterpolate(tag)}</span>`);
                  });
                  _push2(`<!--]-->`);
                  if (product.tags.length > 3) {
                    _push2(`<span class="rounded-full bg-gray-100 px-2 py-1 text-xs text-gray-600"${_scopeId}> +${ssrInterpolate(product.tags.length - 3)} more </span>`);
                  } else {
                    _push2(`<!---->`);
                  }
                  _push2(`</div></div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`<div class="flex items-center gap-2"${_scopeId}>`);
                if (_ctx.$page.props.auth?.abilities?.products?.view) {
                  _push2(ssrRenderComponent(unref(Link), {
                    href: unref(products).show(product.id).url,
                    class: "flex items-center gap-1 rounded border px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                  }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(ssrRenderComponent(unref(Eye), { class: "h-3 w-3" }, null, _parent3, _scopeId2));
                        _push3(` View `);
                      } else {
                        return [
                          createVNode(unref(Eye), { class: "h-3 w-3" }),
                          createTextVNode(" View ")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                } else {
                  _push2(`<!---->`);
                }
                if (_ctx.$page.props.auth?.abilities?.products?.edit) {
                  _push2(ssrRenderComponent(unref(Link), {
                    href: unref(products).edit(product.id).url,
                    class: "flex items-center gap-1 rounded border px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                  }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(ssrRenderComponent(unref(Edit), { class: "h-3 w-3" }, null, _parent3, _scopeId2));
                        _push3(` Edit `);
                      } else {
                        return [
                          createVNode(unref(Edit), { class: "h-3 w-3" }),
                          createTextVNode(" Edit ")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                } else {
                  _push2(`<!---->`);
                }
                if (_ctx.$page.props.auth?.abilities?.products?.delete) {
                  _push2(`<button class="flex items-center gap-1 rounded border border-red-300 px-3 py-1 text-sm text-red-700 hover:bg-red-50"${_scopeId}>`);
                  _push2(ssrRenderComponent(unref(Trash2), { class: "h-3 w-3" }, null, _parent2, _scopeId));
                  _push2(` Delete </button>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div></div>`);
              });
              _push2(`<!--]--></div>`);
            }
            if (unref(products).links && unref(products).links.length > 3) {
              _push2(`<div class="mt-6"${_scopeId}><nav class="flex items-center justify-between"${_scopeId}><div class="text-sm text-gray-700"${_scopeId}> Showing ${ssrInterpolate(unref(products).meta.from)} to ${ssrInterpolate(unref(products).meta.to)} of ${ssrInterpolate(unref(products).meta.total)} results </div><div class="flex gap-1"${_scopeId}><!--[-->`);
              ssrRenderList(unref(products).links, (link) => {
                _push2(ssrRenderComponent(unref(Link), {
                  key: link.label,
                  href: link.url || "#",
                  class: [
                    "px-3 py-2 text-sm rounded-md",
                    link.active ? "bg-blue-600 text-white" : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50",
                    !link.url ? "opacity-50 cursor-not-allowed" : ""
                  ]
                }, null, _parent2, _scopeId));
              });
              _push2(`<!--]--></div></nav></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "bg-blue-50 border-b border-blue-200 px-4 py-3" }, [
                createVNode("div", { class: "flex items-center gap-2 text-sm text-blue-700" }, [
                  createVNode("span", { class: "font-medium" }, "Viewing products for:"),
                  createVNode("span", { class: "font-semibold" }, toDisplayString(props.currentCompany.name), 1)
                ])
              ]),
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "mb-6 flex items-center justify-between" }, [
                  createVNode("div", null, [
                    createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "Products & Services"),
                    createVNode("p", { class: "text-gray-600" }, "Manage your product catalog and service offerings")
                  ]),
                  _ctx.$page.props.auth?.abilities?.products?.create ? (openBlock(), createBlock(unref(Link), {
                    key: 0,
                    href: unref(products).create().url,
                    class: "flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(Plus), { class: "h-4 w-4" }),
                      createTextVNode(" Add Product/Service ")
                    ]),
                    _: 1
                  }, 8, ["href"])) : createCommentVNode("", true)
                ]),
                createVNode("div", { class: "mb-6 rounded-lg border bg-white p-4" }, [
                  createVNode("div", { class: "mb-4 flex items-center gap-2" }, [
                    createVNode(unref(Filter), { class: "h-4 w-4 text-gray-500" }),
                    createVNode("span", { class: "font-medium text-gray-700" }, "Filters")
                  ]),
                  createVNode("div", { class: "grid gap-4 md:grid-cols-2 lg:grid-cols-5" }, [
                    createVNode("div", { class: "relative" }, [
                      createVNode(unref(Search), { class: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" }),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => search.value = $event,
                        type: "text",
                        placeholder: "Search products...",
                        class: "w-full rounded-md border border-gray-300 pl-10 pr-4 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500",
                        onKeyup: withKeys(applyFilters, ["enter"])
                      }, null, 40, ["onUpdate:modelValue"]), [
                        [vModelText, search.value]
                      ])
                    ]),
                    withDirectives(createVNode("select", {
                      "onUpdate:modelValue": ($event) => typeFilter.value = $event,
                      class: "rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500",
                      onChange: applyFilters
                    }, [
                      createVNode("option", { value: "" }, "All Types"),
                      createVNode("option", { value: "product" }, "Products"),
                      createVNode("option", { value: "service" }, "Services")
                    ], 40, ["onUpdate:modelValue"]), [
                      [vModelSelect, typeFilter.value]
                    ]),
                    withDirectives(createVNode("select", {
                      "onUpdate:modelValue": ($event) => categoryFilter.value = $event,
                      class: "rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500",
                      onChange: applyFilters
                    }, [
                      createVNode("option", { value: "" }, "All Categories"),
                      (openBlock(true), createBlock(Fragment, null, renderList(_ctx.categories, (category) => {
                        return openBlock(), createBlock("option", {
                          key: category,
                          value: category
                        }, toDisplayString(category), 9, ["value"]);
                      }), 128))
                    ], 40, ["onUpdate:modelValue"]), [
                      [vModelSelect, categoryFilter.value]
                    ]),
                    createVNode("label", { class: "flex items-center gap-2" }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => activeOnly.value = $event,
                        type: "checkbox",
                        class: "rounded border-gray-300 text-blue-600 focus:ring-blue-500",
                        onChange: applyFilters
                      }, null, 40, ["onUpdate:modelValue"]), [
                        [vModelCheckbox, activeOnly.value]
                      ]),
                      createVNode("span", { class: "text-sm text-gray-700" }, "Active Only")
                    ]),
                    createVNode("button", {
                      onClick: clearFilters,
                      class: "rounded-md border border-gray-300 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
                    }, " Clear Filters ")
                  ])
                ]),
                filteredProducts.value.length === 0 ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "rounded-lg border bg-white p-8 text-center"
                }, [
                  createVNode(unref(Package), { class: "mx-auto h-12 w-12 text-gray-400" }),
                  createVNode("h3", { class: "mt-2 text-lg font-medium text-gray-900" }, "No products found"),
                  createVNode("p", { class: "mt-1 text-gray-500" }, "Get started by creating your first product or service."),
                  createVNode("div", { class: "mt-6" }, [
                    _ctx.$page.props.auth?.abilities?.products?.create ? (openBlock(), createBlock(unref(Link), {
                      key: 0,
                      href: unref(products).create().url,
                      class: "inline-flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(Plus), { class: "h-4 w-4" }),
                        createTextVNode(" Add Product/Service ")
                      ]),
                      _: 1
                    }, 8, ["href"])) : createCommentVNode("", true)
                  ])
                ])) : (openBlock(), createBlock("div", {
                  key: 1,
                  class: "grid gap-6 md:grid-cols-2 lg:grid-cols-3"
                }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(filteredProducts.value, (product) => {
                    return openBlock(), createBlock("div", {
                      key: product.id,
                      class: "rounded-lg border bg-white p-6 shadow-sm hover:shadow-md transition-shadow"
                    }, [
                      createVNode("div", { class: "mb-4 flex items-start justify-between" }, [
                        createVNode("div", { class: "flex items-center gap-3" }, [
                          (openBlock(), createBlock(resolveDynamicComponent(getTypeIcon(product.type)), {
                            class: ["h-6 w-6", getTypeColor(product.type)]
                          }, null, 8, ["class"])),
                          createVNode("div", null, [
                            createVNode("h3", { class: "font-semibold text-gray-900" }, toDisplayString(product.name), 1),
                            createVNode("p", { class: "text-sm text-gray-500" }, toDisplayString(product.type.charAt(0).toUpperCase() + product.type.slice(1)), 1)
                          ])
                        ]),
                        createVNode("span", {
                          class: [
                            "rounded-full px-2 py-1 text-xs font-medium",
                            product.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                          ]
                        }, toDisplayString(product.is_active ? "Active" : "Inactive"), 3)
                      ]),
                      createVNode("div", { class: "mb-4 space-y-2" }, [
                        product.sku ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-sm text-gray-600"
                        }, [
                          createVNode("span", { class: "font-medium" }, "SKU:"),
                          createTextVNode(" " + toDisplayString(product.sku), 1)
                        ])) : createCommentVNode("", true),
                        product.category ? (openBlock(), createBlock("div", {
                          key: 1,
                          class: "text-sm text-gray-600"
                        }, [
                          createVNode("span", { class: "font-medium" }, "Category:"),
                          createTextVNode(" " + toDisplayString(product.category), 1)
                        ])) : createCommentVNode("", true),
                        createVNode("div", { class: "text-sm text-gray-600" }, [
                          createVNode("span", { class: "font-medium" }, "Price:"),
                          createTextVNode(" R" + toDisplayString(Number(product.price).toFixed(2)) + " / " + toDisplayString(product.unit), 1)
                        ]),
                        product.track_stock ? (openBlock(), createBlock("div", {
                          key: 2,
                          class: "text-sm text-gray-600"
                        }, [
                          createVNode("span", { class: "font-medium" }, "Stock:"),
                          createVNode("span", {
                            class: getStockStatus(product).color
                          }, toDisplayString(product.stock_quantity) + " (" + toDisplayString(getStockStatus(product).text) + ") ", 3)
                        ])) : createCommentVNode("", true)
                      ]),
                      product.description ? (openBlock(), createBlock("p", {
                        key: 0,
                        class: "mb-4 text-sm text-gray-600 line-clamp-2"
                      }, toDisplayString(product.description), 1)) : createCommentVNode("", true),
                      product.tags && product.tags.length > 0 ? (openBlock(), createBlock("div", {
                        key: 1,
                        class: "mb-4"
                      }, [
                        createVNode("div", { class: "flex flex-wrap gap-1" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(product.tags.slice(0, 3), (tag) => {
                            return openBlock(), createBlock("span", {
                              key: tag,
                              class: "rounded-full bg-gray-100 px-2 py-1 text-xs text-gray-600"
                            }, toDisplayString(tag), 1);
                          }), 128)),
                          product.tags.length > 3 ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "rounded-full bg-gray-100 px-2 py-1 text-xs text-gray-600"
                          }, " +" + toDisplayString(product.tags.length - 3) + " more ", 1)) : createCommentVNode("", true)
                        ])
                      ])) : createCommentVNode("", true),
                      createVNode("div", { class: "flex items-center gap-2" }, [
                        _ctx.$page.props.auth?.abilities?.products?.view ? (openBlock(), createBlock(unref(Link), {
                          key: 0,
                          href: unref(products).show(product.id).url,
                          class: "flex items-center gap-1 rounded border px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(Eye), { class: "h-3 w-3" }),
                            createTextVNode(" View ")
                          ]),
                          _: 1
                        }, 8, ["href"])) : createCommentVNode("", true),
                        _ctx.$page.props.auth?.abilities?.products?.edit ? (openBlock(), createBlock(unref(Link), {
                          key: 1,
                          href: unref(products).edit(product.id).url,
                          class: "flex items-center gap-1 rounded border px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(Edit), { class: "h-3 w-3" }),
                            createTextVNode(" Edit ")
                          ]),
                          _: 1
                        }, 8, ["href"])) : createCommentVNode("", true),
                        _ctx.$page.props.auth?.abilities?.products?.delete ? (openBlock(), createBlock("button", {
                          key: 2,
                          onClick: ($event) => deleteProduct(product),
                          class: "flex items-center gap-1 rounded border border-red-300 px-3 py-1 text-sm text-red-700 hover:bg-red-50"
                        }, [
                          createVNode(unref(Trash2), { class: "h-3 w-3" }),
                          createTextVNode(" Delete ")
                        ], 8, ["onClick"])) : createCommentVNode("", true)
                      ])
                    ]);
                  }), 128))
                ])),
                unref(products).links && unref(products).links.length > 3 ? (openBlock(), createBlock("div", {
                  key: 2,
                  class: "mt-6"
                }, [
                  createVNode("nav", { class: "flex items-center justify-between" }, [
                    createVNode("div", { class: "text-sm text-gray-700" }, " Showing " + toDisplayString(unref(products).meta.from) + " to " + toDisplayString(unref(products).meta.to) + " of " + toDisplayString(unref(products).meta.total) + " results ", 1),
                    createVNode("div", { class: "flex gap-1" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(products).links, (link) => {
                        return openBlock(), createBlock(unref(Link), {
                          key: link.label,
                          href: link.url || "#",
                          class: [
                            "px-3 py-2 text-sm rounded-md",
                            link.active ? "bg-blue-600 text-white" : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50",
                            !link.url ? "opacity-50 cursor-not-allowed" : ""
                          ],
                          innerHTML: link.label
                        }, null, 8, ["href", "class", "innerHTML"]);
                      }), 128))
                    ])
                  ])
                ])) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/products/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
