import { defineComponent, unref, withCtx, createTextVNode, createVNode, withModifiers, withDirectives, createBlock, createCommentVNode, openBlock, Fragment, renderList, toDisplayString, vModelSelect, vModelText, vModelCheckbox, useSSRContext } from "vue";
import { ssrRenderComponent, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1, d as contacts } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link } from "@inertiajs/vue3";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    contact: {},
    customers: {}
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      customer_id: props.contact.customer.id,
      name: props.contact.name,
      email: props.contact.email || "",
      phone: props.contact.phone || "",
      position: props.contact.position || "",
      notes: props.contact.notes || "",
      is_primary: props.contact.is_primary
    });
    function submit() {
      form.put(contacts.update(props.contact.id).url);
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Edit Contact" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Contacts", href: unref(contacts).index().url },
          { title: "Edit", href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="space-y-4 p-4"${_scopeId}><div class="grid gap-4 md:grid-cols-2"${_scopeId}><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Customer *</span><select class="w-full rounded border px-3 py-2" required${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(unref(form).customer_id) ? ssrLooseContain(unref(form).customer_id, "") : ssrLooseEqual(unref(form).customer_id, "")) ? " selected" : ""}${_scopeId}>Select a customer</option><!--[-->`);
            ssrRenderList(props.customers, (customer) => {
              _push2(`<option${ssrRenderAttr("value", customer.id)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).customer_id) ? ssrLooseContain(unref(form).customer_id, customer.id) : ssrLooseEqual(unref(form).customer_id, customer.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(customer.name)}</option>`);
            });
            _push2(`<!--]--></select>`);
            if (unref(form).errors.customer_id) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.customer_id)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Name *</span><input${ssrRenderAttr("value", unref(form).name)} class="w-full rounded border px-3 py-2" required${_scopeId}>`);
            if (unref(form).errors.name) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.name)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Email</span><input${ssrRenderAttr("value", unref(form).email)} type="email" class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.email) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.email)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Phone</span><input${ssrRenderAttr("value", unref(form).phone)} class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.phone) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.phone)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Position</span><input${ssrRenderAttr("value", unref(form).position)} class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.position) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.position)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Primary Contact</span><label class="flex items-center"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_primary) ? ssrLooseContain(unref(form).is_primary, null) : unref(form).is_primary) ? " checked" : ""} type="checkbox" class="mr-2"${_scopeId}><span class="text-sm"${_scopeId}>Mark as primary contact for this customer</span></label></label></div><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Notes</span><textarea rows="3" class="w-full rounded border px-3 py-2"${_scopeId}>${ssrInterpolate(unref(form).notes)}</textarea>`);
            if (unref(form).errors.notes) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.notes)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><div class="flex items-center gap-2"${_scopeId}><button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="rounded bg-blue-600 px-4 py-2 text-white disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(form).processing ? "Updating..." : "Update Contact")}</button>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(contacts).show(props.contact.id).url,
              class: "rounded border px-4 py-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Cancel`);
                } else {
                  return [
                    createTextVNode("Cancel")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                onSubmit: withModifiers(submit, ["prevent"]),
                class: "space-y-4 p-4"
              }, [
                createVNode("div", { class: "grid gap-4 md:grid-cols-2" }, [
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Customer *"),
                    withDirectives(createVNode("select", {
                      "onUpdate:modelValue": ($event) => unref(form).customer_id = $event,
                      class: "w-full rounded border px-3 py-2",
                      required: ""
                    }, [
                      createVNode("option", { value: "" }, "Select a customer"),
                      (openBlock(true), createBlock(Fragment, null, renderList(props.customers, (customer) => {
                        return openBlock(), createBlock("option", {
                          key: customer.id,
                          value: customer.id
                        }, toDisplayString(customer.name), 9, ["value"]);
                      }), 128))
                    ], 8, ["onUpdate:modelValue"]), [
                      [vModelSelect, unref(form).customer_id]
                    ]),
                    unref(form).errors.customer_id ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "text-sm text-red-600"
                    }, toDisplayString(unref(form).errors.customer_id), 1)) : createCommentVNode("", true)
                  ]),
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Name *"),
                    withDirectives(createVNode("input", {
                      "onUpdate:modelValue": ($event) => unref(form).name = $event,
                      class: "w-full rounded border px-3 py-2",
                      required: ""
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).name]
                    ]),
                    unref(form).errors.name ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "text-sm text-red-600"
                    }, toDisplayString(unref(form).errors.name), 1)) : createCommentVNode("", true)
                  ]),
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Email"),
                    withDirectives(createVNode("input", {
                      "onUpdate:modelValue": ($event) => unref(form).email = $event,
                      type: "email",
                      class: "w-full rounded border px-3 py-2"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).email]
                    ]),
                    unref(form).errors.email ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "text-sm text-red-600"
                    }, toDisplayString(unref(form).errors.email), 1)) : createCommentVNode("", true)
                  ]),
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Phone"),
                    withDirectives(createVNode("input", {
                      "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                      class: "w-full rounded border px-3 py-2"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).phone]
                    ]),
                    unref(form).errors.phone ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "text-sm text-red-600"
                    }, toDisplayString(unref(form).errors.phone), 1)) : createCommentVNode("", true)
                  ]),
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Position"),
                    withDirectives(createVNode("input", {
                      "onUpdate:modelValue": ($event) => unref(form).position = $event,
                      class: "w-full rounded border px-3 py-2"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).position]
                    ]),
                    unref(form).errors.position ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "text-sm text-red-600"
                    }, toDisplayString(unref(form).errors.position), 1)) : createCommentVNode("", true)
                  ]),
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Primary Contact"),
                    createVNode("label", { class: "flex items-center" }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => unref(form).is_primary = $event,
                        type: "checkbox",
                        class: "mr-2"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelCheckbox, unref(form).is_primary]
                      ]),
                      createVNode("span", { class: "text-sm" }, "Mark as primary contact for this customer")
                    ])
                  ])
                ]),
                createVNode("label", { class: "block" }, [
                  createVNode("span", { class: "mb-1 block" }, "Notes"),
                  withDirectives(createVNode("textarea", {
                    "onUpdate:modelValue": ($event) => unref(form).notes = $event,
                    rows: "3",
                    class: "w-full rounded border px-3 py-2"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(form).notes]
                  ]),
                  unref(form).errors.notes ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "text-sm text-red-600"
                  }, toDisplayString(unref(form).errors.notes), 1)) : createCommentVNode("", true)
                ]),
                createVNode("div", { class: "flex items-center gap-2" }, [
                  createVNode("button", {
                    type: "submit",
                    disabled: unref(form).processing,
                    class: "rounded bg-blue-600 px-4 py-2 text-white disabled:opacity-50"
                  }, toDisplayString(unref(form).processing ? "Updating..." : "Update Contact"), 9, ["disabled"]),
                  createVNode(unref(Link), {
                    href: unref(contacts).show(props.contact.id).url,
                    class: "rounded border px-4 py-2"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Cancel")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ])
              ], 32)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/contacts/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
