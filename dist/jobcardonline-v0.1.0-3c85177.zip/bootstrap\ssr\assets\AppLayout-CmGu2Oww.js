import { defineComponent, unref, mergeProps, withCtx, renderSlot, useSSRContext, computed, createVNode, createTextVNode, resolveDynamicComponent, createBlock, openBlock, Fragment, toDisplayString, ref, renderList, createCommentVNode, onMounted, onUnmounted } from "vue";
import { ssrRenderComponent, ssrRenderSlot, ssrRenderAttrs, ssrRenderClass, ssrInterpolate, ssrRenderVNode, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { cva } from "class-variance-authority";
import { c as cn, _ as _sfc_main$1e, t as toUrl, u as urlIsActive, a as logout, d as dashboard, b as _sfc_main$1f } from "./Footer-Ce4AN4A5.js";
import { useForwardPropsEmits, DialogRoot, DialogClose, DialogOverlay, DialogPortal, DialogContent, DialogDescription, DialogTitle, DialogTrigger, createContext, Primitive, TooltipRoot, TooltipPortal, TooltipContent, TooltipArrow, TooltipProvider, TooltipTrigger, Separator, AvatarRoot, AvatarFallback, AvatarImage, DropdownMenuRoot, DropdownMenuCheckboxItem, DropdownMenuItemIndicator, DropdownMenuPortal, DropdownMenuContent, DropdownMenuGroup, useForwardProps, DropdownMenuItem, DropdownMenuLabel, DropdownMenuRadioGroup, DropdownMenuRadioItem, DropdownMenuSeparator, DropdownMenuSub, DropdownMenuSubContent, DropdownMenuSubTrigger, DropdownMenuTrigger } from "reka-ui";
import { reactiveOmit, useMediaQuery, useVModel, useEventListener } from "@vueuse/core";
import { X, PanelLeft, Check, Circle, ChevronRight, Settings, LogOut, ChevronsUpDown, LayoutGrid, Users, UserCheck, Package, ClipboardList, FileText, Receipt, Building2, MoreHorizontal, ChevronDown, Star, ShieldX } from "lucide-vue-next";
import { _ as _sfc_main$1d } from "./Input-CBU-ZeCu.js";
import { usePage, Link, router } from "@inertiajs/vue3";
import { q as queryParams, a as applyUrlDefaults } from "./index--D7ld9AJ.js";
import { j as jobcards, _ as _export_sfc } from "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main$1c = /* @__PURE__ */ defineComponent({
  __name: "Sheet",
  __ssrInlineRender: true,
  props: {
    open: { type: Boolean },
    defaultOpen: { type: Boolean },
    modal: { type: Boolean }
  },
  emits: ["update:open"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const forwarded = useForwardPropsEmits(props, emits);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DialogRoot), mergeProps({ "data-slot": "sheet" }, unref(forwarded), _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$1c = _sfc_main$1c.setup;
_sfc_main$1c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sheet/Sheet.vue");
  return _sfc_setup$1c ? _sfc_setup$1c(props, ctx) : void 0;
};
const _sfc_main$1b = /* @__PURE__ */ defineComponent({
  __name: "SheetClose",
  __ssrInlineRender: true,
  props: {
    asChild: { type: Boolean },
    as: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DialogClose), mergeProps({ "data-slot": "sheet-close" }, props, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$1b = _sfc_main$1b.setup;
_sfc_main$1b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sheet/SheetClose.vue");
  return _sfc_setup$1b ? _sfc_setup$1b(props, ctx) : void 0;
};
const _sfc_main$1a = /* @__PURE__ */ defineComponent({
  __name: "SheetOverlay",
  __ssrInlineRender: true,
  props: {
    forceMount: { type: Boolean },
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(__props) {
    const props = __props;
    const delegatedProps = computed(() => {
      const { class: _, ...delegated } = props;
      return delegated;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DialogOverlay), mergeProps({
        "data-slot": "sheet-overlay",
        class: unref(cn)("data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/80", props.class)
      }, delegatedProps.value, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$1a = _sfc_main$1a.setup;
_sfc_main$1a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sheet/SheetOverlay.vue");
  return _sfc_setup$1a ? _sfc_setup$1a(props, ctx) : void 0;
};
const _sfc_main$19 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "SheetContent",
  __ssrInlineRender: true,
  props: {
    class: {},
    side: { default: "right" },
    forceMount: { type: Boolean },
    disableOutsidePointerEvents: { type: Boolean },
    asChild: { type: Boolean },
    as: {}
  },
  emits: ["escapeKeyDown", "pointerDownOutside", "focusOutside", "interactOutside", "openAutoFocus", "closeAutoFocus"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const delegatedProps = reactiveOmit(props, "class", "side");
    const forwarded = useForwardPropsEmits(delegatedProps, emits);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DialogPortal), _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$1a, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(DialogContent), mergeProps({
              "data-slot": "sheet-content",
              class: unref(cn)(
                "bg-background data-[state=open]:animate-in data-[state=closed]:animate-out fixed z-50 flex flex-col gap-4 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500",
                _ctx.side === "right" && "data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm",
                _ctx.side === "left" && "data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm",
                _ctx.side === "top" && "data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top inset-x-0 top-0 h-auto border-b",
                _ctx.side === "bottom" && "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom inset-x-0 bottom-0 h-auto border-t",
                props.class
              )
            }, { ...unref(forwarded), ..._ctx.$attrs }), {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push3, _parent3, _scopeId2);
                  _push3(ssrRenderComponent(unref(DialogClose), { class: "ring-offset-background focus:ring-ring data-[state=open]:bg-secondary absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(X), { class: "size-4" }, null, _parent4, _scopeId3));
                        _push4(`<span class="sr-only"${_scopeId3}>Close</span>`);
                      } else {
                        return [
                          createVNode(unref(X), { class: "size-4" }),
                          createVNode("span", { class: "sr-only" }, "Close")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    renderSlot(_ctx.$slots, "default"),
                    createVNode(unref(DialogClose), { class: "ring-offset-background focus:ring-ring data-[state=open]:bg-secondary absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none" }, {
                      default: withCtx(() => [
                        createVNode(unref(X), { class: "size-4" }),
                        createVNode("span", { class: "sr-only" }, "Close")
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 3
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$1a),
              createVNode(unref(DialogContent), mergeProps({
                "data-slot": "sheet-content",
                class: unref(cn)(
                  "bg-background data-[state=open]:animate-in data-[state=closed]:animate-out fixed z-50 flex flex-col gap-4 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500",
                  _ctx.side === "right" && "data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm",
                  _ctx.side === "left" && "data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm",
                  _ctx.side === "top" && "data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top inset-x-0 top-0 h-auto border-b",
                  _ctx.side === "bottom" && "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom inset-x-0 bottom-0 h-auto border-t",
                  props.class
                )
              }, { ...unref(forwarded), ..._ctx.$attrs }), {
                default: withCtx(() => [
                  renderSlot(_ctx.$slots, "default"),
                  createVNode(unref(DialogClose), { class: "ring-offset-background focus:ring-ring data-[state=open]:bg-secondary absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none" }, {
                    default: withCtx(() => [
                      createVNode(unref(X), { class: "size-4" }),
                      createVNode("span", { class: "sr-only" }, "Close")
                    ]),
                    _: 1
                  })
                ]),
                _: 3
              }, 16, ["class"])
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$19 = _sfc_main$19.setup;
_sfc_main$19.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sheet/SheetContent.vue");
  return _sfc_setup$19 ? _sfc_setup$19(props, ctx) : void 0;
};
const _sfc_main$18 = /* @__PURE__ */ defineComponent({
  __name: "SheetDescription",
  __ssrInlineRender: true,
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(__props) {
    const props = __props;
    const delegatedProps = computed(() => {
      const { class: _, ...delegated } = props;
      return delegated;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DialogDescription), mergeProps({
        "data-slot": "sheet-description",
        class: unref(cn)("text-muted-foreground text-sm", props.class)
      }, delegatedProps.value, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$18 = _sfc_main$18.setup;
_sfc_main$18.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sheet/SheetDescription.vue");
  return _sfc_setup$18 ? _sfc_setup$18(props, ctx) : void 0;
};
const _sfc_main$17 = /* @__PURE__ */ defineComponent({
  __name: "SheetFooter",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        "data-slot": "sheet-footer",
        class: unref(cn)("mt-auto flex flex-col gap-2 p-4", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
});
const _sfc_setup$17 = _sfc_main$17.setup;
_sfc_main$17.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sheet/SheetFooter.vue");
  return _sfc_setup$17 ? _sfc_setup$17(props, ctx) : void 0;
};
const _sfc_main$16 = /* @__PURE__ */ defineComponent({
  __name: "SheetHeader",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        "data-slot": "sheet-header",
        class: unref(cn)("flex flex-col gap-1.5 p-4", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
});
const _sfc_setup$16 = _sfc_main$16.setup;
_sfc_main$16.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sheet/SheetHeader.vue");
  return _sfc_setup$16 ? _sfc_setup$16(props, ctx) : void 0;
};
const _sfc_main$15 = /* @__PURE__ */ defineComponent({
  __name: "SheetTitle",
  __ssrInlineRender: true,
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(__props) {
    const props = __props;
    const delegatedProps = computed(() => {
      const { class: _, ...delegated } = props;
      return delegated;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DialogTitle), mergeProps({
        "data-slot": "sheet-title",
        class: unref(cn)("text-foreground font-semibold", props.class)
      }, delegatedProps.value, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$15 = _sfc_main$15.setup;
_sfc_main$15.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sheet/SheetTitle.vue");
  return _sfc_setup$15 ? _sfc_setup$15(props, ctx) : void 0;
};
const _sfc_main$14 = /* @__PURE__ */ defineComponent({
  __name: "SheetTrigger",
  __ssrInlineRender: true,
  props: {
    asChild: { type: Boolean },
    as: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DialogTrigger), mergeProps({ "data-slot": "sheet-trigger" }, props, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$14 = _sfc_main$14.setup;
_sfc_main$14.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sheet/SheetTrigger.vue");
  return _sfc_setup$14 ? _sfc_setup$14(props, ctx) : void 0;
};
const SIDEBAR_COOKIE_NAME = "sidebar_state";
const SIDEBAR_COOKIE_MAX_AGE = 60 * 60 * 24 * 7;
const SIDEBAR_WIDTH = "16rem";
const SIDEBAR_WIDTH_MOBILE = "18rem";
const SIDEBAR_WIDTH_ICON = "3rem";
const SIDEBAR_KEYBOARD_SHORTCUT = "b";
const [useSidebar, provideSidebarContext] = createContext("Sidebar");
const _sfc_main$13 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "Sidebar",
  __ssrInlineRender: true,
  props: {
    side: { default: "left" },
    variant: { default: "sidebar" },
    collapsible: { default: "offcanvas" },
    class: {}
  },
  setup(__props) {
    const props = __props;
    const { isMobile, state, openMobile, setOpenMobile } = useSidebar();
    return (_ctx, _push, _parent, _attrs) => {
      if (_ctx.collapsible === "none") {
        _push(`<div${ssrRenderAttrs(mergeProps({
          "data-slot": "sidebar",
          class: unref(cn)("bg-sidebar text-sidebar-foreground flex h-full w-(--sidebar-width) flex-col", props.class)
        }, _ctx.$attrs, _attrs))}>`);
        ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
        _push(`</div>`);
      } else if (unref(isMobile)) {
        _push(ssrRenderComponent(unref(_sfc_main$1c), mergeProps({ open: unref(openMobile) }, _ctx.$attrs, { "onUpdate:open": unref(setOpenMobile) }, _attrs), {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(unref(_sfc_main$19), {
                "data-sidebar": "sidebar",
                "data-slot": "sidebar",
                "data-mobile": "true",
                side: _ctx.side,
                class: "bg-sidebar text-sidebar-foreground w-(--sidebar-width) p-0 [&>button]:hidden",
                style: {
                  "--sidebar-width": unref(SIDEBAR_WIDTH_MOBILE)
                }
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$16, { class: "sr-only" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(_sfc_main$15, null, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(`Sidebar`);
                              } else {
                                return [
                                  createTextVNode("Sidebar")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(_sfc_main$18, null, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(`Displays the mobile sidebar.`);
                              } else {
                                return [
                                  createTextVNode("Displays the mobile sidebar.")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(_sfc_main$15, null, {
                              default: withCtx(() => [
                                createTextVNode("Sidebar")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$18, null, {
                              default: withCtx(() => [
                                createTextVNode("Displays the mobile sidebar.")
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(`<div class="flex h-full w-full flex-col"${_scopeId2}>`);
                    ssrRenderSlot(_ctx.$slots, "default", {}, null, _push3, _parent3, _scopeId2);
                    _push3(`</div>`);
                  } else {
                    return [
                      createVNode(_sfc_main$16, { class: "sr-only" }, {
                        default: withCtx(() => [
                          createVNode(_sfc_main$15, null, {
                            default: withCtx(() => [
                              createTextVNode("Sidebar")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$18, null, {
                            default: withCtx(() => [
                              createTextVNode("Displays the mobile sidebar.")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("div", { class: "flex h-full w-full flex-col" }, [
                        renderSlot(_ctx.$slots, "default")
                      ])
                    ];
                  }
                }),
                _: 3
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(unref(_sfc_main$19), {
                  "data-sidebar": "sidebar",
                  "data-slot": "sidebar",
                  "data-mobile": "true",
                  side: _ctx.side,
                  class: "bg-sidebar text-sidebar-foreground w-(--sidebar-width) p-0 [&>button]:hidden",
                  style: {
                    "--sidebar-width": unref(SIDEBAR_WIDTH_MOBILE)
                  }
                }, {
                  default: withCtx(() => [
                    createVNode(_sfc_main$16, { class: "sr-only" }, {
                      default: withCtx(() => [
                        createVNode(_sfc_main$15, null, {
                          default: withCtx(() => [
                            createTextVNode("Sidebar")
                          ]),
                          _: 1
                        }),
                        createVNode(_sfc_main$18, null, {
                          default: withCtx(() => [
                            createTextVNode("Displays the mobile sidebar.")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "flex h-full w-full flex-col" }, [
                      renderSlot(_ctx.$slots, "default")
                    ])
                  ]),
                  _: 3
                }, 8, ["side", "style"])
              ];
            }
          }),
          _: 3
        }, _parent));
      } else {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "group peer text-sidebar-foreground hidden md:block",
          "data-slot": "sidebar",
          "data-state": unref(state),
          "data-collapsible": unref(state) === "collapsed" ? _ctx.collapsible : "",
          "data-variant": _ctx.variant,
          "data-side": _ctx.side
        }, _attrs))}><div class="${ssrRenderClass(unref(cn)(
          "relative w-(--sidebar-width) bg-transparent transition-[width] duration-200 ease-linear",
          "group-data-[collapsible=offcanvas]:w-0",
          "group-data-[side=right]:rotate-180",
          _ctx.variant === "floating" || _ctx.variant === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4)))]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)"
        ))}"></div><div${ssrRenderAttrs(mergeProps({
          class: unref(cn)(
            "fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear md:flex",
            _ctx.side === "left" ? "left-0 group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)]" : "right-0 group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)]",
            // Adjust the padding for floating and inset variants.
            _ctx.variant === "floating" || _ctx.variant === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4))+2px)]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l",
            props.class
          )
        }, _ctx.$attrs))}><div data-sidebar="sidebar" class="bg-sidebar group-data-[variant=floating]:border-sidebar-border flex h-full w-full flex-col group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:border group-data-[variant=floating]:shadow-sm">`);
        ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
        _push(`</div></div></div>`);
      }
    };
  }
});
const _sfc_setup$13 = _sfc_main$13.setup;
_sfc_main$13.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/Sidebar.vue");
  return _sfc_setup$13 ? _sfc_setup$13(props, ctx) : void 0;
};
const _sfc_main$12 = /* @__PURE__ */ defineComponent({
  __name: "SidebarContent",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        "data-slot": "sidebar-content",
        "data-sidebar": "content",
        class: unref(cn)("flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
});
const _sfc_setup$12 = _sfc_main$12.setup;
_sfc_main$12.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarContent.vue");
  return _sfc_setup$12 ? _sfc_setup$12(props, ctx) : void 0;
};
const _sfc_main$11 = /* @__PURE__ */ defineComponent({
  __name: "SidebarFooter",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        "data-slot": "sidebar-footer",
        "data-sidebar": "footer",
        class: unref(cn)("flex flex-col gap-2 p-2", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
});
const _sfc_setup$11 = _sfc_main$11.setup;
_sfc_main$11.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarFooter.vue");
  return _sfc_setup$11 ? _sfc_setup$11(props, ctx) : void 0;
};
const _sfc_main$10 = /* @__PURE__ */ defineComponent({
  __name: "SidebarGroup",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        "data-slot": "sidebar-group",
        "data-sidebar": "group",
        class: unref(cn)("relative flex w-full min-w-0 flex-col p-2", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
});
const _sfc_setup$10 = _sfc_main$10.setup;
_sfc_main$10.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarGroup.vue");
  return _sfc_setup$10 ? _sfc_setup$10(props, ctx) : void 0;
};
const _sfc_main$$ = /* @__PURE__ */ defineComponent({
  __name: "SidebarGroupAction",
  __ssrInlineRender: true,
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Primitive), mergeProps({
        "data-slot": "sidebar-group-action",
        "data-sidebar": "group-action",
        as: _ctx.as,
        "as-child": _ctx.asChild,
        class: unref(cn)(
          "text-sidebar-foreground ring-sidebar-ring hover:bg-sidebar-accent hover:text-sidebar-accent-foreground absolute top-3.5 right-3 flex aspect-square w-5 items-center justify-center rounded-md p-0 outline-hidden transition-transform focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
          "after:absolute after:-inset-2 md:after:hidden",
          "group-data-[collapsible=icon]:hidden",
          props.class
        )
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$$ = _sfc_main$$.setup;
_sfc_main$$.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarGroupAction.vue");
  return _sfc_setup$$ ? _sfc_setup$$(props, ctx) : void 0;
};
const _sfc_main$_ = /* @__PURE__ */ defineComponent({
  __name: "SidebarGroupContent",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        "data-slot": "sidebar-group-content",
        "data-sidebar": "group-content",
        class: unref(cn)("w-full text-sm", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
});
const _sfc_setup$_ = _sfc_main$_.setup;
_sfc_main$_.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarGroupContent.vue");
  return _sfc_setup$_ ? _sfc_setup$_(props, ctx) : void 0;
};
const _sfc_main$Z = /* @__PURE__ */ defineComponent({
  __name: "SidebarGroupLabel",
  __ssrInlineRender: true,
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Primitive), mergeProps({
        "data-slot": "sidebar-group-label",
        "data-sidebar": "group-label",
        as: _ctx.as,
        "as-child": _ctx.asChild,
        class: unref(cn)(
          "text-sidebar-foreground/70 ring-sidebar-ring flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium outline-hidden transition-[margin,opacity] duration-200 ease-linear focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
          "group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0",
          props.class
        )
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$Z = _sfc_main$Z.setup;
_sfc_main$Z.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarGroupLabel.vue");
  return _sfc_setup$Z ? _sfc_setup$Z(props, ctx) : void 0;
};
const _sfc_main$Y = /* @__PURE__ */ defineComponent({
  __name: "SidebarHeader",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        "data-slot": "sidebar-header",
        "data-sidebar": "header",
        class: unref(cn)("flex flex-col gap-2 p-2", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
});
const _sfc_setup$Y = _sfc_main$Y.setup;
_sfc_main$Y.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarHeader.vue");
  return _sfc_setup$Y ? _sfc_setup$Y(props, ctx) : void 0;
};
const _sfc_main$X = /* @__PURE__ */ defineComponent({
  __name: "SidebarInput",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(_sfc_main$1d), mergeProps({
        "data-slot": "sidebar-input",
        "data-sidebar": "input",
        class: unref(cn)(
          "bg-background h-8 w-full shadow-none",
          props.class
        )
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$X = _sfc_main$X.setup;
_sfc_main$X.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarInput.vue");
  return _sfc_setup$X ? _sfc_setup$X(props, ctx) : void 0;
};
const _sfc_main$W = /* @__PURE__ */ defineComponent({
  __name: "SidebarInset",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<main${ssrRenderAttrs(mergeProps({
        "data-slot": "sidebar-inset",
        class: unref(cn)(
          "bg-background relative flex w-full flex-1 flex-col",
          "md:peer-data-[variant=inset]:m-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow-sm md:peer-data-[variant=inset]:peer-data-[state=collapsed]:ml-0",
          props.class
        )
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</main>`);
    };
  }
});
const _sfc_setup$W = _sfc_main$W.setup;
_sfc_main$W.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarInset.vue");
  return _sfc_setup$W ? _sfc_setup$W(props, ctx) : void 0;
};
const _sfc_main$V = /* @__PURE__ */ defineComponent({
  __name: "SidebarMenu",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<ul${ssrRenderAttrs(mergeProps({
        "data-slot": "sidebar-menu",
        "data-sidebar": "menu",
        class: unref(cn)("flex w-full min-w-0 flex-col gap-1", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</ul>`);
    };
  }
});
const _sfc_setup$V = _sfc_main$V.setup;
_sfc_main$V.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarMenu.vue");
  return _sfc_setup$V ? _sfc_setup$V(props, ctx) : void 0;
};
const _sfc_main$U = /* @__PURE__ */ defineComponent({
  __name: "SidebarMenuAction",
  __ssrInlineRender: true,
  props: {
    asChild: { type: Boolean },
    as: { default: "button" },
    showOnHover: { type: Boolean },
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Primitive), mergeProps({
        "data-slot": "sidebar-menu-action",
        "data-sidebar": "menu-action",
        class: unref(cn)(
          "text-sidebar-foreground ring-sidebar-ring hover:bg-sidebar-accent hover:text-sidebar-accent-foreground peer-hover/menu-button:text-sidebar-accent-foreground absolute top-1.5 right-1 flex aspect-square w-5 items-center justify-center rounded-md p-0 outline-hidden transition-transform focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
          "after:absolute after:-inset-2 md:after:hidden",
          "peer-data-[size=sm]/menu-button:top-1",
          "peer-data-[size=default]/menu-button:top-1.5",
          "peer-data-[size=lg]/menu-button:top-2.5",
          "group-data-[collapsible=icon]:hidden",
          _ctx.showOnHover && "peer-data-[active=true]/menu-button:text-sidebar-accent-foreground group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 data-[state=open]:opacity-100 md:opacity-0",
          props.class
        ),
        as: _ctx.as,
        "as-child": _ctx.asChild
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$U = _sfc_main$U.setup;
_sfc_main$U.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarMenuAction.vue");
  return _sfc_setup$U ? _sfc_setup$U(props, ctx) : void 0;
};
const _sfc_main$T = /* @__PURE__ */ defineComponent({
  __name: "SidebarMenuBadge",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        "data-slot": "sidebar-menu-badge",
        "data-sidebar": "menu-badge",
        class: unref(cn)(
          "text-sidebar-foreground pointer-events-none absolute right-1 flex h-5 min-w-5 items-center justify-center rounded-md px-1 text-xs font-medium tabular-nums select-none",
          "peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[active=true]/menu-button:text-sidebar-accent-foreground",
          "peer-data-[size=sm]/menu-button:top-1",
          "peer-data-[size=default]/menu-button:top-1.5",
          "peer-data-[size=lg]/menu-button:top-2.5",
          "group-data-[collapsible=icon]:hidden",
          props.class
        )
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
});
const _sfc_setup$T = _sfc_main$T.setup;
_sfc_main$T.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarMenuBadge.vue");
  return _sfc_setup$T ? _sfc_setup$T(props, ctx) : void 0;
};
const _sfc_main$S = /* @__PURE__ */ defineComponent({
  __name: "Tooltip",
  __ssrInlineRender: true,
  props: {
    defaultOpen: { type: Boolean },
    open: { type: Boolean },
    delayDuration: {},
    disableHoverableContent: { type: Boolean },
    disableClosingTrigger: { type: Boolean },
    disabled: { type: Boolean },
    ignoreNonKeyboardFocus: { type: Boolean }
  },
  emits: ["update:open"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const forwarded = useForwardPropsEmits(props, emits);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(TooltipRoot), mergeProps({ "data-slot": "tooltip" }, unref(forwarded), _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$S = _sfc_main$S.setup;
_sfc_main$S.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/tooltip/Tooltip.vue");
  return _sfc_setup$S ? _sfc_setup$S(props, ctx) : void 0;
};
const _sfc_main$R = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "TooltipContent",
  __ssrInlineRender: true,
  props: {
    forceMount: { type: Boolean },
    ariaLabel: {},
    asChild: { type: Boolean },
    as: {},
    side: {},
    sideOffset: { default: 4 },
    align: {},
    alignOffset: {},
    avoidCollisions: { type: Boolean },
    collisionBoundary: {},
    collisionPadding: {},
    arrowPadding: {},
    sticky: {},
    hideWhenDetached: { type: Boolean },
    positionStrategy: {},
    updatePositionStrategy: {},
    class: {}
  },
  emits: ["escapeKeyDown", "pointerDownOutside"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const delegatedProps = reactiveOmit(props, "class");
    const forwarded = useForwardPropsEmits(delegatedProps, emits);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(TooltipPortal), _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(TooltipContent), mergeProps({ "data-slot": "tooltip-content" }, { ...unref(forwarded), ..._ctx.$attrs }, {
              class: unref(cn)("bg-primary text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 w-fit rounded-md px-3 py-1.5 text-xs text-balance", props.class)
            }), {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push3, _parent3, _scopeId2);
                  _push3(ssrRenderComponent(unref(TooltipArrow), { class: "bg-primary fill-primary z-50 size-2.5 translate-y-[calc(-50%_-_2px)] rotate-45 rounded-[2px]" }, null, _parent3, _scopeId2));
                } else {
                  return [
                    renderSlot(_ctx.$slots, "default"),
                    createVNode(unref(TooltipArrow), { class: "bg-primary fill-primary z-50 size-2.5 translate-y-[calc(-50%_-_2px)] rotate-45 rounded-[2px]" })
                  ];
                }
              }),
              _: 3
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(TooltipContent), mergeProps({ "data-slot": "tooltip-content" }, { ...unref(forwarded), ..._ctx.$attrs }, {
                class: unref(cn)("bg-primary text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 w-fit rounded-md px-3 py-1.5 text-xs text-balance", props.class)
              }), {
                default: withCtx(() => [
                  renderSlot(_ctx.$slots, "default"),
                  createVNode(unref(TooltipArrow), { class: "bg-primary fill-primary z-50 size-2.5 translate-y-[calc(-50%_-_2px)] rotate-45 rounded-[2px]" })
                ]),
                _: 3
              }, 16, ["class"])
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$R = _sfc_main$R.setup;
_sfc_main$R.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/tooltip/TooltipContent.vue");
  return _sfc_setup$R ? _sfc_setup$R(props, ctx) : void 0;
};
const _sfc_main$Q = /* @__PURE__ */ defineComponent({
  __name: "TooltipProvider",
  __ssrInlineRender: true,
  props: {
    delayDuration: { default: 0 },
    skipDelayDuration: {},
    disableHoverableContent: { type: Boolean },
    disableClosingTrigger: { type: Boolean },
    disabled: { type: Boolean },
    ignoreNonKeyboardFocus: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(TooltipProvider), mergeProps(props, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$Q = _sfc_main$Q.setup;
_sfc_main$Q.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/tooltip/TooltipProvider.vue");
  return _sfc_setup$Q ? _sfc_setup$Q(props, ctx) : void 0;
};
const _sfc_main$P = /* @__PURE__ */ defineComponent({
  __name: "TooltipTrigger",
  __ssrInlineRender: true,
  props: {
    reference: {},
    asChild: { type: Boolean },
    as: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(TooltipTrigger), mergeProps({ "data-slot": "tooltip-trigger" }, props, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$P = _sfc_main$P.setup;
_sfc_main$P.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/tooltip/TooltipTrigger.vue");
  return _sfc_setup$P ? _sfc_setup$P(props, ctx) : void 0;
};
const _sfc_main$O = /* @__PURE__ */ defineComponent({
  __name: "SidebarMenuButtonChild",
  __ssrInlineRender: true,
  props: {
    variant: { default: "default" },
    size: { default: "default" },
    isActive: { type: Boolean },
    class: {},
    asChild: { type: Boolean },
    as: { default: "button" }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Primitive), mergeProps({
        "data-slot": "sidebar-menu-button",
        "data-sidebar": "menu-button",
        "data-size": _ctx.size,
        "data-active": _ctx.isActive,
        class: unref(cn)(unref(sidebarMenuButtonVariants)({ variant: _ctx.variant, size: _ctx.size }), props.class),
        as: _ctx.as,
        "as-child": _ctx.asChild
      }, _ctx.$attrs, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$O = _sfc_main$O.setup;
_sfc_main$O.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarMenuButtonChild.vue");
  return _sfc_setup$O ? _sfc_setup$O(props, ctx) : void 0;
};
const _sfc_main$N = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "SidebarMenuButton",
  __ssrInlineRender: true,
  props: {
    variant: { default: "default" },
    size: { default: "default" },
    isActive: { type: Boolean },
    class: {},
    asChild: { type: Boolean },
    as: { default: "button" },
    tooltip: {}
  },
  setup(__props) {
    const props = __props;
    const { isMobile, state } = useSidebar();
    const delegatedProps = computed(() => {
      const { tooltip, ...delegated } = props;
      return delegated;
    });
    return (_ctx, _push, _parent, _attrs) => {
      if (!_ctx.tooltip) {
        _push(ssrRenderComponent(_sfc_main$O, mergeProps({ ...delegatedProps.value, ..._ctx.$attrs }, _attrs), {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
            } else {
              return [
                renderSlot(_ctx.$slots, "default")
              ];
            }
          }),
          _: 3
        }, _parent));
      } else {
        _push(ssrRenderComponent(unref(_sfc_main$S), _attrs, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(unref(_sfc_main$P), { "as-child": "" }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$O, { ...delegatedProps.value, ..._ctx.$attrs }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          ssrRenderSlot(_ctx.$slots, "default", {}, null, _push4, _parent4, _scopeId3);
                        } else {
                          return [
                            renderSlot(_ctx.$slots, "default")
                          ];
                        }
                      }),
                      _: 3
                    }, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_sfc_main$O, { ...delegatedProps.value, ..._ctx.$attrs }, {
                        default: withCtx(() => [
                          renderSlot(_ctx.$slots, "default")
                        ]),
                        _: 3
                      }, 16)
                    ];
                  }
                }),
                _: 3
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(unref(_sfc_main$R), {
                side: "right",
                align: "center",
                hidden: unref(state) !== "collapsed" || unref(isMobile)
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    if (typeof _ctx.tooltip === "string") {
                      _push3(`<!--[-->${ssrInterpolate(_ctx.tooltip)}<!--]-->`);
                    } else {
                      ssrRenderVNode(_push3, createVNode(resolveDynamicComponent(_ctx.tooltip), null, null), _parent3, _scopeId2);
                    }
                  } else {
                    return [
                      typeof _ctx.tooltip === "string" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                        createTextVNode(toDisplayString(_ctx.tooltip), 1)
                      ], 64)) : (openBlock(), createBlock(resolveDynamicComponent(_ctx.tooltip), { key: 1 }))
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(unref(_sfc_main$P), { "as-child": "" }, {
                  default: withCtx(() => [
                    createVNode(_sfc_main$O, { ...delegatedProps.value, ..._ctx.$attrs }, {
                      default: withCtx(() => [
                        renderSlot(_ctx.$slots, "default")
                      ]),
                      _: 3
                    }, 16)
                  ]),
                  _: 3
                }),
                createVNode(unref(_sfc_main$R), {
                  side: "right",
                  align: "center",
                  hidden: unref(state) !== "collapsed" || unref(isMobile)
                }, {
                  default: withCtx(() => [
                    typeof _ctx.tooltip === "string" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                      createTextVNode(toDisplayString(_ctx.tooltip), 1)
                    ], 64)) : (openBlock(), createBlock(resolveDynamicComponent(_ctx.tooltip), { key: 1 }))
                  ]),
                  _: 1
                }, 8, ["hidden"])
              ];
            }
          }),
          _: 3
        }, _parent));
      }
    };
  }
});
const _sfc_setup$N = _sfc_main$N.setup;
_sfc_main$N.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarMenuButton.vue");
  return _sfc_setup$N ? _sfc_setup$N(props, ctx) : void 0;
};
const _sfc_main$M = /* @__PURE__ */ defineComponent({
  __name: "SidebarMenuItem",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<li${ssrRenderAttrs(mergeProps({
        "data-slot": "sidebar-menu-item",
        "data-sidebar": "menu-item",
        class: unref(cn)("group/menu-item relative", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</li>`);
    };
  }
});
const _sfc_setup$M = _sfc_main$M.setup;
_sfc_main$M.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarMenuItem.vue");
  return _sfc_setup$M ? _sfc_setup$M(props, ctx) : void 0;
};
const _sfc_main$L = /* @__PURE__ */ defineComponent({
  __name: "Skeleton",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        "data-slot": "skeleton",
        class: unref(cn)("animate-pulse rounded-md bg-primary/10", props.class)
      }, _attrs))}></div>`);
    };
  }
});
const _sfc_setup$L = _sfc_main$L.setup;
_sfc_main$L.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/skeleton/Skeleton.vue");
  return _sfc_setup$L ? _sfc_setup$L(props, ctx) : void 0;
};
const _sfc_main$K = /* @__PURE__ */ defineComponent({
  __name: "SidebarMenuSkeleton",
  __ssrInlineRender: true,
  props: {
    showIcon: { type: Boolean },
    class: {}
  },
  setup(__props) {
    const props = __props;
    const width = computed(() => {
      return `${Math.floor(Math.random() * 40) + 50}%`;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        "data-slot": "sidebar-menu-skeleton",
        "data-sidebar": "menu-skeleton",
        class: unref(cn)("flex h-8 items-center gap-2 rounded-md px-2", props.class)
      }, _attrs))}>`);
      if (_ctx.showIcon) {
        _push(ssrRenderComponent(unref(_sfc_main$L), {
          class: "size-4 rounded-md",
          "data-sidebar": "menu-skeleton-icon"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(unref(_sfc_main$L), {
        class: "h-4 max-w-(--skeleton-width) flex-1",
        "data-sidebar": "menu-skeleton-text",
        style: { "--skeleton-width": width.value }
      }, null, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$K = _sfc_main$K.setup;
_sfc_main$K.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarMenuSkeleton.vue");
  return _sfc_setup$K ? _sfc_setup$K(props, ctx) : void 0;
};
const _sfc_main$J = /* @__PURE__ */ defineComponent({
  __name: "SidebarMenuSub",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<ul${ssrRenderAttrs(mergeProps({
        "data-slot": "sidebar-menu-sub",
        "data-sidebar": "menu-badge",
        class: unref(cn)(
          "border-sidebar-border mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l px-2.5 py-0.5",
          "group-data-[collapsible=icon]:hidden",
          props.class
        )
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</ul>`);
    };
  }
});
const _sfc_setup$J = _sfc_main$J.setup;
_sfc_main$J.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarMenuSub.vue");
  return _sfc_setup$J ? _sfc_setup$J(props, ctx) : void 0;
};
const _sfc_main$I = /* @__PURE__ */ defineComponent({
  __name: "SidebarMenuSubButton",
  __ssrInlineRender: true,
  props: {
    asChild: { type: Boolean },
    as: { default: "a" },
    size: { default: "md" },
    isActive: { type: Boolean },
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Primitive), mergeProps({
        "data-slot": "sidebar-menu-sub-button",
        "data-sidebar": "menu-sub-button",
        as: _ctx.as,
        "as-child": _ctx.asChild,
        "data-size": _ctx.size,
        "data-active": _ctx.isActive,
        class: unref(cn)(
          "text-sidebar-foreground ring-sidebar-ring hover:bg-sidebar-accent hover:text-sidebar-accent-foreground active:bg-sidebar-accent active:text-sidebar-accent-foreground [&>svg]:text-sidebar-accent-foreground flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 outline-hidden focus-visible:ring-2 disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0",
          "data-[active=true]:bg-sidebar-accent data-[active=true]:text-sidebar-accent-foreground",
          _ctx.size === "sm" && "text-xs",
          _ctx.size === "md" && "text-sm",
          "group-data-[collapsible=icon]:hidden",
          props.class
        )
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$I = _sfc_main$I.setup;
_sfc_main$I.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarMenuSubButton.vue");
  return _sfc_setup$I ? _sfc_setup$I(props, ctx) : void 0;
};
const _sfc_main$H = /* @__PURE__ */ defineComponent({
  __name: "SidebarMenuSubItem",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<li${ssrRenderAttrs(mergeProps({
        "data-slot": "sidebar-menu-sub-item",
        "data-sidebar": "menu-sub-item",
        class: unref(cn)("group/menu-sub-item relative", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</li>`);
    };
  }
});
const _sfc_setup$H = _sfc_main$H.setup;
_sfc_main$H.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarMenuSubItem.vue");
  return _sfc_setup$H ? _sfc_setup$H(props, ctx) : void 0;
};
const _sfc_main$G = /* @__PURE__ */ defineComponent({
  __name: "SidebarProvider",
  __ssrInlineRender: true,
  props: {
    defaultOpen: { type: Boolean, default: true },
    open: { type: Boolean, default: void 0 },
    class: {}
  },
  emits: ["update:open"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const isMobile = useMediaQuery("(max-width: 768px)");
    const openMobile = ref(false);
    const open = useVModel(props, "open", emits, {
      defaultValue: props.defaultOpen ?? false,
      passive: props.open === void 0
    });
    function setOpen(value) {
      open.value = value;
      document.cookie = `${SIDEBAR_COOKIE_NAME}=${open.value}; path=/; max-age=${SIDEBAR_COOKIE_MAX_AGE}`;
    }
    function setOpenMobile(value) {
      openMobile.value = value;
    }
    function toggleSidebar() {
      return isMobile.value ? setOpenMobile(!openMobile.value) : setOpen(!open.value);
    }
    useEventListener("keydown", (event) => {
      if (event.key === SIDEBAR_KEYBOARD_SHORTCUT && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        toggleSidebar();
      }
    });
    const state = computed(() => open.value ? "expanded" : "collapsed");
    provideSidebarContext({
      state,
      open,
      setOpen,
      isMobile,
      openMobile,
      setOpenMobile,
      toggleSidebar
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(TooltipProvider), mergeProps({ "delay-duration": 0 }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${ssrRenderAttrs(mergeProps({
              "data-slot": "sidebar-wrapper",
              style: {
                "--sidebar-width": unref(SIDEBAR_WIDTH),
                "--sidebar-width-icon": unref(SIDEBAR_WIDTH_ICON)
              },
              class: unref(cn)("group/sidebar-wrapper has-data-[variant=inset]:bg-sidebar flex min-h-svh w-full", props.class)
            }, _ctx.$attrs))}${_scopeId}>`);
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", mergeProps({
                "data-slot": "sidebar-wrapper",
                style: {
                  "--sidebar-width": unref(SIDEBAR_WIDTH),
                  "--sidebar-width-icon": unref(SIDEBAR_WIDTH_ICON)
                },
                class: unref(cn)("group/sidebar-wrapper has-data-[variant=inset]:bg-sidebar flex min-h-svh w-full", props.class)
              }, _ctx.$attrs), [
                renderSlot(_ctx.$slots, "default")
              ], 16)
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$G = _sfc_main$G.setup;
_sfc_main$G.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarProvider.vue");
  return _sfc_setup$G ? _sfc_setup$G(props, ctx) : void 0;
};
const _sfc_main$F = /* @__PURE__ */ defineComponent({
  __name: "SidebarRail",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    const { toggleSidebar } = useSidebar();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<button${ssrRenderAttrs(mergeProps({
        "data-sidebar": "rail",
        "data-slot": "sidebar-rail",
        "aria-label": "Toggle Sidebar",
        tabindex: -1,
        title: "Toggle Sidebar",
        class: unref(cn)(
          "hover:after:bg-sidebar-border absolute inset-y-0 z-20 hidden w-4 -translate-x-1/2 transition-all ease-linear group-data-[side=left]:-right-4 group-data-[side=right]:left-0 after:absolute after:inset-y-0 after:left-1/2 after:w-[2px] sm:flex",
          "in-data-[side=left]:cursor-w-resize in-data-[side=right]:cursor-e-resize",
          "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize",
          "hover:group-data-[collapsible=offcanvas]:bg-sidebar group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full",
          "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2",
          "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2",
          props.class
        )
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</button>`);
    };
  }
});
const _sfc_setup$F = _sfc_main$F.setup;
_sfc_main$F.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarRail.vue");
  return _sfc_setup$F ? _sfc_setup$F(props, ctx) : void 0;
};
const _sfc_main$E = /* @__PURE__ */ defineComponent({
  __name: "Separator",
  __ssrInlineRender: true,
  props: {
    orientation: { default: "horizontal" },
    decorative: { type: Boolean, default: true },
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(__props) {
    const props = __props;
    const delegatedProps = reactiveOmit(props, "class");
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Separator), mergeProps({ "data-slot": "separator-root" }, unref(delegatedProps), {
        class: unref(cn)(
          `bg-border shrink-0 data-[orientation=horizontal]:h-px data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-px`,
          props.class
        )
      }, _attrs), null, _parent));
    };
  }
});
const _sfc_setup$E = _sfc_main$E.setup;
_sfc_main$E.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/separator/Separator.vue");
  return _sfc_setup$E ? _sfc_setup$E(props, ctx) : void 0;
};
const _sfc_main$D = /* @__PURE__ */ defineComponent({
  __name: "SidebarSeparator",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(_sfc_main$E), mergeProps({
        "data-slot": "sidebar-separator",
        "data-sidebar": "separator",
        class: unref(cn)("bg-sidebar-border mx-2 w-auto", props.class)
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$D = _sfc_main$D.setup;
_sfc_main$D.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarSeparator.vue");
  return _sfc_setup$D ? _sfc_setup$D(props, ctx) : void 0;
};
const _sfc_main$C = /* @__PURE__ */ defineComponent({
  __name: "SidebarTrigger",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    const { toggleSidebar } = useSidebar();
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(_sfc_main$1e), mergeProps({
        "data-sidebar": "trigger",
        "data-slot": "sidebar-trigger",
        variant: "ghost",
        size: "icon",
        class: unref(cn)("h-7 w-7", props.class),
        onClick: unref(toggleSidebar)
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(PanelLeft), null, null, _parent2, _scopeId));
            _push2(`<span class="sr-only"${_scopeId}>Toggle Sidebar</span>`);
          } else {
            return [
              createVNode(unref(PanelLeft)),
              createVNode("span", { class: "sr-only" }, "Toggle Sidebar")
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$C = _sfc_main$C.setup;
_sfc_main$C.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/sidebar/SidebarTrigger.vue");
  return _sfc_setup$C ? _sfc_setup$C(props, ctx) : void 0;
};
const sidebarMenuButtonVariants = cva(
  "peer/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-hidden ring-sidebar-ring transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 group-has-data-[sidebar=menu-action]/menu-item:pr-8 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground group-data-[collapsible=icon]:size-8! group-data-[collapsible=icon]:pr-2! [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
        outline: "bg-background shadow-[0_0_0_1px_hsl(var(--sidebar-border))] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_hsl(var(--sidebar-accent))]"
      },
      size: {
        default: "h-8 text-sm",
        sm: "h-7 text-xs",
        lg: "h-12 text-sm group-data-[collapsible=icon]:p-0!"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const _sfc_main$B = /* @__PURE__ */ defineComponent({
  __name: "AppContent",
  __ssrInlineRender: true,
  props: {
    variant: {},
    class: {}
  },
  setup(__props) {
    const props = __props;
    const className = computed(() => props.class);
    return (_ctx, _push, _parent, _attrs) => {
      if (props.variant === "sidebar") {
        _push(ssrRenderComponent(unref(_sfc_main$W), mergeProps({ class: className.value }, _attrs), {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
            } else {
              return [
                renderSlot(_ctx.$slots, "default")
              ];
            }
          }),
          _: 3
        }, _parent));
      } else {
        _push(`<main${ssrRenderAttrs(mergeProps({
          class: ["mx-auto flex h-full w-full max-w-7xl flex-1 flex-col gap-4 rounded-xl", className.value]
        }, _attrs))}>`);
        ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
        _push(`</main>`);
      }
    };
  }
});
const _sfc_setup$B = _sfc_main$B.setup;
_sfc_main$B.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/AppContent.vue");
  return _sfc_setup$B ? _sfc_setup$B(props, ctx) : void 0;
};
const _sfc_main$A = /* @__PURE__ */ defineComponent({
  __name: "AppShell",
  __ssrInlineRender: true,
  props: {
    variant: {}
  },
  setup(__props) {
    const isOpen = usePage().props.sidebarOpen;
    return (_ctx, _push, _parent, _attrs) => {
      if (_ctx.variant === "header") {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex min-h-screen w-full flex-col" }, _attrs))}>`);
        ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
        _push(`</div>`);
      } else {
        _push(ssrRenderComponent(unref(_sfc_main$G), mergeProps({ "default-open": unref(isOpen) }, _attrs), {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
            } else {
              return [
                renderSlot(_ctx.$slots, "default")
              ];
            }
          }),
          _: 3
        }, _parent));
      }
    };
  }
});
const _sfc_setup$A = _sfc_main$A.setup;
_sfc_main$A.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/AppShell.vue");
  return _sfc_setup$A ? _sfc_setup$A(props, ctx) : void 0;
};
const _sfc_main$z = /* @__PURE__ */ defineComponent({
  __name: "NavFooter",
  __ssrInlineRender: true,
  props: {
    items: {},
    class: {}
  },
  setup(__props) {
    function isExternalUrl(href) {
      return href.startsWith("http://") || href.startsWith("https://");
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(_sfc_main$10), mergeProps({
        class: `group-data-[collapsible=icon]:p-0 ${_ctx.$props.class || ""}`
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(_sfc_main$_), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(_sfc_main$V), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<!--[-->`);
                        ssrRenderList(_ctx.items, (item) => {
                          _push4(ssrRenderComponent(unref(_sfc_main$M), {
                            key: item.title
                          }, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(unref(_sfc_main$N), {
                                  class: "text-neutral-600 hover:text-neutral-800 dark:text-neutral-300 dark:hover:text-neutral-100",
                                  "as-child": ""
                                }, {
                                  default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      if (!isExternalUrl(unref(toUrl)(item.href))) {
                                        _push6(ssrRenderComponent(unref(Link), {
                                          href: unref(toUrl)(item.href)
                                        }, {
                                          default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                            if (_push7) {
                                              ssrRenderVNode(_push7, createVNode(resolveDynamicComponent(item.icon), null, null), _parent7, _scopeId6);
                                              _push7(`<span${_scopeId6}>${ssrInterpolate(item.title)}</span>`);
                                            } else {
                                              return [
                                                (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                                createVNode("span", null, toDisplayString(item.title), 1)
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent6, _scopeId5));
                                      } else {
                                        _push6(`<a${ssrRenderAttr("href", unref(toUrl)(item.href))} target="_blank" rel="noopener noreferrer"${_scopeId5}>`);
                                        ssrRenderVNode(_push6, createVNode(resolveDynamicComponent(item.icon), null, null), _parent6, _scopeId5);
                                        _push6(`<span${_scopeId5}>${ssrInterpolate(item.title)}</span></a>`);
                                      }
                                    } else {
                                      return [
                                        !isExternalUrl(unref(toUrl)(item.href)) ? (openBlock(), createBlock(unref(Link), {
                                          key: 0,
                                          href: unref(toUrl)(item.href)
                                        }, {
                                          default: withCtx(() => [
                                            (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                            createVNode("span", null, toDisplayString(item.title), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["href"])) : (openBlock(), createBlock("a", {
                                          key: 1,
                                          href: unref(toUrl)(item.href),
                                          target: "_blank",
                                          rel: "noopener noreferrer"
                                        }, [
                                          (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                          createVNode("span", null, toDisplayString(item.title), 1)
                                        ], 8, ["href"]))
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(unref(_sfc_main$N), {
                                    class: "text-neutral-600 hover:text-neutral-800 dark:text-neutral-300 dark:hover:text-neutral-100",
                                    "as-child": ""
                                  }, {
                                    default: withCtx(() => [
                                      !isExternalUrl(unref(toUrl)(item.href)) ? (openBlock(), createBlock(unref(Link), {
                                        key: 0,
                                        href: unref(toUrl)(item.href)
                                      }, {
                                        default: withCtx(() => [
                                          (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                          createVNode("span", null, toDisplayString(item.title), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["href"])) : (openBlock(), createBlock("a", {
                                        key: 1,
                                        href: unref(toUrl)(item.href),
                                        target: "_blank",
                                        rel: "noopener noreferrer"
                                      }, [
                                        (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                        createVNode("span", null, toDisplayString(item.title), 1)
                                      ], 8, ["href"]))
                                    ]),
                                    _: 2
                                  }, 1024)
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        });
                        _push4(`<!--]-->`);
                      } else {
                        return [
                          (openBlock(true), createBlock(Fragment, null, renderList(_ctx.items, (item) => {
                            return openBlock(), createBlock(unref(_sfc_main$M), {
                              key: item.title
                            }, {
                              default: withCtx(() => [
                                createVNode(unref(_sfc_main$N), {
                                  class: "text-neutral-600 hover:text-neutral-800 dark:text-neutral-300 dark:hover:text-neutral-100",
                                  "as-child": ""
                                }, {
                                  default: withCtx(() => [
                                    !isExternalUrl(unref(toUrl)(item.href)) ? (openBlock(), createBlock(unref(Link), {
                                      key: 0,
                                      href: unref(toUrl)(item.href)
                                    }, {
                                      default: withCtx(() => [
                                        (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                        createVNode("span", null, toDisplayString(item.title), 1)
                                      ]),
                                      _: 2
                                    }, 1032, ["href"])) : (openBlock(), createBlock("a", {
                                      key: 1,
                                      href: unref(toUrl)(item.href),
                                      target: "_blank",
                                      rel: "noopener noreferrer"
                                    }, [
                                      (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                      createVNode("span", null, toDisplayString(item.title), 1)
                                    ], 8, ["href"]))
                                  ]),
                                  _: 2
                                }, 1024)
                              ]),
                              _: 2
                            }, 1024);
                          }), 128))
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(_sfc_main$V), null, {
                      default: withCtx(() => [
                        (openBlock(true), createBlock(Fragment, null, renderList(_ctx.items, (item) => {
                          return openBlock(), createBlock(unref(_sfc_main$M), {
                            key: item.title
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(_sfc_main$N), {
                                class: "text-neutral-600 hover:text-neutral-800 dark:text-neutral-300 dark:hover:text-neutral-100",
                                "as-child": ""
                              }, {
                                default: withCtx(() => [
                                  !isExternalUrl(unref(toUrl)(item.href)) ? (openBlock(), createBlock(unref(Link), {
                                    key: 0,
                                    href: unref(toUrl)(item.href)
                                  }, {
                                    default: withCtx(() => [
                                      (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                      createVNode("span", null, toDisplayString(item.title), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["href"])) : (openBlock(), createBlock("a", {
                                    key: 1,
                                    href: unref(toUrl)(item.href),
                                    target: "_blank",
                                    rel: "noopener noreferrer"
                                  }, [
                                    (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                    createVNode("span", null, toDisplayString(item.title), 1)
                                  ], 8, ["href"]))
                                ]),
                                _: 2
                              }, 1024)
                            ]),
                            _: 2
                          }, 1024);
                        }), 128))
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(_sfc_main$_), null, {
                default: withCtx(() => [
                  createVNode(unref(_sfc_main$V), null, {
                    default: withCtx(() => [
                      (openBlock(true), createBlock(Fragment, null, renderList(_ctx.items, (item) => {
                        return openBlock(), createBlock(unref(_sfc_main$M), {
                          key: item.title
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(_sfc_main$N), {
                              class: "text-neutral-600 hover:text-neutral-800 dark:text-neutral-300 dark:hover:text-neutral-100",
                              "as-child": ""
                            }, {
                              default: withCtx(() => [
                                !isExternalUrl(unref(toUrl)(item.href)) ? (openBlock(), createBlock(unref(Link), {
                                  key: 0,
                                  href: unref(toUrl)(item.href)
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                    createVNode("span", null, toDisplayString(item.title), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["href"])) : (openBlock(), createBlock("a", {
                                  key: 1,
                                  href: unref(toUrl)(item.href),
                                  target: "_blank",
                                  rel: "noopener noreferrer"
                                }, [
                                  (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                  createVNode("span", null, toDisplayString(item.title), 1)
                                ], 8, ["href"]))
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          _: 2
                        }, 1024);
                      }), 128))
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$z = _sfc_main$z.setup;
_sfc_main$z.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/NavFooter.vue");
  return _sfc_setup$z ? _sfc_setup$z(props, ctx) : void 0;
};
const _sfc_main$y = /* @__PURE__ */ defineComponent({
  __name: "NavMain",
  __ssrInlineRender: true,
  props: {
    items: {}
  },
  setup(__props) {
    const page = usePage();
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(_sfc_main$10), mergeProps({ class: "px-2 py-0" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(_sfc_main$Z), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Platform`);
                } else {
                  return [
                    createTextVNode("Platform")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(_sfc_main$V), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(_ctx.items, (item) => {
                    _push3(ssrRenderComponent(unref(_sfc_main$M), {
                      key: item.title
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(unref(_sfc_main$N), {
                            "as-child": "",
                            "is-active": unref(urlIsActive)(item.href, unref(page).url),
                            tooltip: item.title
                          }, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(unref(Link), {
                                  href: item.href
                                }, {
                                  default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      ssrRenderVNode(_push6, createVNode(resolveDynamicComponent(item.icon), null, null), _parent6, _scopeId5);
                                      _push6(`<span${_scopeId5}>${ssrInterpolate(item.title)}</span>`);
                                    } else {
                                      return [
                                        (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                        createVNode("span", null, toDisplayString(item.title), 1)
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(unref(Link), {
                                    href: item.href
                                  }, {
                                    default: withCtx(() => [
                                      (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                      createVNode("span", null, toDisplayString(item.title), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["href"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(unref(_sfc_main$N), {
                              "as-child": "",
                              "is-active": unref(urlIsActive)(item.href, unref(page).url),
                              tooltip: item.title
                            }, {
                              default: withCtx(() => [
                                createVNode(unref(Link), {
                                  href: item.href
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                    createVNode("span", null, toDisplayString(item.title), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["href"])
                              ]),
                              _: 2
                            }, 1032, ["is-active", "tooltip"])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(_ctx.items, (item) => {
                      return openBlock(), createBlock(unref(_sfc_main$M), {
                        key: item.title
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(_sfc_main$N), {
                            "as-child": "",
                            "is-active": unref(urlIsActive)(item.href, unref(page).url),
                            tooltip: item.title
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: item.href
                              }, {
                                default: withCtx(() => [
                                  (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                  createVNode("span", null, toDisplayString(item.title), 1)
                                ]),
                                _: 2
                              }, 1032, ["href"])
                            ]),
                            _: 2
                          }, 1032, ["is-active", "tooltip"])
                        ]),
                        _: 2
                      }, 1024);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(_sfc_main$Z), null, {
                default: withCtx(() => [
                  createTextVNode("Platform")
                ]),
                _: 1
              }),
              createVNode(unref(_sfc_main$V), null, {
                default: withCtx(() => [
                  (openBlock(true), createBlock(Fragment, null, renderList(_ctx.items, (item) => {
                    return openBlock(), createBlock(unref(_sfc_main$M), {
                      key: item.title
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(_sfc_main$N), {
                          "as-child": "",
                          "is-active": unref(urlIsActive)(item.href, unref(page).url),
                          tooltip: item.title
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(Link), {
                              href: item.href
                            }, {
                              default: withCtx(() => [
                                (openBlock(), createBlock(resolveDynamicComponent(item.icon))),
                                createVNode("span", null, toDisplayString(item.title), 1)
                              ]),
                              _: 2
                            }, 1032, ["href"])
                          ]),
                          _: 2
                        }, 1032, ["is-active", "tooltip"])
                      ]),
                      _: 2
                    }, 1024);
                  }), 128))
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$y = _sfc_main$y.setup;
_sfc_main$y.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/NavMain.vue");
  return _sfc_setup$y ? _sfc_setup$y(props, ctx) : void 0;
};
const _sfc_main$x = /* @__PURE__ */ defineComponent({
  __name: "Avatar",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(AvatarRoot), mergeProps({
        "data-slot": "avatar",
        class: unref(cn)("relative flex size-8 shrink-0 overflow-hidden rounded-full", props.class)
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$x = _sfc_main$x.setup;
_sfc_main$x.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/avatar/Avatar.vue");
  return _sfc_setup$x ? _sfc_setup$x(props, ctx) : void 0;
};
const _sfc_main$w = /* @__PURE__ */ defineComponent({
  __name: "AvatarFallback",
  __ssrInlineRender: true,
  props: {
    delayMs: {},
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(__props) {
    const props = __props;
    const delegatedProps = computed(() => {
      const { class: _, ...delegated } = props;
      return delegated;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(AvatarFallback), mergeProps({ "data-slot": "avatar-fallback" }, delegatedProps.value, {
        class: unref(cn)("bg-muted flex size-full items-center justify-center rounded-full", props.class)
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$w = _sfc_main$w.setup;
_sfc_main$w.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/avatar/AvatarFallback.vue");
  return _sfc_setup$w ? _sfc_setup$w(props, ctx) : void 0;
};
const _sfc_main$v = /* @__PURE__ */ defineComponent({
  __name: "AvatarImage",
  __ssrInlineRender: true,
  props: {
    src: {},
    referrerPolicy: {},
    crossOrigin: {},
    asChild: { type: Boolean },
    as: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(AvatarImage), mergeProps({ "data-slot": "avatar-image" }, props, { class: "aspect-square size-full" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$v = _sfc_main$v.setup;
_sfc_main$v.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/avatar/AvatarImage.vue");
  return _sfc_setup$v ? _sfc_setup$v(props, ctx) : void 0;
};
function getInitials(fullName) {
  if (!fullName) return "";
  const names = fullName.trim().split(" ");
  if (names.length === 0) return "";
  if (names.length === 1) return names[0].charAt(0).toUpperCase();
  return `${names[0].charAt(0)}${names[names.length - 1].charAt(0)}`.toUpperCase();
}
function useInitials() {
  return { getInitials };
}
const _sfc_main$u = /* @__PURE__ */ defineComponent({
  __name: "UserInfo",
  __ssrInlineRender: true,
  props: {
    user: {},
    showEmail: { type: Boolean, default: false }
  },
  setup(__props) {
    const props = __props;
    const { getInitials: getInitials2 } = useInitials();
    const showAvatar = computed(
      () => props.user.avatar && props.user.avatar !== ""
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(_sfc_main$x), { class: "h-8 w-8 overflow-hidden rounded-lg" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (showAvatar.value) {
              _push2(ssrRenderComponent(unref(_sfc_main$v), {
                src: _ctx.user.avatar,
                alt: _ctx.user.name
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(unref(_sfc_main$w), { class: "rounded-lg text-black dark:text-white" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(getInitials2)(_ctx.user.name))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(getInitials2)(_ctx.user.name)), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              showAvatar.value ? (openBlock(), createBlock(unref(_sfc_main$v), {
                key: 0,
                src: _ctx.user.avatar,
                alt: _ctx.user.name
              }, null, 8, ["src", "alt"])) : createCommentVNode("", true),
              createVNode(unref(_sfc_main$w), { class: "rounded-lg text-black dark:text-white" }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(getInitials2)(_ctx.user.name)), 1)
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="grid flex-1 text-left text-sm leading-tight"><span class="truncate font-medium">${ssrInterpolate(_ctx.user.name)}</span>`);
      if (_ctx.showEmail) {
        _push(`<span class="truncate text-xs text-muted-foreground">${ssrInterpolate(_ctx.user.email)}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><!--]-->`);
    };
  }
});
const _sfc_setup$u = _sfc_main$u.setup;
_sfc_main$u.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/UserInfo.vue");
  return _sfc_setup$u ? _sfc_setup$u(props, ctx) : void 0;
};
const _sfc_main$t = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenu",
  __ssrInlineRender: true,
  props: {
    defaultOpen: { type: Boolean },
    open: { type: Boolean },
    dir: {},
    modal: { type: Boolean }
  },
  emits: ["update:open"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const forwarded = useForwardPropsEmits(props, emits);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuRoot), mergeProps({ "data-slot": "dropdown-menu" }, unref(forwarded), _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$t = _sfc_main$t.setup;
_sfc_main$t.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenu.vue");
  return _sfc_setup$t ? _sfc_setup$t(props, ctx) : void 0;
};
const _sfc_main$s = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuCheckboxItem",
  __ssrInlineRender: true,
  props: {
    modelValue: { type: [Boolean, String] },
    disabled: { type: Boolean },
    textValue: {},
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  emits: ["select", "update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const delegatedProps = computed(() => {
      const { class: _, ...delegated } = props;
      return delegated;
    });
    const forwarded = useForwardPropsEmits(delegatedProps, emits);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuCheckboxItem), mergeProps({ "data-slot": "dropdown-menu-checkbox-item" }, unref(forwarded), {
        class: unref(cn)(
          `focus:bg-accent focus:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4`,
          props.class
        )
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="pointer-events-none absolute left-2 flex size-3.5 items-center justify-center"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(DropdownMenuItemIndicator), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Check), { class: "size-4" }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(Check), { class: "size-4" })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</span>`);
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              createVNode("span", { class: "pointer-events-none absolute left-2 flex size-3.5 items-center justify-center" }, [
                createVNode(unref(DropdownMenuItemIndicator), null, {
                  default: withCtx(() => [
                    createVNode(unref(Check), { class: "size-4" })
                  ]),
                  _: 1
                })
              ]),
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$s = _sfc_main$s.setup;
_sfc_main$s.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuCheckboxItem.vue");
  return _sfc_setup$s ? _sfc_setup$s(props, ctx) : void 0;
};
const _sfc_main$r = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuContent",
  __ssrInlineRender: true,
  props: {
    forceMount: { type: Boolean },
    loop: { type: Boolean },
    side: {},
    sideOffset: { default: 4 },
    sideFlip: { type: Boolean },
    align: {},
    alignOffset: {},
    alignFlip: { type: Boolean },
    avoidCollisions: { type: Boolean },
    collisionBoundary: {},
    collisionPadding: {},
    arrowPadding: {},
    sticky: {},
    hideWhenDetached: { type: Boolean },
    positionStrategy: {},
    updatePositionStrategy: {},
    disableUpdateOnLayoutShift: { type: Boolean },
    prioritizePosition: { type: Boolean },
    reference: {},
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  emits: ["escapeKeyDown", "pointerDownOutside", "focusOutside", "interactOutside", "closeAutoFocus"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const delegatedProps = computed(() => {
      const { class: _, ...delegated } = props;
      return delegated;
    });
    const forwarded = useForwardPropsEmits(delegatedProps, emits);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuPortal), _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(DropdownMenuContent), mergeProps({ "data-slot": "dropdown-menu-content" }, unref(forwarded), {
              class: unref(cn)("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 max-h-(--reka-dropdown-menu-content-available-height) min-w-[8rem] origin-(--reka-dropdown-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border p-1 shadow-md", props.class)
            }), {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push3, _parent3, _scopeId2);
                } else {
                  return [
                    renderSlot(_ctx.$slots, "default")
                  ];
                }
              }),
              _: 3
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(DropdownMenuContent), mergeProps({ "data-slot": "dropdown-menu-content" }, unref(forwarded), {
                class: unref(cn)("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 max-h-(--reka-dropdown-menu-content-available-height) min-w-[8rem] origin-(--reka-dropdown-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border p-1 shadow-md", props.class)
              }), {
                default: withCtx(() => [
                  renderSlot(_ctx.$slots, "default")
                ]),
                _: 3
              }, 16, ["class"])
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$r = _sfc_main$r.setup;
_sfc_main$r.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuContent.vue");
  return _sfc_setup$r ? _sfc_setup$r(props, ctx) : void 0;
};
const _sfc_main$q = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuGroup",
  __ssrInlineRender: true,
  props: {
    asChild: { type: Boolean },
    as: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuGroup), mergeProps({ "data-slot": "dropdown-menu-group" }, props, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$q = _sfc_main$q.setup;
_sfc_main$q.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuGroup.vue");
  return _sfc_setup$q ? _sfc_setup$q(props, ctx) : void 0;
};
const _sfc_main$p = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuItem",
  __ssrInlineRender: true,
  props: {
    disabled: { type: Boolean },
    textValue: {},
    asChild: { type: Boolean },
    as: {},
    class: {},
    inset: { type: Boolean },
    variant: { default: "default" }
  },
  setup(__props) {
    const props = __props;
    const delegatedProps = reactiveOmit(props, "inset", "variant");
    const forwardedProps = useForwardProps(delegatedProps);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuItem), mergeProps({
        "data-slot": "dropdown-menu-item",
        "data-inset": _ctx.inset ? "" : void 0,
        "data-variant": _ctx.variant
      }, unref(forwardedProps), {
        class: unref(cn)(`focus:bg-accent focus:text-accent-foreground data-[variant=destructive]:text-destructive-foreground data-[variant=destructive]:focus:bg-destructive/10 dark:data-[variant=destructive]:focus:bg-destructive/40 data-[variant=destructive]:focus:text-destructive-foreground data-[variant=destructive]:*:[svg]:!text-destructive-foreground [&_svg:not([class*='text-'])]:text-muted-foreground relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 data-[inset]:pl-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4`, props.class)
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$p = _sfc_main$p.setup;
_sfc_main$p.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuItem.vue");
  return _sfc_setup$p ? _sfc_setup$p(props, ctx) : void 0;
};
const _sfc_main$o = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuLabel",
  __ssrInlineRender: true,
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {},
    inset: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const delegatedProps = reactiveOmit(props, "class", "inset");
    const forwardedProps = useForwardProps(delegatedProps);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuLabel), mergeProps({
        "data-slot": "dropdown-menu-label",
        "data-inset": _ctx.inset ? "" : void 0
      }, unref(forwardedProps), {
        class: unref(cn)("px-2 py-1.5 text-sm font-medium data-[inset]:pl-8", props.class)
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$o = _sfc_main$o.setup;
_sfc_main$o.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuLabel.vue");
  return _sfc_setup$o ? _sfc_setup$o(props, ctx) : void 0;
};
const _sfc_main$n = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuRadioGroup",
  __ssrInlineRender: true,
  props: {
    modelValue: {},
    asChild: { type: Boolean },
    as: {}
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const forwarded = useForwardPropsEmits(props, emits);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuRadioGroup), mergeProps({ "data-slot": "dropdown-menu-radio-group" }, unref(forwarded), _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$n = _sfc_main$n.setup;
_sfc_main$n.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuRadioGroup.vue");
  return _sfc_setup$n ? _sfc_setup$n(props, ctx) : void 0;
};
const _sfc_main$m = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuRadioItem",
  __ssrInlineRender: true,
  props: {
    value: {},
    disabled: { type: Boolean },
    textValue: {},
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  emits: ["select"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const delegatedProps = computed(() => {
      const { class: _, ...delegated } = props;
      return delegated;
    });
    const forwarded = useForwardPropsEmits(delegatedProps, emits);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuRadioItem), mergeProps({ "data-slot": "dropdown-menu-radio-item" }, unref(forwarded), {
        class: unref(cn)(
          `focus:bg-accent focus:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4`,
          props.class
        )
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="pointer-events-none absolute left-2 flex size-3.5 items-center justify-center"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(DropdownMenuItemIndicator), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Circle), { class: "size-2 fill-current" }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(Circle), { class: "size-2 fill-current" })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</span>`);
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              createVNode("span", { class: "pointer-events-none absolute left-2 flex size-3.5 items-center justify-center" }, [
                createVNode(unref(DropdownMenuItemIndicator), null, {
                  default: withCtx(() => [
                    createVNode(unref(Circle), { class: "size-2 fill-current" })
                  ]),
                  _: 1
                })
              ]),
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$m = _sfc_main$m.setup;
_sfc_main$m.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuRadioItem.vue");
  return _sfc_setup$m ? _sfc_setup$m(props, ctx) : void 0;
};
const _sfc_main$l = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuSeparator",
  __ssrInlineRender: true,
  props: {
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  setup(__props) {
    const props = __props;
    const delegatedProps = computed(() => {
      const { class: _, ...delegated } = props;
      return delegated;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuSeparator), mergeProps({ "data-slot": "dropdown-menu-separator" }, delegatedProps.value, {
        class: unref(cn)("bg-border -mx-1 my-1 h-px", props.class)
      }, _attrs), null, _parent));
    };
  }
});
const _sfc_setup$l = _sfc_main$l.setup;
_sfc_main$l.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuSeparator.vue");
  return _sfc_setup$l ? _sfc_setup$l(props, ctx) : void 0;
};
const _sfc_main$k = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuShortcut",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<span${ssrRenderAttrs(mergeProps({
        "data-slot": "dropdown-menu-shortcut",
        class: unref(cn)("text-muted-foreground ml-auto text-xs tracking-widest", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</span>`);
    };
  }
});
const _sfc_setup$k = _sfc_main$k.setup;
_sfc_main$k.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuShortcut.vue");
  return _sfc_setup$k ? _sfc_setup$k(props, ctx) : void 0;
};
const _sfc_main$j = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuSub",
  __ssrInlineRender: true,
  props: {
    defaultOpen: { type: Boolean },
    open: { type: Boolean }
  },
  emits: ["update:open"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const forwarded = useForwardPropsEmits(props, emits);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuSub), mergeProps({ "data-slot": "dropdown-menu-sub" }, unref(forwarded), _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$j = _sfc_main$j.setup;
_sfc_main$j.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuSub.vue");
  return _sfc_setup$j ? _sfc_setup$j(props, ctx) : void 0;
};
const _sfc_main$i = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuSubContent",
  __ssrInlineRender: true,
  props: {
    forceMount: { type: Boolean },
    loop: { type: Boolean },
    sideOffset: {},
    sideFlip: { type: Boolean },
    alignOffset: {},
    alignFlip: { type: Boolean },
    avoidCollisions: { type: Boolean },
    collisionBoundary: {},
    collisionPadding: {},
    arrowPadding: {},
    sticky: {},
    hideWhenDetached: { type: Boolean },
    positionStrategy: {},
    updatePositionStrategy: {},
    disableUpdateOnLayoutShift: { type: Boolean },
    prioritizePosition: { type: Boolean },
    reference: {},
    asChild: { type: Boolean },
    as: {},
    class: {}
  },
  emits: ["escapeKeyDown", "pointerDownOutside", "focusOutside", "interactOutside", "entryFocus", "openAutoFocus", "closeAutoFocus"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const delegatedProps = computed(() => {
      const { class: _, ...delegated } = props;
      return delegated;
    });
    const forwarded = useForwardPropsEmits(delegatedProps, emits);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuSubContent), mergeProps({ "data-slot": "dropdown-menu-sub-content" }, unref(forwarded), {
        class: unref(cn)("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 min-w-[8rem] origin-(--reka-dropdown-menu-content-transform-origin) overflow-hidden rounded-md border p-1 shadow-lg", props.class)
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$i = _sfc_main$i.setup;
_sfc_main$i.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuSubContent.vue");
  return _sfc_setup$i ? _sfc_setup$i(props, ctx) : void 0;
};
const _sfc_main$h = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuSubTrigger",
  __ssrInlineRender: true,
  props: {
    disabled: { type: Boolean },
    textValue: {},
    asChild: { type: Boolean },
    as: {},
    class: {},
    inset: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const delegatedProps = reactiveOmit(props, "class", "inset");
    const forwardedProps = useForwardProps(delegatedProps);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuSubTrigger), mergeProps({ "data-slot": "dropdown-menu-sub-trigger" }, unref(forwardedProps), {
        class: unref(cn)(
          "focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground flex cursor-default items-center rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[inset]:pl-8",
          props.class
        )
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
            _push2(ssrRenderComponent(unref(ChevronRight), { class: "ml-auto size-4" }, null, _parent2, _scopeId));
          } else {
            return [
              renderSlot(_ctx.$slots, "default"),
              createVNode(unref(ChevronRight), { class: "ml-auto size-4" })
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$h = _sfc_main$h.setup;
_sfc_main$h.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuSubTrigger.vue");
  return _sfc_setup$h ? _sfc_setup$h(props, ctx) : void 0;
};
const _sfc_main$g = /* @__PURE__ */ defineComponent({
  __name: "DropdownMenuTrigger",
  __ssrInlineRender: true,
  props: {
    disabled: { type: Boolean },
    asChild: { type: Boolean },
    as: {}
  },
  setup(__props) {
    const props = __props;
    const forwardedProps = useForwardProps(props);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(DropdownMenuTrigger), mergeProps({ "data-slot": "dropdown-menu-trigger" }, unref(forwardedProps), _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$g = _sfc_main$g.setup;
_sfc_main$g.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/dropdown-menu/DropdownMenuTrigger.vue");
  return _sfc_setup$g ? _sfc_setup$g(props, ctx) : void 0;
};
const edit$7 = (options) => ({
  url: edit$7.url(options),
  method: "get"
});
edit$7.definition = {
  methods: ["get", "head"],
  url: "/settings/profile"
};
edit$7.url = (options) => {
  return edit$7.definition.url + queryParams(options);
};
edit$7.get = (options) => ({
  url: edit$7.url(options),
  method: "get"
});
edit$7.head = (options) => ({
  url: edit$7.url(options),
  method: "head"
});
const editForm$7 = (options) => ({
  action: edit$7.url(options),
  method: "get"
});
editForm$7.get = (options) => ({
  action: edit$7.url(options),
  method: "get"
});
editForm$7.head = (options) => ({
  action: edit$7.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
edit$7.form = editForm$7;
const update$8 = (options) => ({
  url: update$8.url(options),
  method: "patch"
});
update$8.definition = {
  methods: ["patch"],
  url: "/settings/profile"
};
update$8.url = (options) => {
  return update$8.definition.url + queryParams(options);
};
update$8.patch = (options) => ({
  url: update$8.url(options),
  method: "patch"
});
const updateForm$8 = (options) => ({
  action: update$8.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PATCH",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm$8.patch = (options) => ({
  action: update$8.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PATCH",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
update$8.form = updateForm$8;
const destroy$7 = (options) => ({
  url: destroy$7.url(options),
  method: "delete"
});
destroy$7.definition = {
  methods: ["delete"],
  url: "/settings/profile"
};
destroy$7.url = (options) => {
  return destroy$7.definition.url + queryParams(options);
};
destroy$7.delete = (options) => ({
  url: destroy$7.url(options),
  method: "delete"
});
const destroyForm$7 = (options) => ({
  action: destroy$7.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroyForm$7.delete = (options) => ({
  action: destroy$7.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroy$7.form = destroyForm$7;
({
  edit: Object.assign(edit$7, edit$7),
  update: Object.assign(update$8, update$8),
  destroy: Object.assign(destroy$7, destroy$7)
});
const _sfc_main$f = /* @__PURE__ */ defineComponent({
  __name: "UserMenuContent",
  __ssrInlineRender: true,
  props: {
    user: {}
  },
  setup(__props) {
    const handleLogout = () => {
      router.flushAll();
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(_sfc_main$o), { class: "p-0 font-normal" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex items-center gap-2 px-1 py-1.5 text-left text-sm"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$u, {
              user: _ctx.user,
              "show-email": true
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center gap-2 px-1 py-1.5 text-left text-sm" }, [
                createVNode(_sfc_main$u, {
                  user: _ctx.user,
                  "show-email": true
                }, null, 8, ["user"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(unref(_sfc_main$l), null, null, _parent));
      _push(ssrRenderComponent(unref(_sfc_main$q), null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(_sfc_main$p), { "as-child": true }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Link), {
                    class: "block w-full",
                    href: unref(edit$7)(),
                    prefetch: "",
                    as: "button"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(Settings), { class: "mr-2 h-4 w-4" }, null, _parent4, _scopeId3));
                        _push4(` Settings `);
                      } else {
                        return [
                          createVNode(unref(Settings), { class: "mr-2 h-4 w-4" }),
                          createTextVNode(" Settings ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(Link), {
                      class: "block w-full",
                      href: unref(edit$7)(),
                      prefetch: "",
                      as: "button"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(Settings), { class: "mr-2 h-4 w-4" }),
                        createTextVNode(" Settings ")
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(_sfc_main$p), { "as-child": true }, {
                default: withCtx(() => [
                  createVNode(unref(Link), {
                    class: "block w-full",
                    href: unref(edit$7)(),
                    prefetch: "",
                    as: "button"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(Settings), { class: "mr-2 h-4 w-4" }),
                      createTextVNode(" Settings ")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(unref(_sfc_main$l), null, null, _parent));
      _push(ssrRenderComponent(unref(_sfc_main$p), { "as-child": true }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Link), {
              class: "block w-full",
              href: unref(logout)(),
              onClick: handleLogout,
              as: "button",
              "data-test": "logout-button"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(LogOut), { class: "mr-2 h-4 w-4" }, null, _parent3, _scopeId2));
                  _push3(` Log out `);
                } else {
                  return [
                    createVNode(unref(LogOut), { class: "mr-2 h-4 w-4" }),
                    createTextVNode(" Log out ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Link), {
                class: "block w-full",
                href: unref(logout)(),
                onClick: handleLogout,
                as: "button",
                "data-test": "logout-button"
              }, {
                default: withCtx(() => [
                  createVNode(unref(LogOut), { class: "mr-2 h-4 w-4" }),
                  createTextVNode(" Log out ")
                ]),
                _: 1
              }, 8, ["href"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/UserMenuContent.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const _sfc_main$e = /* @__PURE__ */ defineComponent({
  __name: "NavUser",
  __ssrInlineRender: true,
  setup(__props) {
    const page = usePage();
    const user = page.props.auth.user;
    const { isMobile, state } = useSidebar();
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(_sfc_main$V), _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(_sfc_main$M), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(_sfc_main$t), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(_sfc_main$g), { "as-child": "" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(_sfc_main$N), {
                                size: "lg",
                                class: "data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_sfc_main$u, { user: unref(user) }, null, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(unref(ChevronsUpDown), { class: "ml-auto size-4" }, null, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_sfc_main$u, { user: unref(user) }, null, 8, ["user"]),
                                      createVNode(unref(ChevronsUpDown), { class: "ml-auto size-4" })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(unref(_sfc_main$N), {
                                  size: "lg",
                                  class: "data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_sfc_main$u, { user: unref(user) }, null, 8, ["user"]),
                                    createVNode(unref(ChevronsUpDown), { class: "ml-auto size-4" })
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(unref(_sfc_main$r), {
                          class: "w-(--reka-dropdown-menu-trigger-width) min-w-56 rounded-lg",
                          side: unref(isMobile) ? "bottom" : unref(state) === "collapsed" ? "left" : "bottom",
                          align: "end",
                          "side-offset": 4
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_sfc_main$f, { user: unref(user) }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_sfc_main$f, { user: unref(user) }, null, 8, ["user"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(_sfc_main$g), { "as-child": "" }, {
                            default: withCtx(() => [
                              createVNode(unref(_sfc_main$N), {
                                size: "lg",
                                class: "data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_sfc_main$u, { user: unref(user) }, null, 8, ["user"]),
                                  createVNode(unref(ChevronsUpDown), { class: "ml-auto size-4" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$r), {
                            class: "w-(--reka-dropdown-menu-trigger-width) min-w-56 rounded-lg",
                            side: unref(isMobile) ? "bottom" : unref(state) === "collapsed" ? "left" : "bottom",
                            align: "end",
                            "side-offset": 4
                          }, {
                            default: withCtx(() => [
                              createVNode(_sfc_main$f, { user: unref(user) }, null, 8, ["user"])
                            ]),
                            _: 1
                          }, 8, ["side"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(_sfc_main$t), null, {
                      default: withCtx(() => [
                        createVNode(unref(_sfc_main$g), { "as-child": "" }, {
                          default: withCtx(() => [
                            createVNode(unref(_sfc_main$N), {
                              size: "lg",
                              class: "data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
                            }, {
                              default: withCtx(() => [
                                createVNode(_sfc_main$u, { user: unref(user) }, null, 8, ["user"]),
                                createVNode(unref(ChevronsUpDown), { class: "ml-auto size-4" })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(unref(_sfc_main$r), {
                          class: "w-(--reka-dropdown-menu-trigger-width) min-w-56 rounded-lg",
                          side: unref(isMobile) ? "bottom" : unref(state) === "collapsed" ? "left" : "bottom",
                          align: "end",
                          "side-offset": 4
                        }, {
                          default: withCtx(() => [
                            createVNode(_sfc_main$f, { user: unref(user) }, null, 8, ["user"])
                          ]),
                          _: 1
                        }, 8, ["side"])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(_sfc_main$M), null, {
                default: withCtx(() => [
                  createVNode(unref(_sfc_main$t), null, {
                    default: withCtx(() => [
                      createVNode(unref(_sfc_main$g), { "as-child": "" }, {
                        default: withCtx(() => [
                          createVNode(unref(_sfc_main$N), {
                            size: "lg",
                            class: "data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
                          }, {
                            default: withCtx(() => [
                              createVNode(_sfc_main$u, { user: unref(user) }, null, 8, ["user"]),
                              createVNode(unref(ChevronsUpDown), { class: "ml-auto size-4" })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(unref(_sfc_main$r), {
                        class: "w-(--reka-dropdown-menu-trigger-width) min-w-56 rounded-lg",
                        side: unref(isMobile) ? "bottom" : unref(state) === "collapsed" ? "left" : "bottom",
                        align: "end",
                        "side-offset": 4
                      }, {
                        default: withCtx(() => [
                          createVNode(_sfc_main$f, { user: unref(user) }, null, 8, ["user"])
                        ]),
                        _: 1
                      }, 8, ["side"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/NavUser.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const index$7 = (options) => ({
  url: index$7.url(options),
  method: "get"
});
index$7.definition = {
  methods: ["get", "head"],
  url: "/customers"
};
index$7.url = (options) => {
  return index$7.definition.url + queryParams(options);
};
index$7.get = (options) => ({
  url: index$7.url(options),
  method: "get"
});
index$7.head = (options) => ({
  url: index$7.url(options),
  method: "head"
});
const indexForm$7 = (options) => ({
  action: index$7.url(options),
  method: "get"
});
indexForm$7.get = (options) => ({
  action: index$7.url(options),
  method: "get"
});
indexForm$7.head = (options) => ({
  action: index$7.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
index$7.form = indexForm$7;
const create$6 = (options) => ({
  url: create$6.url(options),
  method: "get"
});
create$6.definition = {
  methods: ["get", "head"],
  url: "/customers/create"
};
create$6.url = (options) => {
  return create$6.definition.url + queryParams(options);
};
create$6.get = (options) => ({
  url: create$6.url(options),
  method: "get"
});
create$6.head = (options) => ({
  url: create$6.url(options),
  method: "head"
});
const createForm$6 = (options) => ({
  action: create$6.url(options),
  method: "get"
});
createForm$6.get = (options) => ({
  action: create$6.url(options),
  method: "get"
});
createForm$6.head = (options) => ({
  action: create$6.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create$6.form = createForm$6;
const store$6 = (options) => ({
  url: store$6.url(options),
  method: "post"
});
store$6.definition = {
  methods: ["post"],
  url: "/customers"
};
store$6.url = (options) => {
  return store$6.definition.url + queryParams(options);
};
store$6.post = (options) => ({
  url: store$6.url(options),
  method: "post"
});
const storeForm$6 = (options) => ({
  action: store$6.url(options),
  method: "post"
});
storeForm$6.post = (options) => ({
  action: store$6.url(options),
  method: "post"
});
store$6.form = storeForm$6;
const show$6 = (args, options) => ({
  url: show$6.url(args, options),
  method: "get"
});
show$6.definition = {
  methods: ["get", "head"],
  url: "/customers/{customer}"
};
show$6.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { customer: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { customer: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      customer: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    customer: typeof args.customer === "object" ? args.customer.id : args.customer
  };
  return show$6.definition.url.replace("{customer}", parsedArgs.customer.toString()).replace(/\/+$/, "") + queryParams(options);
};
show$6.get = (args, options) => ({
  url: show$6.url(args, options),
  method: "get"
});
show$6.head = (args, options) => ({
  url: show$6.url(args, options),
  method: "head"
});
const showForm$6 = (args, options) => ({
  action: show$6.url(args, options),
  method: "get"
});
showForm$6.get = (args, options) => ({
  action: show$6.url(args, options),
  method: "get"
});
showForm$6.head = (args, options) => ({
  action: show$6.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
show$6.form = showForm$6;
const edit$6 = (args, options) => ({
  url: edit$6.url(args, options),
  method: "get"
});
edit$6.definition = {
  methods: ["get", "head"],
  url: "/customers/{customer}/edit"
};
edit$6.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { customer: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { customer: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      customer: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    customer: typeof args.customer === "object" ? args.customer.id : args.customer
  };
  return edit$6.definition.url.replace("{customer}", parsedArgs.customer.toString()).replace(/\/+$/, "") + queryParams(options);
};
edit$6.get = (args, options) => ({
  url: edit$6.url(args, options),
  method: "get"
});
edit$6.head = (args, options) => ({
  url: edit$6.url(args, options),
  method: "head"
});
const editForm$6 = (args, options) => ({
  action: edit$6.url(args, options),
  method: "get"
});
editForm$6.get = (args, options) => ({
  action: edit$6.url(args, options),
  method: "get"
});
editForm$6.head = (args, options) => ({
  action: edit$6.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
edit$6.form = editForm$6;
const update$7 = (args, options) => ({
  url: update$7.url(args, options),
  method: "put"
});
update$7.definition = {
  methods: ["put"],
  url: "/customers/{customer}"
};
update$7.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { customer: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { customer: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      customer: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    customer: typeof args.customer === "object" ? args.customer.id : args.customer
  };
  return update$7.definition.url.replace("{customer}", parsedArgs.customer.toString()).replace(/\/+$/, "") + queryParams(options);
};
update$7.put = (args, options) => ({
  url: update$7.url(args, options),
  method: "put"
});
const updateForm$7 = (args, options) => ({
  action: update$7.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm$7.put = (args, options) => ({
  action: update$7.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
update$7.form = updateForm$7;
const destroy$6 = (args, options) => ({
  url: destroy$6.url(args, options),
  method: "delete"
});
destroy$6.definition = {
  methods: ["delete"],
  url: "/customers/{customer}"
};
destroy$6.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { customer: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { customer: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      customer: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    customer: typeof args.customer === "object" ? args.customer.id : args.customer
  };
  return destroy$6.definition.url.replace("{customer}", parsedArgs.customer.toString()).replace(/\/+$/, "") + queryParams(options);
};
destroy$6.delete = (args, options) => ({
  url: destroy$6.url(args, options),
  method: "delete"
});
const destroyForm$6 = (args, options) => ({
  action: destroy$6.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroyForm$6.delete = (args, options) => ({
  action: destroy$6.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroy$6.form = destroyForm$6;
const sendSMS = (args, options) => ({
  url: sendSMS.url(args, options),
  method: "post"
});
sendSMS.definition = {
  methods: ["post"],
  url: "/customers/{customer}/send-sms"
};
sendSMS.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { customer: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { customer: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      customer: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    customer: typeof args.customer === "object" ? args.customer.id : args.customer
  };
  return sendSMS.definition.url.replace("{customer}", parsedArgs.customer.toString()).replace(/\/+$/, "") + queryParams(options);
};
sendSMS.post = (args, options) => ({
  url: sendSMS.url(args, options),
  method: "post"
});
const sendSMSForm = (args, options) => ({
  action: sendSMS.url(args, options),
  method: "post"
});
sendSMSForm.post = (args, options) => ({
  action: sendSMS.url(args, options),
  method: "post"
});
sendSMS.form = sendSMSForm;
const customers = {
  index: Object.assign(index$7, index$7),
  create: Object.assign(create$6, create$6),
  store: Object.assign(store$6, store$6),
  show: Object.assign(show$6, show$6),
  edit: Object.assign(edit$6, edit$6),
  update: Object.assign(update$7, update$7),
  destroy: Object.assign(destroy$6, destroy$6),
  sendSMS: Object.assign(sendSMS, sendSMS)
};
const index$6 = (options) => ({
  url: index$6.url(options),
  method: "get"
});
index$6.definition = {
  methods: ["get", "head"],
  url: "/contacts"
};
index$6.url = (options) => {
  return index$6.definition.url + queryParams(options);
};
index$6.get = (options) => ({
  url: index$6.url(options),
  method: "get"
});
index$6.head = (options) => ({
  url: index$6.url(options),
  method: "head"
});
const indexForm$6 = (options) => ({
  action: index$6.url(options),
  method: "get"
});
indexForm$6.get = (options) => ({
  action: index$6.url(options),
  method: "get"
});
indexForm$6.head = (options) => ({
  action: index$6.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
index$6.form = indexForm$6;
const create$5 = (options) => ({
  url: create$5.url(options),
  method: "get"
});
create$5.definition = {
  methods: ["get", "head"],
  url: "/contacts/create"
};
create$5.url = (options) => {
  return create$5.definition.url + queryParams(options);
};
create$5.get = (options) => ({
  url: create$5.url(options),
  method: "get"
});
create$5.head = (options) => ({
  url: create$5.url(options),
  method: "head"
});
const createForm$5 = (options) => ({
  action: create$5.url(options),
  method: "get"
});
createForm$5.get = (options) => ({
  action: create$5.url(options),
  method: "get"
});
createForm$5.head = (options) => ({
  action: create$5.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create$5.form = createForm$5;
const store$5 = (options) => ({
  url: store$5.url(options),
  method: "post"
});
store$5.definition = {
  methods: ["post"],
  url: "/contacts"
};
store$5.url = (options) => {
  return store$5.definition.url + queryParams(options);
};
store$5.post = (options) => ({
  url: store$5.url(options),
  method: "post"
});
const storeForm$5 = (options) => ({
  action: store$5.url(options),
  method: "post"
});
storeForm$5.post = (options) => ({
  action: store$5.url(options),
  method: "post"
});
store$5.form = storeForm$5;
const show$5 = (args, options) => ({
  url: show$5.url(args, options),
  method: "get"
});
show$5.definition = {
  methods: ["get", "head"],
  url: "/contacts/{contact}"
};
show$5.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { contact: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { contact: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      contact: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    contact: typeof args.contact === "object" ? args.contact.id : args.contact
  };
  return show$5.definition.url.replace("{contact}", parsedArgs.contact.toString()).replace(/\/+$/, "") + queryParams(options);
};
show$5.get = (args, options) => ({
  url: show$5.url(args, options),
  method: "get"
});
show$5.head = (args, options) => ({
  url: show$5.url(args, options),
  method: "head"
});
const showForm$5 = (args, options) => ({
  action: show$5.url(args, options),
  method: "get"
});
showForm$5.get = (args, options) => ({
  action: show$5.url(args, options),
  method: "get"
});
showForm$5.head = (args, options) => ({
  action: show$5.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
show$5.form = showForm$5;
const edit$5 = (args, options) => ({
  url: edit$5.url(args, options),
  method: "get"
});
edit$5.definition = {
  methods: ["get", "head"],
  url: "/contacts/{contact}/edit"
};
edit$5.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { contact: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { contact: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      contact: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    contact: typeof args.contact === "object" ? args.contact.id : args.contact
  };
  return edit$5.definition.url.replace("{contact}", parsedArgs.contact.toString()).replace(/\/+$/, "") + queryParams(options);
};
edit$5.get = (args, options) => ({
  url: edit$5.url(args, options),
  method: "get"
});
edit$5.head = (args, options) => ({
  url: edit$5.url(args, options),
  method: "head"
});
const editForm$5 = (args, options) => ({
  action: edit$5.url(args, options),
  method: "get"
});
editForm$5.get = (args, options) => ({
  action: edit$5.url(args, options),
  method: "get"
});
editForm$5.head = (args, options) => ({
  action: edit$5.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
edit$5.form = editForm$5;
const update$6 = (args, options) => ({
  url: update$6.url(args, options),
  method: "put"
});
update$6.definition = {
  methods: ["put"],
  url: "/contacts/{contact}"
};
update$6.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { contact: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { contact: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      contact: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    contact: typeof args.contact === "object" ? args.contact.id : args.contact
  };
  return update$6.definition.url.replace("{contact}", parsedArgs.contact.toString()).replace(/\/+$/, "") + queryParams(options);
};
update$6.put = (args, options) => ({
  url: update$6.url(args, options),
  method: "put"
});
const updateForm$6 = (args, options) => ({
  action: update$6.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm$6.put = (args, options) => ({
  action: update$6.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
update$6.form = updateForm$6;
const destroy$5 = (args, options) => ({
  url: destroy$5.url(args, options),
  method: "delete"
});
destroy$5.definition = {
  methods: ["delete"],
  url: "/contacts/{contact}"
};
destroy$5.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { contact: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { contact: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      contact: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    contact: typeof args.contact === "object" ? args.contact.id : args.contact
  };
  return destroy$5.definition.url.replace("{contact}", parsedArgs.contact.toString()).replace(/\/+$/, "") + queryParams(options);
};
destroy$5.delete = (args, options) => ({
  url: destroy$5.url(args, options),
  method: "delete"
});
const destroyForm$5 = (args, options) => ({
  action: destroy$5.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroyForm$5.delete = (args, options) => ({
  action: destroy$5.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroy$5.form = destroyForm$5;
const sms = (args, options) => ({
  url: sms.url(args, options),
  method: "post"
});
sms.definition = {
  methods: ["post"],
  url: "/contacts/{contact}/sms"
};
sms.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { contact: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { contact: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      contact: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    contact: typeof args.contact === "object" ? args.contact.id : args.contact
  };
  return sms.definition.url.replace("{contact}", parsedArgs.contact.toString()).replace(/\/+$/, "") + queryParams(options);
};
sms.post = (args, options) => ({
  url: sms.url(args, options),
  method: "post"
});
const smsForm = (args, options) => ({
  action: sms.url(args, options),
  method: "post"
});
smsForm.post = (args, options) => ({
  action: sms.url(args, options),
  method: "post"
});
sms.form = smsForm;
const contacts = {
  index: Object.assign(index$6, index$6),
  create: Object.assign(create$5, create$5),
  store: Object.assign(store$5, store$5),
  show: Object.assign(show$5, show$5),
  edit: Object.assign(edit$5, edit$5),
  update: Object.assign(update$6, update$6),
  destroy: Object.assign(destroy$5, destroy$5),
  sms: Object.assign(sms, sms)
};
const index$5 = (options) => ({
  url: index$5.url(options),
  method: "get"
});
index$5.definition = {
  methods: ["get", "head"],
  url: "/products"
};
index$5.url = (options) => {
  return index$5.definition.url + queryParams(options);
};
index$5.get = (options) => ({
  url: index$5.url(options),
  method: "get"
});
index$5.head = (options) => ({
  url: index$5.url(options),
  method: "head"
});
const indexForm$5 = (options) => ({
  action: index$5.url(options),
  method: "get"
});
indexForm$5.get = (options) => ({
  action: index$5.url(options),
  method: "get"
});
indexForm$5.head = (options) => ({
  action: index$5.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
index$5.form = indexForm$5;
const create$4 = (options) => ({
  url: create$4.url(options),
  method: "get"
});
create$4.definition = {
  methods: ["get", "head"],
  url: "/products/create"
};
create$4.url = (options) => {
  return create$4.definition.url + queryParams(options);
};
create$4.get = (options) => ({
  url: create$4.url(options),
  method: "get"
});
create$4.head = (options) => ({
  url: create$4.url(options),
  method: "head"
});
const createForm$4 = (options) => ({
  action: create$4.url(options),
  method: "get"
});
createForm$4.get = (options) => ({
  action: create$4.url(options),
  method: "get"
});
createForm$4.head = (options) => ({
  action: create$4.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create$4.form = createForm$4;
const store$4 = (options) => ({
  url: store$4.url(options),
  method: "post"
});
store$4.definition = {
  methods: ["post"],
  url: "/products"
};
store$4.url = (options) => {
  return store$4.definition.url + queryParams(options);
};
store$4.post = (options) => ({
  url: store$4.url(options),
  method: "post"
});
const storeForm$4 = (options) => ({
  action: store$4.url(options),
  method: "post"
});
storeForm$4.post = (options) => ({
  action: store$4.url(options),
  method: "post"
});
store$4.form = storeForm$4;
const show$4 = (args, options) => ({
  url: show$4.url(args, options),
  method: "get"
});
show$4.definition = {
  methods: ["get", "head"],
  url: "/products/{product}"
};
show$4.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { product: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { product: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      product: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    product: typeof args.product === "object" ? args.product.id : args.product
  };
  return show$4.definition.url.replace("{product}", parsedArgs.product.toString()).replace(/\/+$/, "") + queryParams(options);
};
show$4.get = (args, options) => ({
  url: show$4.url(args, options),
  method: "get"
});
show$4.head = (args, options) => ({
  url: show$4.url(args, options),
  method: "head"
});
const showForm$4 = (args, options) => ({
  action: show$4.url(args, options),
  method: "get"
});
showForm$4.get = (args, options) => ({
  action: show$4.url(args, options),
  method: "get"
});
showForm$4.head = (args, options) => ({
  action: show$4.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
show$4.form = showForm$4;
const edit$4 = (args, options) => ({
  url: edit$4.url(args, options),
  method: "get"
});
edit$4.definition = {
  methods: ["get", "head"],
  url: "/products/{product}/edit"
};
edit$4.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { product: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { product: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      product: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    product: typeof args.product === "object" ? args.product.id : args.product
  };
  return edit$4.definition.url.replace("{product}", parsedArgs.product.toString()).replace(/\/+$/, "") + queryParams(options);
};
edit$4.get = (args, options) => ({
  url: edit$4.url(args, options),
  method: "get"
});
edit$4.head = (args, options) => ({
  url: edit$4.url(args, options),
  method: "head"
});
const editForm$4 = (args, options) => ({
  action: edit$4.url(args, options),
  method: "get"
});
editForm$4.get = (args, options) => ({
  action: edit$4.url(args, options),
  method: "get"
});
editForm$4.head = (args, options) => ({
  action: edit$4.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
edit$4.form = editForm$4;
const update$5 = (args, options) => ({
  url: update$5.url(args, options),
  method: "put"
});
update$5.definition = {
  methods: ["put"],
  url: "/products/{product}"
};
update$5.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { product: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { product: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      product: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    product: typeof args.product === "object" ? args.product.id : args.product
  };
  return update$5.definition.url.replace("{product}", parsedArgs.product.toString()).replace(/\/+$/, "") + queryParams(options);
};
update$5.put = (args, options) => ({
  url: update$5.url(args, options),
  method: "put"
});
const updateForm$5 = (args, options) => ({
  action: update$5.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm$5.put = (args, options) => ({
  action: update$5.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
update$5.form = updateForm$5;
const destroy$4 = (args, options) => ({
  url: destroy$4.url(args, options),
  method: "delete"
});
destroy$4.definition = {
  methods: ["delete"],
  url: "/products/{product}"
};
destroy$4.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { product: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { product: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      product: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    product: typeof args.product === "object" ? args.product.id : args.product
  };
  return destroy$4.definition.url.replace("{product}", parsedArgs.product.toString()).replace(/\/+$/, "") + queryParams(options);
};
destroy$4.delete = (args, options) => ({
  url: destroy$4.url(args, options),
  method: "delete"
});
const destroyForm$4 = (args, options) => ({
  action: destroy$4.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroyForm$4.delete = (args, options) => ({
  action: destroy$4.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroy$4.form = destroyForm$4;
const products = {
  index: Object.assign(index$5, index$5),
  create: Object.assign(create$4, create$4),
  store: Object.assign(store$4, store$4),
  show: Object.assign(show$4, show$4),
  edit: Object.assign(edit$4, edit$4),
  update: Object.assign(update$5, update$5),
  destroy: Object.assign(destroy$4, destroy$4)
};
const index$4 = (options) => ({
  url: index$4.url(options),
  method: "get"
});
index$4.definition = {
  methods: ["get", "head"],
  url: "/quotes"
};
index$4.url = (options) => {
  return index$4.definition.url + queryParams(options);
};
index$4.get = (options) => ({
  url: index$4.url(options),
  method: "get"
});
index$4.head = (options) => ({
  url: index$4.url(options),
  method: "head"
});
const indexForm$4 = (options) => ({
  action: index$4.url(options),
  method: "get"
});
indexForm$4.get = (options) => ({
  action: index$4.url(options),
  method: "get"
});
indexForm$4.head = (options) => ({
  action: index$4.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
index$4.form = indexForm$4;
const create$3 = (options) => ({
  url: create$3.url(options),
  method: "get"
});
create$3.definition = {
  methods: ["get", "head"],
  url: "/quotes/create"
};
create$3.url = (options) => {
  return create$3.definition.url + queryParams(options);
};
create$3.get = (options) => ({
  url: create$3.url(options),
  method: "get"
});
create$3.head = (options) => ({
  url: create$3.url(options),
  method: "head"
});
const createForm$3 = (options) => ({
  action: create$3.url(options),
  method: "get"
});
createForm$3.get = (options) => ({
  action: create$3.url(options),
  method: "get"
});
createForm$3.head = (options) => ({
  action: create$3.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create$3.form = createForm$3;
const store$3 = (options) => ({
  url: store$3.url(options),
  method: "post"
});
store$3.definition = {
  methods: ["post"],
  url: "/quotes"
};
store$3.url = (options) => {
  return store$3.definition.url + queryParams(options);
};
store$3.post = (options) => ({
  url: store$3.url(options),
  method: "post"
});
const storeForm$3 = (options) => ({
  action: store$3.url(options),
  method: "post"
});
storeForm$3.post = (options) => ({
  action: store$3.url(options),
  method: "post"
});
store$3.form = storeForm$3;
const show$3 = (args, options) => ({
  url: show$3.url(args, options),
  method: "get"
});
show$3.definition = {
  methods: ["get", "head"],
  url: "/quotes/{quote}"
};
show$3.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { quote: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { quote: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      quote: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    quote: typeof args.quote === "object" ? args.quote.id : args.quote
  };
  return show$3.definition.url.replace("{quote}", parsedArgs.quote.toString()).replace(/\/+$/, "") + queryParams(options);
};
show$3.get = (args, options) => ({
  url: show$3.url(args, options),
  method: "get"
});
show$3.head = (args, options) => ({
  url: show$3.url(args, options),
  method: "head"
});
const showForm$3 = (args, options) => ({
  action: show$3.url(args, options),
  method: "get"
});
showForm$3.get = (args, options) => ({
  action: show$3.url(args, options),
  method: "get"
});
showForm$3.head = (args, options) => ({
  action: show$3.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
show$3.form = showForm$3;
const edit$3 = (args, options) => ({
  url: edit$3.url(args, options),
  method: "get"
});
edit$3.definition = {
  methods: ["get", "head"],
  url: "/quotes/{quote}/edit"
};
edit$3.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { quote: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { quote: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      quote: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    quote: typeof args.quote === "object" ? args.quote.id : args.quote
  };
  return edit$3.definition.url.replace("{quote}", parsedArgs.quote.toString()).replace(/\/+$/, "") + queryParams(options);
};
edit$3.get = (args, options) => ({
  url: edit$3.url(args, options),
  method: "get"
});
edit$3.head = (args, options) => ({
  url: edit$3.url(args, options),
  method: "head"
});
const editForm$3 = (args, options) => ({
  action: edit$3.url(args, options),
  method: "get"
});
editForm$3.get = (args, options) => ({
  action: edit$3.url(args, options),
  method: "get"
});
editForm$3.head = (args, options) => ({
  action: edit$3.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
edit$3.form = editForm$3;
const update$4 = (args, options) => ({
  url: update$4.url(args, options),
  method: "put"
});
update$4.definition = {
  methods: ["put", "patch"],
  url: "/quotes/{quote}"
};
update$4.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { quote: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { quote: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      quote: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    quote: typeof args.quote === "object" ? args.quote.id : args.quote
  };
  return update$4.definition.url.replace("{quote}", parsedArgs.quote.toString()).replace(/\/+$/, "") + queryParams(options);
};
update$4.put = (args, options) => ({
  url: update$4.url(args, options),
  method: "put"
});
update$4.patch = (args, options) => ({
  url: update$4.url(args, options),
  method: "patch"
});
const updateForm$4 = (args, options) => ({
  action: update$4.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm$4.put = (args, options) => ({
  action: update$4.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm$4.patch = (args, options) => ({
  action: update$4.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PATCH",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
update$4.form = updateForm$4;
const destroy$3 = (args, options) => ({
  url: destroy$3.url(args, options),
  method: "delete"
});
destroy$3.definition = {
  methods: ["delete"],
  url: "/quotes/{quote}"
};
destroy$3.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { quote: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { quote: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      quote: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    quote: typeof args.quote === "object" ? args.quote.id : args.quote
  };
  return destroy$3.definition.url.replace("{quote}", parsedArgs.quote.toString()).replace(/\/+$/, "") + queryParams(options);
};
destroy$3.delete = (args, options) => ({
  url: destroy$3.url(args, options),
  method: "delete"
});
const destroyForm$3 = (args, options) => ({
  action: destroy$3.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroyForm$3.delete = (args, options) => ({
  action: destroy$3.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroy$3.form = destroyForm$3;
const convertToJobcard = (args, options) => ({
  url: convertToJobcard.url(args, options),
  method: "post"
});
convertToJobcard.definition = {
  methods: ["post"],
  url: "/quotes/{quote}/convert-to-jobcard"
};
convertToJobcard.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { quote: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { quote: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      quote: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    quote: typeof args.quote === "object" ? args.quote.id : args.quote
  };
  return convertToJobcard.definition.url.replace("{quote}", parsedArgs.quote.toString()).replace(/\/+$/, "") + queryParams(options);
};
convertToJobcard.post = (args, options) => ({
  url: convertToJobcard.url(args, options),
  method: "post"
});
const convertToJobcardForm = (args, options) => ({
  action: convertToJobcard.url(args, options),
  method: "post"
});
convertToJobcardForm.post = (args, options) => ({
  action: convertToJobcard.url(args, options),
  method: "post"
});
convertToJobcard.form = convertToJobcardForm;
const convertToInvoice = (args, options) => ({
  url: convertToInvoice.url(args, options),
  method: "post"
});
convertToInvoice.definition = {
  methods: ["post"],
  url: "/quotes/{quote}/convert-to-invoice"
};
convertToInvoice.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { quote: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { quote: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      quote: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    quote: typeof args.quote === "object" ? args.quote.id : args.quote
  };
  return convertToInvoice.definition.url.replace("{quote}", parsedArgs.quote.toString()).replace(/\/+$/, "") + queryParams(options);
};
convertToInvoice.post = (args, options) => ({
  url: convertToInvoice.url(args, options),
  method: "post"
});
const convertToInvoiceForm = (args, options) => ({
  action: convertToInvoice.url(args, options),
  method: "post"
});
convertToInvoiceForm.post = (args, options) => ({
  action: convertToInvoice.url(args, options),
  method: "post"
});
convertToInvoice.form = convertToInvoiceForm;
const downloadPdf$1 = (args, options) => ({
  url: downloadPdf$1.url(args, options),
  method: "get"
});
downloadPdf$1.definition = {
  methods: ["get", "head"],
  url: "/quotes/{quote}/download-pdf"
};
downloadPdf$1.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { quote: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { quote: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      quote: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    quote: typeof args.quote === "object" ? args.quote.id : args.quote
  };
  return downloadPdf$1.definition.url.replace("{quote}", parsedArgs.quote.toString()).replace(/\/+$/, "") + queryParams(options);
};
downloadPdf$1.get = (args, options) => ({
  url: downloadPdf$1.url(args, options),
  method: "get"
});
downloadPdf$1.head = (args, options) => ({
  url: downloadPdf$1.url(args, options),
  method: "head"
});
const downloadPdfForm$1 = (args, options) => ({
  action: downloadPdf$1.url(args, options),
  method: "get"
});
downloadPdfForm$1.get = (args, options) => ({
  action: downloadPdf$1.url(args, options),
  method: "get"
});
downloadPdfForm$1.head = (args, options) => ({
  action: downloadPdf$1.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
downloadPdf$1.form = downloadPdfForm$1;
const email$1 = (args, options) => ({
  url: email$1.url(args, options),
  method: "post"
});
email$1.definition = {
  methods: ["post"],
  url: "/quotes/{quote}/email"
};
email$1.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { quote: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { quote: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      quote: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    quote: typeof args.quote === "object" ? args.quote.id : args.quote
  };
  return email$1.definition.url.replace("{quote}", parsedArgs.quote.toString()).replace(/\/+$/, "") + queryParams(options);
};
email$1.post = (args, options) => ({
  url: email$1.url(args, options),
  method: "post"
});
const emailForm$1 = (args, options) => ({
  action: email$1.url(args, options),
  method: "post"
});
emailForm$1.post = (args, options) => ({
  action: email$1.url(args, options),
  method: "post"
});
email$1.form = emailForm$1;
const updateStatus$1 = (args, options) => ({
  url: updateStatus$1.url(args, options),
  method: "patch"
});
updateStatus$1.definition = {
  methods: ["patch"],
  url: "/quotes/{quote}/status"
};
updateStatus$1.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { quote: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { quote: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      quote: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    quote: typeof args.quote === "object" ? args.quote.id : args.quote
  };
  return updateStatus$1.definition.url.replace("{quote}", parsedArgs.quote.toString()).replace(/\/+$/, "") + queryParams(options);
};
updateStatus$1.patch = (args, options) => ({
  url: updateStatus$1.url(args, options),
  method: "patch"
});
const updateStatusForm$1 = (args, options) => ({
  action: updateStatus$1.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PATCH",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateStatusForm$1.patch = (args, options) => ({
  action: updateStatus$1.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PATCH",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateStatus$1.form = updateStatusForm$1;
const quotes = {
  index: Object.assign(index$4, index$4),
  create: Object.assign(create$3, create$3),
  store: Object.assign(store$3, store$3),
  show: Object.assign(show$3, show$3),
  edit: Object.assign(edit$3, edit$3),
  update: Object.assign(update$4, update$4),
  destroy: Object.assign(destroy$3, destroy$3),
  convertToJobcard: Object.assign(convertToJobcard, convertToJobcard),
  convertToInvoice: Object.assign(convertToInvoice, convertToInvoice),
  downloadPdf: Object.assign(downloadPdf$1, downloadPdf$1),
  email: Object.assign(email$1, email$1),
  updateStatus: Object.assign(updateStatus$1, updateStatus$1)
};
const index$3 = (options) => ({
  url: index$3.url(options),
  method: "get"
});
index$3.definition = {
  methods: ["get", "head"],
  url: "/invoices"
};
index$3.url = (options) => {
  return index$3.definition.url + queryParams(options);
};
index$3.get = (options) => ({
  url: index$3.url(options),
  method: "get"
});
index$3.head = (options) => ({
  url: index$3.url(options),
  method: "head"
});
const indexForm$3 = (options) => ({
  action: index$3.url(options),
  method: "get"
});
indexForm$3.get = (options) => ({
  action: index$3.url(options),
  method: "get"
});
indexForm$3.head = (options) => ({
  action: index$3.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
index$3.form = indexForm$3;
const create$2 = (options) => ({
  url: create$2.url(options),
  method: "get"
});
create$2.definition = {
  methods: ["get", "head"],
  url: "/invoices/create"
};
create$2.url = (options) => {
  return create$2.definition.url + queryParams(options);
};
create$2.get = (options) => ({
  url: create$2.url(options),
  method: "get"
});
create$2.head = (options) => ({
  url: create$2.url(options),
  method: "head"
});
const createForm$2 = (options) => ({
  action: create$2.url(options),
  method: "get"
});
createForm$2.get = (options) => ({
  action: create$2.url(options),
  method: "get"
});
createForm$2.head = (options) => ({
  action: create$2.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create$2.form = createForm$2;
const store$2 = (options) => ({
  url: store$2.url(options),
  method: "post"
});
store$2.definition = {
  methods: ["post"],
  url: "/invoices"
};
store$2.url = (options) => {
  return store$2.definition.url + queryParams(options);
};
store$2.post = (options) => ({
  url: store$2.url(options),
  method: "post"
});
const storeForm$2 = (options) => ({
  action: store$2.url(options),
  method: "post"
});
storeForm$2.post = (options) => ({
  action: store$2.url(options),
  method: "post"
});
store$2.form = storeForm$2;
const show$2 = (args, options) => ({
  url: show$2.url(args, options),
  method: "get"
});
show$2.definition = {
  methods: ["get", "head"],
  url: "/invoices/{invoice}"
};
show$2.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { invoice: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { invoice: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      invoice: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    invoice: typeof args.invoice === "object" ? args.invoice.id : args.invoice
  };
  return show$2.definition.url.replace("{invoice}", parsedArgs.invoice.toString()).replace(/\/+$/, "") + queryParams(options);
};
show$2.get = (args, options) => ({
  url: show$2.url(args, options),
  method: "get"
});
show$2.head = (args, options) => ({
  url: show$2.url(args, options),
  method: "head"
});
const showForm$2 = (args, options) => ({
  action: show$2.url(args, options),
  method: "get"
});
showForm$2.get = (args, options) => ({
  action: show$2.url(args, options),
  method: "get"
});
showForm$2.head = (args, options) => ({
  action: show$2.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
show$2.form = showForm$2;
const edit$2 = (args, options) => ({
  url: edit$2.url(args, options),
  method: "get"
});
edit$2.definition = {
  methods: ["get", "head"],
  url: "/invoices/{invoice}/edit"
};
edit$2.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { invoice: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { invoice: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      invoice: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    invoice: typeof args.invoice === "object" ? args.invoice.id : args.invoice
  };
  return edit$2.definition.url.replace("{invoice}", parsedArgs.invoice.toString()).replace(/\/+$/, "") + queryParams(options);
};
edit$2.get = (args, options) => ({
  url: edit$2.url(args, options),
  method: "get"
});
edit$2.head = (args, options) => ({
  url: edit$2.url(args, options),
  method: "head"
});
const editForm$2 = (args, options) => ({
  action: edit$2.url(args, options),
  method: "get"
});
editForm$2.get = (args, options) => ({
  action: edit$2.url(args, options),
  method: "get"
});
editForm$2.head = (args, options) => ({
  action: edit$2.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
edit$2.form = editForm$2;
const update$3 = (args, options) => ({
  url: update$3.url(args, options),
  method: "put"
});
update$3.definition = {
  methods: ["put", "patch"],
  url: "/invoices/{invoice}"
};
update$3.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { invoice: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { invoice: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      invoice: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    invoice: typeof args.invoice === "object" ? args.invoice.id : args.invoice
  };
  return update$3.definition.url.replace("{invoice}", parsedArgs.invoice.toString()).replace(/\/+$/, "") + queryParams(options);
};
update$3.put = (args, options) => ({
  url: update$3.url(args, options),
  method: "put"
});
update$3.patch = (args, options) => ({
  url: update$3.url(args, options),
  method: "patch"
});
const updateForm$3 = (args, options) => ({
  action: update$3.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm$3.put = (args, options) => ({
  action: update$3.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm$3.patch = (args, options) => ({
  action: update$3.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PATCH",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
update$3.form = updateForm$3;
const destroy$2 = (args, options) => ({
  url: destroy$2.url(args, options),
  method: "delete"
});
destroy$2.definition = {
  methods: ["delete"],
  url: "/invoices/{invoice}"
};
destroy$2.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { invoice: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { invoice: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      invoice: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    invoice: typeof args.invoice === "object" ? args.invoice.id : args.invoice
  };
  return destroy$2.definition.url.replace("{invoice}", parsedArgs.invoice.toString()).replace(/\/+$/, "") + queryParams(options);
};
destroy$2.delete = (args, options) => ({
  url: destroy$2.url(args, options),
  method: "delete"
});
const destroyForm$2 = (args, options) => ({
  action: destroy$2.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroyForm$2.delete = (args, options) => ({
  action: destroy$2.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroy$2.form = destroyForm$2;
const updateStatus = (args, options) => ({
  url: updateStatus.url(args, options),
  method: "patch"
});
updateStatus.definition = {
  methods: ["patch"],
  url: "/invoices/{invoice}/status"
};
updateStatus.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { invoice: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { invoice: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      invoice: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    invoice: typeof args.invoice === "object" ? args.invoice.id : args.invoice
  };
  return updateStatus.definition.url.replace("{invoice}", parsedArgs.invoice.toString()).replace(/\/+$/, "") + queryParams(options);
};
updateStatus.patch = (args, options) => ({
  url: updateStatus.url(args, options),
  method: "patch"
});
const updateStatusForm = (args, options) => ({
  action: updateStatus.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PATCH",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateStatusForm.patch = (args, options) => ({
  action: updateStatus.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PATCH",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateStatus.form = updateStatusForm;
const downloadPdf = (args, options) => ({
  url: downloadPdf.url(args, options),
  method: "get"
});
downloadPdf.definition = {
  methods: ["get", "head"],
  url: "/invoices/{invoice}/download-pdf"
};
downloadPdf.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { invoice: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { invoice: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      invoice: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    invoice: typeof args.invoice === "object" ? args.invoice.id : args.invoice
  };
  return downloadPdf.definition.url.replace("{invoice}", parsedArgs.invoice.toString()).replace(/\/+$/, "") + queryParams(options);
};
downloadPdf.get = (args, options) => ({
  url: downloadPdf.url(args, options),
  method: "get"
});
downloadPdf.head = (args, options) => ({
  url: downloadPdf.url(args, options),
  method: "head"
});
const downloadPdfForm = (args, options) => ({
  action: downloadPdf.url(args, options),
  method: "get"
});
downloadPdfForm.get = (args, options) => ({
  action: downloadPdf.url(args, options),
  method: "get"
});
downloadPdfForm.head = (args, options) => ({
  action: downloadPdf.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
downloadPdf.form = downloadPdfForm;
const email = (args, options) => ({
  url: email.url(args, options),
  method: "post"
});
email.definition = {
  methods: ["post"],
  url: "/invoices/{invoice}/email"
};
email.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { invoice: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { invoice: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      invoice: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    invoice: typeof args.invoice === "object" ? args.invoice.id : args.invoice
  };
  return email.definition.url.replace("{invoice}", parsedArgs.invoice.toString()).replace(/\/+$/, "") + queryParams(options);
};
email.post = (args, options) => ({
  url: email.url(args, options),
  method: "post"
});
const emailForm = (args, options) => ({
  action: email.url(args, options),
  method: "post"
});
emailForm.post = (args, options) => ({
  action: email.url(args, options),
  method: "post"
});
email.form = emailForm;
const invoices = {
  index: Object.assign(index$3, index$3),
  create: Object.assign(create$2, create$2),
  store: Object.assign(store$2, store$2),
  show: Object.assign(show$2, show$2),
  edit: Object.assign(edit$2, edit$2),
  update: Object.assign(update$3, update$3),
  destroy: Object.assign(destroy$2, destroy$2),
  updateStatus: Object.assign(updateStatus, updateStatus),
  downloadPdf: Object.assign(downloadPdf, downloadPdf),
  email: Object.assign(email, email)
};
const index$2 = (options) => ({
  url: index$2.url(options),
  method: "get"
});
index$2.definition = {
  methods: ["get", "head"],
  url: "/administration/categories"
};
index$2.url = (options) => {
  return index$2.definition.url + queryParams(options);
};
index$2.get = (options) => ({
  url: index$2.url(options),
  method: "get"
});
index$2.head = (options) => ({
  url: index$2.url(options),
  method: "head"
});
const indexForm$2 = (options) => ({
  action: index$2.url(options),
  method: "get"
});
indexForm$2.get = (options) => ({
  action: index$2.url(options),
  method: "get"
});
indexForm$2.head = (options) => ({
  action: index$2.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
index$2.form = indexForm$2;
const create$1 = (options) => ({
  url: create$1.url(options),
  method: "get"
});
create$1.definition = {
  methods: ["get", "head"],
  url: "/administration/categories/create"
};
create$1.url = (options) => {
  return create$1.definition.url + queryParams(options);
};
create$1.get = (options) => ({
  url: create$1.url(options),
  method: "get"
});
create$1.head = (options) => ({
  url: create$1.url(options),
  method: "head"
});
const createForm$1 = (options) => ({
  action: create$1.url(options),
  method: "get"
});
createForm$1.get = (options) => ({
  action: create$1.url(options),
  method: "get"
});
createForm$1.head = (options) => ({
  action: create$1.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create$1.form = createForm$1;
const store$1 = (options) => ({
  url: store$1.url(options),
  method: "post"
});
store$1.definition = {
  methods: ["post"],
  url: "/administration/categories"
};
store$1.url = (options) => {
  return store$1.definition.url + queryParams(options);
};
store$1.post = (options) => ({
  url: store$1.url(options),
  method: "post"
});
const storeForm$1 = (options) => ({
  action: store$1.url(options),
  method: "post"
});
storeForm$1.post = (options) => ({
  action: store$1.url(options),
  method: "post"
});
store$1.form = storeForm$1;
const show$1 = (args, options) => ({
  url: show$1.url(args, options),
  method: "get"
});
show$1.definition = {
  methods: ["get", "head"],
  url: "/administration/categories/{category}"
};
show$1.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { category: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { category: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      category: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    category: typeof args.category === "object" ? args.category.id : args.category
  };
  return show$1.definition.url.replace("{category}", parsedArgs.category.toString()).replace(/\/+$/, "") + queryParams(options);
};
show$1.get = (args, options) => ({
  url: show$1.url(args, options),
  method: "get"
});
show$1.head = (args, options) => ({
  url: show$1.url(args, options),
  method: "head"
});
const showForm$1 = (args, options) => ({
  action: show$1.url(args, options),
  method: "get"
});
showForm$1.get = (args, options) => ({
  action: show$1.url(args, options),
  method: "get"
});
showForm$1.head = (args, options) => ({
  action: show$1.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
show$1.form = showForm$1;
const edit$1 = (args, options) => ({
  url: edit$1.url(args, options),
  method: "get"
});
edit$1.definition = {
  methods: ["get", "head"],
  url: "/administration/categories/{category}/edit"
};
edit$1.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { category: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { category: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      category: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    category: typeof args.category === "object" ? args.category.id : args.category
  };
  return edit$1.definition.url.replace("{category}", parsedArgs.category.toString()).replace(/\/+$/, "") + queryParams(options);
};
edit$1.get = (args, options) => ({
  url: edit$1.url(args, options),
  method: "get"
});
edit$1.head = (args, options) => ({
  url: edit$1.url(args, options),
  method: "head"
});
const editForm$1 = (args, options) => ({
  action: edit$1.url(args, options),
  method: "get"
});
editForm$1.get = (args, options) => ({
  action: edit$1.url(args, options),
  method: "get"
});
editForm$1.head = (args, options) => ({
  action: edit$1.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
edit$1.form = editForm$1;
const update$2 = (args, options) => ({
  url: update$2.url(args, options),
  method: "put"
});
update$2.definition = {
  methods: ["put"],
  url: "/administration/categories/{category}"
};
update$2.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { category: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { category: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      category: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    category: typeof args.category === "object" ? args.category.id : args.category
  };
  return update$2.definition.url.replace("{category}", parsedArgs.category.toString()).replace(/\/+$/, "") + queryParams(options);
};
update$2.put = (args, options) => ({
  url: update$2.url(args, options),
  method: "put"
});
const updateForm$2 = (args, options) => ({
  action: update$2.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm$2.put = (args, options) => ({
  action: update$2.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
update$2.form = updateForm$2;
const destroy$1 = (args, options) => ({
  url: destroy$1.url(args, options),
  method: "delete"
});
destroy$1.definition = {
  methods: ["delete"],
  url: "/administration/categories/{category}"
};
destroy$1.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { category: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { category: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      category: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    category: typeof args.category === "object" ? args.category.id : args.category
  };
  return destroy$1.definition.url.replace("{category}", parsedArgs.category.toString()).replace(/\/+$/, "") + queryParams(options);
};
destroy$1.delete = (args, options) => ({
  url: destroy$1.url(args, options),
  method: "delete"
});
const destroyForm$1 = (args, options) => ({
  action: destroy$1.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroyForm$1.delete = (args, options) => ({
  action: destroy$1.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroy$1.form = destroyForm$1;
const categories = {
  index: Object.assign(index$2, index$2),
  create: Object.assign(create$1, create$1),
  store: Object.assign(store$1, store$1),
  show: Object.assign(show$1, show$1),
  edit: Object.assign(edit$1, edit$1),
  update: Object.assign(update$2, update$2),
  destroy: Object.assign(destroy$1, destroy$1)
};
const update$1 = (options) => ({
  url: update$1.url(options),
  method: "put"
});
update$1.definition = {
  methods: ["put"],
  url: "/administration/xero-settings"
};
update$1.url = (options) => {
  return update$1.definition.url + queryParams(options);
};
update$1.put = (options) => ({
  url: update$1.url(options),
  method: "put"
});
const updateForm$1 = (options) => ({
  action: update$1.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm$1.put = (options) => ({
  action: update$1.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
update$1.form = updateForm$1;
const xeroSettings$1 = {
  update: Object.assign(update$1, update$1)
};
const index$1 = (options) => ({
  url: index$1.url(options),
  method: "get"
});
index$1.definition = {
  methods: ["get", "head"],
  url: "/administration"
};
index$1.url = (options) => {
  return index$1.definition.url + queryParams(options);
};
index$1.get = (options) => ({
  url: index$1.url(options),
  method: "get"
});
index$1.head = (options) => ({
  url: index$1.url(options),
  method: "head"
});
const indexForm$1 = (options) => ({
  action: index$1.url(options),
  method: "get"
});
indexForm$1.get = (options) => ({
  action: index$1.url(options),
  method: "get"
});
indexForm$1.head = (options) => ({
  action: index$1.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
index$1.form = indexForm$1;
const xeroSettings = (options) => ({
  url: xeroSettings.url(options),
  method: "get"
});
xeroSettings.definition = {
  methods: ["get", "head"],
  url: "/administration/xero-settings"
};
xeroSettings.url = (options) => {
  return xeroSettings.definition.url + queryParams(options);
};
xeroSettings.get = (options) => ({
  url: xeroSettings.url(options),
  method: "get"
});
xeroSettings.head = (options) => ({
  url: xeroSettings.url(options),
  method: "head"
});
const xeroSettingsForm = (options) => ({
  action: xeroSettings.url(options),
  method: "get"
});
xeroSettingsForm.get = (options) => ({
  action: xeroSettings.url(options),
  method: "get"
});
xeroSettingsForm.head = (options) => ({
  action: xeroSettings.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
xeroSettings.form = xeroSettingsForm;
const administration = {
  categories: Object.assign(categories, categories),
  index: Object.assign(index$1, index$1),
  xeroSettings: Object.assign(xeroSettings, xeroSettings$1)
};
const _sfc_main$d = /* @__PURE__ */ defineComponent({
  __name: "AppSidebar",
  __ssrInlineRender: true,
  setup(__props) {
    const page = usePage();
    const currentCompany = computed(() => page.props.currentCompany);
    const mainNavItems = [
      {
        title: "Dashboard",
        href: dashboard().url,
        icon: LayoutGrid
      },
      {
        title: "Customers",
        href: customers.index().url,
        icon: Users
      },
      {
        title: "Contacts",
        href: contacts.index().url,
        icon: UserCheck
      },
      {
        title: "Products & Services",
        href: products.index().url,
        icon: Package
      },
      {
        title: "Jobcards",
        href: jobcards.index().url,
        icon: ClipboardList
      },
      {
        title: "Quotes",
        href: quotes.index().url,
        icon: FileText
      },
      {
        title: "Invoices",
        href: invoices.index().url,
        icon: Receipt
      }
    ];
    const footerNavItems = [
      {
        title: "Administration",
        href: administration.index().url,
        icon: Settings
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(_sfc_main$13), {
        collapsible: "icon",
        variant: "inset"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(_sfc_main$Y), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(_sfc_main$V), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(_sfc_main$M), null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(_sfc_main$N), {
                                size: "lg",
                                "as-child": ""
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(unref(Link), {
                                      href: unref(dashboard)().url
                                    }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`<div class="flex items-center gap-3"${_scopeId6}><div class="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-100"${_scopeId6}>`);
                                          if (currentCompany.value?.logo_path) {
                                            _push7(`<img${ssrRenderAttr("src", `/storage/${currentCompany.value.logo_path}`)}${ssrRenderAttr("alt", currentCompany.value.name)} class="h-6 w-6 rounded object-cover"${_scopeId6}>`);
                                          } else {
                                            _push7(ssrRenderComponent(unref(Building2), { class: "h-5 w-5 text-blue-600" }, null, _parent7, _scopeId6));
                                          }
                                          _push7(`</div><div class="flex flex-col"${_scopeId6}><span class="text-sm font-semibold text-gray-900"${_scopeId6}>${ssrInterpolate(currentCompany.value?.name || "Company")}</span><span class="text-xs text-gray-500"${_scopeId6}>Dashboard</span></div></div>`);
                                        } else {
                                          return [
                                            createVNode("div", { class: "flex items-center gap-3" }, [
                                              createVNode("div", { class: "flex h-8 w-8 items-center justify-center rounded-lg bg-blue-100" }, [
                                                currentCompany.value?.logo_path ? (openBlock(), createBlock("img", {
                                                  key: 0,
                                                  src: `/storage/${currentCompany.value.logo_path}`,
                                                  alt: currentCompany.value.name,
                                                  class: "h-6 w-6 rounded object-cover"
                                                }, null, 8, ["src", "alt"])) : (openBlock(), createBlock(unref(Building2), {
                                                  key: 1,
                                                  class: "h-5 w-5 text-blue-600"
                                                }))
                                              ]),
                                              createVNode("div", { class: "flex flex-col" }, [
                                                createVNode("span", { class: "text-sm font-semibold text-gray-900" }, toDisplayString(currentCompany.value?.name || "Company"), 1),
                                                createVNode("span", { class: "text-xs text-gray-500" }, "Dashboard")
                                              ])
                                            ])
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(unref(Link), {
                                        href: unref(dashboard)().url
                                      }, {
                                        default: withCtx(() => [
                                          createVNode("div", { class: "flex items-center gap-3" }, [
                                            createVNode("div", { class: "flex h-8 w-8 items-center justify-center rounded-lg bg-blue-100" }, [
                                              currentCompany.value?.logo_path ? (openBlock(), createBlock("img", {
                                                key: 0,
                                                src: `/storage/${currentCompany.value.logo_path}`,
                                                alt: currentCompany.value.name,
                                                class: "h-6 w-6 rounded object-cover"
                                              }, null, 8, ["src", "alt"])) : (openBlock(), createBlock(unref(Building2), {
                                                key: 1,
                                                class: "h-5 w-5 text-blue-600"
                                              }))
                                            ]),
                                            createVNode("div", { class: "flex flex-col" }, [
                                              createVNode("span", { class: "text-sm font-semibold text-gray-900" }, toDisplayString(currentCompany.value?.name || "Company"), 1),
                                              createVNode("span", { class: "text-xs text-gray-500" }, "Dashboard")
                                            ])
                                          ])
                                        ]),
                                        _: 1
                                      }, 8, ["href"])
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(unref(_sfc_main$N), {
                                  size: "lg",
                                  "as-child": ""
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(Link), {
                                      href: unref(dashboard)().url
                                    }, {
                                      default: withCtx(() => [
                                        createVNode("div", { class: "flex items-center gap-3" }, [
                                          createVNode("div", { class: "flex h-8 w-8 items-center justify-center rounded-lg bg-blue-100" }, [
                                            currentCompany.value?.logo_path ? (openBlock(), createBlock("img", {
                                              key: 0,
                                              src: `/storage/${currentCompany.value.logo_path}`,
                                              alt: currentCompany.value.name,
                                              class: "h-6 w-6 rounded object-cover"
                                            }, null, 8, ["src", "alt"])) : (openBlock(), createBlock(unref(Building2), {
                                              key: 1,
                                              class: "h-5 w-5 text-blue-600"
                                            }))
                                          ]),
                                          createVNode("div", { class: "flex flex-col" }, [
                                            createVNode("span", { class: "text-sm font-semibold text-gray-900" }, toDisplayString(currentCompany.value?.name || "Company"), 1),
                                            createVNode("span", { class: "text-xs text-gray-500" }, "Dashboard")
                                          ])
                                        ])
                                      ]),
                                      _: 1
                                    }, 8, ["href"])
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(_sfc_main$M), null, {
                            default: withCtx(() => [
                              createVNode(unref(_sfc_main$N), {
                                size: "lg",
                                "as-child": ""
                              }, {
                                default: withCtx(() => [
                                  createVNode(unref(Link), {
                                    href: unref(dashboard)().url
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("div", { class: "flex items-center gap-3" }, [
                                        createVNode("div", { class: "flex h-8 w-8 items-center justify-center rounded-lg bg-blue-100" }, [
                                          currentCompany.value?.logo_path ? (openBlock(), createBlock("img", {
                                            key: 0,
                                            src: `/storage/${currentCompany.value.logo_path}`,
                                            alt: currentCompany.value.name,
                                            class: "h-6 w-6 rounded object-cover"
                                          }, null, 8, ["src", "alt"])) : (openBlock(), createBlock(unref(Building2), {
                                            key: 1,
                                            class: "h-5 w-5 text-blue-600"
                                          }))
                                        ]),
                                        createVNode("div", { class: "flex flex-col" }, [
                                          createVNode("span", { class: "text-sm font-semibold text-gray-900" }, toDisplayString(currentCompany.value?.name || "Company"), 1),
                                          createVNode("span", { class: "text-xs text-gray-500" }, "Dashboard")
                                        ])
                                      ])
                                    ]),
                                    _: 1
                                  }, 8, ["href"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(_sfc_main$V), null, {
                      default: withCtx(() => [
                        createVNode(unref(_sfc_main$M), null, {
                          default: withCtx(() => [
                            createVNode(unref(_sfc_main$N), {
                              size: "lg",
                              "as-child": ""
                            }, {
                              default: withCtx(() => [
                                createVNode(unref(Link), {
                                  href: unref(dashboard)().url
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "flex items-center gap-3" }, [
                                      createVNode("div", { class: "flex h-8 w-8 items-center justify-center rounded-lg bg-blue-100" }, [
                                        currentCompany.value?.logo_path ? (openBlock(), createBlock("img", {
                                          key: 0,
                                          src: `/storage/${currentCompany.value.logo_path}`,
                                          alt: currentCompany.value.name,
                                          class: "h-6 w-6 rounded object-cover"
                                        }, null, 8, ["src", "alt"])) : (openBlock(), createBlock(unref(Building2), {
                                          key: 1,
                                          class: "h-5 w-5 text-blue-600"
                                        }))
                                      ]),
                                      createVNode("div", { class: "flex flex-col" }, [
                                        createVNode("span", { class: "text-sm font-semibold text-gray-900" }, toDisplayString(currentCompany.value?.name || "Company"), 1),
                                        createVNode("span", { class: "text-xs text-gray-500" }, "Dashboard")
                                      ])
                                    ])
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(_sfc_main$12), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_sfc_main$y, {
                    items: mainNavItems.filter((item) => {
                      if (item.title === "Customers") {
                        return _ctx.$page.props.auth?.abilities?.customers?.list;
                      }
                      if (item.title === "Contacts") {
                        return _ctx.$page.props.auth?.abilities?.contacts?.list;
                      }
                      if (item.title === "Products & Services") {
                        return _ctx.$page.props.auth?.abilities?.products?.list;
                      }
                      if (item.title === "Users") {
                        return _ctx.$page.props.auth?.abilities?.users?.list;
                      }
                      if (item.title === "Groups") {
                        return _ctx.$page.props.auth?.abilities?.groups?.list;
                      }
                      return true;
                    })
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_sfc_main$y, {
                      items: mainNavItems.filter((item) => {
                        if (item.title === "Customers") {
                          return _ctx.$page.props.auth?.abilities?.customers?.list;
                        }
                        if (item.title === "Contacts") {
                          return _ctx.$page.props.auth?.abilities?.contacts?.list;
                        }
                        if (item.title === "Products & Services") {
                          return _ctx.$page.props.auth?.abilities?.products?.list;
                        }
                        if (item.title === "Users") {
                          return _ctx.$page.props.auth?.abilities?.users?.list;
                        }
                        if (item.title === "Groups") {
                          return _ctx.$page.props.auth?.abilities?.groups?.list;
                        }
                        return true;
                      })
                    }, null, 8, ["items"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(_sfc_main$11), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_sfc_main$z, { items: footerNavItems }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$e, null, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_sfc_main$z, { items: footerNavItems }),
                    createVNode(_sfc_main$e)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(_sfc_main$Y), null, {
                default: withCtx(() => [
                  createVNode(unref(_sfc_main$V), null, {
                    default: withCtx(() => [
                      createVNode(unref(_sfc_main$M), null, {
                        default: withCtx(() => [
                          createVNode(unref(_sfc_main$N), {
                            size: "lg",
                            "as-child": ""
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: unref(dashboard)().url
                              }, {
                                default: withCtx(() => [
                                  createVNode("div", { class: "flex items-center gap-3" }, [
                                    createVNode("div", { class: "flex h-8 w-8 items-center justify-center rounded-lg bg-blue-100" }, [
                                      currentCompany.value?.logo_path ? (openBlock(), createBlock("img", {
                                        key: 0,
                                        src: `/storage/${currentCompany.value.logo_path}`,
                                        alt: currentCompany.value.name,
                                        class: "h-6 w-6 rounded object-cover"
                                      }, null, 8, ["src", "alt"])) : (openBlock(), createBlock(unref(Building2), {
                                        key: 1,
                                        class: "h-5 w-5 text-blue-600"
                                      }))
                                    ]),
                                    createVNode("div", { class: "flex flex-col" }, [
                                      createVNode("span", { class: "text-sm font-semibold text-gray-900" }, toDisplayString(currentCompany.value?.name || "Company"), 1),
                                      createVNode("span", { class: "text-xs text-gray-500" }, "Dashboard")
                                    ])
                                  ])
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(unref(_sfc_main$12), null, {
                default: withCtx(() => [
                  createVNode(_sfc_main$y, {
                    items: mainNavItems.filter((item) => {
                      if (item.title === "Customers") {
                        return _ctx.$page.props.auth?.abilities?.customers?.list;
                      }
                      if (item.title === "Contacts") {
                        return _ctx.$page.props.auth?.abilities?.contacts?.list;
                      }
                      if (item.title === "Products & Services") {
                        return _ctx.$page.props.auth?.abilities?.products?.list;
                      }
                      if (item.title === "Users") {
                        return _ctx.$page.props.auth?.abilities?.users?.list;
                      }
                      if (item.title === "Groups") {
                        return _ctx.$page.props.auth?.abilities?.groups?.list;
                      }
                      return true;
                    })
                  }, null, 8, ["items"])
                ]),
                _: 1
              }),
              createVNode(unref(_sfc_main$11), null, {
                default: withCtx(() => [
                  createVNode(_sfc_main$z, { items: footerNavItems }),
                  createVNode(_sfc_main$e)
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/AppSidebar.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const _sfc_main$c = /* @__PURE__ */ defineComponent({
  __name: "Breadcrumb",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<nav${ssrRenderAttrs(mergeProps({
        "aria-label": "breadcrumb",
        "data-slot": "breadcrumb",
        class: props.class
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</nav>`);
    };
  }
});
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/breadcrumb/Breadcrumb.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const _sfc_main$b = /* @__PURE__ */ defineComponent({
  __name: "BreadcrumbEllipsis",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<span${ssrRenderAttrs(mergeProps({
        "data-slot": "breadcrumb-ellipsis",
        role: "presentation",
        "aria-hidden": "true",
        class: unref(cn)("flex size-9 items-center justify-center", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, () => {
        _push(ssrRenderComponent(unref(MoreHorizontal), { class: "size-4" }, null, _parent));
      }, _push, _parent);
      _push(`<span class="sr-only">More</span></span>`);
    };
  }
});
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/breadcrumb/BreadcrumbEllipsis.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const _sfc_main$a = /* @__PURE__ */ defineComponent({
  __name: "BreadcrumbItem",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<li${ssrRenderAttrs(mergeProps({
        "data-slot": "breadcrumb-item",
        class: unref(cn)("inline-flex items-center gap-1.5", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</li>`);
    };
  }
});
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/breadcrumb/BreadcrumbItem.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  __name: "BreadcrumbLink",
  __ssrInlineRender: true,
  props: {
    asChild: { type: Boolean },
    as: { default: "a" },
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Primitive), mergeProps({
        "data-slot": "breadcrumb-link",
        as: _ctx.as,
        "as-child": _ctx.asChild,
        class: unref(cn)("hover:text-foreground transition-colors", props.class)
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/breadcrumb/BreadcrumbLink.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  __name: "BreadcrumbList",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<ol${ssrRenderAttrs(mergeProps({
        "data-slot": "breadcrumb-list",
        class: unref(cn)("text-muted-foreground flex flex-wrap items-center gap-1.5 text-sm break-words sm:gap-2.5", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</ol>`);
    };
  }
});
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/breadcrumb/BreadcrumbList.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "BreadcrumbPage",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<span${ssrRenderAttrs(mergeProps({
        "data-slot": "breadcrumb-page",
        role: "link",
        "aria-disabled": "true",
        "aria-current": "page",
        class: unref(cn)("text-foreground font-normal", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</span>`);
    };
  }
});
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/breadcrumb/BreadcrumbPage.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "BreadcrumbSeparator",
  __ssrInlineRender: true,
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<li${ssrRenderAttrs(mergeProps({
        "data-slot": "breadcrumb-separator",
        role: "presentation",
        "aria-hidden": "true",
        class: unref(cn)("[&>svg]:size-3.5", props.class)
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, () => {
        _push(ssrRenderComponent(unref(ChevronRight), null, null, _parent));
      }, _push, _parent);
      _push(`</li>`);
    };
  }
});
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/breadcrumb/BreadcrumbSeparator.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "Breadcrumbs",
  __ssrInlineRender: true,
  props: {
    breadcrumbs: {}
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(_sfc_main$c), _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(_sfc_main$8), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(_ctx.breadcrumbs, (item, index2) => {
                    _push3(`<!--[-->`);
                    _push3(ssrRenderComponent(unref(_sfc_main$a), null, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          if (index2 === _ctx.breadcrumbs.length - 1) {
                            _push4(ssrRenderComponent(unref(_sfc_main$7), null, {
                              default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                                if (_push5) {
                                  _push5(`${ssrInterpolate(item.title)}`);
                                } else {
                                  return [
                                    createTextVNode(toDisplayString(item.title), 1)
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent4, _scopeId3));
                          } else {
                            _push4(ssrRenderComponent(unref(_sfc_main$9), { "as-child": "" }, {
                              default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                                if (_push5) {
                                  _push5(ssrRenderComponent(unref(Link), {
                                    href: item.href ?? "#"
                                  }, {
                                    default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                      if (_push6) {
                                        _push6(`${ssrInterpolate(item.title)}`);
                                      } else {
                                        return [
                                          createTextVNode(toDisplayString(item.title), 1)
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent5, _scopeId4));
                                } else {
                                  return [
                                    createVNode(unref(Link), {
                                      href: item.href ?? "#"
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(item.title), 1)
                                      ]),
                                      _: 2
                                    }, 1032, ["href"])
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent4, _scopeId3));
                          }
                        } else {
                          return [
                            index2 === _ctx.breadcrumbs.length - 1 ? (openBlock(), createBlock(unref(_sfc_main$7), { key: 0 }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(item.title), 1)
                              ]),
                              _: 2
                            }, 1024)) : (openBlock(), createBlock(unref(_sfc_main$9), {
                              key: 1,
                              "as-child": ""
                            }, {
                              default: withCtx(() => [
                                createVNode(unref(Link), {
                                  href: item.href ?? "#"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(item.title), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["href"])
                              ]),
                              _: 2
                            }, 1024))
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                    if (index2 !== _ctx.breadcrumbs.length - 1) {
                      _push3(ssrRenderComponent(unref(_sfc_main$6), null, null, _parent3, _scopeId2));
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(`<!--]-->`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(_ctx.breadcrumbs, (item, index2) => {
                      return openBlock(), createBlock(Fragment, { key: index2 }, [
                        createVNode(unref(_sfc_main$a), null, {
                          default: withCtx(() => [
                            index2 === _ctx.breadcrumbs.length - 1 ? (openBlock(), createBlock(unref(_sfc_main$7), { key: 0 }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(item.title), 1)
                              ]),
                              _: 2
                            }, 1024)) : (openBlock(), createBlock(unref(_sfc_main$9), {
                              key: 1,
                              "as-child": ""
                            }, {
                              default: withCtx(() => [
                                createVNode(unref(Link), {
                                  href: item.href ?? "#"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(item.title), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["href"])
                              ]),
                              _: 2
                            }, 1024))
                          ]),
                          _: 2
                        }, 1024),
                        index2 !== _ctx.breadcrumbs.length - 1 ? (openBlock(), createBlock(unref(_sfc_main$6), { key: 0 })) : createCommentVNode("", true)
                      ], 64);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(_sfc_main$8), null, {
                default: withCtx(() => [
                  (openBlock(true), createBlock(Fragment, null, renderList(_ctx.breadcrumbs, (item, index2) => {
                    return openBlock(), createBlock(Fragment, { key: index2 }, [
                      createVNode(unref(_sfc_main$a), null, {
                        default: withCtx(() => [
                          index2 === _ctx.breadcrumbs.length - 1 ? (openBlock(), createBlock(unref(_sfc_main$7), { key: 0 }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(item.title), 1)
                            ]),
                            _: 2
                          }, 1024)) : (openBlock(), createBlock(unref(_sfc_main$9), {
                            key: 1,
                            "as-child": ""
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: item.href ?? "#"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(item.title), 1)
                                ]),
                                _: 2
                              }, 1032, ["href"])
                            ]),
                            _: 2
                          }, 1024))
                        ]),
                        _: 2
                      }, 1024),
                      index2 !== _ctx.breadcrumbs.length - 1 ? (openBlock(), createBlock(unref(_sfc_main$6), { key: 0 })) : createCommentVNode("", true)
                    ], 64);
                  }), 128))
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/Breadcrumbs.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const index = (options) => ({
  url: index.url(options),
  method: "get"
});
index.definition = {
  methods: ["get", "head"],
  url: "/company-settings"
};
index.url = (options) => {
  return index.definition.url + queryParams(options);
};
index.get = (options) => ({
  url: index.url(options),
  method: "get"
});
index.head = (options) => ({
  url: index.url(options),
  method: "head"
});
const indexForm = (options) => ({
  action: index.url(options),
  method: "get"
});
indexForm.get = (options) => ({
  action: index.url(options),
  method: "get"
});
indexForm.head = (options) => ({
  action: index.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
index.form = indexForm;
const create = (options) => ({
  url: create.url(options),
  method: "get"
});
create.definition = {
  methods: ["get", "head"],
  url: "/company-settings/create"
};
create.url = (options) => {
  return create.definition.url + queryParams(options);
};
create.get = (options) => ({
  url: create.url(options),
  method: "get"
});
create.head = (options) => ({
  url: create.url(options),
  method: "head"
});
const createForm = (options) => ({
  action: create.url(options),
  method: "get"
});
createForm.get = (options) => ({
  action: create.url(options),
  method: "get"
});
createForm.head = (options) => ({
  action: create.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create.form = createForm;
const store = (options) => ({
  url: store.url(options),
  method: "post"
});
store.definition = {
  methods: ["post"],
  url: "/company-settings"
};
store.url = (options) => {
  return store.definition.url + queryParams(options);
};
store.post = (options) => ({
  url: store.url(options),
  method: "post"
});
const storeForm = (options) => ({
  action: store.url(options),
  method: "post"
});
storeForm.post = (options) => ({
  action: store.url(options),
  method: "post"
});
store.form = storeForm;
const show = (args, options) => ({
  url: show.url(args, options),
  method: "get"
});
show.definition = {
  methods: ["get", "head"],
  url: "/company-settings/{company}"
};
show.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { company: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { company: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      company: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    company: typeof args.company === "object" ? args.company.id : args.company
  };
  return show.definition.url.replace("{company}", parsedArgs.company.toString()).replace(/\/+$/, "") + queryParams(options);
};
show.get = (args, options) => ({
  url: show.url(args, options),
  method: "get"
});
show.head = (args, options) => ({
  url: show.url(args, options),
  method: "head"
});
const showForm = (args, options) => ({
  action: show.url(args, options),
  method: "get"
});
showForm.get = (args, options) => ({
  action: show.url(args, options),
  method: "get"
});
showForm.head = (args, options) => ({
  action: show.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
show.form = showForm;
const edit = (args, options) => ({
  url: edit.url(args, options),
  method: "get"
});
edit.definition = {
  methods: ["get", "head"],
  url: "/company-settings/{company}/edit"
};
edit.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { company: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { company: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      company: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    company: typeof args.company === "object" ? args.company.id : args.company
  };
  return edit.definition.url.replace("{company}", parsedArgs.company.toString()).replace(/\/+$/, "") + queryParams(options);
};
edit.get = (args, options) => ({
  url: edit.url(args, options),
  method: "get"
});
edit.head = (args, options) => ({
  url: edit.url(args, options),
  method: "head"
});
const editForm = (args, options) => ({
  action: edit.url(args, options),
  method: "get"
});
editForm.get = (args, options) => ({
  action: edit.url(args, options),
  method: "get"
});
editForm.head = (args, options) => ({
  action: edit.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
edit.form = editForm;
const update = (args, options) => ({
  url: update.url(args, options),
  method: "put"
});
update.definition = {
  methods: ["put"],
  url: "/company-settings/{company}"
};
update.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { company: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { company: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      company: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    company: typeof args.company === "object" ? args.company.id : args.company
  };
  return update.definition.url.replace("{company}", parsedArgs.company.toString()).replace(/\/+$/, "") + queryParams(options);
};
update.put = (args, options) => ({
  url: update.url(args, options),
  method: "put"
});
const updateForm = (args, options) => ({
  action: update.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm.put = (args, options) => ({
  action: update.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
update.form = updateForm;
const uploadLogo = (args, options) => ({
  url: uploadLogo.url(args, options),
  method: "post"
});
uploadLogo.definition = {
  methods: ["post"],
  url: "/company-settings/{company}/upload-logo"
};
uploadLogo.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { company: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { company: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      company: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    company: typeof args.company === "object" ? args.company.id : args.company
  };
  return uploadLogo.definition.url.replace("{company}", parsedArgs.company.toString()).replace(/\/+$/, "") + queryParams(options);
};
uploadLogo.post = (args, options) => ({
  url: uploadLogo.url(args, options),
  method: "post"
});
const uploadLogoForm = (args, options) => ({
  action: uploadLogo.url(args, options),
  method: "post"
});
uploadLogoForm.post = (args, options) => ({
  action: uploadLogo.url(args, options),
  method: "post"
});
uploadLogo.form = uploadLogoForm;
const destroy = (args, options) => ({
  url: destroy.url(args, options),
  method: "delete"
});
destroy.definition = {
  methods: ["delete"],
  url: "/company-settings/{company}"
};
destroy.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { company: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { company: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      company: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    company: typeof args.company === "object" ? args.company.id : args.company
  };
  return destroy.definition.url.replace("{company}", parsedArgs.company.toString()).replace(/\/+$/, "") + queryParams(options);
};
destroy.delete = (args, options) => ({
  url: destroy.url(args, options),
  method: "delete"
});
const destroyForm = (args, options) => ({
  action: destroy.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroyForm.delete = (args, options) => ({
  action: destroy.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroy.form = destroyForm;
const setDefault = (args, options) => ({
  url: setDefault.url(args, options),
  method: "post"
});
setDefault.definition = {
  methods: ["post"],
  url: "/company-settings/{company}/set-default"
};
setDefault.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { company: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { company: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      company: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    company: typeof args.company === "object" ? args.company.id : args.company
  };
  return setDefault.definition.url.replace("{company}", parsedArgs.company.toString()).replace(/\/+$/, "") + queryParams(options);
};
setDefault.post = (args, options) => ({
  url: setDefault.url(args, options),
  method: "post"
});
const setDefaultForm = (args, options) => ({
  action: setDefault.url(args, options),
  method: "post"
});
setDefaultForm.post = (args, options) => ({
  action: setDefault.url(args, options),
  method: "post"
});
setDefault.form = setDefaultForm;
const switchMethod = (args, options) => ({
  url: switchMethod.url(args, options),
  method: "post"
});
switchMethod.definition = {
  methods: ["post"],
  url: "/company-settings/{company}/switch"
};
switchMethod.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { company: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { company: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      company: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    company: typeof args.company === "object" ? args.company.id : args.company
  };
  return switchMethod.definition.url.replace("{company}", parsedArgs.company.toString()).replace(/\/+$/, "") + queryParams(options);
};
switchMethod.post = (args, options) => ({
  url: switchMethod.url(args, options),
  method: "post"
});
const switchMethodForm = (args, options) => ({
  action: switchMethod.url(args, options),
  method: "post"
});
switchMethodForm.post = (args, options) => ({
  action: switchMethod.url(args, options),
  method: "post"
});
switchMethod.form = switchMethodForm;
const companySettings = {
  index: Object.assign(index, index),
  create: Object.assign(create, create),
  store: Object.assign(store, store),
  show: Object.assign(show, show),
  edit: Object.assign(edit, edit),
  update: Object.assign(update, update),
  uploadLogo: Object.assign(uploadLogo, uploadLogo),
  destroy: Object.assign(destroy, destroy),
  setDefault: Object.assign(setDefault, setDefault),
  switch: Object.assign(switchMethod, switchMethod)
};
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "CompanySwitcher",
  __ssrInlineRender: true,
  props: {
    currentCompany: {},
    companies: {}
  },
  setup(__props) {
    const props = __props;
    const isOpen = ref(false);
    function handleClickOutside(event) {
      const target = event.target;
      if (!target.closest(".company-switcher")) {
        isOpen.value = false;
      }
    }
    onMounted(() => {
      document.addEventListener("click", handleClickOutside);
    });
    onUnmounted(() => {
      document.removeEventListener("click", handleClickOutside);
    });
    return (_ctx, _push, _parent, _attrs) => {
      if (props.companies.length > 0) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "company-switcher relative" }, _attrs))} data-v-494b6989><button class="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2" data-v-494b6989><div class="flex h-6 w-6 items-center justify-center rounded bg-blue-100" data-v-494b6989>`);
        _push(ssrRenderComponent(unref(Building2), { class: "h-4 w-4 text-blue-600" }, null, _parent));
        _push(`</div><span class="font-medium text-gray-900" data-v-494b6989>${ssrInterpolate(props.currentCompany?.name || "Select Company")}</span>`);
        _push(ssrRenderComponent(unref(ChevronDown), {
          class: [
            "h-4 w-4 text-gray-400 transition-transform duration-200",
            isOpen.value ? "rotate-180" : ""
          ]
        }, null, _parent));
        _push(`</button>`);
        if (isOpen.value) {
          _push(`<div class="absolute right-0 top-full z-50 mt-2 w-64 rounded-lg border border-gray-200 bg-white shadow-lg" data-v-494b6989><div class="p-2" data-v-494b6989>`);
          if (props.companies.length > 1) {
            _push(`<div data-v-494b6989><div class="mb-2 px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wide" data-v-494b6989> Switch Company </div><div class="space-y-1" data-v-494b6989><!--[-->`);
            ssrRenderList(props.companies, (company) => {
              _push(`<button class="${ssrRenderClass([
                "flex w-full items-center gap-3 rounded-md px-3 py-2 text-left text-sm transition-colors",
                company.id === props.currentCompany?.id ? "bg-blue-50 text-blue-700" : "text-gray-700 hover:bg-gray-50"
              ])}" data-v-494b6989><div class="flex h-8 w-8 items-center justify-center rounded bg-blue-100" data-v-494b6989>`);
              _push(ssrRenderComponent(unref(Building2), { class: "h-4 w-4 text-blue-600" }, null, _parent));
              _push(`</div><div class="flex-1 min-w-0" data-v-494b6989><div class="flex items-center gap-2" data-v-494b6989><span class="font-medium truncate" data-v-494b6989>${ssrInterpolate(company.name)}</span>`);
              if (company.is_default) {
                _push(ssrRenderComponent(unref(Star), { class: "h-3 w-3 text-yellow-500 fill-current flex-shrink-0" }, null, _parent));
              } else {
                _push(`<!---->`);
              }
              _push(`</div></div>`);
              if (company.id === props.currentCompany?.id) {
                _push(`<div class="h-2 w-2 rounded-full bg-blue-600 flex-shrink-0" data-v-494b6989></div>`);
              } else {
                _push(`<!---->`);
              }
              _push(`</button>`);
            });
            _push(`<!--]--></div></div>`);
          } else {
            _push(`<div class="mb-2" data-v-494b6989><div class="px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wide" data-v-494b6989> Current Company </div><div class="flex items-center gap-3 rounded-md px-3 py-2 bg-blue-50" data-v-494b6989><div class="flex h-8 w-8 items-center justify-center rounded bg-blue-100" data-v-494b6989>`);
            _push(ssrRenderComponent(unref(Building2), { class: "h-4 w-4 text-blue-600" }, null, _parent));
            _push(`</div><div class="flex-1 min-w-0" data-v-494b6989><div class="flex items-center gap-2" data-v-494b6989><span class="font-medium text-blue-700 truncate" data-v-494b6989>${ssrInterpolate(props.currentCompany?.name)}</span>`);
            if (props.currentCompany?.is_default) {
              _push(ssrRenderComponent(unref(Star), { class: "h-3 w-3 text-yellow-500 fill-current flex-shrink-0" }, null, _parent));
            } else {
              _push(`<!---->`);
            }
            _push(`</div></div></div></div>`);
          }
          _push(`<div class="mt-3 border-t border-gray-100 pt-2" data-v-494b6989><a${ssrRenderAttr("href", unref(companySettings).index().url)} class="flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm text-gray-600 hover:bg-gray-50" data-v-494b6989>`);
          _push(ssrRenderComponent(unref(Building2), { class: "h-4 w-4" }, null, _parent));
          _push(`<span data-v-494b6989>Manage Companies</span></a></div></div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/CompanySwitcher.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const CompanySwitcher = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-494b6989"]]);
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "AppSidebarHeader",
  __ssrInlineRender: true,
  props: {
    breadcrumbs: { default: () => [] }
  },
  setup(__props) {
    const page = usePage();
    const currentCompany = computed(() => page.props.currentCompany);
    const companies = computed(() => page.props.companies || []);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<header${ssrRenderAttrs(mergeProps({ class: "flex h-16 shrink-0 items-center justify-between gap-2 border-b border-sidebar-border/70 px-6 transition-[width,height] ease-linear group-has-data-[collapsible=icon]/sidebar-wrapper:h-12 md:px-4" }, _attrs))}><div class="flex items-center gap-2">`);
      _push(ssrRenderComponent(unref(_sfc_main$C), { class: "-ml-1" }, null, _parent));
      if (_ctx.breadcrumbs && _ctx.breadcrumbs.length > 0) {
        _push(ssrRenderComponent(_sfc_main$5, { breadcrumbs: _ctx.breadcrumbs }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="flex items-center">`);
      _push(ssrRenderComponent(CompanySwitcher, {
        "current-company": currentCompany.value,
        companies: companies.value
      }, null, _parent));
      _push(`</div></header>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/AppSidebarHeader.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const permissionError = ref(null);
const showPermissionModal = ref(false);
function usePermissionError() {
  const showError = (error) => {
    permissionError.value = error;
    showPermissionModal.value = true;
  };
  const hideError = () => {
    showPermissionModal.value = false;
    permissionError.value = null;
  };
  const getModuleDisplayName = (module) => {
    const moduleNames = {
      "customers": "Customers",
      "users": "Users",
      "groups": "Groups",
      "contacts": "Contacts"
    };
    return moduleNames[module] || module.charAt(0).toUpperCase() + module.slice(1);
  };
  const getAbilityDisplayName = (ability) => {
    const abilityNames = {
      "list": "view the list of",
      "view": "view",
      "create": "create",
      "edit": "edit",
      "delete": "delete"
    };
    return abilityNames[ability] || ability;
  };
  return {
    permissionError,
    showPermissionModal,
    showError,
    hideError,
    getModuleDisplayName,
    getAbilityDisplayName
  };
}
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "PermissionErrorModal",
  __ssrInlineRender: true,
  setup(__props) {
    const { permissionError: permissionError2, showPermissionModal: showPermissionModal2, getModuleDisplayName, getAbilityDisplayName } = usePermissionError();
    const moduleDisplayName = computed(
      () => permissionError2.value ? getModuleDisplayName(permissionError2.value.module) : ""
    );
    const abilityDisplayName = computed(
      () => permissionError2.value ? getAbilityDisplayName(permissionError2.value.ability) : ""
    );
    return (_ctx, _push, _parent, _attrs) => {
      if (unref(showPermissionModal2)) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" }, _attrs))}><div class="relative mx-4 w-full max-w-md rounded-lg bg-white p-6 shadow-xl"><button class="absolute right-4 top-4 text-gray-400 hover:text-gray-600">`);
        _push(ssrRenderComponent(unref(X), { class: "h-5 w-5" }, null, _parent));
        _push(`</button><div class="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-red-100">`);
        _push(ssrRenderComponent(unref(ShieldX), { class: "h-8 w-8 text-red-600" }, null, _parent));
        _push(`</div><h2 class="mb-3 text-center text-xl font-semibold text-gray-900"> Access Denied </h2><p class="mb-4 text-center text-gray-600"> You don&#39;t have permission to ${ssrInterpolate(abilityDisplayName.value)} ${ssrInterpolate(moduleDisplayName.value)}. </p><div class="mb-6 rounded-lg bg-yellow-50 border border-yellow-200 p-3"><p class="text-sm text-yellow-800"><strong>Need access?</strong> Contact your administrator to request permission for this feature. </p></div><div class="flex gap-3"><button class="flex-1 rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"> OK </button></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/PermissionErrorModal.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "AppSidebarLayout",
  __ssrInlineRender: true,
  props: {
    breadcrumbs: { default: () => [] }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$A, mergeProps({ variant: "sidebar" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$d, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$B, {
              variant: "sidebar",
              class: "overflow-x-hidden"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_sfc_main$3, { breadcrumbs: _ctx.breadcrumbs }, null, _parent3, _scopeId2));
                  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push3, _parent3, _scopeId2);
                  _push3(ssrRenderComponent(_sfc_main$1f, null, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_sfc_main$3, { breadcrumbs: _ctx.breadcrumbs }, null, 8, ["breadcrumbs"]),
                    renderSlot(_ctx.$slots, "default"),
                    createVNode(_sfc_main$1f)
                  ];
                }
              }),
              _: 3
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$d),
              createVNode(_sfc_main$B, {
                variant: "sidebar",
                class: "overflow-x-hidden"
              }, {
                default: withCtx(() => [
                  createVNode(_sfc_main$3, { breadcrumbs: _ctx.breadcrumbs }, null, 8, ["breadcrumbs"]),
                  renderSlot(_ctx.$slots, "default"),
                  createVNode(_sfc_main$1f)
                ]),
                _: 3
              }),
              createVNode(_sfc_main$2)
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/layouts/app/AppSidebarLayout.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "AppLayout",
  __ssrInlineRender: true,
  props: {
    breadcrumbs: { default: () => [] }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, mergeProps({ breadcrumbs: _ctx.breadcrumbs }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/layouts/AppLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _,
  administration as a,
  customers as b,
  companySettings as c,
  contacts as d,
  edit$7 as e,
  _sfc_main$E as f,
  invoices as i,
  products as p,
  quotes as q
};
