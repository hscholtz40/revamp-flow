import { q as queryParams, a as applyUrlDefaults } from "./index--D7ld9AJ.js";
const index = (options) => ({
  url: index.url(options),
  method: "get"
});
index.definition = {
  methods: ["get", "head"],
  url: "/administration/sms-settings"
};
index.url = (options) => {
  return index.definition.url + queryParams(options);
};
index.get = (options) => ({
  url: index.url(options),
  method: "get"
});
index.head = (options) => ({
  url: index.url(options),
  method: "head"
});
const indexForm = (options) => ({
  action: index.url(options),
  method: "get"
});
indexForm.get = (options) => ({
  action: index.url(options),
  method: "get"
});
indexForm.head = (options) => ({
  action: index.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
index.form = indexForm;
const store = (options) => ({
  url: store.url(options),
  method: "post"
});
store.definition = {
  methods: ["post"],
  url: "/administration/sms-settings"
};
store.url = (options) => {
  return store.definition.url + queryParams(options);
};
store.post = (options) => ({
  url: store.url(options),
  method: "post"
});
const storeForm = (options) => ({
  action: store.url(options),
  method: "post"
});
storeForm.post = (options) => ({
  action: store.url(options),
  method: "post"
});
store.form = storeForm;
const update = (args, options) => ({
  url: update.url(args, options),
  method: "put"
});
update.definition = {
  methods: ["put"],
  url: "/administration/sms-settings/{smsSettings}"
};
update.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { smsSettings: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { smsSettings: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      smsSettings: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    smsSettings: typeof args.smsSettings === "object" ? args.smsSettings.id : args.smsSettings
  };
  return update.definition.url.replace("{smsSettings}", parsedArgs.smsSettings.toString()).replace(/\/+$/, "") + queryParams(options);
};
update.put = (args, options) => ({
  url: update.url(args, options),
  method: "put"
});
const updateForm = (args, options) => ({
  action: update.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm.put = (args, options) => ({
  action: update.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
update.form = updateForm;
const destroy = (args, options) => ({
  url: destroy.url(args, options),
  method: "delete"
});
destroy.definition = {
  methods: ["delete"],
  url: "/administration/sms-settings/{smsSettings}"
};
destroy.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { smsSettings: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { smsSettings: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      smsSettings: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    smsSettings: typeof args.smsSettings === "object" ? args.smsSettings.id : args.smsSettings
  };
  return destroy.definition.url.replace("{smsSettings}", parsedArgs.smsSettings.toString()).replace(/\/+$/, "") + queryParams(options);
};
destroy.delete = (args, options) => ({
  url: destroy.url(args, options),
  method: "delete"
});
const destroyForm = (args, options) => ({
  action: destroy.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroyForm.delete = (args, options) => ({
  action: destroy.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroy.form = destroyForm;
const smsSettings = {
  index: Object.assign(index, index),
  store: Object.assign(store, store),
  update: Object.assign(update, update),
  destroy: Object.assign(destroy, destroy)
};
export {
  smsSettings as s
};
