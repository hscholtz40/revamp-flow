import { defineComponent, ref, unref, withCtx, createVNode, withModifiers, withDirectives, createBlock, createCommentVNode, vModelText, openBlock, toDisplayString, vModelDynamic, vModelCheckbox, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderClass, ssrIncludeBooleanAttr, ssrInterpolate, ssrRenderDynamicModel, ssrLooseContain } from "vue/server-renderer";
import { _ as _sfc_main$1, a as administration } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head } from "@inertiajs/vue3";
import { s as smsSettings } from "./index-B_1IrT3r.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SMSSettings",
  __ssrInlineRender: true,
  props: {
    settings: {}
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      bulksms_username: props.settings?.bulksms_username || "",
      bulksms_password: props.settings?.bulksms_password || "",
      bulksms_sender_name: props.settings?.bulksms_sender_name || "",
      is_active: props.settings?.is_active ?? true
    });
    const showPassword = ref(false);
    const submit = () => {
      if (props.settings?.id) {
        form.put(smsSettings.update(props.settings.id).url);
      } else {
        form.post(smsSettings.store().url);
      }
    };
    const togglePasswordVisibility = () => {
      showPassword.value = !showPassword.value;
    };
    const handleActiveToggle = () => {
      if (!form.is_active) {
        form.bulksms_username = "";
        form.bulksms_password = "";
        form.bulksms_sender_name = "";
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "SMS Settings" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Administration", href: unref(administration).index().url },
          { title: "SMS Settings", href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-6"${_scopeId}><div class="mb-6"${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>SMS Settings</h1><p class="text-gray-600"${_scopeId}>Configure BulkSMS settings for sending SMS messages to customers.</p></div><div class="bg-white rounded-lg shadow p-6"${_scopeId}><form class="space-y-6"${_scopeId}><div class="grid gap-6 md:grid-cols-2"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-2"${_scopeId}> BulkSMS Username </label><input${ssrRenderAttr("value", unref(form).bulksms_username)} type="text" class="${ssrRenderClass([{ "opacity-50 cursor-not-allowed": !unref(form).is_active }, "w-full rounded border px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"])}"${ssrIncludeBooleanAttr(!unref(form).is_active) ? " disabled" : ""} placeholder="Your BulkSMS username"${ssrIncludeBooleanAttr(unref(form).is_active) ? " required" : ""}${_scopeId}>`);
            if (unref(form).errors.bulksms_username) {
              _push2(`<div class="text-sm text-red-600 mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.bulksms_username)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-2"${_scopeId}> BulkSMS Password </label><div class="relative"${_scopeId}><input${ssrRenderDynamicModel(showPassword.value ? "text" : "password", unref(form).bulksms_password, null)}${ssrRenderAttr("type", showPassword.value ? "text" : "password")} class="${ssrRenderClass([{ "opacity-50 cursor-not-allowed": !unref(form).is_active }, "w-full rounded border px-3 py-2 pr-10 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"])}"${ssrIncludeBooleanAttr(!unref(form).is_active) ? " disabled" : ""} placeholder="Your BulkSMS password"${ssrIncludeBooleanAttr(unref(form).is_active) ? " required" : ""}${_scopeId}><button type="button" class="absolute inset-y-0 right-0 pr-3 flex items-center"${_scopeId}><span class="text-gray-400 hover:text-gray-600"${_scopeId}>${ssrInterpolate(showPassword.value ? "Hide" : "Show")}</span></button></div>`);
            if (unref(form).errors.bulksms_password) {
              _push2(`<div class="text-sm text-red-600 mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.bulksms_password)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-2"${_scopeId}> Sender Name (Optional) </label><input${ssrRenderAttr("value", unref(form).bulksms_sender_name)} type="text" class="${ssrRenderClass([{ "opacity-50 cursor-not-allowed": !unref(form).is_active }, "w-full rounded border px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"])}"${ssrIncludeBooleanAttr(!unref(form).is_active) ? " disabled" : ""} placeholder="Company Name" maxlength="11"${_scopeId}><p class="text-sm text-gray-500 mt-1"${_scopeId}>Maximum 11 characters. This will appear as the sender name in SMS messages.</p>`);
            if (unref(form).errors.bulksms_sender_name) {
              _push2(`<div class="text-sm text-red-600 mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.bulksms_sender_name)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="flex items-center"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, null) : unref(form).is_active) ? " checked" : ""} type="checkbox" id="is_active" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"${_scopeId}><label for="is_active" class="ml-2 block text-sm text-gray-900"${_scopeId}> Enable SMS functionality </label></div><div class="flex items-center justify-between pt-6 border-t"${_scopeId}><div class="text-sm text-gray-500"${_scopeId}>`);
            if (!_ctx.settings) {
              _push2(`<p class="text-amber-600"${_scopeId}><strong${_scopeId}>Note:</strong> SMS functionality is not configured. Configure these settings to enable SMS sending. </p>`);
            } else if (!_ctx.settings.is_active) {
              _push2(`<p class="text-red-600"${_scopeId}><strong${_scopeId}>Note:</strong> SMS functionality is currently disabled. </p>`);
            } else {
              _push2(`<p class="text-green-600"${_scopeId}><strong${_scopeId}>Status:</strong> SMS functionality is active and configured. </p>`);
            }
            _push2(`</div><div class="flex gap-3"${_scopeId}><button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(form).processing ? "Saving..." : _ctx.settings ? "Update Settings" : "Save Settings")}</button></div></div></form></div><div class="mt-8 bg-blue-50 rounded-lg p-6"${_scopeId}><h3 class="text-lg font-medium text-blue-900 mb-3"${_scopeId}>BulkSMS Configuration Help</h3><div class="text-sm text-blue-800 space-y-2"${_scopeId}><p${_scopeId}><strong${_scopeId}>Getting Started:</strong></p><ul class="list-disc list-inside ml-4 space-y-1"${_scopeId}><li${_scopeId}>Sign up for a BulkSMS account at <a href="https://www.bulksms.com" target="_blank" class="underline"${_scopeId}>bulksms.com</a></li><li${_scopeId}>Get your username and password from your BulkSMS dashboard</li><li${_scopeId}>Enter your credentials above to enable SMS functionality</li></ul><p class="mt-4"${_scopeId}><strong${_scopeId}>Sender Name:</strong></p><ul class="list-disc list-inside ml-4 space-y-1"${_scopeId}><li${_scopeId}>Optional field for customizing the sender name in SMS messages</li><li${_scopeId}>Maximum 11 characters allowed</li><li${_scopeId}>If left empty, BulkSMS will use their default sender name</li></ul><p class="mt-4"${_scopeId}><strong${_scopeId}>Phone Number Format:</strong></p><ul class="list-disc list-inside ml-4 space-y-1"${_scopeId}><li${_scopeId}>South African numbers: +27XXXXXXXXX (automatically formatted)</li><li${_scopeId}>International numbers: +[country code][number]</li><li${_scopeId}>Example: +27123456789 for South Africa</li></ul></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "p-6" }, [
                createVNode("div", { class: "mb-6" }, [
                  createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "SMS Settings"),
                  createVNode("p", { class: "text-gray-600" }, "Configure BulkSMS settings for sending SMS messages to customers.")
                ]),
                createVNode("div", { class: "bg-white rounded-lg shadow p-6" }, [
                  createVNode("form", {
                    onSubmit: withModifiers(submit, ["prevent"]),
                    class: "space-y-6"
                  }, [
                    createVNode("div", { class: "grid gap-6 md:grid-cols-2" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-2" }, " BulkSMS Username "),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => unref(form).bulksms_username = $event,
                          type: "text",
                          class: ["w-full rounded border px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500", { "opacity-50 cursor-not-allowed": !unref(form).is_active }],
                          disabled: !unref(form).is_active,
                          placeholder: "Your BulkSMS username",
                          required: unref(form).is_active
                        }, null, 10, ["onUpdate:modelValue", "disabled", "required"]), [
                          [vModelText, unref(form).bulksms_username]
                        ]),
                        unref(form).errors.bulksms_username ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-sm text-red-600 mt-1"
                        }, toDisplayString(unref(form).errors.bulksms_username), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-2" }, " BulkSMS Password "),
                        createVNode("div", { class: "relative" }, [
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).bulksms_password = $event,
                            type: showPassword.value ? "text" : "password",
                            class: ["w-full rounded border px-3 py-2 pr-10 focus:ring-2 focus:ring-blue-500 focus:border-blue-500", { "opacity-50 cursor-not-allowed": !unref(form).is_active }],
                            disabled: !unref(form).is_active,
                            placeholder: "Your BulkSMS password",
                            required: unref(form).is_active
                          }, null, 10, ["onUpdate:modelValue", "type", "disabled", "required"]), [
                            [vModelDynamic, unref(form).bulksms_password]
                          ]),
                          createVNode("button", {
                            type: "button",
                            onClick: togglePasswordVisibility,
                            class: "absolute inset-y-0 right-0 pr-3 flex items-center"
                          }, [
                            createVNode("span", { class: "text-gray-400 hover:text-gray-600" }, toDisplayString(showPassword.value ? "Hide" : "Show"), 1)
                          ])
                        ]),
                        unref(form).errors.bulksms_password ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-sm text-red-600 mt-1"
                        }, toDisplayString(unref(form).errors.bulksms_password), 1)) : createCommentVNode("", true)
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-2" }, " Sender Name (Optional) "),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => unref(form).bulksms_sender_name = $event,
                        type: "text",
                        class: ["w-full rounded border px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500", { "opacity-50 cursor-not-allowed": !unref(form).is_active }],
                        disabled: !unref(form).is_active,
                        placeholder: "Company Name",
                        maxlength: "11"
                      }, null, 10, ["onUpdate:modelValue", "disabled"]), [
                        [vModelText, unref(form).bulksms_sender_name]
                      ]),
                      createVNode("p", { class: "text-sm text-gray-500 mt-1" }, "Maximum 11 characters. This will appear as the sender name in SMS messages."),
                      unref(form).errors.bulksms_sender_name ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-red-600 mt-1"
                      }, toDisplayString(unref(form).errors.bulksms_sender_name), 1)) : createCommentVNode("", true)
                    ]),
                    createVNode("div", { class: "flex items-center" }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => unref(form).is_active = $event,
                        onChange: handleActiveToggle,
                        type: "checkbox",
                        id: "is_active",
                        class: "h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      }, null, 40, ["onUpdate:modelValue"]), [
                        [vModelCheckbox, unref(form).is_active]
                      ]),
                      createVNode("label", {
                        for: "is_active",
                        class: "ml-2 block text-sm text-gray-900"
                      }, " Enable SMS functionality ")
                    ]),
                    createVNode("div", { class: "flex items-center justify-between pt-6 border-t" }, [
                      createVNode("div", { class: "text-sm text-gray-500" }, [
                        !_ctx.settings ? (openBlock(), createBlock("p", {
                          key: 0,
                          class: "text-amber-600"
                        }, [
                          createVNode("strong", null, "Note:"),
                          createTextVNode(" SMS functionality is not configured. Configure these settings to enable SMS sending. ")
                        ])) : !_ctx.settings.is_active ? (openBlock(), createBlock("p", {
                          key: 1,
                          class: "text-red-600"
                        }, [
                          createVNode("strong", null, "Note:"),
                          createTextVNode(" SMS functionality is currently disabled. ")
                        ])) : (openBlock(), createBlock("p", {
                          key: 2,
                          class: "text-green-600"
                        }, [
                          createVNode("strong", null, "Status:"),
                          createTextVNode(" SMS functionality is active and configured. ")
                        ]))
                      ]),
                      createVNode("div", { class: "flex gap-3" }, [
                        createVNode("button", {
                          type: "submit",
                          disabled: unref(form).processing,
                          class: "rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 disabled:opacity-50"
                        }, toDisplayString(unref(form).processing ? "Saving..." : _ctx.settings ? "Update Settings" : "Save Settings"), 9, ["disabled"])
                      ])
                    ])
                  ], 32)
                ]),
                createVNode("div", { class: "mt-8 bg-blue-50 rounded-lg p-6" }, [
                  createVNode("h3", { class: "text-lg font-medium text-blue-900 mb-3" }, "BulkSMS Configuration Help"),
                  createVNode("div", { class: "text-sm text-blue-800 space-y-2" }, [
                    createVNode("p", null, [
                      createVNode("strong", null, "Getting Started:")
                    ]),
                    createVNode("ul", { class: "list-disc list-inside ml-4 space-y-1" }, [
                      createVNode("li", null, [
                        createTextVNode("Sign up for a BulkSMS account at "),
                        createVNode("a", {
                          href: "https://www.bulksms.com",
                          target: "_blank",
                          class: "underline"
                        }, "bulksms.com")
                      ]),
                      createVNode("li", null, "Get your username and password from your BulkSMS dashboard"),
                      createVNode("li", null, "Enter your credentials above to enable SMS functionality")
                    ]),
                    createVNode("p", { class: "mt-4" }, [
                      createVNode("strong", null, "Sender Name:")
                    ]),
                    createVNode("ul", { class: "list-disc list-inside ml-4 space-y-1" }, [
                      createVNode("li", null, "Optional field for customizing the sender name in SMS messages"),
                      createVNode("li", null, "Maximum 11 characters allowed"),
                      createVNode("li", null, "If left empty, BulkSMS will use their default sender name")
                    ]),
                    createVNode("p", { class: "mt-4" }, [
                      createVNode("strong", null, "Phone Number Format:")
                    ]),
                    createVNode("ul", { class: "list-disc list-inside ml-4 space-y-1" }, [
                      createVNode("li", null, "South African numbers: +27XXXXXXXXX (automatically formatted)"),
                      createVNode("li", null, "International numbers: +[country code][number]"),
                      createVNode("li", null, "Example: +27123456789 for South Africa")
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/administration/SMSSettings.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
