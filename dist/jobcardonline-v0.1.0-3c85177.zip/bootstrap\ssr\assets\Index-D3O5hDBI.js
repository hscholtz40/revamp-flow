import { defineComponent, ref, watch, unref, withCtx, createTextVNode, createVNode, createBlock, createCommentVNode, toDisplayString, withDirectives, vModelText, openBlock, Fragment, renderList, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrIncludeBooleanAttr, ssrRenderClass } from "vue/server-renderer";
import { d as contacts, _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import { router, useForm, Head, Link } from "@inertiajs/vue3";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    contacts: {},
    filters: {},
    currentCompany: {}
  },
  setup(__props) {
    const props = __props;
    const search = ref(props.filters?.search ?? "");
    watch(search, (value) => {
      const params = {};
      if (value && value.trim()) {
        params.search = value.trim();
      }
      router.get(contacts.index().url, params, {
        preserveState: true,
        replace: true
      });
    });
    const showSMSModal = ref(false);
    const showSMSResultModal = ref(false);
    const selectedContact = ref(null);
    const smsResult = ref(null);
    const smsForm = useForm({
      message: ""
    });
    const openSMSModal = (contact) => {
      selectedContact.value = contact;
      smsForm.message = "";
      smsForm.clearErrors();
      showSMSModal.value = true;
    };
    const sendSMS = () => {
      if (!selectedContact.value) return;
      smsForm.post(contacts.sms(selectedContact.value.id).url, {
        onSuccess: (page) => {
          showSMSModal.value = false;
          smsResult.value = {
            success: true,
            message: `SMS sent successfully to ${selectedContact.value?.name} at ${selectedContact.value?.phone}`
          };
          showSMSResultModal.value = true;
        },
        onError: (errors) => {
          if (errors.message) {
            smsResult.value = {
              success: false,
              message: errors.message
            };
            showSMSModal.value = false;
            showSMSResultModal.value = true;
          }
        }
      });
    };
    const closeSMSResultModal = () => {
      showSMSResultModal.value = false;
      smsResult.value = null;
      selectedContact.value = null;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Contacts" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [{ title: "Contacts", href: unref(contacts).index().url }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-blue-50 border-b border-blue-200 px-4 py-3"${_scopeId}><div class="flex items-center gap-2 text-sm text-blue-700"${_scopeId}><span class="font-medium"${_scopeId}>Viewing contacts for:</span><span class="font-semibold"${_scopeId}>${ssrInterpolate(props.currentCompany.name)}</span></div></div><div class="p-4"${_scopeId}><div class="flex items-center justify-between gap-3 mb-6"${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>Contacts</h1>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(contacts).create().url,
              class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` New Contact `);
                } else {
                  return [
                    createTextVNode(" New Contact ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="bg-white rounded-lg border border-gray-200 shadow-sm p-4 mb-6"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Search</label><input${ssrRenderAttr("value", search.value)} type="search" placeholder="Search contacts..." class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"${_scopeId}></div><div class="flex items-end"${_scopeId}><button class="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"${_scopeId}> Clear Search </button></div></div></div><div class="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden"${_scopeId}><div class="overflow-x-auto"${_scopeId}><table class="w-full"${_scopeId}><thead class="bg-gray-50"${_scopeId}><tr${_scopeId}><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Name </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Customer </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Email </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Phone </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Position </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Primary </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Actions </th></tr></thead><tbody class="bg-white divide-y divide-gray-200"${_scopeId}><!--[-->`);
            ssrRenderList(props.contacts.data, (contact) => {
              _push2(`<tr class="hover:bg-gray-50"${_scopeId}><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(contact.name)}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(contact.customer.name)}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(contact.email || "-")}</div></td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"${_scopeId}>${ssrInterpolate(contact.phone || "-")}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"${_scopeId}>${ssrInterpolate(contact.position || "-")}</td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}>`);
              if (contact.is_primary) {
                _push2(`<span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800"${_scopeId}> Primary </span>`);
              } else {
                _push2(`<span class="text-gray-400"${_scopeId}>-</span>`);
              }
              _push2(`</td><td class="px-6 py-4 whitespace-nowrap text-sm font-medium"${_scopeId}><div class="flex items-center gap-2"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(contacts).show(contact.id).url,
                class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` View `);
                  } else {
                    return [
                      createTextVNode(" View ")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(contacts).edit(contact.id).url,
                class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Edit `);
                  } else {
                    return [
                      createTextVNode(" Edit ")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              if (contact.phone) {
                _push2(`<button class="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-green-700 bg-green-100 hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"${_scopeId}> SMS </button>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div>`);
            if (props.contacts.links) {
              _push2(`<div class="bg-white px-4 py-3 border-t border-gray-200"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div class="text-sm text-gray-700"${_scopeId}> Showing ${ssrInterpolate(props.contacts.from || 0)} to ${ssrInterpolate(props.contacts.to || 0)} of ${ssrInterpolate(props.contacts.total || 0)} results </div><div class="flex space-x-1"${_scopeId}><!--[-->`);
              ssrRenderList(props.contacts.links, (link) => {
                _push2(ssrRenderComponent(unref(Link), {
                  key: link.label,
                  href: link.url || "#",
                  class: [
                    "px-3 py-2 text-sm border rounded-md",
                    link.active ? "bg-blue-50 border-blue-500 text-blue-600" : "border-gray-300 text-gray-700 hover:bg-gray-50",
                    !link.url ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
                  ]
                }, null, _parent2, _scopeId));
              });
              _push2(`<!--]--></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
            if (showSMSModal.value) {
              _push2(`<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"${_scopeId}><div class="bg-white rounded-lg p-6 w-full max-w-md"${_scopeId}><div class="flex items-center justify-between mb-4"${_scopeId}><h3 class="text-lg font-semibold text-gray-900"${_scopeId}>Send SMS</h3><button class="text-gray-400 hover:text-gray-600"${_scopeId}><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"${_scopeId}></path></svg></button></div><form${_scopeId}><div class="mb-4"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-2"${_scopeId}>To:</label><div class="text-sm text-gray-900 bg-gray-50 p-3 rounded-md"${_scopeId}><div class="font-medium"${_scopeId}>${ssrInterpolate(selectedContact.value?.name)}</div><div class="text-gray-600"${_scopeId}>${ssrInterpolate(selectedContact.value?.phone)}</div><div class="text-gray-500"${_scopeId}>${ssrInterpolate(selectedContact.value?.customer?.name)}</div></div></div><div class="mb-4"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-2"${_scopeId}>Message:</label><textarea rows="4" class="w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" placeholder="Type your message here..." maxlength="160"${_scopeId}>${ssrInterpolate(unref(smsForm).message)}</textarea><div class="text-xs text-gray-500 mt-1"${_scopeId}>${ssrInterpolate(unref(smsForm).message.length)}/160 characters</div>`);
              if (unref(smsForm).errors.message) {
                _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(smsForm).errors.message)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="flex items-center justify-end gap-3"${_scopeId}><button type="button" class="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"${_scopeId}> Cancel </button><button type="submit"${ssrIncludeBooleanAttr(unref(smsForm).processing) ? " disabled" : ""} class="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(smsForm).processing ? "Sending..." : "Send SMS")}</button></div></form></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (showSMSResultModal.value) {
              _push2(`<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"${_scopeId}><div class="bg-white rounded-lg p-6 w-full max-w-md"${_scopeId}><div class="flex items-center mb-4"${_scopeId}>`);
              if (smsResult.value?.success) {
                _push2(`<div class="flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-3"${_scopeId}><svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"${_scopeId}></path></svg></div>`);
              } else {
                _push2(`<div class="flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-3"${_scopeId}><svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"${_scopeId}></path></svg></div>`);
              }
              _push2(`<h3 class="${ssrRenderClass([smsResult.value?.success ? "text-green-800" : "text-red-800", "text-lg font-semibold"])}"${_scopeId}>${ssrInterpolate(smsResult.value?.success ? "SMS Sent Successfully!" : "SMS Failed to Send")}</h3></div><div class="mb-6"${_scopeId}><p class="${ssrRenderClass([smsResult.value?.success ? "text-green-700" : "text-red-700", "text-gray-700"])}"${_scopeId}>${ssrInterpolate(smsResult.value?.message)}</p></div><div class="flex justify-end"${_scopeId}><button class="${ssrRenderClass([smsResult.value?.success ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500", "rounded-md px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2"])}"${_scopeId}> OK </button></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              createVNode("div", { class: "bg-blue-50 border-b border-blue-200 px-4 py-3" }, [
                createVNode("div", { class: "flex items-center gap-2 text-sm text-blue-700" }, [
                  createVNode("span", { class: "font-medium" }, "Viewing contacts for:"),
                  createVNode("span", { class: "font-semibold" }, toDisplayString(props.currentCompany.name), 1)
                ])
              ]),
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "flex items-center justify-between gap-3 mb-6" }, [
                  createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "Contacts"),
                  createVNode(unref(Link), {
                    href: unref(contacts).create().url,
                    class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" New Contact ")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ]),
                createVNode("div", { class: "bg-white rounded-lg border border-gray-200 shadow-sm p-4 mb-6" }, [
                  createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4" }, [
                    createVNode("div", null, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Search"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => search.value = $event,
                        type: "search",
                        placeholder: "Search contacts...",
                        class: "w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, search.value]
                      ])
                    ]),
                    createVNode("div", { class: "flex items-end" }, [
                      createVNode("button", {
                        onClick: ($event) => search.value = "",
                        class: "w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, " Clear Search ", 8, ["onClick"])
                    ])
                  ])
                ]),
                createVNode("div", { class: "bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden" }, [
                  createVNode("div", { class: "overflow-x-auto" }, [
                    createVNode("table", { class: "w-full" }, [
                      createVNode("thead", { class: "bg-gray-50" }, [
                        createVNode("tr", null, [
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Name "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Customer "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Email "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Phone "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Position "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Primary "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Actions ")
                        ])
                      ]),
                      createVNode("tbody", { class: "bg-white divide-y divide-gray-200" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(props.contacts.data, (contact) => {
                          return openBlock(), createBlock("tr", {
                            key: contact.id,
                            class: "hover:bg-gray-50"
                          }, [
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm font-medium text-gray-900" }, toDisplayString(contact.name), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(contact.customer.name), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(contact.email || "-"), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm text-gray-900" }, toDisplayString(contact.phone || "-"), 1),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm text-gray-900" }, toDisplayString(contact.position || "-"), 1),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              contact.is_primary ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800"
                              }, " Primary ")) : (openBlock(), createBlock("span", {
                                key: 1,
                                class: "text-gray-400"
                              }, "-"))
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm font-medium" }, [
                              createVNode("div", { class: "flex items-center gap-2" }, [
                                createVNode(unref(Link), {
                                  href: unref(contacts).show(contact.id).url,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" View ")
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(unref(Link), {
                                  href: unref(contacts).edit(contact.id).url,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Edit ")
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                contact.phone ? (openBlock(), createBlock("button", {
                                  key: 0,
                                  onClick: ($event) => openSMSModal(contact),
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-green-700 bg-green-100 hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                                }, " SMS ", 8, ["onClick"])) : createCommentVNode("", true)
                              ])
                            ])
                          ]);
                        }), 128))
                      ])
                    ])
                  ]),
                  props.contacts.links ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "bg-white px-4 py-3 border-t border-gray-200"
                  }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", { class: "text-sm text-gray-700" }, " Showing " + toDisplayString(props.contacts.from || 0) + " to " + toDisplayString(props.contacts.to || 0) + " of " + toDisplayString(props.contacts.total || 0) + " results ", 1),
                      createVNode("div", { class: "flex space-x-1" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(props.contacts.links, (link) => {
                          return openBlock(), createBlock(unref(Link), {
                            key: link.label,
                            href: link.url || "#",
                            innerHTML: link.label,
                            class: [
                              "px-3 py-2 text-sm border rounded-md",
                              link.active ? "bg-blue-50 border-blue-500 text-blue-600" : "border-gray-300 text-gray-700 hover:bg-gray-50",
                              !link.url ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
                            ]
                          }, null, 8, ["href", "innerHTML", "class"]);
                        }), 128))
                      ])
                    ])
                  ])) : createCommentVNode("", true)
                ])
              ]),
              showSMSModal.value ? (openBlock(), createBlock("div", {
                key: 0,
                class: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
              }, [
                createVNode("div", { class: "bg-white rounded-lg p-6 w-full max-w-md" }, [
                  createVNode("div", { class: "flex items-center justify-between mb-4" }, [
                    createVNode("h3", { class: "text-lg font-semibold text-gray-900" }, "Send SMS"),
                    createVNode("button", {
                      onClick: ($event) => showSMSModal.value = false,
                      class: "text-gray-400 hover:text-gray-600"
                    }, [
                      (openBlock(), createBlock("svg", {
                        class: "w-6 h-6",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        createVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M6 18L18 6M6 6l12 12"
                        })
                      ]))
                    ], 8, ["onClick"])
                  ]),
                  createVNode("form", {
                    onSubmit: withModifiers(sendSMS, ["prevent"])
                  }, [
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-2" }, "To:"),
                      createVNode("div", { class: "text-sm text-gray-900 bg-gray-50 p-3 rounded-md" }, [
                        createVNode("div", { class: "font-medium" }, toDisplayString(selectedContact.value?.name), 1),
                        createVNode("div", { class: "text-gray-600" }, toDisplayString(selectedContact.value?.phone), 1),
                        createVNode("div", { class: "text-gray-500" }, toDisplayString(selectedContact.value?.customer?.name), 1)
                      ])
                    ]),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-2" }, "Message:"),
                      withDirectives(createVNode("textarea", {
                        "onUpdate:modelValue": ($event) => unref(smsForm).message = $event,
                        rows: "4",
                        class: "w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500",
                        placeholder: "Type your message here...",
                        maxlength: "160"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(smsForm).message]
                      ]),
                      createVNode("div", { class: "text-xs text-gray-500 mt-1" }, toDisplayString(unref(smsForm).message.length) + "/160 characters", 1),
                      unref(smsForm).errors.message ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-red-600"
                      }, toDisplayString(unref(smsForm).errors.message), 1)) : createCommentVNode("", true)
                    ]),
                    createVNode("div", { class: "flex items-center justify-end gap-3" }, [
                      createVNode("button", {
                        type: "button",
                        onClick: ($event) => showSMSModal.value = false,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, " Cancel ", 8, ["onClick"]),
                      createVNode("button", {
                        type: "submit",
                        disabled: unref(smsForm).processing,
                        class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50"
                      }, toDisplayString(unref(smsForm).processing ? "Sending..." : "Send SMS"), 9, ["disabled"])
                    ])
                  ], 32)
                ])
              ])) : createCommentVNode("", true),
              showSMSResultModal.value ? (openBlock(), createBlock("div", {
                key: 1,
                class: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
              }, [
                createVNode("div", { class: "bg-white rounded-lg p-6 w-full max-w-md" }, [
                  createVNode("div", { class: "flex items-center mb-4" }, [
                    smsResult.value?.success ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-3"
                    }, [
                      (openBlock(), createBlock("svg", {
                        class: "w-6 h-6 text-green-600",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        createVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M5 13l4 4L19 7"
                        })
                      ]))
                    ])) : (openBlock(), createBlock("div", {
                      key: 1,
                      class: "flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-3"
                    }, [
                      (openBlock(), createBlock("svg", {
                        class: "w-6 h-6 text-red-600",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        createVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M6 18L18 6M6 6l12 12"
                        })
                      ]))
                    ])),
                    createVNode("h3", {
                      class: ["text-lg font-semibold", smsResult.value?.success ? "text-green-800" : "text-red-800"]
                    }, toDisplayString(smsResult.value?.success ? "SMS Sent Successfully!" : "SMS Failed to Send"), 3)
                  ]),
                  createVNode("div", { class: "mb-6" }, [
                    createVNode("p", {
                      class: ["text-gray-700", smsResult.value?.success ? "text-green-700" : "text-red-700"]
                    }, toDisplayString(smsResult.value?.message), 3)
                  ]),
                  createVNode("div", { class: "flex justify-end" }, [
                    createVNode("button", {
                      onClick: closeSMSResultModal,
                      class: ["rounded-md px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2", smsResult.value?.success ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500"]
                    }, " OK ", 2)
                  ])
                ])
              ])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/contacts/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
