import { defineComponent, ref, unref, withCtx, createVNode, createTextVNode, withModifiers, createBlock, createCommentVNode, openBlock, withDirectives, vModelText, toDisplayString, vModelCheckbox, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrIncludeBooleanAttr, ssrLooseContain } from "vue/server-renderer";
import { _ as _sfc_main$1, c as companySettings } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { ArrowLeft } from "lucide-vue-next";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Create",
  __ssrInlineRender: true,
  setup(__props) {
    const form = useForm({
      name: "",
      email: "",
      phone: "",
      address: "",
      city: "",
      state: "",
      postal_code: "",
      country: "",
      website: "",
      description: "",
      invoice_footer: "",
      jobcard_footer: "",
      quote_footer: "",
      default_invoice_terms: "",
      default_quote_terms: "",
      default_jobcard_terms: "",
      is_active: true,
      is_default: false,
      logo: null
    });
    const logoPreview = ref(null);
    function handleLogoChange(event) {
      const target = event.target;
      if (target.files && target.files[0]) {
        form.logo = target.files[0];
        const reader = new FileReader();
        reader.onload = (e) => {
          logoPreview.value = e.target?.result;
        };
        reader.readAsDataURL(target.files[0]);
      }
    }
    function submit() {
      form.post(companySettings.store().url, {
        forceFormData: true
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Create Company" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Administration", href: "/administration" },
          { title: "Company Settings", href: unref(companySettings).index().url },
          { title: "Create", href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-4"${_scopeId}><div class="mb-6 flex items-center gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(companySettings).index().url,
              class: "flex items-center gap-2 text-gray-600 hover:text-gray-900"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(ArrowLeft), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                  _push3(` Back to Companies `);
                } else {
                  return [
                    createVNode(unref(ArrowLeft), { class: "h-4 w-4" }),
                    createTextVNode(" Back to Companies ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="mx-auto max-w-4xl"${_scopeId}><div class="mb-6"${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>Create New Company</h1><p class="text-gray-600"${_scopeId}>Add a new company to your organization</p></div><form class="space-y-6"${_scopeId}><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Company Logo</h2><div class="flex items-center gap-6"${_scopeId}>`);
            if (logoPreview.value) {
              _push2(`<div class="h-20 w-20 overflow-hidden rounded-lg border"${_scopeId}><img${ssrRenderAttr("src", logoPreview.value)} alt="Company Logo" class="h-full w-full object-cover"${_scopeId}></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div${_scopeId}><input type="file" accept="image/*" class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"${_scopeId}><p class="mt-1 text-xs text-gray-500"${_scopeId}>PNG, JPG, GIF up to 2MB</p></div></div></div><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Company Information</h2><div class="grid gap-4 md:grid-cols-2"${_scopeId}><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Company Name *</label><input${ssrRenderAttr("value", unref(form).name)} type="text" class="w-full rounded border px-3 py-2" required${_scopeId}>`);
            if (unref(form).errors.name) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.name)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Email</label><input${ssrRenderAttr("value", unref(form).email)} type="email" class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.email) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.email)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Phone</label><input${ssrRenderAttr("value", unref(form).phone)} type="tel" class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.phone) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.phone)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Website</label><input${ssrRenderAttr("value", unref(form).website)} type="url" class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.website) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.website)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Address Information</h2><div class="space-y-4"${_scopeId}><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Address</label><textarea rows="3" class="w-full rounded border px-3 py-2"${_scopeId}>${ssrInterpolate(unref(form).address)}</textarea>`);
            if (unref(form).errors.address) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.address)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="grid gap-4 md:grid-cols-3"${_scopeId}><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>City</label><input${ssrRenderAttr("value", unref(form).city)} type="text" class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.city) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.city)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>State/Province</label><input${ssrRenderAttr("value", unref(form).state)} type="text" class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.state) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.state)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Postal Code</label><input${ssrRenderAttr("value", unref(form).postal_code)} type="text" class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.postal_code) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.postal_code)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Country</label><input${ssrRenderAttr("value", unref(form).country)} type="text" class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.country) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.country)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Description</h2><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Company Description</label><textarea rows="4" class="w-full rounded border px-3 py-2" placeholder="Tell us about your company..."${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea>`);
            if (unref(form).errors.description) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.description)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Document Footers</h2><p class="mb-4 text-sm text-gray-600"${_scopeId}>These footer texts will appear at the bottom of the respective PDF documents.</p><div class="space-y-6"${_scopeId}><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Invoice Footer</label><textarea rows="4" class="w-full rounded border px-3 py-2" placeholder="Enter footer text that will appear on invoice PDFs (e.g., payment terms, thank you message, etc.)"${_scopeId}>${ssrInterpolate(unref(form).invoice_footer)}</textarea>`);
            if (unref(form).errors.invoice_footer) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.invoice_footer)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<p class="mt-1 text-xs text-gray-500"${_scopeId}>This text will appear at the bottom of all invoice PDFs generated for this company.</p></div><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Quote Footer</label><textarea rows="4" class="w-full rounded border px-3 py-2" placeholder="Enter footer text that will appear on quote PDFs (e.g., validity period, terms, etc.)"${_scopeId}>${ssrInterpolate(unref(form).quote_footer)}</textarea>`);
            if (unref(form).errors.quote_footer) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.quote_footer)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<p class="mt-1 text-xs text-gray-500"${_scopeId}>This text will appear at the bottom of all quote PDFs generated for this company.</p></div><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Jobcard Footer</label><textarea rows="4" class="w-full rounded border px-3 py-2" placeholder="Enter footer text that will appear on jobcard PDFs (e.g., completion notes, warranty info, etc.)"${_scopeId}>${ssrInterpolate(unref(form).jobcard_footer)}</textarea>`);
            if (unref(form).errors.jobcard_footer) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.jobcard_footer)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<p class="mt-1 text-xs text-gray-500"${_scopeId}>This text will appear at the bottom of all jobcard PDFs generated for this company.</p></div></div></div><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Default Terms &amp; Conditions</h2><p class="mb-4 text-sm text-gray-600"${_scopeId}>These terms will be automatically populated when creating new documents. They can be customized for each individual document.</p><div class="space-y-6"${_scopeId}><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Default Invoice Terms</label><textarea rows="4" class="w-full rounded border px-3 py-2" placeholder="Enter default terms and conditions for invoices (e.g., payment terms, late fees, etc.)"${_scopeId}>${ssrInterpolate(unref(form).default_invoice_terms)}</textarea>`);
            if (unref(form).errors.default_invoice_terms) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.default_invoice_terms)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<p class="mt-1 text-xs text-gray-500"${_scopeId}>These terms will be pre-filled when creating new invoices.</p></div><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Default Quote Terms</label><textarea rows="4" class="w-full rounded border px-3 py-2" placeholder="Enter default terms and conditions for quotes (e.g., validity period, acceptance terms, etc.)"${_scopeId}>${ssrInterpolate(unref(form).default_quote_terms)}</textarea>`);
            if (unref(form).errors.default_quote_terms) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.default_quote_terms)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<p class="mt-1 text-xs text-gray-500"${_scopeId}>These terms will be pre-filled when creating new quotes.</p></div><div${_scopeId}><label class="mb-1 block text-sm font-medium"${_scopeId}>Default Jobcard Terms</label><textarea rows="4" class="w-full rounded border px-3 py-2" placeholder="Enter default terms and conditions for jobcards (e.g., warranty info, completion terms, etc.)"${_scopeId}>${ssrInterpolate(unref(form).default_jobcard_terms)}</textarea>`);
            if (unref(form).errors.default_jobcard_terms) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.default_jobcard_terms)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<p class="mt-1 text-xs text-gray-500"${_scopeId}>These terms will be pre-filled when creating new jobcards.</p></div></div></div><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Settings</h2><div class="space-y-4"${_scopeId}><div${_scopeId}><label class="flex items-center gap-2"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, null) : unref(form).is_active) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"${_scopeId}><span class="text-sm font-medium text-gray-700"${_scopeId}>Active (available for selection)</span></label></div><div${_scopeId}><label class="flex items-center gap-2"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_default) ? ssrLooseContain(unref(form).is_default, null) : unref(form).is_default) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"${_scopeId}><span class="text-sm font-medium text-gray-700"${_scopeId}>Set as default company</span></label></div></div></div><div class="flex items-center justify-end gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(companySettings).index().url,
              class: "rounded-md border border-gray-300 px-4 py-2 text-gray-700 hover:bg-gray-50"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Cancel `);
                } else {
                  return [
                    createTextVNode(" Cancel ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(form).processing ? "Creating..." : "Create Company")}</button></div></form></div></div>`);
          } else {
            return [
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "mb-6 flex items-center gap-4" }, [
                  createVNode(unref(Link), {
                    href: unref(companySettings).index().url,
                    class: "flex items-center gap-2 text-gray-600 hover:text-gray-900"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(ArrowLeft), { class: "h-4 w-4" }),
                      createTextVNode(" Back to Companies ")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ]),
                createVNode("div", { class: "mx-auto max-w-4xl" }, [
                  createVNode("div", { class: "mb-6" }, [
                    createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "Create New Company"),
                    createVNode("p", { class: "text-gray-600" }, "Add a new company to your organization")
                  ]),
                  createVNode("form", {
                    onSubmit: withModifiers(submit, ["prevent"]),
                    class: "space-y-6"
                  }, [
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Company Logo"),
                      createVNode("div", { class: "flex items-center gap-6" }, [
                        logoPreview.value ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "h-20 w-20 overflow-hidden rounded-lg border"
                        }, [
                          createVNode("img", {
                            src: logoPreview.value,
                            alt: "Company Logo",
                            class: "h-full w-full object-cover"
                          }, null, 8, ["src"])
                        ])) : createCommentVNode("", true),
                        createVNode("div", null, [
                          createVNode("input", {
                            type: "file",
                            accept: "image/*",
                            onChange: handleLogoChange,
                            class: "block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                          }, null, 32),
                          createVNode("p", { class: "mt-1 text-xs text-gray-500" }, "PNG, JPG, GIF up to 2MB")
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Company Information"),
                      createVNode("div", { class: "grid gap-4 md:grid-cols-2" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Company Name *"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            type: "text",
                            class: "w-full rounded border px-3 py-2",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).name]
                          ]),
                          unref(form).errors.name ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.name), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Email"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).email = $event,
                            type: "email",
                            class: "w-full rounded border px-3 py-2"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).email]
                          ]),
                          unref(form).errors.email ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.email), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Phone"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                            type: "tel",
                            class: "w-full rounded border px-3 py-2"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).phone]
                          ]),
                          unref(form).errors.phone ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.phone), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Website"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).website = $event,
                            type: "url",
                            class: "w-full rounded border px-3 py-2"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).website]
                          ]),
                          unref(form).errors.website ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.website), 1)) : createCommentVNode("", true)
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Address Information"),
                      createVNode("div", { class: "space-y-4" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Address"),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => unref(form).address = $event,
                            rows: "3",
                            class: "w-full rounded border px-3 py-2"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).address]
                          ]),
                          unref(form).errors.address ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.address), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "grid gap-4 md:grid-cols-3" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "mb-1 block text-sm font-medium" }, "City"),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).city = $event,
                              type: "text",
                              class: "w-full rounded border px-3 py-2"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).city]
                            ]),
                            unref(form).errors.city ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "mt-1 text-sm text-red-600"
                            }, toDisplayString(unref(form).errors.city), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "mb-1 block text-sm font-medium" }, "State/Province"),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).state = $event,
                              type: "text",
                              class: "w-full rounded border px-3 py-2"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).state]
                            ]),
                            unref(form).errors.state ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "mt-1 text-sm text-red-600"
                            }, toDisplayString(unref(form).errors.state), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Postal Code"),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).postal_code = $event,
                              type: "text",
                              class: "w-full rounded border px-3 py-2"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).postal_code]
                            ]),
                            unref(form).errors.postal_code ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "mt-1 text-sm text-red-600"
                            }, toDisplayString(unref(form).errors.postal_code), 1)) : createCommentVNode("", true)
                          ])
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Country"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).country = $event,
                            type: "text",
                            class: "w-full rounded border px-3 py-2"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).country]
                          ]),
                          unref(form).errors.country ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.country), 1)) : createCommentVNode("", true)
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Description"),
                      createVNode("div", null, [
                        createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Company Description"),
                        withDirectives(createVNode("textarea", {
                          "onUpdate:modelValue": ($event) => unref(form).description = $event,
                          rows: "4",
                          class: "w-full rounded border px-3 py-2",
                          placeholder: "Tell us about your company..."
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).description]
                        ]),
                        unref(form).errors.description ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "mt-1 text-sm text-red-600"
                        }, toDisplayString(unref(form).errors.description), 1)) : createCommentVNode("", true)
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Document Footers"),
                      createVNode("p", { class: "mb-4 text-sm text-gray-600" }, "These footer texts will appear at the bottom of the respective PDF documents."),
                      createVNode("div", { class: "space-y-6" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Invoice Footer"),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => unref(form).invoice_footer = $event,
                            rows: "4",
                            class: "w-full rounded border px-3 py-2",
                            placeholder: "Enter footer text that will appear on invoice PDFs (e.g., payment terms, thank you message, etc.)"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).invoice_footer]
                          ]),
                          unref(form).errors.invoice_footer ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.invoice_footer), 1)) : createCommentVNode("", true),
                          createVNode("p", { class: "mt-1 text-xs text-gray-500" }, "This text will appear at the bottom of all invoice PDFs generated for this company.")
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Quote Footer"),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => unref(form).quote_footer = $event,
                            rows: "4",
                            class: "w-full rounded border px-3 py-2",
                            placeholder: "Enter footer text that will appear on quote PDFs (e.g., validity period, terms, etc.)"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).quote_footer]
                          ]),
                          unref(form).errors.quote_footer ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.quote_footer), 1)) : createCommentVNode("", true),
                          createVNode("p", { class: "mt-1 text-xs text-gray-500" }, "This text will appear at the bottom of all quote PDFs generated for this company.")
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Jobcard Footer"),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => unref(form).jobcard_footer = $event,
                            rows: "4",
                            class: "w-full rounded border px-3 py-2",
                            placeholder: "Enter footer text that will appear on jobcard PDFs (e.g., completion notes, warranty info, etc.)"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).jobcard_footer]
                          ]),
                          unref(form).errors.jobcard_footer ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.jobcard_footer), 1)) : createCommentVNode("", true),
                          createVNode("p", { class: "mt-1 text-xs text-gray-500" }, "This text will appear at the bottom of all jobcard PDFs generated for this company.")
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Default Terms & Conditions"),
                      createVNode("p", { class: "mb-4 text-sm text-gray-600" }, "These terms will be automatically populated when creating new documents. They can be customized for each individual document."),
                      createVNode("div", { class: "space-y-6" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Default Invoice Terms"),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => unref(form).default_invoice_terms = $event,
                            rows: "4",
                            class: "w-full rounded border px-3 py-2",
                            placeholder: "Enter default terms and conditions for invoices (e.g., payment terms, late fees, etc.)"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).default_invoice_terms]
                          ]),
                          unref(form).errors.default_invoice_terms ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.default_invoice_terms), 1)) : createCommentVNode("", true),
                          createVNode("p", { class: "mt-1 text-xs text-gray-500" }, "These terms will be pre-filled when creating new invoices.")
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Default Quote Terms"),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => unref(form).default_quote_terms = $event,
                            rows: "4",
                            class: "w-full rounded border px-3 py-2",
                            placeholder: "Enter default terms and conditions for quotes (e.g., validity period, acceptance terms, etc.)"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).default_quote_terms]
                          ]),
                          unref(form).errors.default_quote_terms ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.default_quote_terms), 1)) : createCommentVNode("", true),
                          createVNode("p", { class: "mt-1 text-xs text-gray-500" }, "These terms will be pre-filled when creating new quotes.")
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "mb-1 block text-sm font-medium" }, "Default Jobcard Terms"),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => unref(form).default_jobcard_terms = $event,
                            rows: "4",
                            class: "w-full rounded border px-3 py-2",
                            placeholder: "Enter default terms and conditions for jobcards (e.g., warranty info, completion terms, etc.)"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).default_jobcard_terms]
                          ]),
                          unref(form).errors.default_jobcard_terms ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.default_jobcard_terms), 1)) : createCommentVNode("", true),
                          createVNode("p", { class: "mt-1 text-xs text-gray-500" }, "These terms will be pre-filled when creating new jobcards.")
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Settings"),
                      createVNode("div", { class: "space-y-4" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "flex items-center gap-2" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).is_active = $event,
                              type: "checkbox",
                              class: "rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelCheckbox, unref(form).is_active]
                            ]),
                            createVNode("span", { class: "text-sm font-medium text-gray-700" }, "Active (available for selection)")
                          ])
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "flex items-center gap-2" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).is_default = $event,
                              type: "checkbox",
                              class: "rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelCheckbox, unref(form).is_default]
                            ]),
                            createVNode("span", { class: "text-sm font-medium text-gray-700" }, "Set as default company")
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "flex items-center justify-end gap-4" }, [
                      createVNode(unref(Link), {
                        href: unref(companySettings).index().url,
                        class: "rounded-md border border-gray-300 px-4 py-2 text-gray-700 hover:bg-gray-50"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Cancel ")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createVNode("button", {
                        type: "submit",
                        disabled: unref(form).processing,
                        class: "rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 disabled:opacity-50"
                      }, toDisplayString(unref(form).processing ? "Creating..." : "Create Company"), 9, ["disabled"])
                    ])
                  ], 32)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/company-settings/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
