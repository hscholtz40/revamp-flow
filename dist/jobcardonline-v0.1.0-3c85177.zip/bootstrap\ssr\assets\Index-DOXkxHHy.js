import { defineComponent, ref, watch, unref, withCtx, createTextVNode, createVNode, withDirectives, vModelText, createBlock, openBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import { router, Head, Link } from "@inertiajs/vue3";
import { u as users } from "./index-B7IvN102.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    users: {},
    filters: {}
  },
  setup(__props) {
    const props = __props;
    const search = ref(props.filters?.search ?? "");
    watch(search, (value) => {
      const params = {};
      if (value && value.trim()) {
        params.search = value.trim();
      }
      router.get(users.index().url, params, { preserveState: true, replace: true });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Users" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [{ title: "Users", href: unref(users).index().url }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex items-center justify-between gap-3 p-4"${_scopeId}><input${ssrRenderAttr("value", search.value)} type="search" placeholder="Search users..." class="w-full max-w-sm rounded border px-3 py-2"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(users).create().url,
              class: "rounded bg-blue-600 px-3 py-2 text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`New User`);
                } else {
                  return [
                    createTextVNode("New User")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="p-4"${_scopeId}><div class="overflow-x-auto"${_scopeId}><table class="min-w-full border"${_scopeId}><thead${_scopeId}><tr class="bg-gray-50"${_scopeId}><th class="p-2 text-left"${_scopeId}>Name</th><th class="p-2 text-left"${_scopeId}>Email</th><th class="p-2 text-right"${_scopeId}>Actions</th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(props.users.data, (u) => {
              _push2(`<tr class="border-t"${_scopeId}><td class="p-2"${_scopeId}>${ssrInterpolate(u.name)}</td><td class="p-2"${_scopeId}>${ssrInterpolate(u.email)}</td><td class="p-2 text-right"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(users).show(u.id).url,
                class: "rounded border px-2 py-1"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`View`);
                  } else {
                    return [
                      createTextVNode("View")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(users).edit(u.id).url,
                class: "ml-2 rounded bg-gray-200 px-2 py-1"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Edit`);
                  } else {
                    return [
                      createTextVNode("Edit")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center justify-between gap-3 p-4" }, [
                withDirectives(createVNode("input", {
                  "onUpdate:modelValue": ($event) => search.value = $event,
                  type: "search",
                  placeholder: "Search users...",
                  class: "w-full max-w-sm rounded border px-3 py-2"
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, search.value]
                ]),
                createVNode(unref(Link), {
                  href: unref(users).create().url,
                  class: "rounded bg-blue-600 px-3 py-2 text-white"
                }, {
                  default: withCtx(() => [
                    createTextVNode("New User")
                  ]),
                  _: 1
                }, 8, ["href"])
              ]),
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "overflow-x-auto" }, [
                  createVNode("table", { class: "min-w-full border" }, [
                    createVNode("thead", null, [
                      createVNode("tr", { class: "bg-gray-50" }, [
                        createVNode("th", { class: "p-2 text-left" }, "Name"),
                        createVNode("th", { class: "p-2 text-left" }, "Email"),
                        createVNode("th", { class: "p-2 text-right" }, "Actions")
                      ])
                    ]),
                    createVNode("tbody", null, [
                      (openBlock(true), createBlock(Fragment, null, renderList(props.users.data, (u) => {
                        return openBlock(), createBlock("tr", {
                          key: u.id,
                          class: "border-t"
                        }, [
                          createVNode("td", { class: "p-2" }, toDisplayString(u.name), 1),
                          createVNode("td", { class: "p-2" }, toDisplayString(u.email), 1),
                          createVNode("td", { class: "p-2 text-right" }, [
                            createVNode(unref(Link), {
                              href: unref(users).show(u.id).url,
                              class: "rounded border px-2 py-1"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("View")
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: unref(users).edit(u.id).url,
                              class: "ml-2 rounded bg-gray-200 px-2 py-1"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Edit")
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ])
                        ]);
                      }), 128))
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/users/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
