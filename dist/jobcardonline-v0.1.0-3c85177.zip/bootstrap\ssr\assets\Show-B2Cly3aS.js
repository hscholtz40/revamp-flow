import { defineComponent, unref, withCtx, createVNode, createTextVNode, createBlock, createCommentVNode, toDisplayString, openBlock, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderClass, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1, c as companySettings } from "./AppLayout-CmGu2Oww.js";
import { Head, Link } from "@inertiajs/vue3";
import { ArrowLeft, Edit, Building2, Star, Mail, Phone, Globe, MapPin, Calendar } from "lucide-vue-next";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    company: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: props.company.name
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Administration", href: "/administration" },
          { title: "Company Settings", href: unref(companySettings).index().url },
          { title: props.company.name, href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-4"${_scopeId}><div class="mb-6 flex items-center justify-between"${_scopeId}><div class="flex items-center gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(companySettings).index().url,
              class: "flex items-center gap-2 text-gray-600 hover:text-gray-900"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(ArrowLeft), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                  _push3(` Back to Companies `);
                } else {
                  return [
                    createVNode(unref(ArrowLeft), { class: "h-4 w-4" }),
                    createTextVNode(" Back to Companies ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="flex items-center gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(companySettings).edit(props.company.id).url,
              class: "flex items-center gap-2 rounded-md border border-gray-300 px-4 py-2 text-gray-700 hover:bg-gray-50"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Edit), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                  _push3(` Edit `);
                } else {
                  return [
                    createVNode(unref(Edit), { class: "h-4 w-4" }),
                    createTextVNode(" Edit ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="mx-auto max-w-4xl"${_scopeId}><div class="mb-8 rounded-lg border bg-white p-6"${_scopeId}><div class="flex items-start gap-6"${_scopeId}><div class="flex-shrink-0"${_scopeId}><div class="flex h-20 w-20 items-center justify-center rounded-lg bg-blue-100"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Building2), { class: "h-10 w-10 text-blue-600" }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex-1"${_scopeId}><div class="mb-2 flex items-center gap-3"${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>${ssrInterpolate(props.company.name)}</h1>`);
            if (props.company.is_default) {
              _push2(ssrRenderComponent(unref(Star), { class: "h-6 w-6 text-yellow-500 fill-current" }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="mb-4 flex items-center gap-4"${_scopeId}><span class="${ssrRenderClass([
              "rounded-full px-3 py-1 text-sm font-medium",
              props.company.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
            ])}"${_scopeId}>${ssrInterpolate(props.company.is_active ? "Active" : "Inactive")}</span>`);
            if (props.company.is_default) {
              _push2(`<span class="rounded-full bg-yellow-100 px-3 py-1 text-sm font-medium text-yellow-800"${_scopeId}> Default Company </span>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
            if (props.company.description) {
              _push2(`<p class="text-gray-600"${_scopeId}>${ssrInterpolate(props.company.description)}</p>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="grid gap-6 lg:grid-cols-3"${_scopeId}><div class="lg:col-span-2 space-y-6"${_scopeId}><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Contact Information</h2><div class="grid gap-4 md:grid-cols-2"${_scopeId}>`);
            if (props.company.email) {
              _push2(`<div class="flex items-center gap-3"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Mail), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
              _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Email</div><div class="text-gray-900"${_scopeId}>${ssrInterpolate(props.company.email)}</div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (props.company.phone) {
              _push2(`<div class="flex items-center gap-3"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Phone), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
              _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Phone</div><div class="text-gray-900"${_scopeId}>${ssrInterpolate(props.company.phone)}</div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (props.company.website) {
              _push2(`<div class="flex items-center gap-3"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Globe), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
              _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Website</div><a${ssrRenderAttr("href", props.company.website)} target="_blank" class="text-blue-600 hover:underline"${_scopeId}>${ssrInterpolate(props.company.website)}</a></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
            if (props.company.address || props.company.city) {
              _push2(`<div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Address Information</h2><div class="flex items-start gap-3"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(MapPin), { class: "h-5 w-5 text-gray-400 mt-0.5" }, null, _parent2, _scopeId));
              _push2(`<div class="text-gray-900"${_scopeId}>`);
              if (props.company.address) {
                _push2(`<div${_scopeId}>${ssrInterpolate(props.company.address)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              if (props.company.city || props.company.state || props.company.postal_code) {
                _push2(`<div${_scopeId}>${ssrInterpolate([props.company.city, props.company.state, props.company.postal_code].filter(Boolean).join(", "))}</div>`);
              } else {
                _push2(`<!---->`);
              }
              if (props.company.country) {
                _push2(`<div${_scopeId}>${ssrInterpolate(props.company.country)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (props.company.description) {
              _push2(`<div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Description</h2><div class="text-gray-700 whitespace-pre-wrap"${_scopeId}>${ssrInterpolate(props.company.description)}</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="space-y-6"${_scopeId}><div class="rounded-lg border bg-white p-6"${_scopeId}><h3 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Company Status</h3><div class="space-y-4"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Status</span><span class="${ssrRenderClass([
              "text-sm font-medium",
              props.company.is_active ? "text-green-600" : "text-red-600"
            ])}"${_scopeId}>${ssrInterpolate(props.company.is_active ? "Active" : "Inactive")}</span></div><div class="flex items-center justify-between"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Default</span><span class="text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(props.company.is_default ? "Yes" : "No")}</span></div></div></div><div class="rounded-lg border bg-white p-6"${_scopeId}><h3 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Timestamps</h3><div class="space-y-4"${_scopeId}><div class="flex items-center gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Calendar), { class: "h-4 w-4 text-gray-400" }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Created</div><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(new Date(props.company.created_at).toLocaleDateString())}</div></div></div><div class="flex items-center gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Calendar), { class: "h-4 w-4 text-gray-400" }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Last Updated</div><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(new Date(props.company.updated_at).toLocaleDateString())}</div></div></div></div></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "mb-6 flex items-center justify-between" }, [
                  createVNode("div", { class: "flex items-center gap-4" }, [
                    createVNode(unref(Link), {
                      href: unref(companySettings).index().url,
                      class: "flex items-center gap-2 text-gray-600 hover:text-gray-900"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(ArrowLeft), { class: "h-4 w-4" }),
                        createTextVNode(" Back to Companies ")
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ]),
                  createVNode("div", { class: "flex items-center gap-3" }, [
                    createVNode(unref(Link), {
                      href: unref(companySettings).edit(props.company.id).url,
                      class: "flex items-center gap-2 rounded-md border border-gray-300 px-4 py-2 text-gray-700 hover:bg-gray-50"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(Edit), { class: "h-4 w-4" }),
                        createTextVNode(" Edit ")
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ])
                ]),
                createVNode("div", { class: "mx-auto max-w-4xl" }, [
                  createVNode("div", { class: "mb-8 rounded-lg border bg-white p-6" }, [
                    createVNode("div", { class: "flex items-start gap-6" }, [
                      createVNode("div", { class: "flex-shrink-0" }, [
                        createVNode("div", { class: "flex h-20 w-20 items-center justify-center rounded-lg bg-blue-100" }, [
                          createVNode(unref(Building2), { class: "h-10 w-10 text-blue-600" })
                        ])
                      ]),
                      createVNode("div", { class: "flex-1" }, [
                        createVNode("div", { class: "mb-2 flex items-center gap-3" }, [
                          createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, toDisplayString(props.company.name), 1),
                          props.company.is_default ? (openBlock(), createBlock(unref(Star), {
                            key: 0,
                            class: "h-6 w-6 text-yellow-500 fill-current"
                          })) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mb-4 flex items-center gap-4" }, [
                          createVNode("span", {
                            class: [
                              "rounded-full px-3 py-1 text-sm font-medium",
                              props.company.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                            ]
                          }, toDisplayString(props.company.is_active ? "Active" : "Inactive"), 3),
                          props.company.is_default ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "rounded-full bg-yellow-100 px-3 py-1 text-sm font-medium text-yellow-800"
                          }, " Default Company ")) : createCommentVNode("", true)
                        ]),
                        props.company.description ? (openBlock(), createBlock("p", {
                          key: 0,
                          class: "text-gray-600"
                        }, toDisplayString(props.company.description), 1)) : createCommentVNode("", true)
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "grid gap-6 lg:grid-cols-3" }, [
                    createVNode("div", { class: "lg:col-span-2 space-y-6" }, [
                      createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                        createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Contact Information"),
                        createVNode("div", { class: "grid gap-4 md:grid-cols-2" }, [
                          props.company.email ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "flex items-center gap-3"
                          }, [
                            createVNode(unref(Mail), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Email"),
                              createVNode("div", { class: "text-gray-900" }, toDisplayString(props.company.email), 1)
                            ])
                          ])) : createCommentVNode("", true),
                          props.company.phone ? (openBlock(), createBlock("div", {
                            key: 1,
                            class: "flex items-center gap-3"
                          }, [
                            createVNode(unref(Phone), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Phone"),
                              createVNode("div", { class: "text-gray-900" }, toDisplayString(props.company.phone), 1)
                            ])
                          ])) : createCommentVNode("", true),
                          props.company.website ? (openBlock(), createBlock("div", {
                            key: 2,
                            class: "flex items-center gap-3"
                          }, [
                            createVNode(unref(Globe), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Website"),
                              createVNode("a", {
                                href: props.company.website,
                                target: "_blank",
                                class: "text-blue-600 hover:underline"
                              }, toDisplayString(props.company.website), 9, ["href"])
                            ])
                          ])) : createCommentVNode("", true)
                        ])
                      ]),
                      props.company.address || props.company.city ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "rounded-lg border bg-white p-6"
                      }, [
                        createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Address Information"),
                        createVNode("div", { class: "flex items-start gap-3" }, [
                          createVNode(unref(MapPin), { class: "h-5 w-5 text-gray-400 mt-0.5" }),
                          createVNode("div", { class: "text-gray-900" }, [
                            props.company.address ? (openBlock(), createBlock("div", { key: 0 }, toDisplayString(props.company.address), 1)) : createCommentVNode("", true),
                            props.company.city || props.company.state || props.company.postal_code ? (openBlock(), createBlock("div", { key: 1 }, toDisplayString([props.company.city, props.company.state, props.company.postal_code].filter(Boolean).join(", ")), 1)) : createCommentVNode("", true),
                            props.company.country ? (openBlock(), createBlock("div", { key: 2 }, toDisplayString(props.company.country), 1)) : createCommentVNode("", true)
                          ])
                        ])
                      ])) : createCommentVNode("", true),
                      props.company.description ? (openBlock(), createBlock("div", {
                        key: 1,
                        class: "rounded-lg border bg-white p-6"
                      }, [
                        createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Description"),
                        createVNode("div", { class: "text-gray-700 whitespace-pre-wrap" }, toDisplayString(props.company.description), 1)
                      ])) : createCommentVNode("", true)
                    ]),
                    createVNode("div", { class: "space-y-6" }, [
                      createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                        createVNode("h3", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Company Status"),
                        createVNode("div", { class: "space-y-4" }, [
                          createVNode("div", { class: "flex items-center justify-between" }, [
                            createVNode("span", { class: "text-sm text-gray-500" }, "Status"),
                            createVNode("span", {
                              class: [
                                "text-sm font-medium",
                                props.company.is_active ? "text-green-600" : "text-red-600"
                              ]
                            }, toDisplayString(props.company.is_active ? "Active" : "Inactive"), 3)
                          ]),
                          createVNode("div", { class: "flex items-center justify-between" }, [
                            createVNode("span", { class: "text-sm text-gray-500" }, "Default"),
                            createVNode("span", { class: "text-sm font-medium text-gray-900" }, toDisplayString(props.company.is_default ? "Yes" : "No"), 1)
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                        createVNode("h3", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Timestamps"),
                        createVNode("div", { class: "space-y-4" }, [
                          createVNode("div", { class: "flex items-center gap-3" }, [
                            createVNode(unref(Calendar), { class: "h-4 w-4 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Created"),
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(new Date(props.company.created_at).toLocaleDateString()), 1)
                            ])
                          ]),
                          createVNode("div", { class: "flex items-center gap-3" }, [
                            createVNode(unref(Calendar), { class: "h-4 w-4 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Last Updated"),
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(new Date(props.company.updated_at).toLocaleDateString()), 1)
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/company-settings/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
