import { defineComponent, unref, withCtx, createTextVNode, createVNode, withModifiers, withDirectives, createBlock, createCommentVNode, vModelText, openBlock, toDisplayString, vModelCheckbox, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrIncludeBooleanAttr, ssrLooseContain } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { g as groups } from "./index-TOLxu5Uw.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Create",
  __ssrInlineRender: true,
  setup(__props) {
    const form = useForm({
      name: "",
      description: "",
      is_administrator: false
    });
    function submit() {
      form.post(groups.store().url);
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "New Group" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [{ title: "Groups", href: unref(groups).index().url }, { title: "Create", href: "#" }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="space-y-4 p-4"${_scopeId}><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Name</span><input${ssrRenderAttr("value", unref(form).name)} class="w-full rounded border px-3 py-2" required${_scopeId}>`);
            if (unref(form).errors.name) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.name)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Description</span><textarea class="w-full rounded border px-3 py-2" rows="3"${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea>`);
            if (unref(form).errors.description) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.description)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="flex items-center space-x-2"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_administrator) ? ssrLooseContain(unref(form).is_administrator, null) : unref(form).is_administrator) ? " checked" : ""} class="rounded border-gray-300"${_scopeId}><span class="text-sm font-medium"${_scopeId}>Administrator Group</span>`);
            if (unref(form).errors.is_administrator) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.is_administrator)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><p class="text-xs text-gray-600"${_scopeId}> Administrator groups have access to all administration functions and system settings. </p><div class="flex items-center gap-3"${_scopeId}><button${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="rounded bg-blue-600 px-4 py-2 text-white"${_scopeId}>Create</button>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(groups).index().url,
              class: "rounded border px-4 py-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Cancel`);
                } else {
                  return [
                    createTextVNode("Cancel")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                onSubmit: withModifiers(submit, ["prevent"]),
                class: "space-y-4 p-4"
              }, [
                createVNode("label", { class: "block" }, [
                  createVNode("span", { class: "mb-1 block" }, "Name"),
                  withDirectives(createVNode("input", {
                    "onUpdate:modelValue": ($event) => unref(form).name = $event,
                    class: "w-full rounded border px-3 py-2",
                    required: ""
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(form).name]
                  ]),
                  unref(form).errors.name ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "text-sm text-red-600"
                  }, toDisplayString(unref(form).errors.name), 1)) : createCommentVNode("", true)
                ]),
                createVNode("label", { class: "block" }, [
                  createVNode("span", { class: "mb-1 block" }, "Description"),
                  withDirectives(createVNode("textarea", {
                    "onUpdate:modelValue": ($event) => unref(form).description = $event,
                    class: "w-full rounded border px-3 py-2",
                    rows: "3"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(form).description]
                  ]),
                  unref(form).errors.description ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "text-sm text-red-600"
                  }, toDisplayString(unref(form).errors.description), 1)) : createCommentVNode("", true)
                ]),
                createVNode("label", { class: "flex items-center space-x-2" }, [
                  withDirectives(createVNode("input", {
                    type: "checkbox",
                    "onUpdate:modelValue": ($event) => unref(form).is_administrator = $event,
                    class: "rounded border-gray-300"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelCheckbox, unref(form).is_administrator]
                  ]),
                  createVNode("span", { class: "text-sm font-medium" }, "Administrator Group"),
                  unref(form).errors.is_administrator ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "text-sm text-red-600"
                  }, toDisplayString(unref(form).errors.is_administrator), 1)) : createCommentVNode("", true)
                ]),
                createVNode("p", { class: "text-xs text-gray-600" }, " Administrator groups have access to all administration functions and system settings. "),
                createVNode("div", { class: "flex items-center gap-3" }, [
                  createVNode("button", {
                    disabled: unref(form).processing,
                    class: "rounded bg-blue-600 px-4 py-2 text-white"
                  }, "Create", 8, ["disabled"]),
                  createVNode(unref(Link), {
                    href: unref(groups).index().url,
                    class: "rounded border px-4 py-2"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Cancel")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ])
              ], 32)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/groups/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
