import { q as queryParams, a as applyUrlDefaults } from "./index--D7ld9AJ.js";
const index = (options) => ({
  url: index.url(options),
  method: "get"
});
index.definition = {
  methods: ["get", "head"],
  url: "/groups"
};
index.url = (options) => {
  return index.definition.url + queryParams(options);
};
index.get = (options) => ({
  url: index.url(options),
  method: "get"
});
index.head = (options) => ({
  url: index.url(options),
  method: "head"
});
const indexForm = (options) => ({
  action: index.url(options),
  method: "get"
});
indexForm.get = (options) => ({
  action: index.url(options),
  method: "get"
});
indexForm.head = (options) => ({
  action: index.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
index.form = indexForm;
const create = (options) => ({
  url: create.url(options),
  method: "get"
});
create.definition = {
  methods: ["get", "head"],
  url: "/groups/create"
};
create.url = (options) => {
  return create.definition.url + queryParams(options);
};
create.get = (options) => ({
  url: create.url(options),
  method: "get"
});
create.head = (options) => ({
  url: create.url(options),
  method: "head"
});
const createForm = (options) => ({
  action: create.url(options),
  method: "get"
});
createForm.get = (options) => ({
  action: create.url(options),
  method: "get"
});
createForm.head = (options) => ({
  action: create.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create.form = createForm;
const store = (options) => ({
  url: store.url(options),
  method: "post"
});
store.definition = {
  methods: ["post"],
  url: "/groups"
};
store.url = (options) => {
  return store.definition.url + queryParams(options);
};
store.post = (options) => ({
  url: store.url(options),
  method: "post"
});
const storeForm = (options) => ({
  action: store.url(options),
  method: "post"
});
storeForm.post = (options) => ({
  action: store.url(options),
  method: "post"
});
store.form = storeForm;
const edit = (args, options) => ({
  url: edit.url(args, options),
  method: "get"
});
edit.definition = {
  methods: ["get", "head"],
  url: "/groups/{group}/edit"
};
edit.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { group: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { group: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      group: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    group: typeof args.group === "object" ? args.group.id : args.group
  };
  return edit.definition.url.replace("{group}", parsedArgs.group.toString()).replace(/\/+$/, "") + queryParams(options);
};
edit.get = (args, options) => ({
  url: edit.url(args, options),
  method: "get"
});
edit.head = (args, options) => ({
  url: edit.url(args, options),
  method: "head"
});
const editForm = (args, options) => ({
  action: edit.url(args, options),
  method: "get"
});
editForm.get = (args, options) => ({
  action: edit.url(args, options),
  method: "get"
});
editForm.head = (args, options) => ({
  action: edit.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
edit.form = editForm;
const update = (args, options) => ({
  url: update.url(args, options),
  method: "put"
});
update.definition = {
  methods: ["put"],
  url: "/groups/{group}"
};
update.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { group: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { group: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      group: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    group: typeof args.group === "object" ? args.group.id : args.group
  };
  return update.definition.url.replace("{group}", parsedArgs.group.toString()).replace(/\/+$/, "") + queryParams(options);
};
update.put = (args, options) => ({
  url: update.url(args, options),
  method: "put"
});
const updateForm = (args, options) => ({
  action: update.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm.put = (args, options) => ({
  action: update.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
update.form = updateForm;
const permissions = (args, options) => ({
  url: permissions.url(args, options),
  method: "put"
});
permissions.definition = {
  methods: ["put"],
  url: "/groups/{group}/permissions"
};
permissions.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { group: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { group: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      group: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    group: typeof args.group === "object" ? args.group.id : args.group
  };
  return permissions.definition.url.replace("{group}", parsedArgs.group.toString()).replace(/\/+$/, "") + queryParams(options);
};
permissions.put = (args, options) => ({
  url: permissions.url(args, options),
  method: "put"
});
const permissionsForm = (args, options) => ({
  action: permissions.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
permissionsForm.put = (args, options) => ({
  action: permissions.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
permissions.form = permissionsForm;
const groups = {
  index: Object.assign(index, index),
  create: Object.assign(create, create),
  store: Object.assign(store, store),
  edit: Object.assign(edit, edit),
  update: Object.assign(update, update),
  permissions: Object.assign(permissions, permissions)
};
export {
  groups as g
};
