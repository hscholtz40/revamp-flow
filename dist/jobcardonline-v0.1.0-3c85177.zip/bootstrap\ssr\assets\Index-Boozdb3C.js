import { defineComponent, ref, watch, unref, withCtx, createTextVNode, createVNode, toDisplayString, withDirectives, vModelText, vModelSelect, createBlock, openBlock, Fragment, renderList, vModelCheckbox, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import { router, Head, Link } from "@inertiajs/vue3";
import { i as invoices, _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    invoices: {},
    customers: {},
    currentCompany: {},
    filters: {},
    canEditCompleted: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const search = ref(props.filters.search || "");
    const status = ref(props.filters.status || "");
    const customerId = ref(props.filters.customer_id || "");
    const showPaid = ref(props.filters.show_paid || false);
    const canEditInvoice = (invoice) => {
      if (invoice.status !== "paid") {
        return true;
      }
      return props.canEditCompleted;
    };
    const canDeleteInvoice = (invoice) => {
      if (invoice.status !== "paid") {
        return true;
      }
      return props.canEditCompleted;
    };
    watch([search, status, customerId, showPaid], () => {
      router.get(invoices.index().url, {
        search: search.value,
        status: status.value,
        customer_id: customerId.value,
        show_paid: showPaid.value
      }, {
        preserveState: true,
        replace: true
      });
    });
    const clearFilters = () => {
      search.value = "";
      status.value = "";
      customerId.value = "";
      showPaid.value = false;
    };
    const formatDate = (date) => {
      return new Date(date).toLocaleDateString();
    };
    const formatCurrency = (amount) => {
      return new Intl.NumberFormat("en-ZA", {
        style: "currency",
        currency: "ZAR"
      }).format(amount);
    };
    const getStatusBadgeClass = (status2) => {
      const classes = {
        draft: "bg-gray-100 text-gray-800",
        sent: "bg-blue-100 text-blue-800",
        paid: "bg-green-100 text-green-800",
        overdue: "bg-red-100 text-red-800",
        cancelled: "bg-gray-100 text-gray-800"
      };
      return classes[status2] || "bg-gray-100 text-gray-800";
    };
    const deleteInvoice = (id) => {
      if (confirm("Are you sure you want to delete this invoice?")) {
        router.delete(invoices.destroy(id).url);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Invoices" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [{ title: "Invoices", href: unref(invoices).index().url }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-blue-50 border-b border-blue-200 px-4 py-3"${_scopeId}><div class="flex items-center gap-2 text-sm text-blue-700"${_scopeId}><span class="font-medium"${_scopeId}>Viewing invoices for:</span><span class="font-semibold"${_scopeId}>${ssrInterpolate(props.currentCompany.name)}</span></div></div><div class="p-4"${_scopeId}><div class="flex items-center justify-between gap-3 mb-6"${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>Invoices</h1>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(invoices).create().url,
              class: "rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` New Invoice `);
                } else {
                  return [
                    createTextVNode(" New Invoice ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="bg-white rounded-lg border p-4 mb-6"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-4 gap-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Search</label><input${ssrRenderAttr("value", search.value)} type="search" placeholder="Search invoices..." class="w-full rounded border px-3 py-2"${_scopeId}></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Status</label><select class="w-full rounded border px-3 py-2"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "") : ssrLooseEqual(status.value, "")) ? " selected" : ""}${_scopeId}>All Statuses</option><option value="draft"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "draft") : ssrLooseEqual(status.value, "draft")) ? " selected" : ""}${_scopeId}>Draft</option><option value="sent"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "sent") : ssrLooseEqual(status.value, "sent")) ? " selected" : ""}${_scopeId}>Sent</option><option value="paid"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "paid") : ssrLooseEqual(status.value, "paid")) ? " selected" : ""}${_scopeId}>Paid</option><option value="overdue"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "overdue") : ssrLooseEqual(status.value, "overdue")) ? " selected" : ""}${_scopeId}>Overdue</option><option value="cancelled"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "cancelled") : ssrLooseEqual(status.value, "cancelled")) ? " selected" : ""}${_scopeId}>Cancelled</option></select></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Customer</label><select class="w-full rounded border px-3 py-2"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(customerId.value) ? ssrLooseContain(customerId.value, "") : ssrLooseEqual(customerId.value, "")) ? " selected" : ""}${_scopeId}>All Customers</option><!--[-->`);
            ssrRenderList(props.customers, (customer) => {
              _push2(`<option${ssrRenderAttr("value", customer.id)}${ssrIncludeBooleanAttr(Array.isArray(customerId.value) ? ssrLooseContain(customerId.value, customer.id) : ssrLooseEqual(customerId.value, customer.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(customer.name)}</option>`);
            });
            _push2(`<!--]--></select></div><div class="flex items-end"${_scopeId}><button class="w-full rounded bg-gray-500 px-4 py-2 text-white hover:bg-gray-600"${_scopeId}> Clear Filters </button></div></div><div class="mt-4"${_scopeId}><label class="flex items-center gap-2"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(showPaid.value) ? ssrLooseContain(showPaid.value, null) : showPaid.value) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"${_scopeId}><span class="text-sm font-medium text-gray-700"${_scopeId}>Show paid invoices</span></label></div></div><div class="bg-white rounded-lg border overflow-hidden"${_scopeId}><div class="overflow-x-auto"${_scopeId}><table class="w-full"${_scopeId}><thead class="bg-gray-50 border-b"${_scopeId}><tr${_scopeId}><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Invoice </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Customer </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Salesperson </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Date </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Due Date </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Status </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Total </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Actions </th></tr></thead><tbody class="bg-white divide-y divide-gray-200"${_scopeId}><!--[-->`);
            ssrRenderList(props.invoices.data, (invoice) => {
              _push2(`<tr class="hover:bg-gray-50"${_scopeId}><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div${_scopeId}><div class="text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(invoice.invoice_number)}</div><div class="text-sm text-gray-500"${_scopeId}>${ssrInterpolate(invoice.title)}</div></div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(invoice.customer?.name)}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(invoice.salesperson?.name || "-")}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatDate(invoice.invoice_date))}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatDate(invoice.due_date))}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><span class="${ssrRenderClass([getStatusBadgeClass(invoice.status), "inline-flex px-2 py-1 text-xs font-semibold rounded-full"])}"${_scopeId}>${ssrInterpolate(invoice.status)}</span></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(formatCurrency(invoice.total))}</div></td><td class="px-6 py-4 whitespace-nowrap text-sm font-medium"${_scopeId}><div class="flex items-center gap-2"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(invoices).show(invoice.id).url,
                class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` View `);
                  } else {
                    return [
                      createTextVNode(" View ")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              if (canEditInvoice(invoice)) {
                _push2(ssrRenderComponent(unref(Link), {
                  href: unref(invoices).edit(invoice.id).url,
                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` Edit `);
                    } else {
                      return [
                        createTextVNode(" Edit ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              } else {
                _push2(`<span class="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed" title="Cannot edit paid invoices without permission"${_scopeId}> Edit </span>`);
              }
              if (canDeleteInvoice(invoice)) {
                _push2(`<button class="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-red-700 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"${_scopeId}> Delete </button>`);
              } else {
                _push2(`<span class="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed" title="Cannot delete paid invoices without permission"${_scopeId}> Delete </span>`);
              }
              _push2(`</div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div>`);
            if (props.invoices.links) {
              _push2(`<div class="bg-white px-4 py-3 border-t border-gray-200 sm:px-6"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div class="flex-1 flex justify-between sm:hidden"${_scopeId}>`);
              if (props.invoices.prev_page_url) {
                _push2(ssrRenderComponent(unref(Link), {
                  href: props.invoices.prev_page_url,
                  class: "relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` Previous `);
                    } else {
                      return [
                        createTextVNode(" Previous ")
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              if (props.invoices.next_page_url) {
                _push2(ssrRenderComponent(unref(Link), {
                  href: props.invoices.next_page_url,
                  class: "ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` Next `);
                    } else {
                      return [
                        createTextVNode(" Next ")
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between"${_scopeId}><div${_scopeId}><p class="text-sm text-gray-700"${_scopeId}> Showing <span class="font-medium"${_scopeId}>${ssrInterpolate(props.invoices.from)}</span> to <span class="font-medium"${_scopeId}>${ssrInterpolate(props.invoices.to)}</span> of <span class="font-medium"${_scopeId}>${ssrInterpolate(props.invoices.total)}</span> results </p></div><div${_scopeId}><nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination"${_scopeId}><!--[-->`);
              ssrRenderList(props.invoices.links, (link, index) => {
                _push2(`<!--[-->`);
                if (link.url) {
                  _push2(ssrRenderComponent(unref(Link), {
                    href: link.url,
                    class: [
                      "relative inline-flex items-center px-4 py-2 border text-sm font-medium",
                      link.active ? "z-10 bg-blue-50 border-blue-500 text-blue-600" : "bg-white border-gray-300 text-gray-500 hover:bg-gray-50"
                    ]
                  }, null, _parent2, _scopeId));
                } else {
                  _push2(`<span class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-gray-100 text-sm font-medium text-gray-400 cursor-not-allowed"${_scopeId}>${link.label ?? ""}</span>`);
                }
                _push2(`<!--]-->`);
              });
              _push2(`<!--]--></nav></div></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-blue-50 border-b border-blue-200 px-4 py-3" }, [
                createVNode("div", { class: "flex items-center gap-2 text-sm text-blue-700" }, [
                  createVNode("span", { class: "font-medium" }, "Viewing invoices for:"),
                  createVNode("span", { class: "font-semibold" }, toDisplayString(props.currentCompany.name), 1)
                ])
              ]),
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "flex items-center justify-between gap-3 mb-6" }, [
                  createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "Invoices"),
                  createVNode(unref(Link), {
                    href: unref(invoices).create().url,
                    class: "rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" New Invoice ")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ]),
                createVNode("div", { class: "bg-white rounded-lg border p-4 mb-6" }, [
                  createVNode("div", { class: "grid grid-cols-1 md:grid-cols-4 gap-4" }, [
                    createVNode("div", null, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Search"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => search.value = $event,
                        type: "search",
                        placeholder: "Search invoices...",
                        class: "w-full rounded border px-3 py-2"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, search.value]
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Status"),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => status.value = $event,
                        class: "w-full rounded border px-3 py-2"
                      }, [
                        createVNode("option", { value: "" }, "All Statuses"),
                        createVNode("option", { value: "draft" }, "Draft"),
                        createVNode("option", { value: "sent" }, "Sent"),
                        createVNode("option", { value: "paid" }, "Paid"),
                        createVNode("option", { value: "overdue" }, "Overdue"),
                        createVNode("option", { value: "cancelled" }, "Cancelled")
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, status.value]
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Customer"),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => customerId.value = $event,
                        class: "w-full rounded border px-3 py-2"
                      }, [
                        createVNode("option", { value: "" }, "All Customers"),
                        (openBlock(true), createBlock(Fragment, null, renderList(props.customers, (customer) => {
                          return openBlock(), createBlock("option", {
                            key: customer.id,
                            value: customer.id
                          }, toDisplayString(customer.name), 9, ["value"]);
                        }), 128))
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, customerId.value]
                      ])
                    ]),
                    createVNode("div", { class: "flex items-end" }, [
                      createVNode("button", {
                        onClick: clearFilters,
                        class: "w-full rounded bg-gray-500 px-4 py-2 text-white hover:bg-gray-600"
                      }, " Clear Filters ")
                    ])
                  ]),
                  createVNode("div", { class: "mt-4" }, [
                    createVNode("label", { class: "flex items-center gap-2" }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => showPaid.value = $event,
                        type: "checkbox",
                        class: "rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelCheckbox, showPaid.value]
                      ]),
                      createVNode("span", { class: "text-sm font-medium text-gray-700" }, "Show paid invoices")
                    ])
                  ])
                ]),
                createVNode("div", { class: "bg-white rounded-lg border overflow-hidden" }, [
                  createVNode("div", { class: "overflow-x-auto" }, [
                    createVNode("table", { class: "w-full" }, [
                      createVNode("thead", { class: "bg-gray-50 border-b" }, [
                        createVNode("tr", null, [
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Invoice "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Customer "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Salesperson "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Date "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Due Date "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Status "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Total "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Actions ")
                        ])
                      ]),
                      createVNode("tbody", { class: "bg-white divide-y divide-gray-200" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(props.invoices.data, (invoice) => {
                          return openBlock(), createBlock("tr", {
                            key: invoice.id,
                            class: "hover:bg-gray-50"
                          }, [
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", null, [
                                createVNode("div", { class: "text-sm font-medium text-gray-900" }, toDisplayString(invoice.invoice_number), 1),
                                createVNode("div", { class: "text-sm text-gray-500" }, toDisplayString(invoice.title), 1)
                              ])
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(invoice.customer?.name), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(invoice.salesperson?.name || "-"), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(formatDate(invoice.invoice_date)), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(formatDate(invoice.due_date)), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("span", {
                                class: [getStatusBadgeClass(invoice.status), "inline-flex px-2 py-1 text-xs font-semibold rounded-full"]
                              }, toDisplayString(invoice.status), 3)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm font-medium text-gray-900" }, toDisplayString(formatCurrency(invoice.total)), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm font-medium" }, [
                              createVNode("div", { class: "flex items-center gap-2" }, [
                                createVNode(unref(Link), {
                                  href: unref(invoices).show(invoice.id).url,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" View ")
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                canEditInvoice(invoice) ? (openBlock(), createBlock(unref(Link), {
                                  key: 0,
                                  href: unref(invoices).edit(invoice.id).url,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Edit ")
                                  ]),
                                  _: 1
                                }, 8, ["href"])) : (openBlock(), createBlock("span", {
                                  key: 1,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed",
                                  title: "Cannot edit paid invoices without permission"
                                }, " Edit ")),
                                canDeleteInvoice(invoice) ? (openBlock(), createBlock("button", {
                                  key: 2,
                                  onClick: ($event) => deleteInvoice(invoice.id),
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-red-700 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                                }, " Delete ", 8, ["onClick"])) : (openBlock(), createBlock("span", {
                                  key: 3,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed",
                                  title: "Cannot delete paid invoices without permission"
                                }, " Delete "))
                              ])
                            ])
                          ]);
                        }), 128))
                      ])
                    ])
                  ]),
                  props.invoices.links ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "bg-white px-4 py-3 border-t border-gray-200 sm:px-6"
                  }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", { class: "flex-1 flex justify-between sm:hidden" }, [
                        props.invoices.prev_page_url ? (openBlock(), createBlock(unref(Link), {
                          key: 0,
                          href: props.invoices.prev_page_url,
                          class: "relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Previous ")
                          ]),
                          _: 1
                        }, 8, ["href"])) : createCommentVNode("", true),
                        props.invoices.next_page_url ? (openBlock(), createBlock(unref(Link), {
                          key: 1,
                          href: props.invoices.next_page_url,
                          class: "ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Next ")
                          ]),
                          _: 1
                        }, 8, ["href"])) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "hidden sm:flex-1 sm:flex sm:items-center sm:justify-between" }, [
                        createVNode("div", null, [
                          createVNode("p", { class: "text-sm text-gray-700" }, [
                            createTextVNode(" Showing "),
                            createVNode("span", { class: "font-medium" }, toDisplayString(props.invoices.from), 1),
                            createTextVNode(" to "),
                            createVNode("span", { class: "font-medium" }, toDisplayString(props.invoices.to), 1),
                            createTextVNode(" of "),
                            createVNode("span", { class: "font-medium" }, toDisplayString(props.invoices.total), 1),
                            createTextVNode(" results ")
                          ])
                        ]),
                        createVNode("div", null, [
                          createVNode("nav", {
                            class: "relative z-0 inline-flex rounded-md shadow-sm -space-x-px",
                            "aria-label": "Pagination"
                          }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(props.invoices.links, (link, index) => {
                              return openBlock(), createBlock(Fragment, { key: index }, [
                                link.url ? (openBlock(), createBlock(unref(Link), {
                                  key: 0,
                                  href: link.url,
                                  innerHTML: link.label,
                                  class: [
                                    "relative inline-flex items-center px-4 py-2 border text-sm font-medium",
                                    link.active ? "z-10 bg-blue-50 border-blue-500 text-blue-600" : "bg-white border-gray-300 text-gray-500 hover:bg-gray-50"
                                  ]
                                }, null, 8, ["href", "innerHTML", "class"])) : (openBlock(), createBlock("span", {
                                  key: 1,
                                  innerHTML: link.label,
                                  class: "relative inline-flex items-center px-4 py-2 border border-gray-300 bg-gray-100 text-sm font-medium text-gray-400 cursor-not-allowed"
                                }, null, 8, ["innerHTML"]))
                              ], 64);
                            }), 128))
                          ])
                        ])
                      ])
                    ])
                  ])) : createCommentVNode("", true)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/invoices/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
