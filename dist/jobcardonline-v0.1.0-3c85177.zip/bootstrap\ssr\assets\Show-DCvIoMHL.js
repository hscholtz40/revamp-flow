import { defineComponent, computed, unref, withCtx, createTextVNode, createVNode, resolveDynamicComponent, toDisplayString, createBlock, createCommentVNode, openBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderVNode, ssrRenderClass, ssrRenderList } from "vue/server-renderer";
import { _ as _sfc_main$1, p as products } from "./AppLayout-CmGu2Oww.js";
import { Head, Link } from "@inertiajs/vue3";
import { Hash, Tag, DollarSign, Package, Calendar, Wrench } from "lucide-vue-next";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    product: {}
  },
  setup(__props) {
    const props = __props;
    function getTypeIcon(type) {
      return type === "product" ? Package : Wrench;
    }
    function getTypeColor(type) {
      return type === "product" ? "text-blue-600" : "text-green-600";
    }
    function getStockStatus(product) {
      if (!product.track_stock) return { text: "Not Tracked", color: "text-gray-500", bg: "bg-gray-100" };
      if (product.stock_quantity <= product.min_stock_level) {
        return { text: "Low Stock", color: "text-red-600", bg: "bg-red-100" };
      }
      return { text: "In Stock", color: "text-green-600", bg: "bg-green-100" };
    }
    const profitMargin = computed(() => {
      const cost = Number(props.product.cost);
      const price = Number(props.product.price);
      if (!cost || cost === 0) return null;
      return (price - cost) / cost * 100;
    });
    function deleteProduct() {
      if (confirm(`Are you sure you want to delete "${props.product.name}"?`)) {
        console.log("Delete product:", props.product.id);
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: props.product.name
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Products & Services", href: unref(products).index().url },
          { title: props.product.name, href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="space-y-6 p-4"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 p-6 shadow-sm"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>${ssrInterpolate(props.product.name)}</h1><p class="text-sm text-gray-500 mt-1"${_scopeId}>Product &amp; Service Details</p></div><div class="flex items-center gap-2"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(products).index().url,
              class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Back `);
                } else {
                  return [
                    createTextVNode(" Back ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            if (_ctx.$page.props.auth?.abilities?.products?.edit) {
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(products).edit(props.product.id).url,
                class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Edit `);
                  } else {
                    return [
                      createTextVNode(" Edit ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (_ctx.$page.props.auth?.abilities?.products?.delete) {
              _push2(`<button class="rounded-md border border-red-300 bg-white px-4 py-2 text-sm font-medium text-red-700 hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"${_scopeId}> Delete </button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Product Information</h2><p class="text-sm text-gray-600"${_scopeId}>Basic details and specifications</p></div><div class="p-6"${_scopeId}><div class="flex items-start gap-6"${_scopeId}><div class="flex-shrink-0"${_scopeId}><div class="flex h-16 w-16 items-center justify-center rounded-lg bg-gray-100"${_scopeId}>`);
            ssrRenderVNode(_push2, createVNode(resolveDynamicComponent(getTypeIcon(props.product.type)), {
              class: ["h-8 w-8", getTypeColor(props.product.type)]
            }, null), _parent2, _scopeId);
            _push2(`</div></div><div class="flex-1"${_scopeId}><div class="mb-4 flex items-center gap-3"${_scopeId}><span class="${ssrRenderClass([
              "inline-flex items-center rounded-full px-3 py-1 text-sm font-medium",
              props.product.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
            ])}"${_scopeId}>${ssrInterpolate(props.product.is_active ? "Active" : "Inactive")}</span><span class="${ssrRenderClass([
              "inline-flex items-center rounded-full px-3 py-1 text-sm font-medium",
              props.product.type === "product" ? "bg-blue-100 text-blue-800" : "bg-green-100 text-green-800"
            ])}"${_scopeId}>${ssrInterpolate(props.product.type.charAt(0).toUpperCase() + props.product.type.slice(1))}</span></div>`);
            if (props.product.description) {
              _push2(`<p class="text-gray-700 bg-gray-50 p-4 rounded-md"${_scopeId}>${ssrInterpolate(props.product.description)}</p>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div></div><div class="grid gap-6 lg:grid-cols-3"${_scopeId}><div class="lg:col-span-2 space-y-6"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Basic Information</h2><p class="text-sm text-gray-600"${_scopeId}>Product specifications and pricing</p></div><div class="p-6"${_scopeId}><div class="grid gap-4 md:grid-cols-2"${_scopeId}>`);
            if (props.product.sku) {
              _push2(`<div class="flex items-center gap-3"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Hash), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
              _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>SKU</div><div class="text-gray-900"${_scopeId}>${ssrInterpolate(props.product.sku)}</div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (props.product.category) {
              _push2(`<div class="flex items-center gap-3"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Tag), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
              _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Category</div><div class="text-gray-900"${_scopeId}>${ssrInterpolate(props.product.category)}</div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex items-center gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(DollarSign), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Price</div><div class="text-gray-900"${_scopeId}>R${ssrInterpolate(Number(props.product.price).toFixed(2))} / ${ssrInterpolate(props.product.unit)}</div></div></div>`);
            if (props.product.cost) {
              _push2(`<div class="flex items-center gap-3"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(DollarSign), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
              _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Cost</div><div class="text-gray-900"${_scopeId}>R${ssrInterpolate(Number(props.product.cost).toFixed(2))}</div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (profitMargin.value) {
              _push2(`<div class="flex items-center gap-3"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(DollarSign), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
              _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Profit Margin</div><div class="text-gray-900"${_scopeId}>${ssrInterpolate(profitMargin.value.toFixed(1))}%</div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div>`);
            if (props.product.type === "product") {
              _push2(`<div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Inventory Information</h2><p class="text-sm text-gray-600"${_scopeId}>Stock tracking and inventory details</p></div><div class="p-6"${_scopeId}><div class="grid gap-4 md:grid-cols-3"${_scopeId}><div class="flex items-center gap-3"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Package), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
              _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Stock Tracking</div><div class="text-gray-900"${_scopeId}>${ssrInterpolate(props.product.track_stock ? "Enabled" : "Disabled")}</div></div></div>`);
              if (props.product.track_stock) {
                _push2(`<div class="flex items-center gap-3"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Hash), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
                _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Current Stock</div><div class="text-gray-900"${_scopeId}>${ssrInterpolate(props.product.stock_quantity)}</div></div></div>`);
              } else {
                _push2(`<!---->`);
              }
              if (props.product.track_stock) {
                _push2(`<div class="flex items-center gap-3"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Hash), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
                _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Min Stock Level</div><div class="text-gray-900"${_scopeId}>${ssrInterpolate(props.product.min_stock_level)}</div></div></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
              if (props.product.track_stock) {
                _push2(`<div class="mt-4"${_scopeId}><div class="flex items-center gap-2"${_scopeId}><span class="text-sm font-medium text-gray-500"${_scopeId}>Stock Status:</span><span class="${ssrRenderClass([
                  "inline-flex items-center rounded-full px-2 py-1 text-xs font-medium",
                  getStockStatus(props.product).bg,
                  getStockStatus(props.product).color
                ])}"${_scopeId}>${ssrInterpolate(getStockStatus(props.product).text)}</span></div></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (props.product.tags && props.product.tags.length > 0) {
              _push2(`<div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Tags</h2><p class="text-sm text-gray-600"${_scopeId}>Product categorization tags</p></div><div class="p-6"${_scopeId}><div class="flex flex-wrap gap-2"${_scopeId}><!--[-->`);
              ssrRenderList(props.product.tags, (tag) => {
                _push2(`<span class="inline-flex items-center rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-800"${_scopeId}>${ssrInterpolate(tag)}</span>`);
              });
              _push2(`<!--]--></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (props.product.notes) {
              _push2(`<div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Notes</h2><p class="text-sm text-gray-600"${_scopeId}>Additional product information</p></div><div class="p-6"${_scopeId}><div class="text-gray-700 whitespace-pre-wrap bg-gray-50 p-4 rounded-md"${_scopeId}>${ssrInterpolate(props.product.notes)}</div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="space-y-6"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h3 class="text-lg font-semibold text-gray-900"${_scopeId}>Quick Stats</h3><p class="text-sm text-gray-600"${_scopeId}>Product overview and status</p></div><div class="p-6"${_scopeId}><div class="space-y-4"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Type</span><span class="text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(props.product.type.charAt(0).toUpperCase() + props.product.type.slice(1))}</span></div><div class="flex items-center justify-between"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Status</span><span class="${ssrRenderClass([
              "text-sm font-medium",
              props.product.is_active ? "text-green-600" : "text-red-600"
            ])}"${_scopeId}>${ssrInterpolate(props.product.is_active ? "Active" : "Inactive")}</span></div>`);
            if (props.product.track_stock) {
              _push2(`<div class="flex items-center justify-between"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Stock Status</span><span class="${ssrRenderClass([
                "text-sm font-medium",
                getStockStatus(props.product).color
              ])}"${_scopeId}>${ssrInterpolate(getStockStatus(props.product).text)}</span></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (profitMargin.value) {
              _push2(`<div class="flex items-center justify-between"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Profit Margin</span><span class="text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(profitMargin.value.toFixed(1))}% </span></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h3 class="text-lg font-semibold text-gray-900"${_scopeId}>Timestamps</h3><p class="text-sm text-gray-600"${_scopeId}>Creation and modification dates</p></div><div class="p-6"${_scopeId}><div class="space-y-4"${_scopeId}><div class="flex items-center gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Calendar), { class: "h-4 w-4 text-gray-400" }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Created</div><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(new Date(props.product.created_at).toLocaleDateString())}</div></div></div><div class="flex items-center gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Calendar), { class: "h-4 w-4 text-gray-400" }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Last Updated</div><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(new Date(props.product.updated_at).toLocaleDateString())}</div></div></div></div></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "space-y-6 p-4" }, [
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 p-6 shadow-sm" }, [
                  createVNode("div", { class: "flex items-center justify-between" }, [
                    createVNode("div", null, [
                      createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, toDisplayString(props.product.name), 1),
                      createVNode("p", { class: "text-sm text-gray-500 mt-1" }, "Product & Service Details")
                    ]),
                    createVNode("div", { class: "flex items-center gap-2" }, [
                      createVNode(unref(Link), {
                        href: unref(products).index().url,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Back ")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      _ctx.$page.props.auth?.abilities?.products?.edit ? (openBlock(), createBlock(unref(Link), {
                        key: 0,
                        href: unref(products).edit(props.product.id).url,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Edit ")
                        ]),
                        _: 1
                      }, 8, ["href"])) : createCommentVNode("", true),
                      _ctx.$page.props.auth?.abilities?.products?.delete ? (openBlock(), createBlock("button", {
                        key: 1,
                        onClick: deleteProduct,
                        class: "rounded-md border border-red-300 bg-white px-4 py-2 text-sm font-medium text-red-700 hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                      }, " Delete ")) : createCommentVNode("", true)
                    ])
                  ])
                ]),
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                  createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Product Information"),
                    createVNode("p", { class: "text-sm text-gray-600" }, "Basic details and specifications")
                  ]),
                  createVNode("div", { class: "p-6" }, [
                    createVNode("div", { class: "flex items-start gap-6" }, [
                      createVNode("div", { class: "flex-shrink-0" }, [
                        createVNode("div", { class: "flex h-16 w-16 items-center justify-center rounded-lg bg-gray-100" }, [
                          (openBlock(), createBlock(resolveDynamicComponent(getTypeIcon(props.product.type)), {
                            class: ["h-8 w-8", getTypeColor(props.product.type)]
                          }, null, 8, ["class"]))
                        ])
                      ]),
                      createVNode("div", { class: "flex-1" }, [
                        createVNode("div", { class: "mb-4 flex items-center gap-3" }, [
                          createVNode("span", {
                            class: [
                              "inline-flex items-center rounded-full px-3 py-1 text-sm font-medium",
                              props.product.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                            ]
                          }, toDisplayString(props.product.is_active ? "Active" : "Inactive"), 3),
                          createVNode("span", {
                            class: [
                              "inline-flex items-center rounded-full px-3 py-1 text-sm font-medium",
                              props.product.type === "product" ? "bg-blue-100 text-blue-800" : "bg-green-100 text-green-800"
                            ]
                          }, toDisplayString(props.product.type.charAt(0).toUpperCase() + props.product.type.slice(1)), 3)
                        ]),
                        props.product.description ? (openBlock(), createBlock("p", {
                          key: 0,
                          class: "text-gray-700 bg-gray-50 p-4 rounded-md"
                        }, toDisplayString(props.product.description), 1)) : createCommentVNode("", true)
                      ])
                    ])
                  ])
                ]),
                createVNode("div", { class: "grid gap-6 lg:grid-cols-3" }, [
                  createVNode("div", { class: "lg:col-span-2 space-y-6" }, [
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Basic Information"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Product specifications and pricing")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "grid gap-4 md:grid-cols-2" }, [
                          props.product.sku ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "flex items-center gap-3"
                          }, [
                            createVNode(unref(Hash), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "SKU"),
                              createVNode("div", { class: "text-gray-900" }, toDisplayString(props.product.sku), 1)
                            ])
                          ])) : createCommentVNode("", true),
                          props.product.category ? (openBlock(), createBlock("div", {
                            key: 1,
                            class: "flex items-center gap-3"
                          }, [
                            createVNode(unref(Tag), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Category"),
                              createVNode("div", { class: "text-gray-900" }, toDisplayString(props.product.category), 1)
                            ])
                          ])) : createCommentVNode("", true),
                          createVNode("div", { class: "flex items-center gap-3" }, [
                            createVNode(unref(DollarSign), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Price"),
                              createVNode("div", { class: "text-gray-900" }, "R" + toDisplayString(Number(props.product.price).toFixed(2)) + " / " + toDisplayString(props.product.unit), 1)
                            ])
                          ]),
                          props.product.cost ? (openBlock(), createBlock("div", {
                            key: 2,
                            class: "flex items-center gap-3"
                          }, [
                            createVNode(unref(DollarSign), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Cost"),
                              createVNode("div", { class: "text-gray-900" }, "R" + toDisplayString(Number(props.product.cost).toFixed(2)), 1)
                            ])
                          ])) : createCommentVNode("", true),
                          profitMargin.value ? (openBlock(), createBlock("div", {
                            key: 3,
                            class: "flex items-center gap-3"
                          }, [
                            createVNode(unref(DollarSign), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Profit Margin"),
                              createVNode("div", { class: "text-gray-900" }, toDisplayString(profitMargin.value.toFixed(1)) + "%", 1)
                            ])
                          ])) : createCommentVNode("", true)
                        ])
                      ])
                    ]),
                    props.product.type === "product" ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "rounded-lg bg-white border border-gray-200 shadow-sm"
                    }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Inventory Information"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Stock tracking and inventory details")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "grid gap-4 md:grid-cols-3" }, [
                          createVNode("div", { class: "flex items-center gap-3" }, [
                            createVNode(unref(Package), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Stock Tracking"),
                              createVNode("div", { class: "text-gray-900" }, toDisplayString(props.product.track_stock ? "Enabled" : "Disabled"), 1)
                            ])
                          ]),
                          props.product.track_stock ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "flex items-center gap-3"
                          }, [
                            createVNode(unref(Hash), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Current Stock"),
                              createVNode("div", { class: "text-gray-900" }, toDisplayString(props.product.stock_quantity), 1)
                            ])
                          ])) : createCommentVNode("", true),
                          props.product.track_stock ? (openBlock(), createBlock("div", {
                            key: 1,
                            class: "flex items-center gap-3"
                          }, [
                            createVNode(unref(Hash), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Min Stock Level"),
                              createVNode("div", { class: "text-gray-900" }, toDisplayString(props.product.min_stock_level), 1)
                            ])
                          ])) : createCommentVNode("", true)
                        ]),
                        props.product.track_stock ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "mt-4"
                        }, [
                          createVNode("div", { class: "flex items-center gap-2" }, [
                            createVNode("span", { class: "text-sm font-medium text-gray-500" }, "Stock Status:"),
                            createVNode("span", {
                              class: [
                                "inline-flex items-center rounded-full px-2 py-1 text-xs font-medium",
                                getStockStatus(props.product).bg,
                                getStockStatus(props.product).color
                              ]
                            }, toDisplayString(getStockStatus(props.product).text), 3)
                          ])
                        ])) : createCommentVNode("", true)
                      ])
                    ])) : createCommentVNode("", true),
                    props.product.tags && props.product.tags.length > 0 ? (openBlock(), createBlock("div", {
                      key: 1,
                      class: "rounded-lg bg-white border border-gray-200 shadow-sm"
                    }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Tags"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Product categorization tags")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "flex flex-wrap gap-2" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(props.product.tags, (tag) => {
                            return openBlock(), createBlock("span", {
                              key: tag,
                              class: "inline-flex items-center rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-800"
                            }, toDisplayString(tag), 1);
                          }), 128))
                        ])
                      ])
                    ])) : createCommentVNode("", true),
                    props.product.notes ? (openBlock(), createBlock("div", {
                      key: 2,
                      class: "rounded-lg bg-white border border-gray-200 shadow-sm"
                    }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Notes"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Additional product information")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "text-gray-700 whitespace-pre-wrap bg-gray-50 p-4 rounded-md" }, toDisplayString(props.product.notes), 1)
                      ])
                    ])) : createCommentVNode("", true)
                  ]),
                  createVNode("div", { class: "space-y-6" }, [
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h3", { class: "text-lg font-semibold text-gray-900" }, "Quick Stats"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Product overview and status")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "space-y-4" }, [
                          createVNode("div", { class: "flex items-center justify-between" }, [
                            createVNode("span", { class: "text-sm text-gray-500" }, "Type"),
                            createVNode("span", { class: "text-sm font-medium text-gray-900" }, toDisplayString(props.product.type.charAt(0).toUpperCase() + props.product.type.slice(1)), 1)
                          ]),
                          createVNode("div", { class: "flex items-center justify-between" }, [
                            createVNode("span", { class: "text-sm text-gray-500" }, "Status"),
                            createVNode("span", {
                              class: [
                                "text-sm font-medium",
                                props.product.is_active ? "text-green-600" : "text-red-600"
                              ]
                            }, toDisplayString(props.product.is_active ? "Active" : "Inactive"), 3)
                          ]),
                          props.product.track_stock ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "flex items-center justify-between"
                          }, [
                            createVNode("span", { class: "text-sm text-gray-500" }, "Stock Status"),
                            createVNode("span", {
                              class: [
                                "text-sm font-medium",
                                getStockStatus(props.product).color
                              ]
                            }, toDisplayString(getStockStatus(props.product).text), 3)
                          ])) : createCommentVNode("", true),
                          profitMargin.value ? (openBlock(), createBlock("div", {
                            key: 1,
                            class: "flex items-center justify-between"
                          }, [
                            createVNode("span", { class: "text-sm text-gray-500" }, "Profit Margin"),
                            createVNode("span", { class: "text-sm font-medium text-gray-900" }, toDisplayString(profitMargin.value.toFixed(1)) + "% ", 1)
                          ])) : createCommentVNode("", true)
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h3", { class: "text-lg font-semibold text-gray-900" }, "Timestamps"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Creation and modification dates")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "space-y-4" }, [
                          createVNode("div", { class: "flex items-center gap-3" }, [
                            createVNode(unref(Calendar), { class: "h-4 w-4 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Created"),
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(new Date(props.product.created_at).toLocaleDateString()), 1)
                            ])
                          ]),
                          createVNode("div", { class: "flex items-center gap-3" }, [
                            createVNode(unref(Calendar), { class: "h-4 w-4 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Last Updated"),
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(new Date(props.product.updated_at).toLocaleDateString()), 1)
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/products/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
