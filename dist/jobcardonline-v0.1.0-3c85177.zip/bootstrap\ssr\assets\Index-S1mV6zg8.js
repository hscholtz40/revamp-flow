import { defineComponent, unref, withCtx, createVNode, createTextVNode, createBlock, openBlock, Fragment, renderList, createCommentVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderStyle, ssrInterpolate, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1, a as administration } from "./AppLayout-CmGu2Oww.js";
import { Head, Link, router } from "@inertiajs/vue3";
import { Plus, Tag, Eye, Edit, Trash2 } from "lucide-vue-next";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    categories: {}
  },
  setup(__props) {
    const props = __props;
    function deleteCategory(category) {
      if (category.products_count > 0) {
        alert(`Cannot delete "${category.name}" because it has ${category.products_count} products. Please move or delete the products first.`);
        return;
      }
      if (confirm(`Are you sure you want to delete "${category.name}"?`)) {
        router.delete(administration.categories.destroy(category.id).url);
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Category Management" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Administration", href: unref(administration).index().url },
          { title: "Categories", href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-4"${_scopeId}><div class="mb-6 flex items-center justify-between"${_scopeId}><div${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>Category Management</h1><p class="text-gray-600"${_scopeId}>Manage product and service categories</p></div>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(administration).categories.create().url,
              class: "flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Plus), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                  _push3(` Add Category `);
                } else {
                  return [
                    createVNode(unref(Plus), { class: "h-4 w-4" }),
                    createTextVNode(" Add Category ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
            if (props.categories.length === 0) {
              _push2(`<div class="rounded-lg border bg-white p-8 text-center"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Tag), { class: "mx-auto h-12 w-12 text-gray-400" }, null, _parent2, _scopeId));
              _push2(`<h3 class="mt-2 text-lg font-medium text-gray-900"${_scopeId}>No categories found</h3><p class="mt-1 text-gray-500"${_scopeId}>Get started by creating your first category.</p><div class="mt-6"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(administration).categories.create().url,
                class: "inline-flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(unref(Plus), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                    _push3(` Add Category `);
                  } else {
                    return [
                      createVNode(unref(Plus), { class: "h-4 w-4" }),
                      createTextVNode(" Add Category ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div></div>`);
            } else {
              _push2(`<div class="grid gap-6 md:grid-cols-2 lg:grid-cols-3"${_scopeId}><!--[-->`);
              ssrRenderList(props.categories, (category) => {
                _push2(`<div class="rounded-lg border bg-white p-6 shadow-sm hover:shadow-md transition-shadow"${_scopeId}><div class="mb-4 flex items-start justify-between"${_scopeId}><div class="flex items-center gap-3"${_scopeId}><div class="h-4 w-4 rounded-full" style="${ssrRenderStyle({ backgroundColor: category.color })}"${_scopeId}></div><div${_scopeId}><h3 class="font-semibold text-gray-900"${_scopeId}>${ssrInterpolate(category.name)}</h3><p class="text-sm text-gray-500"${_scopeId}>${ssrInterpolate(category.products_count)} products</p></div></div><span class="${ssrRenderClass([
                  "rounded-full px-2 py-1 text-xs font-medium",
                  category.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                ])}"${_scopeId}>${ssrInterpolate(category.is_active ? "Active" : "Inactive")}</span></div>`);
                if (category.description) {
                  _push2(`<p class="mb-4 text-sm text-gray-600 line-clamp-2"${_scopeId}>${ssrInterpolate(category.description)}</p>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`<div class="mb-4 text-sm text-gray-500"${_scopeId}> Sort Order: ${ssrInterpolate(category.sort_order)}</div><div class="flex items-center gap-2"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: unref(administration).categories.show(category.id).url,
                  class: "flex items-center gap-1 rounded border px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(Eye), { class: "h-3 w-3" }, null, _parent3, _scopeId2));
                      _push3(` View `);
                    } else {
                      return [
                        createVNode(unref(Eye), { class: "h-3 w-3" }),
                        createTextVNode(" View ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(ssrRenderComponent(unref(Link), {
                  href: unref(administration).categories.edit(category.id).url,
                  class: "flex items-center gap-1 rounded border px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(Edit), { class: "h-3 w-3" }, null, _parent3, _scopeId2));
                      _push3(` Edit `);
                    } else {
                      return [
                        createVNode(unref(Edit), { class: "h-3 w-3" }),
                        createTextVNode(" Edit ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`<button class="flex items-center gap-1 rounded border border-red-300 px-3 py-1 text-sm text-red-700 hover:bg-red-50"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Trash2), { class: "h-3 w-3" }, null, _parent2, _scopeId));
                _push2(` Delete </button></div></div>`);
              });
              _push2(`<!--]--></div>`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "mb-6 flex items-center justify-between" }, [
                  createVNode("div", null, [
                    createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "Category Management"),
                    createVNode("p", { class: "text-gray-600" }, "Manage product and service categories")
                  ]),
                  createVNode(unref(Link), {
                    href: unref(administration).categories.create().url,
                    class: "flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(Plus), { class: "h-4 w-4" }),
                      createTextVNode(" Add Category ")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ]),
                props.categories.length === 0 ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "rounded-lg border bg-white p-8 text-center"
                }, [
                  createVNode(unref(Tag), { class: "mx-auto h-12 w-12 text-gray-400" }),
                  createVNode("h3", { class: "mt-2 text-lg font-medium text-gray-900" }, "No categories found"),
                  createVNode("p", { class: "mt-1 text-gray-500" }, "Get started by creating your first category."),
                  createVNode("div", { class: "mt-6" }, [
                    createVNode(unref(Link), {
                      href: unref(administration).categories.create().url,
                      class: "inline-flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(Plus), { class: "h-4 w-4" }),
                        createTextVNode(" Add Category ")
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ])
                ])) : (openBlock(), createBlock("div", {
                  key: 1,
                  class: "grid gap-6 md:grid-cols-2 lg:grid-cols-3"
                }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(props.categories, (category) => {
                    return openBlock(), createBlock("div", {
                      key: category.id,
                      class: "rounded-lg border bg-white p-6 shadow-sm hover:shadow-md transition-shadow"
                    }, [
                      createVNode("div", { class: "mb-4 flex items-start justify-between" }, [
                        createVNode("div", { class: "flex items-center gap-3" }, [
                          createVNode("div", {
                            class: "h-4 w-4 rounded-full",
                            style: { backgroundColor: category.color }
                          }, null, 4),
                          createVNode("div", null, [
                            createVNode("h3", { class: "font-semibold text-gray-900" }, toDisplayString(category.name), 1),
                            createVNode("p", { class: "text-sm text-gray-500" }, toDisplayString(category.products_count) + " products", 1)
                          ])
                        ]),
                        createVNode("span", {
                          class: [
                            "rounded-full px-2 py-1 text-xs font-medium",
                            category.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                          ]
                        }, toDisplayString(category.is_active ? "Active" : "Inactive"), 3)
                      ]),
                      category.description ? (openBlock(), createBlock("p", {
                        key: 0,
                        class: "mb-4 text-sm text-gray-600 line-clamp-2"
                      }, toDisplayString(category.description), 1)) : createCommentVNode("", true),
                      createVNode("div", { class: "mb-4 text-sm text-gray-500" }, " Sort Order: " + toDisplayString(category.sort_order), 1),
                      createVNode("div", { class: "flex items-center gap-2" }, [
                        createVNode(unref(Link), {
                          href: unref(administration).categories.show(category.id).url,
                          class: "flex items-center gap-1 rounded border px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(Eye), { class: "h-3 w-3" }),
                            createTextVNode(" View ")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode(unref(Link), {
                          href: unref(administration).categories.edit(category.id).url,
                          class: "flex items-center gap-1 rounded border px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(Edit), { class: "h-3 w-3" }),
                            createTextVNode(" Edit ")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode("button", {
                          onClick: ($event) => deleteCategory(category),
                          class: "flex items-center gap-1 rounded border border-red-300 px-3 py-1 text-sm text-red-700 hover:bg-red-50"
                        }, [
                          createVNode(unref(Trash2), { class: "h-3 w-3" }),
                          createTextVNode(" Delete ")
                        ], 8, ["onClick"])
                      ])
                    ]);
                  }), 128))
                ]))
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/administration/categories/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
