import { defineComponent, ref, nextTick, watch, unref, withCtx, createTextVNode, createVNode, toDisplayString, withDirectives, vModelText, vModelSelect, createBlock, openBlock, Fragment, renderList, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import { router, Head, Link } from "@inertiajs/vue3";
import { j as jobcards } from "./_plugin-vue_export-helper-BjD8VFd3.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    jobcards: {},
    customers: {},
    filters: {},
    currentCompany: {},
    canEditCompleted: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    console.log("Jobcards Index Props:", {
      jobcards: props.jobcards,
      customers: props.customers,
      filters: props.filters,
      currentCompany: props.currentCompany
    });
    const search = ref(props.filters?.search || "");
    const status = ref(props.filters?.status || "");
    const customerId = ref(props.filters?.customer_id || "");
    let isInitialized = false;
    nextTick(() => {
      isInitialized = true;
    });
    const clearFilters = () => {
      search.value = "";
      status.value = "";
      customerId.value = "";
      router.get(jobcards.index().url, {}, {
        preserveState: true,
        replace: true
      });
    };
    const canEditJobcard = (jobcard) => {
      if (jobcard.status !== "completed") {
        return true;
      }
      return props.canEditCompleted;
    };
    const canDeleteJobcard = (jobcard) => {
      if (jobcard.status !== "completed") {
        return true;
      }
      return props.canEditCompleted;
    };
    const deleteJobcard = (jobcard) => {
      if (!jobcard || !jobcard.id) {
        console.error("Invalid jobcard data:", jobcard);
        return;
      }
      const jobNumber = jobcard.job_number || `#${jobcard.id}`;
      if (confirm(`Are you sure you want to delete jobcard ${jobNumber}?`)) {
        router.delete(jobcards.destroy(jobcard.id).url, {
          onSuccess: () => {
            console.log("Jobcard deleted successfully");
          },
          onError: (errors) => {
            console.error("Error deleting jobcard:", errors);
            alert("Failed to delete jobcard. Please try again.");
          }
        });
      }
    };
    const getStatusBadgeClass = (status2) => {
      if (!status2) return "bg-gray-100 text-gray-800";
      const classes = {
        draft: "bg-gray-100 text-gray-800",
        pending: "bg-yellow-100 text-yellow-800",
        in_progress: "bg-blue-100 text-blue-800",
        completed: "bg-green-100 text-green-800",
        cancelled: "bg-red-100 text-red-800"
      };
      return classes[status2] || classes.draft;
    };
    const formatStatus = (status2) => {
      if (!status2) return "";
      return status2.replace("_", " ").replace(/\b\w/g, (l) => l.toUpperCase());
    };
    const formatDate = (date) => {
      if (!date) return "";
      return new Date(date).toLocaleDateString();
    };
    watch([search, status, customerId], () => {
      if (!isInitialized || !props.filters) return;
      const params = {};
      if (search.value && search.value.trim()) params.search = search.value.trim();
      if (status.value && status.value.trim()) params.status = status.value.trim();
      if (customerId.value && customerId.value.trim()) params.customer_id = customerId.value.trim();
      router.get(jobcards.index().url, params, {
        preserveState: true,
        replace: true
      });
    }, { immediate: false });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Jobcards" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [{ title: "Jobcards", href: unref(jobcards).index().url }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-blue-50 border-b border-blue-200 px-4 py-3"${_scopeId}><div class="flex items-center gap-2 text-sm text-blue-700"${_scopeId}><span class="font-medium"${_scopeId}>Viewing jobcards for:</span><span class="font-semibold"${_scopeId}>${ssrInterpolate(props.currentCompany.name)}</span></div></div><div class="p-4"${_scopeId}><div class="flex items-center justify-between gap-3 mb-6"${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>Jobcards</h1>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(jobcards).create().url,
              class: "rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` New Jobcard `);
                } else {
                  return [
                    createTextVNode(" New Jobcard ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="bg-white rounded-lg border p-4 mb-6"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-4 gap-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Search</label><input${ssrRenderAttr("value", search.value)} type="search" placeholder="Search jobcards..." class="w-full rounded border px-3 py-2"${_scopeId}></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Status</label><select class="w-full rounded border px-3 py-2"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "") : ssrLooseEqual(status.value, "")) ? " selected" : ""}${_scopeId}>All Statuses</option><option value="draft"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "draft") : ssrLooseEqual(status.value, "draft")) ? " selected" : ""}${_scopeId}>Draft</option><option value="pending"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "pending") : ssrLooseEqual(status.value, "pending")) ? " selected" : ""}${_scopeId}>Pending</option><option value="in_progress"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "in_progress") : ssrLooseEqual(status.value, "in_progress")) ? " selected" : ""}${_scopeId}>In Progress</option><option value="completed"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "completed") : ssrLooseEqual(status.value, "completed")) ? " selected" : ""}${_scopeId}>Completed</option><option value="cancelled"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "cancelled") : ssrLooseEqual(status.value, "cancelled")) ? " selected" : ""}${_scopeId}>Cancelled</option></select></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Customer</label><select class="w-full rounded border px-3 py-2"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(customerId.value) ? ssrLooseContain(customerId.value, "") : ssrLooseEqual(customerId.value, "")) ? " selected" : ""}${_scopeId}>All Customers</option><!--[-->`);
            ssrRenderList(props.customers, (customer) => {
              _push2(`<option${ssrRenderAttr("value", customer.id)}${ssrIncludeBooleanAttr(Array.isArray(customerId.value) ? ssrLooseContain(customerId.value, customer.id) : ssrLooseEqual(customerId.value, customer.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(customer.name)}</option>`);
            });
            _push2(`<!--]--></select></div><div class="flex items-end"${_scopeId}><button class="w-full rounded border border-gray-300 px-3 py-2 text-gray-700 hover:bg-gray-50"${_scopeId}> Clear Filters </button></div></div></div><div class="bg-white rounded-lg border overflow-hidden"${_scopeId}><div class="overflow-x-auto"${_scopeId}><table class="w-full"${_scopeId}><thead class="bg-gray-50"${_scopeId}><tr${_scopeId}><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Job Number </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Title </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Customer </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Status </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Due Date </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Total </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Actions </th></tr></thead><tbody class="bg-white divide-y divide-gray-200"${_scopeId}><!--[-->`);
            ssrRenderList(props.jobcards.data, (jobcard) => {
              _push2(`<tr class="hover:bg-gray-50"${_scopeId}><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(jobcard.job_number)}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(jobcard.title)}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(jobcard.customer.name)}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><span class="${ssrRenderClass([getStatusBadgeClass(jobcard.status), "inline-flex px-2 py-1 text-xs font-semibold rounded-full"])}"${_scopeId}>${ssrInterpolate(formatStatus(jobcard.status))}</span></td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"${_scopeId}>${ssrInterpolate(jobcard.due_date ? formatDate(jobcard.due_date) : "-")}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"${_scopeId}>${ssrInterpolate(jobcard.formatted_total || "R0.00")}</td><td class="px-6 py-4 whitespace-nowrap text-sm font-medium"${_scopeId}><div class="flex items-center gap-2"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(jobcards).show(jobcard.id).url,
                class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` View `);
                  } else {
                    return [
                      createTextVNode(" View ")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              if (canEditJobcard(jobcard)) {
                _push2(ssrRenderComponent(unref(Link), {
                  href: unref(jobcards).edit(jobcard.id).url,
                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` Edit `);
                    } else {
                      return [
                        createTextVNode(" Edit ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              } else {
                _push2(`<span class="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed" title="Cannot edit completed jobcards without permission"${_scopeId}> Edit </span>`);
              }
              if (canDeleteJobcard(jobcard)) {
                _push2(`<button class="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-red-700 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"${_scopeId}> Delete </button>`);
              } else {
                _push2(`<span class="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed" title="Cannot delete completed jobcards without permission"${_scopeId}> Delete </span>`);
              }
              _push2(`</div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div>`);
            if (props.jobcards.links) {
              _push2(`<div class="bg-white px-4 py-3 border-t border-gray-200"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div class="text-sm text-gray-700"${_scopeId}> Showing ${ssrInterpolate(props.jobcards.from)} to ${ssrInterpolate(props.jobcards.to)} of ${ssrInterpolate(props.jobcards.total)} results </div><div class="flex space-x-1"${_scopeId}><!--[-->`);
              ssrRenderList(props.jobcards.links, (link) => {
                _push2(ssrRenderComponent(unref(Link), {
                  key: link.label,
                  href: link.url || "#",
                  class: [
                    "px-3 py-2 text-sm border rounded",
                    link.active ? "bg-blue-50 border-blue-500 text-blue-600" : "border-gray-300 text-gray-700 hover:bg-gray-50",
                    !link.url ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
                  ]
                }, null, _parent2, _scopeId));
              });
              _push2(`<!--]--></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-blue-50 border-b border-blue-200 px-4 py-3" }, [
                createVNode("div", { class: "flex items-center gap-2 text-sm text-blue-700" }, [
                  createVNode("span", { class: "font-medium" }, "Viewing jobcards for:"),
                  createVNode("span", { class: "font-semibold" }, toDisplayString(props.currentCompany.name), 1)
                ])
              ]),
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "flex items-center justify-between gap-3 mb-6" }, [
                  createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "Jobcards"),
                  createVNode(unref(Link), {
                    href: unref(jobcards).create().url,
                    class: "rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" New Jobcard ")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ]),
                createVNode("div", { class: "bg-white rounded-lg border p-4 mb-6" }, [
                  createVNode("div", { class: "grid grid-cols-1 md:grid-cols-4 gap-4" }, [
                    createVNode("div", null, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Search"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => search.value = $event,
                        type: "search",
                        placeholder: "Search jobcards...",
                        class: "w-full rounded border px-3 py-2"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, search.value]
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Status"),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => status.value = $event,
                        class: "w-full rounded border px-3 py-2"
                      }, [
                        createVNode("option", { value: "" }, "All Statuses"),
                        createVNode("option", { value: "draft" }, "Draft"),
                        createVNode("option", { value: "pending" }, "Pending"),
                        createVNode("option", { value: "in_progress" }, "In Progress"),
                        createVNode("option", { value: "completed" }, "Completed"),
                        createVNode("option", { value: "cancelled" }, "Cancelled")
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, status.value]
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Customer"),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => customerId.value = $event,
                        class: "w-full rounded border px-3 py-2"
                      }, [
                        createVNode("option", { value: "" }, "All Customers"),
                        (openBlock(true), createBlock(Fragment, null, renderList(props.customers, (customer) => {
                          return openBlock(), createBlock("option", {
                            key: customer.id,
                            value: customer.id
                          }, toDisplayString(customer.name), 9, ["value"]);
                        }), 128))
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, customerId.value]
                      ])
                    ]),
                    createVNode("div", { class: "flex items-end" }, [
                      createVNode("button", {
                        onClick: clearFilters,
                        class: "w-full rounded border border-gray-300 px-3 py-2 text-gray-700 hover:bg-gray-50"
                      }, " Clear Filters ")
                    ])
                  ])
                ]),
                createVNode("div", { class: "bg-white rounded-lg border overflow-hidden" }, [
                  createVNode("div", { class: "overflow-x-auto" }, [
                    createVNode("table", { class: "w-full" }, [
                      createVNode("thead", { class: "bg-gray-50" }, [
                        createVNode("tr", null, [
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Job Number "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Title "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Customer "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Status "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Due Date "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Total "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Actions ")
                        ])
                      ]),
                      createVNode("tbody", { class: "bg-white divide-y divide-gray-200" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(props.jobcards.data, (jobcard) => {
                          return openBlock(), createBlock("tr", {
                            key: jobcard.id,
                            class: "hover:bg-gray-50"
                          }, [
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm font-medium text-gray-900" }, toDisplayString(jobcard.job_number), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(jobcard.title), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(jobcard.customer.name), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("span", {
                                class: [getStatusBadgeClass(jobcard.status), "inline-flex px-2 py-1 text-xs font-semibold rounded-full"]
                              }, toDisplayString(formatStatus(jobcard.status)), 3)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm text-gray-900" }, toDisplayString(jobcard.due_date ? formatDate(jobcard.due_date) : "-"), 1),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm text-gray-900" }, toDisplayString(jobcard.formatted_total || "R0.00"), 1),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm font-medium" }, [
                              createVNode("div", { class: "flex items-center gap-2" }, [
                                createVNode(unref(Link), {
                                  href: unref(jobcards).show(jobcard.id).url,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" View ")
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                canEditJobcard(jobcard) ? (openBlock(), createBlock(unref(Link), {
                                  key: 0,
                                  href: unref(jobcards).edit(jobcard.id).url,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Edit ")
                                  ]),
                                  _: 1
                                }, 8, ["href"])) : (openBlock(), createBlock("span", {
                                  key: 1,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed",
                                  title: "Cannot edit completed jobcards without permission"
                                }, " Edit ")),
                                canDeleteJobcard(jobcard) ? (openBlock(), createBlock("button", {
                                  key: 2,
                                  onClick: ($event) => deleteJobcard(jobcard),
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-red-700 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                                }, " Delete ", 8, ["onClick"])) : (openBlock(), createBlock("span", {
                                  key: 3,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed",
                                  title: "Cannot delete completed jobcards without permission"
                                }, " Delete "))
                              ])
                            ])
                          ]);
                        }), 128))
                      ])
                    ])
                  ]),
                  props.jobcards.links ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "bg-white px-4 py-3 border-t border-gray-200"
                  }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", { class: "text-sm text-gray-700" }, " Showing " + toDisplayString(props.jobcards.from) + " to " + toDisplayString(props.jobcards.to) + " of " + toDisplayString(props.jobcards.total) + " results ", 1),
                      createVNode("div", { class: "flex space-x-1" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(props.jobcards.links, (link) => {
                          return openBlock(), createBlock(unref(Link), {
                            key: link.label,
                            href: link.url || "#",
                            innerHTML: link.label,
                            class: [
                              "px-3 py-2 text-sm border rounded",
                              link.active ? "bg-blue-50 border-blue-500 text-blue-600" : "border-gray-300 text-gray-700 hover:bg-gray-50",
                              !link.url ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
                            ]
                          }, null, 8, ["href", "innerHTML", "class"]);
                        }), 128))
                      ])
                    ])
                  ])) : createCommentVNode("", true)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/jobcards/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
