import { defineComponent, ref, watch, unref, withCtx, createTextVNode, createVNode, createBlock, createCommentVNode, toDisplayString, openBlock, withDirectives, vModelText, vModelSelect, Fragment, renderList, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1, b as customers, d as contacts } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link, router } from "@inertiajs/vue3";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    customer: {},
    contacts: {},
    smsActivities: {},
    filters: {}
  },
  setup(__props) {
    const props = __props;
    const showSMSModal = ref(false);
    const showSMSResultModal = ref(false);
    const smsResult = ref(null);
    const smsForm = useForm({
      message: ""
    });
    const openSMSModal = () => {
      smsForm.message = "";
      showSMSModal.value = true;
    };
    const sendSMS = () => {
      smsForm.post(customers.sendSMS(props.customer.id).url, {
        onSuccess: (page) => {
          showSMSModal.value = false;
          smsForm.reset();
          smsResult.value = {
            success: true,
            message: page.props.flash?.success || "SMS sent successfully!"
          };
          showSMSResultModal.value = true;
        },
        onError: (errors) => {
          showSMSModal.value = false;
          const errorMessage = errors.message || "Failed to send SMS. Please try again.";
          smsResult.value = {
            success: false,
            message: errorMessage
          };
          showSMSResultModal.value = true;
        }
      });
    };
    const closeSMSResultModal = () => {
      showSMSResultModal.value = false;
      smsResult.value = null;
    };
    const contactSearch = ref(String(props.filters?.contact_search ?? ""));
    const contactsPerPage = ref(Number(props.filters?.contacts_per_page ?? 5));
    const smsSearch = ref(String(props.filters?.sms_search ?? ""));
    const smsStatus = ref(String(props.filters?.sms_status ?? ""));
    const smsPerPage = ref(Number(props.filters?.sms_per_page ?? 5));
    const updateFilters = () => {
      if (!props.customer?.id) {
        console.warn("Customer ID is not available");
        return;
      }
      const params = {};
      if (contactSearch.value && typeof contactSearch.value === "string" && contactSearch.value.trim()) {
        params.contact_search = contactSearch.value.trim();
      }
      if (contactsPerPage.value && contactsPerPage.value !== 5) {
        params.contacts_per_page = contactsPerPage.value.toString();
      }
      if (smsSearch.value && typeof smsSearch.value === "string" && smsSearch.value.trim()) {
        params.sms_search = smsSearch.value.trim();
      }
      if (smsStatus.value && typeof smsStatus.value === "string" && smsStatus.value.trim()) {
        params.sms_status = smsStatus.value.trim();
      }
      if (smsPerPage.value && smsPerPage.value !== 5) {
        params.sms_per_page = smsPerPage.value.toString();
      }
      router.get(customers.show(props.customer.id).url, params, {
        preserveState: true,
        replace: true
      });
    };
    watch([contactSearch, contactsPerPage, smsSearch, smsStatus, smsPerPage], () => {
      if (props.customer?.id) {
        updateFilters();
      }
    }, { debounce: 300 });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Customer • ${props.customer.name}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Customers", href: unref(customers).index().url },
          { title: props.customer.name, href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="space-y-6 p-4"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 p-6 shadow-sm"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>${ssrInterpolate(props.customer.name)}</h1><p class="text-sm text-gray-500 mt-1"${_scopeId}>Customer Details</p></div><div class="flex items-center gap-2"${_scopeId}>`);
            if (props.customer.phone) {
              _push2(`<button class="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"${_scopeId}> Send SMS </button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(customers).edit(props.customer.id).url,
              class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Edit `);
                } else {
                  return [
                    createTextVNode(" Edit ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(customers).index().url,
              class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Back `);
                } else {
                  return [
                    createTextVNode(" Back ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Customer Information</h2><p class="text-sm text-gray-600"${_scopeId}>Basic details and contact information</p></div><div class="p-6"${_scopeId}><div class="grid gap-6 md:grid-cols-2"${_scopeId}><div class="space-y-4"${_scopeId}><div${_scopeId}><h3 class="text-sm font-medium text-gray-900 mb-3 flex items-center"${_scopeId}><svg class="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"${_scopeId}></path></svg> Contact Information </h3><div class="space-y-3"${_scopeId}><div class="flex items-center"${_scopeId}><span class="text-sm font-medium text-gray-500 w-20"${_scopeId}>Email:</span><span class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.customer.email)}</span></div><div class="flex items-center"${_scopeId}><span class="text-sm font-medium text-gray-500 w-20"${_scopeId}>Phone:</span><span class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.customer.phone || "-")}</span></div></div></div></div><div class="space-y-4"${_scopeId}><div${_scopeId}><h3 class="text-sm font-medium text-gray-900 mb-3 flex items-center"${_scopeId}><svg class="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"${_scopeId}></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"${_scopeId}></path></svg> Address Information </h3><div class="space-y-3"${_scopeId}><div class="flex items-start"${_scopeId}><span class="text-sm font-medium text-gray-500 w-20"${_scopeId}>Address:</span><span class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.customer.address || "-")}</span></div><div class="flex items-center"${_scopeId}><span class="text-sm font-medium text-gray-500 w-20"${_scopeId}>City:</span><span class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.customer.city || "-")}</span></div><div class="flex items-center"${_scopeId}><span class="text-sm font-medium text-gray-500 w-20"${_scopeId}>Country:</span><span class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.customer.country || "-")}</span></div></div></div></div></div>`);
            if (props.customer.notes) {
              _push2(`<div class="mt-6 pt-6 border-t border-gray-200"${_scopeId}><h3 class="text-sm font-medium text-gray-900 mb-3 flex items-center"${_scopeId}><svg class="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"${_scopeId}></path></svg> Notes </h3><p class="text-sm text-gray-700 whitespace-pre-line bg-gray-50 p-4 rounded-md"${_scopeId}>${ssrInterpolate(props.customer.notes)}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-blue-50 px-6 py-4"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h2 class="text-lg font-semibold text-gray-900 flex items-center"${_scopeId}><svg class="w-5 h-5 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"${_scopeId}></path></svg> Contacts </h2><p class="text-sm text-gray-600"${_scopeId}>Manage customer contacts and relationships</p></div><div class="flex items-center gap-2"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(contacts).create().url + "?customer_id=" + props.customer.id,
              class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Add Contact `);
                } else {
                  return [
                    createTextVNode(" Add Contact ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(contacts).index().url,
              class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` View All `);
                } else {
                  return [
                    createTextVNode(" View All ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div><div class="p-6"${_scopeId}><div class="mb-6 grid gap-3 md:grid-cols-2"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Search Contacts</label><input${ssrRenderAttr("value", contactSearch.value)} type="text" placeholder="Search by name, email, phone, or position..." class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"${_scopeId}></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Results per page</label><select class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"${_scopeId}><option value="5"${ssrIncludeBooleanAttr(Array.isArray(contactsPerPage.value) ? ssrLooseContain(contactsPerPage.value, "5") : ssrLooseEqual(contactsPerPage.value, "5")) ? " selected" : ""}${_scopeId}>5 per page</option><option value="10"${ssrIncludeBooleanAttr(Array.isArray(contactsPerPage.value) ? ssrLooseContain(contactsPerPage.value, "10") : ssrLooseEqual(contactsPerPage.value, "10")) ? " selected" : ""}${_scopeId}>10 per page</option><option value="25"${ssrIncludeBooleanAttr(Array.isArray(contactsPerPage.value) ? ssrLooseContain(contactsPerPage.value, "25") : ssrLooseEqual(contactsPerPage.value, "25")) ? " selected" : ""}${_scopeId}>25 per page</option><option value="50"${ssrIncludeBooleanAttr(Array.isArray(contactsPerPage.value) ? ssrLooseContain(contactsPerPage.value, "50") : ssrLooseEqual(contactsPerPage.value, "50")) ? " selected" : ""}${_scopeId}>50 per page</option></select></div></div>`);
            if ((props.contacts?.data || []).length === 0) {
              _push2(`<div class="text-center py-8"${_scopeId}><svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"${_scopeId}></path></svg><h3 class="mt-2 text-sm font-medium text-gray-900"${_scopeId}>No contacts</h3><p class="mt-1 text-sm text-gray-500"${_scopeId}>`);
              if (contactSearch.value) {
                _push2(`<span${_scopeId}>No contacts found matching &quot;${ssrInterpolate(contactSearch.value)}&quot;.</span>`);
              } else {
                _push2(`<span${_scopeId}>Get started by adding a new contact.</span>`);
              }
              _push2(`</p></div>`);
            } else {
              _push2(`<div class="space-y-3"${_scopeId}><!--[-->`);
              ssrRenderList(props.contacts?.data || [], (contact) => {
                _push2(`<div class="flex items-center justify-between rounded-lg border border-gray-200 bg-gray-50 p-4 hover:bg-gray-100 transition-colors"${_scopeId}><div class="flex-1"${_scopeId}><div class="flex items-center gap-3"${_scopeId}><div class="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100"${_scopeId}><svg class="h-5 w-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"${_scopeId}></path></svg></div><div${_scopeId}><div class="flex items-center gap-2"${_scopeId}><span class="font-medium text-gray-900"${_scopeId}>${ssrInterpolate(contact.name)}</span>`);
                if (contact.is_primary) {
                  _push2(`<span class="inline-flex items-center rounded-full bg-green-100 px-2 py-1 text-xs font-medium text-green-800"${_scopeId}> Primary </span>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div><div class="text-sm text-gray-600"${_scopeId}>`);
                if (contact.position) {
                  _push2(`<span class="font-medium"${_scopeId}>${ssrInterpolate(contact.position)}</span>`);
                } else {
                  _push2(`<!---->`);
                }
                if (contact.email) {
                  _push2(`<span class="ml-2"${_scopeId}>${ssrInterpolate(contact.email)}</span>`);
                } else {
                  _push2(`<!---->`);
                }
                if (contact.phone) {
                  _push2(`<span class="ml-2"${_scopeId}>${ssrInterpolate(contact.phone)}</span>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div></div></div></div><div class="flex items-center gap-2"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: unref(contacts).show(contact.id).url,
                  class: "rounded-md border border-gray-300 bg-white px-3 py-1 text-xs font-medium text-gray-700 hover:bg-gray-50"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` View `);
                    } else {
                      return [
                        createTextVNode(" View ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(ssrRenderComponent(unref(Link), {
                  href: unref(contacts).edit(contact.id).url,
                  class: "rounded-md bg-blue-600 px-3 py-1 text-xs font-medium text-white hover:bg-blue-700"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` Edit `);
                    } else {
                      return [
                        createTextVNode(" Edit ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</div></div>`);
              });
              _push2(`<!--]--></div>`);
            }
            if (props.contacts?.last_page > 1) {
              _push2(`<div class="mt-6 pt-6 border-t border-gray-200"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div class="text-sm text-gray-500"${_scopeId}> Showing ${ssrInterpolate(((props.contacts?.current_page || 1) - 1) * (props.contacts?.per_page || 5) + 1)} to ${ssrInterpolate(Math.min((props.contacts?.current_page || 1) * (props.contacts?.per_page || 5), props.contacts?.total || 0))} of ${ssrInterpolate(props.contacts?.total || 0)} contacts </div><div class="flex items-center gap-1"${_scopeId}><!--[-->`);
              ssrRenderList(props.contacts?.links || [], (link) => {
                _push2(ssrRenderComponent(unref(Link), {
                  key: link.label,
                  href: link.url || "#",
                  "preserve-scroll": true,
                  class: [
                    "px-3 py-1 text-sm rounded-md",
                    link.active ? "bg-blue-600 text-white" : link.url ? "bg-white border border-gray-300 text-gray-700 hover:bg-gray-50" : "bg-gray-100 text-gray-400 cursor-not-allowed"
                  ]
                }, null, _parent2, _scopeId));
              });
              _push2(`<!--]--></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-green-50 px-6 py-4"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h2 class="text-lg font-semibold text-gray-900 flex items-center"${_scopeId}><svg class="w-5 h-5 mr-2 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"${_scopeId}></path></svg> SMS Activity </h2><p class="text-sm text-gray-600"${_scopeId}>View and manage SMS communication history</p></div><div class="flex items-center gap-2"${_scopeId}><span class="inline-flex items-center rounded-full bg-green-100 px-3 py-1 text-sm font-medium text-green-800"${_scopeId}>${ssrInterpolate(props.smsActivities?.total || 0)} message${ssrInterpolate((props.smsActivities?.total || 0) !== 1 ? "s" : "")}</span></div></div></div><div class="p-6"${_scopeId}><div class="mb-6 grid gap-3 md:grid-cols-3"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Search Messages</label><input${ssrRenderAttr("value", smsSearch.value)} type="text" placeholder="Search by message, phone, or status..." class="w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"${_scopeId}></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Filter by Status</label><select class="w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(smsStatus.value) ? ssrLooseContain(smsStatus.value, "") : ssrLooseEqual(smsStatus.value, "")) ? " selected" : ""}${_scopeId}>All Statuses</option><option value="sent"${ssrIncludeBooleanAttr(Array.isArray(smsStatus.value) ? ssrLooseContain(smsStatus.value, "sent") : ssrLooseEqual(smsStatus.value, "sent")) ? " selected" : ""}${_scopeId}>Sent</option><option value="failed"${ssrIncludeBooleanAttr(Array.isArray(smsStatus.value) ? ssrLooseContain(smsStatus.value, "failed") : ssrLooseEqual(smsStatus.value, "failed")) ? " selected" : ""}${_scopeId}>Failed</option><option value="pending"${ssrIncludeBooleanAttr(Array.isArray(smsStatus.value) ? ssrLooseContain(smsStatus.value, "pending") : ssrLooseEqual(smsStatus.value, "pending")) ? " selected" : ""}${_scopeId}>Pending</option></select></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Results per page</label><select class="w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"${_scopeId}><option value="5"${ssrIncludeBooleanAttr(Array.isArray(smsPerPage.value) ? ssrLooseContain(smsPerPage.value, "5") : ssrLooseEqual(smsPerPage.value, "5")) ? " selected" : ""}${_scopeId}>5 per page</option><option value="10"${ssrIncludeBooleanAttr(Array.isArray(smsPerPage.value) ? ssrLooseContain(smsPerPage.value, "10") : ssrLooseEqual(smsPerPage.value, "10")) ? " selected" : ""}${_scopeId}>10 per page</option><option value="25"${ssrIncludeBooleanAttr(Array.isArray(smsPerPage.value) ? ssrLooseContain(smsPerPage.value, "25") : ssrLooseEqual(smsPerPage.value, "25")) ? " selected" : ""}${_scopeId}>25 per page</option><option value="50"${ssrIncludeBooleanAttr(Array.isArray(smsPerPage.value) ? ssrLooseContain(smsPerPage.value, "50") : ssrLooseEqual(smsPerPage.value, "50")) ? " selected" : ""}${_scopeId}>50 per page</option></select></div></div>`);
            if ((props.smsActivities?.data || []).length === 0) {
              _push2(`<div class="text-center py-8"${_scopeId}><svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"${_scopeId}></path></svg><h3 class="mt-2 text-sm font-medium text-gray-900"${_scopeId}>No SMS messages</h3><p class="mt-1 text-sm text-gray-500"${_scopeId}>`);
              if (smsSearch.value || smsStatus.value) {
                _push2(`<span${_scopeId}>No SMS messages found matching your filters.</span>`);
              } else {
                _push2(`<span${_scopeId}>No SMS messages sent to this customer yet.</span>`);
              }
              _push2(`</p></div>`);
            } else {
              _push2(`<div class="space-y-4"${_scopeId}><!--[-->`);
              ssrRenderList(props.smsActivities?.data || [], (activity) => {
                _push2(`<div class="rounded-lg border border-gray-200 bg-white p-4 shadow-sm hover:shadow-md transition-shadow"${_scopeId}><div class="flex items-start justify-between mb-3"${_scopeId}><div class="flex items-center gap-3"${_scopeId}><div class="${ssrRenderClass([{
                  "bg-green-100": activity.status === "sent",
                  "bg-red-100": activity.status === "failed",
                  "bg-yellow-100": activity.status === "pending"
                }, "flex h-8 w-8 items-center justify-center rounded-full"])}"${_scopeId}><svg class="${ssrRenderClass([{
                  "text-green-600": activity.status === "sent",
                  "text-red-600": activity.status === "failed",
                  "text-yellow-600": activity.status === "pending"
                }, "h-4 w-4"])}" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"${_scopeId}></path></svg></div><div${_scopeId}><span class="${ssrRenderClass([{
                  "bg-green-100 text-green-800": activity.status === "sent",
                  "bg-red-100 text-red-800": activity.status === "failed",
                  "bg-yellow-100 text-yellow-800": activity.status === "pending"
                }, "inline-flex items-center rounded-full px-2 py-1 text-xs font-medium"])}"${_scopeId}>${ssrInterpolate(activity.status.charAt(0).toUpperCase() + activity.status.slice(1))}</span><div class="text-xs text-gray-500 mt-1"${_scopeId}>${ssrInterpolate(new Date(activity.created_at).toLocaleString())}</div></div></div><div class="text-sm text-gray-500"${_scopeId}> by ${ssrInterpolate(activity.user.name)}</div></div><div class="mb-3"${_scopeId}><span class="text-sm font-medium text-gray-700"${_scopeId}>To:</span><span class="text-sm text-gray-600 ml-1 font-mono"${_scopeId}>${ssrInterpolate(activity.phone_number)}</span></div><div class="text-sm text-gray-700 bg-gray-50 p-3 rounded-md border"${_scopeId}>${ssrInterpolate(activity.message)}</div>`);
                if (activity.error_message) {
                  _push2(`<div class="mt-3 text-sm text-red-600 bg-red-50 p-3 rounded-md border border-red-200"${_scopeId}><span class="font-medium"${_scopeId}>Error:</span> ${ssrInterpolate(activity.error_message)}</div>`);
                } else {
                  _push2(`<!---->`);
                }
                if (activity.bulksms_reference) {
                  _push2(`<div class="mt-3 text-xs text-gray-500 bg-gray-50 p-2 rounded"${_scopeId}><span class="font-medium"${_scopeId}>Reference:</span> ${ssrInterpolate(activity.bulksms_reference)}</div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div>`);
              });
              _push2(`<!--]--></div>`);
            }
            if (props.smsActivities?.last_page > 1) {
              _push2(`<div class="mt-6 pt-6 border-t border-gray-200"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div class="text-sm text-gray-500"${_scopeId}> Showing ${ssrInterpolate(((props.smsActivities?.current_page || 1) - 1) * (props.smsActivities?.per_page || 5) + 1)} to ${ssrInterpolate(Math.min((props.smsActivities?.current_page || 1) * (props.smsActivities?.per_page || 5), props.smsActivities?.total || 0))} of ${ssrInterpolate(props.smsActivities?.total || 0)} messages </div><div class="flex items-center gap-1"${_scopeId}><!--[-->`);
              ssrRenderList(props.smsActivities?.links || [], (link) => {
                _push2(ssrRenderComponent(unref(Link), {
                  key: link.label,
                  href: link.url || "#",
                  "preserve-scroll": true,
                  class: [
                    "px-3 py-1 text-sm rounded-md",
                    link.active ? "bg-green-600 text-white" : link.url ? "bg-white border border-gray-300 text-gray-700 hover:bg-gray-50" : "bg-gray-100 text-gray-400 cursor-not-allowed"
                  ]
                }, null, _parent2, _scopeId));
              });
              _push2(`<!--]--></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="rounded-lg bg-gray-50 border border-gray-200 p-4"${_scopeId}><div class="flex items-center justify-between text-sm text-gray-500"${_scopeId}><div class="flex items-center gap-4"${_scopeId}><div class="flex items-center gap-2"${_scopeId}><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"${_scopeId}></path></svg><span${_scopeId}>Created: ${ssrInterpolate(new Date(props.customer.created_at).toLocaleDateString())}</span></div><div class="flex items-center gap-2"${_scopeId}><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"${_scopeId}></path></svg><span${_scopeId}>Updated: ${ssrInterpolate(new Date(props.customer.updated_at).toLocaleDateString())}</span></div></div></div></div></div>`);
            if (showSMSModal.value) {
              _push2(`<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"${_scopeId}><div class="bg-white rounded-lg p-6 w-full max-w-md"${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>Send SMS to ${ssrInterpolate(props.customer.name)}</h3><form${_scopeId}><div class="mb-4"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Message (max 160 characters)</label><textarea rows="4" class="w-full rounded border px-3 py-2" placeholder="Enter your SMS message..." maxlength="160" required${_scopeId}>${ssrInterpolate(unref(smsForm).message)}</textarea><div class="text-xs text-gray-500 mt-1"${_scopeId}>${ssrInterpolate(unref(smsForm).message.length)}/160 characters</div>`);
              if (unref(smsForm).errors.message) {
                _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(smsForm).errors.message)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="flex items-center justify-end gap-3"${_scopeId}><button type="button" class="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"${_scopeId}> Cancel </button><button type="submit"${ssrIncludeBooleanAttr(unref(smsForm).processing) ? " disabled" : ""} class="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(smsForm).processing ? "Sending..." : "Send SMS")}</button></div></form></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (showSMSResultModal.value) {
              _push2(`<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"${_scopeId}><div class="bg-white rounded-lg p-6 w-full max-w-md"${_scopeId}><div class="flex items-center mb-4"${_scopeId}>`);
              if (smsResult.value?.success) {
                _push2(`<div class="flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-3"${_scopeId}><svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"${_scopeId}></path></svg></div>`);
              } else {
                _push2(`<div class="flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-3"${_scopeId}><svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"${_scopeId}></path></svg></div>`);
              }
              _push2(`<h3 class="${ssrRenderClass([smsResult.value?.success ? "text-green-800" : "text-red-800", "text-lg font-semibold"])}"${_scopeId}>${ssrInterpolate(smsResult.value?.success ? "SMS Sent Successfully!" : "SMS Failed to Send")}</h3></div><div class="mb-6"${_scopeId}><p class="${ssrRenderClass([smsResult.value?.success ? "text-green-700" : "text-red-700", "text-gray-700"])}"${_scopeId}>${ssrInterpolate(smsResult.value?.message)}</p></div><div class="flex justify-end"${_scopeId}><button class="${ssrRenderClass([smsResult.value?.success ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500", "rounded-md px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2"])}"${_scopeId}> OK </button></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              createVNode("div", { class: "space-y-6 p-4" }, [
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 p-6 shadow-sm" }, [
                  createVNode("div", { class: "flex items-center justify-between" }, [
                    createVNode("div", null, [
                      createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, toDisplayString(props.customer.name), 1),
                      createVNode("p", { class: "text-sm text-gray-500 mt-1" }, "Customer Details")
                    ]),
                    createVNode("div", { class: "flex items-center gap-2" }, [
                      props.customer.phone ? (openBlock(), createBlock("button", {
                        key: 0,
                        onClick: openSMSModal,
                        class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
                      }, " Send SMS ")) : createCommentVNode("", true),
                      createVNode(unref(Link), {
                        href: unref(customers).edit(props.customer.id).url,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Edit ")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createVNode(unref(Link), {
                        href: unref(customers).index().url,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Back ")
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ])
                  ])
                ]),
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                  createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Customer Information"),
                    createVNode("p", { class: "text-sm text-gray-600" }, "Basic details and contact information")
                  ]),
                  createVNode("div", { class: "p-6" }, [
                    createVNode("div", { class: "grid gap-6 md:grid-cols-2" }, [
                      createVNode("div", { class: "space-y-4" }, [
                        createVNode("div", null, [
                          createVNode("h3", { class: "text-sm font-medium text-gray-900 mb-3 flex items-center" }, [
                            (openBlock(), createBlock("svg", {
                              class: "w-4 h-4 mr-2 text-gray-400",
                              fill: "none",
                              stroke: "currentColor",
                              viewBox: "0 0 24 24"
                            }, [
                              createVNode("path", {
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round",
                                "stroke-width": "2",
                                d: "M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                              })
                            ])),
                            createTextVNode(" Contact Information ")
                          ]),
                          createVNode("div", { class: "space-y-3" }, [
                            createVNode("div", { class: "flex items-center" }, [
                              createVNode("span", { class: "text-sm font-medium text-gray-500 w-20" }, "Email:"),
                              createVNode("span", { class: "text-sm text-gray-900" }, toDisplayString(props.customer.email), 1)
                            ]),
                            createVNode("div", { class: "flex items-center" }, [
                              createVNode("span", { class: "text-sm font-medium text-gray-500 w-20" }, "Phone:"),
                              createVNode("span", { class: "text-sm text-gray-900" }, toDisplayString(props.customer.phone || "-"), 1)
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "space-y-4" }, [
                        createVNode("div", null, [
                          createVNode("h3", { class: "text-sm font-medium text-gray-900 mb-3 flex items-center" }, [
                            (openBlock(), createBlock("svg", {
                              class: "w-4 h-4 mr-2 text-gray-400",
                              fill: "none",
                              stroke: "currentColor",
                              viewBox: "0 0 24 24"
                            }, [
                              createVNode("path", {
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round",
                                "stroke-width": "2",
                                d: "M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                              }),
                              createVNode("path", {
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round",
                                "stroke-width": "2",
                                d: "M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                              })
                            ])),
                            createTextVNode(" Address Information ")
                          ]),
                          createVNode("div", { class: "space-y-3" }, [
                            createVNode("div", { class: "flex items-start" }, [
                              createVNode("span", { class: "text-sm font-medium text-gray-500 w-20" }, "Address:"),
                              createVNode("span", { class: "text-sm text-gray-900" }, toDisplayString(props.customer.address || "-"), 1)
                            ]),
                            createVNode("div", { class: "flex items-center" }, [
                              createVNode("span", { class: "text-sm font-medium text-gray-500 w-20" }, "City:"),
                              createVNode("span", { class: "text-sm text-gray-900" }, toDisplayString(props.customer.city || "-"), 1)
                            ]),
                            createVNode("div", { class: "flex items-center" }, [
                              createVNode("span", { class: "text-sm font-medium text-gray-500 w-20" }, "Country:"),
                              createVNode("span", { class: "text-sm text-gray-900" }, toDisplayString(props.customer.country || "-"), 1)
                            ])
                          ])
                        ])
                      ])
                    ]),
                    props.customer.notes ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "mt-6 pt-6 border-t border-gray-200"
                    }, [
                      createVNode("h3", { class: "text-sm font-medium text-gray-900 mb-3 flex items-center" }, [
                        (openBlock(), createBlock("svg", {
                          class: "w-4 h-4 mr-2 text-gray-400",
                          fill: "none",
                          stroke: "currentColor",
                          viewBox: "0 0 24 24"
                        }, [
                          createVNode("path", {
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round",
                            "stroke-width": "2",
                            d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                          })
                        ])),
                        createTextVNode(" Notes ")
                      ]),
                      createVNode("p", { class: "text-sm text-gray-700 whitespace-pre-line bg-gray-50 p-4 rounded-md" }, toDisplayString(props.customer.notes), 1)
                    ])) : createCommentVNode("", true)
                  ])
                ]),
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                  createVNode("div", { class: "border-b border-gray-200 bg-blue-50 px-6 py-4" }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", null, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900 flex items-center" }, [
                          (openBlock(), createBlock("svg", {
                            class: "w-5 h-5 mr-2 text-blue-600",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24"
                          }, [
                            createVNode("path", {
                              "stroke-linecap": "round",
                              "stroke-linejoin": "round",
                              "stroke-width": "2",
                              d: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                            })
                          ])),
                          createTextVNode(" Contacts ")
                        ]),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Manage customer contacts and relationships")
                      ]),
                      createVNode("div", { class: "flex items-center gap-2" }, [
                        createVNode(unref(Link), {
                          href: unref(contacts).create().url + "?customer_id=" + props.customer.id,
                          class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Add Contact ")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode(unref(Link), {
                          href: unref(contacts).index().url,
                          class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" View All ")
                          ]),
                          _: 1
                        }, 8, ["href"])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "p-6" }, [
                    createVNode("div", { class: "mb-6 grid gap-3 md:grid-cols-2" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Search Contacts"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => contactSearch.value = $event,
                          type: "text",
                          placeholder: "Search by name, email, phone, or position...",
                          class: "w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, contactSearch.value]
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Results per page"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => contactsPerPage.value = $event,
                          class: "w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        }, [
                          createVNode("option", { value: "5" }, "5 per page"),
                          createVNode("option", { value: "10" }, "10 per page"),
                          createVNode("option", { value: "25" }, "25 per page"),
                          createVNode("option", { value: "50" }, "50 per page")
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, contactsPerPage.value]
                        ])
                      ])
                    ]),
                    (props.contacts?.data || []).length === 0 ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "text-center py-8"
                    }, [
                      (openBlock(), createBlock("svg", {
                        class: "mx-auto h-12 w-12 text-gray-400",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        createVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                        })
                      ])),
                      createVNode("h3", { class: "mt-2 text-sm font-medium text-gray-900" }, "No contacts"),
                      createVNode("p", { class: "mt-1 text-sm text-gray-500" }, [
                        contactSearch.value ? (openBlock(), createBlock("span", { key: 0 }, 'No contacts found matching "' + toDisplayString(contactSearch.value) + '".', 1)) : (openBlock(), createBlock("span", { key: 1 }, "Get started by adding a new contact."))
                      ])
                    ])) : (openBlock(), createBlock("div", {
                      key: 1,
                      class: "space-y-3"
                    }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(props.contacts?.data || [], (contact) => {
                        return openBlock(), createBlock("div", {
                          key: contact.id,
                          class: "flex items-center justify-between rounded-lg border border-gray-200 bg-gray-50 p-4 hover:bg-gray-100 transition-colors"
                        }, [
                          createVNode("div", { class: "flex-1" }, [
                            createVNode("div", { class: "flex items-center gap-3" }, [
                              createVNode("div", { class: "flex h-10 w-10 items-center justify-center rounded-full bg-blue-100" }, [
                                (openBlock(), createBlock("svg", {
                                  class: "h-5 w-5 text-blue-600",
                                  fill: "none",
                                  stroke: "currentColor",
                                  viewBox: "0 0 24 24"
                                }, [
                                  createVNode("path", {
                                    "stroke-linecap": "round",
                                    "stroke-linejoin": "round",
                                    "stroke-width": "2",
                                    d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                                  })
                                ]))
                              ]),
                              createVNode("div", null, [
                                createVNode("div", { class: "flex items-center gap-2" }, [
                                  createVNode("span", { class: "font-medium text-gray-900" }, toDisplayString(contact.name), 1),
                                  contact.is_primary ? (openBlock(), createBlock("span", {
                                    key: 0,
                                    class: "inline-flex items-center rounded-full bg-green-100 px-2 py-1 text-xs font-medium text-green-800"
                                  }, " Primary ")) : createCommentVNode("", true)
                                ]),
                                createVNode("div", { class: "text-sm text-gray-600" }, [
                                  contact.position ? (openBlock(), createBlock("span", {
                                    key: 0,
                                    class: "font-medium"
                                  }, toDisplayString(contact.position), 1)) : createCommentVNode("", true),
                                  contact.email ? (openBlock(), createBlock("span", {
                                    key: 1,
                                    class: "ml-2"
                                  }, toDisplayString(contact.email), 1)) : createCommentVNode("", true),
                                  contact.phone ? (openBlock(), createBlock("span", {
                                    key: 2,
                                    class: "ml-2"
                                  }, toDisplayString(contact.phone), 1)) : createCommentVNode("", true)
                                ])
                              ])
                            ])
                          ]),
                          createVNode("div", { class: "flex items-center gap-2" }, [
                            createVNode(unref(Link), {
                              href: unref(contacts).show(contact.id).url,
                              class: "rounded-md border border-gray-300 bg-white px-3 py-1 text-xs font-medium text-gray-700 hover:bg-gray-50"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" View ")
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: unref(contacts).edit(contact.id).url,
                              class: "rounded-md bg-blue-600 px-3 py-1 text-xs font-medium text-white hover:bg-blue-700"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Edit ")
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ])
                        ]);
                      }), 128))
                    ])),
                    props.contacts?.last_page > 1 ? (openBlock(), createBlock("div", {
                      key: 2,
                      class: "mt-6 pt-6 border-t border-gray-200"
                    }, [
                      createVNode("div", { class: "flex items-center justify-between" }, [
                        createVNode("div", { class: "text-sm text-gray-500" }, " Showing " + toDisplayString(((props.contacts?.current_page || 1) - 1) * (props.contacts?.per_page || 5) + 1) + " to " + toDisplayString(Math.min((props.contacts?.current_page || 1) * (props.contacts?.per_page || 5), props.contacts?.total || 0)) + " of " + toDisplayString(props.contacts?.total || 0) + " contacts ", 1),
                        createVNode("div", { class: "flex items-center gap-1" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(props.contacts?.links || [], (link) => {
                            return openBlock(), createBlock(unref(Link), {
                              key: link.label,
                              href: link.url || "#",
                              "preserve-scroll": true,
                              class: [
                                "px-3 py-1 text-sm rounded-md",
                                link.active ? "bg-blue-600 text-white" : link.url ? "bg-white border border-gray-300 text-gray-700 hover:bg-gray-50" : "bg-gray-100 text-gray-400 cursor-not-allowed"
                              ],
                              innerHTML: link.label
                            }, null, 8, ["href", "class", "innerHTML"]);
                          }), 128))
                        ])
                      ])
                    ])) : createCommentVNode("", true)
                  ])
                ]),
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                  createVNode("div", { class: "border-b border-gray-200 bg-green-50 px-6 py-4" }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", null, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900 flex items-center" }, [
                          (openBlock(), createBlock("svg", {
                            class: "w-5 h-5 mr-2 text-green-600",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24"
                          }, [
                            createVNode("path", {
                              "stroke-linecap": "round",
                              "stroke-linejoin": "round",
                              "stroke-width": "2",
                              d: "M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                            })
                          ])),
                          createTextVNode(" SMS Activity ")
                        ]),
                        createVNode("p", { class: "text-sm text-gray-600" }, "View and manage SMS communication history")
                      ]),
                      createVNode("div", { class: "flex items-center gap-2" }, [
                        createVNode("span", { class: "inline-flex items-center rounded-full bg-green-100 px-3 py-1 text-sm font-medium text-green-800" }, toDisplayString(props.smsActivities?.total || 0) + " message" + toDisplayString((props.smsActivities?.total || 0) !== 1 ? "s" : ""), 1)
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "p-6" }, [
                    createVNode("div", { class: "mb-6 grid gap-3 md:grid-cols-3" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Search Messages"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => smsSearch.value = $event,
                          type: "text",
                          placeholder: "Search by message, phone, or status...",
                          class: "w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, smsSearch.value]
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Filter by Status"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => smsStatus.value = $event,
                          class: "w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                        }, [
                          createVNode("option", { value: "" }, "All Statuses"),
                          createVNode("option", { value: "sent" }, "Sent"),
                          createVNode("option", { value: "failed" }, "Failed"),
                          createVNode("option", { value: "pending" }, "Pending")
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, smsStatus.value]
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Results per page"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => smsPerPage.value = $event,
                          class: "w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                        }, [
                          createVNode("option", { value: "5" }, "5 per page"),
                          createVNode("option", { value: "10" }, "10 per page"),
                          createVNode("option", { value: "25" }, "25 per page"),
                          createVNode("option", { value: "50" }, "50 per page")
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, smsPerPage.value]
                        ])
                      ])
                    ]),
                    (props.smsActivities?.data || []).length === 0 ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "text-center py-8"
                    }, [
                      (openBlock(), createBlock("svg", {
                        class: "mx-auto h-12 w-12 text-gray-400",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        createVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                        })
                      ])),
                      createVNode("h3", { class: "mt-2 text-sm font-medium text-gray-900" }, "No SMS messages"),
                      createVNode("p", { class: "mt-1 text-sm text-gray-500" }, [
                        smsSearch.value || smsStatus.value ? (openBlock(), createBlock("span", { key: 0 }, "No SMS messages found matching your filters.")) : (openBlock(), createBlock("span", { key: 1 }, "No SMS messages sent to this customer yet."))
                      ])
                    ])) : (openBlock(), createBlock("div", {
                      key: 1,
                      class: "space-y-4"
                    }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(props.smsActivities?.data || [], (activity) => {
                        return openBlock(), createBlock("div", {
                          key: activity.id,
                          class: "rounded-lg border border-gray-200 bg-white p-4 shadow-sm hover:shadow-md transition-shadow"
                        }, [
                          createVNode("div", { class: "flex items-start justify-between mb-3" }, [
                            createVNode("div", { class: "flex items-center gap-3" }, [
                              createVNode("div", {
                                class: ["flex h-8 w-8 items-center justify-center rounded-full", {
                                  "bg-green-100": activity.status === "sent",
                                  "bg-red-100": activity.status === "failed",
                                  "bg-yellow-100": activity.status === "pending"
                                }]
                              }, [
                                (openBlock(), createBlock("svg", {
                                  class: ["h-4 w-4", {
                                    "text-green-600": activity.status === "sent",
                                    "text-red-600": activity.status === "failed",
                                    "text-yellow-600": activity.status === "pending"
                                  }],
                                  fill: "none",
                                  stroke: "currentColor",
                                  viewBox: "0 0 24 24"
                                }, [
                                  createVNode("path", {
                                    "stroke-linecap": "round",
                                    "stroke-linejoin": "round",
                                    "stroke-width": "2",
                                    d: "M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                                  })
                                ], 2))
                              ], 2),
                              createVNode("div", null, [
                                createVNode("span", {
                                  class: ["inline-flex items-center rounded-full px-2 py-1 text-xs font-medium", {
                                    "bg-green-100 text-green-800": activity.status === "sent",
                                    "bg-red-100 text-red-800": activity.status === "failed",
                                    "bg-yellow-100 text-yellow-800": activity.status === "pending"
                                  }]
                                }, toDisplayString(activity.status.charAt(0).toUpperCase() + activity.status.slice(1)), 3),
                                createVNode("div", { class: "text-xs text-gray-500 mt-1" }, toDisplayString(new Date(activity.created_at).toLocaleString()), 1)
                              ])
                            ]),
                            createVNode("div", { class: "text-sm text-gray-500" }, " by " + toDisplayString(activity.user.name), 1)
                          ]),
                          createVNode("div", { class: "mb-3" }, [
                            createVNode("span", { class: "text-sm font-medium text-gray-700" }, "To:"),
                            createVNode("span", { class: "text-sm text-gray-600 ml-1 font-mono" }, toDisplayString(activity.phone_number), 1)
                          ]),
                          createVNode("div", { class: "text-sm text-gray-700 bg-gray-50 p-3 rounded-md border" }, toDisplayString(activity.message), 1),
                          activity.error_message ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-3 text-sm text-red-600 bg-red-50 p-3 rounded-md border border-red-200"
                          }, [
                            createVNode("span", { class: "font-medium" }, "Error:"),
                            createTextVNode(" " + toDisplayString(activity.error_message), 1)
                          ])) : createCommentVNode("", true),
                          activity.bulksms_reference ? (openBlock(), createBlock("div", {
                            key: 1,
                            class: "mt-3 text-xs text-gray-500 bg-gray-50 p-2 rounded"
                          }, [
                            createVNode("span", { class: "font-medium" }, "Reference:"),
                            createTextVNode(" " + toDisplayString(activity.bulksms_reference), 1)
                          ])) : createCommentVNode("", true)
                        ]);
                      }), 128))
                    ])),
                    props.smsActivities?.last_page > 1 ? (openBlock(), createBlock("div", {
                      key: 2,
                      class: "mt-6 pt-6 border-t border-gray-200"
                    }, [
                      createVNode("div", { class: "flex items-center justify-between" }, [
                        createVNode("div", { class: "text-sm text-gray-500" }, " Showing " + toDisplayString(((props.smsActivities?.current_page || 1) - 1) * (props.smsActivities?.per_page || 5) + 1) + " to " + toDisplayString(Math.min((props.smsActivities?.current_page || 1) * (props.smsActivities?.per_page || 5), props.smsActivities?.total || 0)) + " of " + toDisplayString(props.smsActivities?.total || 0) + " messages ", 1),
                        createVNode("div", { class: "flex items-center gap-1" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(props.smsActivities?.links || [], (link) => {
                            return openBlock(), createBlock(unref(Link), {
                              key: link.label,
                              href: link.url || "#",
                              "preserve-scroll": true,
                              class: [
                                "px-3 py-1 text-sm rounded-md",
                                link.active ? "bg-green-600 text-white" : link.url ? "bg-white border border-gray-300 text-gray-700 hover:bg-gray-50" : "bg-gray-100 text-gray-400 cursor-not-allowed"
                              ],
                              innerHTML: link.label
                            }, null, 8, ["href", "class", "innerHTML"]);
                          }), 128))
                        ])
                      ])
                    ])) : createCommentVNode("", true)
                  ])
                ]),
                createVNode("div", { class: "rounded-lg bg-gray-50 border border-gray-200 p-4" }, [
                  createVNode("div", { class: "flex items-center justify-between text-sm text-gray-500" }, [
                    createVNode("div", { class: "flex items-center gap-4" }, [
                      createVNode("div", { class: "flex items-center gap-2" }, [
                        (openBlock(), createBlock("svg", {
                          class: "w-4 h-4",
                          fill: "none",
                          stroke: "currentColor",
                          viewBox: "0 0 24 24"
                        }, [
                          createVNode("path", {
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round",
                            "stroke-width": "2",
                            d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                          })
                        ])),
                        createVNode("span", null, "Created: " + toDisplayString(new Date(props.customer.created_at).toLocaleDateString()), 1)
                      ]),
                      createVNode("div", { class: "flex items-center gap-2" }, [
                        (openBlock(), createBlock("svg", {
                          class: "w-4 h-4",
                          fill: "none",
                          stroke: "currentColor",
                          viewBox: "0 0 24 24"
                        }, [
                          createVNode("path", {
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round",
                            "stroke-width": "2",
                            d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                          })
                        ])),
                        createVNode("span", null, "Updated: " + toDisplayString(new Date(props.customer.updated_at).toLocaleDateString()), 1)
                      ])
                    ])
                  ])
                ])
              ]),
              showSMSModal.value ? (openBlock(), createBlock("div", {
                key: 0,
                class: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
              }, [
                createVNode("div", { class: "bg-white rounded-lg p-6 w-full max-w-md" }, [
                  createVNode("h3", { class: "text-lg font-semibold mb-4" }, "Send SMS to " + toDisplayString(props.customer.name), 1),
                  createVNode("form", {
                    onSubmit: withModifiers(sendSMS, ["prevent"])
                  }, [
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Message (max 160 characters)"),
                      withDirectives(createVNode("textarea", {
                        "onUpdate:modelValue": ($event) => unref(smsForm).message = $event,
                        rows: "4",
                        class: "w-full rounded border px-3 py-2",
                        placeholder: "Enter your SMS message...",
                        maxlength: "160",
                        required: ""
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(smsForm).message]
                      ]),
                      createVNode("div", { class: "text-xs text-gray-500 mt-1" }, toDisplayString(unref(smsForm).message.length) + "/160 characters", 1),
                      unref(smsForm).errors.message ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-red-600"
                      }, toDisplayString(unref(smsForm).errors.message), 1)) : createCommentVNode("", true)
                    ]),
                    createVNode("div", { class: "flex items-center justify-end gap-3" }, [
                      createVNode("button", {
                        type: "button",
                        onClick: ($event) => showSMSModal.value = false,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, " Cancel ", 8, ["onClick"]),
                      createVNode("button", {
                        type: "submit",
                        disabled: unref(smsForm).processing,
                        class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50"
                      }, toDisplayString(unref(smsForm).processing ? "Sending..." : "Send SMS"), 9, ["disabled"])
                    ])
                  ], 32)
                ])
              ])) : createCommentVNode("", true),
              showSMSResultModal.value ? (openBlock(), createBlock("div", {
                key: 1,
                class: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
              }, [
                createVNode("div", { class: "bg-white rounded-lg p-6 w-full max-w-md" }, [
                  createVNode("div", { class: "flex items-center mb-4" }, [
                    smsResult.value?.success ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-3"
                    }, [
                      (openBlock(), createBlock("svg", {
                        class: "w-6 h-6 text-green-600",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        createVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M5 13l4 4L19 7"
                        })
                      ]))
                    ])) : (openBlock(), createBlock("div", {
                      key: 1,
                      class: "flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-3"
                    }, [
                      (openBlock(), createBlock("svg", {
                        class: "w-6 h-6 text-red-600",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        createVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M6 18L18 6M6 6l12 12"
                        })
                      ]))
                    ])),
                    createVNode("h3", {
                      class: ["text-lg font-semibold", smsResult.value?.success ? "text-green-800" : "text-red-800"]
                    }, toDisplayString(smsResult.value?.success ? "SMS Sent Successfully!" : "SMS Failed to Send"), 3)
                  ]),
                  createVNode("div", { class: "mb-6" }, [
                    createVNode("p", {
                      class: ["text-gray-700", smsResult.value?.success ? "text-green-700" : "text-red-700"]
                    }, toDisplayString(smsResult.value?.message), 3)
                  ]),
                  createVNode("div", { class: "flex justify-end" }, [
                    createVNode("button", {
                      onClick: closeSMSResultModal,
                      class: ["rounded-md px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2", smsResult.value?.success ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500"]
                    }, " OK ", 2)
                  ])
                ])
              ])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/customers/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
