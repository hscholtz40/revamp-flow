import { defineComponent, unref, withCtx, createVNode, createTextVNode, createBlock, createCommentVNode, toDisplayString, openBlock, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderStyle, ssrInterpolate, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1, a as administration } from "./AppLayout-CmGu2Oww.js";
import { Head, Link } from "@inertiajs/vue3";
import { ArrowLeft, Edit, Trash2, Tag, Package, Calendar } from "lucide-vue-next";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    category: {}
  },
  setup(__props) {
    const props = __props;
    function deleteCategory() {
      if (props.category.products_count > 0) {
        alert(`Cannot delete "${props.category.name}" because it has ${props.category.products_count} products. Please move or delete the products first.`);
        return;
      }
      if (confirm(`Are you sure you want to delete "${props.category.name}"?`)) {
        console.log("Delete category:", props.category.id);
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: props.category.name
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Administration", href: unref(administration).index().url },
          { title: "Categories", href: unref(administration).categories.index().url },
          { title: props.category.name, href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-4"${_scopeId}><div class="mb-6 flex items-center justify-between"${_scopeId}><div class="flex items-center gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(administration).categories.index().url,
              class: "flex items-center gap-2 text-gray-600 hover:text-gray-900"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(ArrowLeft), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                  _push3(` Back to Categories `);
                } else {
                  return [
                    createVNode(unref(ArrowLeft), { class: "h-4 w-4" }),
                    createTextVNode(" Back to Categories ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="flex items-center gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(administration).categories.edit(props.category.id).url,
              class: "flex items-center gap-2 rounded-md border border-gray-300 px-4 py-2 text-gray-700 hover:bg-gray-50"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Edit), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                  _push3(` Edit `);
                } else {
                  return [
                    createVNode(unref(Edit), { class: "h-4 w-4" }),
                    createTextVNode(" Edit ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<button class="flex items-center gap-2 rounded-md border border-red-300 px-4 py-2 text-red-700 hover:bg-red-50"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Trash2), { class: "h-4 w-4" }, null, _parent2, _scopeId));
            _push2(` Delete </button></div></div><div class="mx-auto max-w-4xl"${_scopeId}><div class="mb-8 rounded-lg border bg-white p-6"${_scopeId}><div class="flex items-start gap-6"${_scopeId}><div class="flex-shrink-0"${_scopeId}><div class="flex h-16 w-16 items-center justify-center rounded-lg" style="${ssrRenderStyle({ backgroundColor: props.category.color })}"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Tag), { class: "h-8 w-8 text-white" }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex-1"${_scopeId}><div class="mb-2 flex items-center gap-3"${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>${ssrInterpolate(props.category.name)}</h1><span class="${ssrRenderClass([
              "rounded-full px-3 py-1 text-sm font-medium",
              props.category.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
            ])}"${_scopeId}>${ssrInterpolate(props.category.is_active ? "Active" : "Inactive")}</span></div>`);
            if (props.category.description) {
              _push2(`<p class="text-gray-600"${_scopeId}>${ssrInterpolate(props.category.description)}</p>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="grid gap-6 lg:grid-cols-3"${_scopeId}><div class="lg:col-span-2 space-y-6"${_scopeId}><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Basic Information</h2><div class="grid gap-4 md:grid-cols-2"${_scopeId}><div class="flex items-center gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Tag), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Name</div><div class="text-gray-900"${_scopeId}>${ssrInterpolate(props.category.name)}</div></div></div><div class="flex items-center gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Package), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Products Count</div><div class="text-gray-900"${_scopeId}>${ssrInterpolate(props.category.products_count)}</div></div></div><div class="flex items-center gap-3"${_scopeId}><div class="h-5 w-5 rounded-full" style="${ssrRenderStyle({ backgroundColor: props.category.color })}"${_scopeId}></div><div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Color</div><div class="text-gray-900"${_scopeId}>${ssrInterpolate(props.category.color)}</div></div></div><div class="flex items-center gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Tag), { class: "h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Sort Order</div><div class="text-gray-900"${_scopeId}>${ssrInterpolate(props.category.sort_order)}</div></div></div></div></div>`);
            if (props.category.description) {
              _push2(`<div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Description</h2><div class="text-gray-700 whitespace-pre-wrap"${_scopeId}>${ssrInterpolate(props.category.description)}</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="space-y-6"${_scopeId}><div class="rounded-lg border bg-white p-6"${_scopeId}><h3 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Quick Stats</h3><div class="space-y-4"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Status</span><span class="${ssrRenderClass([
              "text-sm font-medium",
              props.category.is_active ? "text-green-600" : "text-red-600"
            ])}"${_scopeId}>${ssrInterpolate(props.category.is_active ? "Active" : "Inactive")}</span></div><div class="flex items-center justify-between"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Products</span><span class="text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(props.category.products_count)}</span></div><div class="flex items-center justify-between"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Sort Order</span><span class="text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(props.category.sort_order)}</span></div></div></div><div class="rounded-lg border bg-white p-6"${_scopeId}><h3 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Timestamps</h3><div class="space-y-4"${_scopeId}><div class="flex items-center gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Calendar), { class: "h-4 w-4 text-gray-400" }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Created</div><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(new Date(props.category.created_at).toLocaleDateString())}</div></div></div><div class="flex items-center gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Calendar), { class: "h-4 w-4 text-gray-400" }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="text-sm font-medium text-gray-500"${_scopeId}>Last Updated</div><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(new Date(props.category.updated_at).toLocaleDateString())}</div></div></div></div></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "mb-6 flex items-center justify-between" }, [
                  createVNode("div", { class: "flex items-center gap-4" }, [
                    createVNode(unref(Link), {
                      href: unref(administration).categories.index().url,
                      class: "flex items-center gap-2 text-gray-600 hover:text-gray-900"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(ArrowLeft), { class: "h-4 w-4" }),
                        createTextVNode(" Back to Categories ")
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ]),
                  createVNode("div", { class: "flex items-center gap-3" }, [
                    createVNode(unref(Link), {
                      href: unref(administration).categories.edit(props.category.id).url,
                      class: "flex items-center gap-2 rounded-md border border-gray-300 px-4 py-2 text-gray-700 hover:bg-gray-50"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(Edit), { class: "h-4 w-4" }),
                        createTextVNode(" Edit ")
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode("button", {
                      onClick: deleteCategory,
                      class: "flex items-center gap-2 rounded-md border border-red-300 px-4 py-2 text-red-700 hover:bg-red-50"
                    }, [
                      createVNode(unref(Trash2), { class: "h-4 w-4" }),
                      createTextVNode(" Delete ")
                    ])
                  ])
                ]),
                createVNode("div", { class: "mx-auto max-w-4xl" }, [
                  createVNode("div", { class: "mb-8 rounded-lg border bg-white p-6" }, [
                    createVNode("div", { class: "flex items-start gap-6" }, [
                      createVNode("div", { class: "flex-shrink-0" }, [
                        createVNode("div", {
                          class: "flex h-16 w-16 items-center justify-center rounded-lg",
                          style: { backgroundColor: props.category.color }
                        }, [
                          createVNode(unref(Tag), { class: "h-8 w-8 text-white" })
                        ], 4)
                      ]),
                      createVNode("div", { class: "flex-1" }, [
                        createVNode("div", { class: "mb-2 flex items-center gap-3" }, [
                          createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, toDisplayString(props.category.name), 1),
                          createVNode("span", {
                            class: [
                              "rounded-full px-3 py-1 text-sm font-medium",
                              props.category.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                            ]
                          }, toDisplayString(props.category.is_active ? "Active" : "Inactive"), 3)
                        ]),
                        props.category.description ? (openBlock(), createBlock("p", {
                          key: 0,
                          class: "text-gray-600"
                        }, toDisplayString(props.category.description), 1)) : createCommentVNode("", true)
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "grid gap-6 lg:grid-cols-3" }, [
                    createVNode("div", { class: "lg:col-span-2 space-y-6" }, [
                      createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                        createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Basic Information"),
                        createVNode("div", { class: "grid gap-4 md:grid-cols-2" }, [
                          createVNode("div", { class: "flex items-center gap-3" }, [
                            createVNode(unref(Tag), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Name"),
                              createVNode("div", { class: "text-gray-900" }, toDisplayString(props.category.name), 1)
                            ])
                          ]),
                          createVNode("div", { class: "flex items-center gap-3" }, [
                            createVNode(unref(Package), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Products Count"),
                              createVNode("div", { class: "text-gray-900" }, toDisplayString(props.category.products_count), 1)
                            ])
                          ]),
                          createVNode("div", { class: "flex items-center gap-3" }, [
                            createVNode("div", {
                              class: "h-5 w-5 rounded-full",
                              style: { backgroundColor: props.category.color }
                            }, null, 4),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Color"),
                              createVNode("div", { class: "text-gray-900" }, toDisplayString(props.category.color), 1)
                            ])
                          ]),
                          createVNode("div", { class: "flex items-center gap-3" }, [
                            createVNode(unref(Tag), { class: "h-5 w-5 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Sort Order"),
                              createVNode("div", { class: "text-gray-900" }, toDisplayString(props.category.sort_order), 1)
                            ])
                          ])
                        ])
                      ]),
                      props.category.description ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "rounded-lg border bg-white p-6"
                      }, [
                        createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Description"),
                        createVNode("div", { class: "text-gray-700 whitespace-pre-wrap" }, toDisplayString(props.category.description), 1)
                      ])) : createCommentVNode("", true)
                    ]),
                    createVNode("div", { class: "space-y-6" }, [
                      createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                        createVNode("h3", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Quick Stats"),
                        createVNode("div", { class: "space-y-4" }, [
                          createVNode("div", { class: "flex items-center justify-between" }, [
                            createVNode("span", { class: "text-sm text-gray-500" }, "Status"),
                            createVNode("span", {
                              class: [
                                "text-sm font-medium",
                                props.category.is_active ? "text-green-600" : "text-red-600"
                              ]
                            }, toDisplayString(props.category.is_active ? "Active" : "Inactive"), 3)
                          ]),
                          createVNode("div", { class: "flex items-center justify-between" }, [
                            createVNode("span", { class: "text-sm text-gray-500" }, "Products"),
                            createVNode("span", { class: "text-sm font-medium text-gray-900" }, toDisplayString(props.category.products_count), 1)
                          ]),
                          createVNode("div", { class: "flex items-center justify-between" }, [
                            createVNode("span", { class: "text-sm text-gray-500" }, "Sort Order"),
                            createVNode("span", { class: "text-sm font-medium text-gray-900" }, toDisplayString(props.category.sort_order), 1)
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                        createVNode("h3", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Timestamps"),
                        createVNode("div", { class: "space-y-4" }, [
                          createVNode("div", { class: "flex items-center gap-3" }, [
                            createVNode(unref(Calendar), { class: "h-4 w-4 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Created"),
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(new Date(props.category.created_at).toLocaleDateString()), 1)
                            ])
                          ]),
                          createVNode("div", { class: "flex items-center gap-3" }, [
                            createVNode(unref(Calendar), { class: "h-4 w-4 text-gray-400" }),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-sm font-medium text-gray-500" }, "Last Updated"),
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(new Date(props.category.updated_at).toLocaleDateString()), 1)
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/administration/categories/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
