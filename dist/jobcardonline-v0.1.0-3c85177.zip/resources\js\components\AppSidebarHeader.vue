<script setup lang="ts">
import Breadcrumbs from '@/components/Breadcrumbs.vue';
import CompanySwitcher from '@/components/CompanySwitcher.vue';
import { SidebarTrigger } from '@/components/ui/sidebar';
import type { BreadcrumbItemType } from '@/types';
import { usePage } from '@inertiajs/vue3';
import { computed } from 'vue';

interface Company {
    id: number;
    name: string;
    logo_path: string | null;
    is_default: boolean;
}

const props = withDefaults(
    defineProps<{
        breadcrumbs?: BreadcrumbItemType[];
    }>(),
    {
        breadcrumbs: () => [],
    },
);

const page = usePage();

const currentCompany = computed(() => page.props.currentCompany as Company | null);
const companies = computed(() => page.props.companies as Company[] || []);
</script>

<template>
    <header
        class="flex h-16 shrink-0 items-center justify-between gap-2 border-b border-sidebar-border/70 px-6 transition-[width,height] ease-linear group-has-data-[collapsible=icon]/sidebar-wrapper:h-12 md:px-4"
    >
        <div class="flex items-center gap-2">
            <SidebarTrigger class="-ml-1" />
            <template v-if="breadcrumbs && breadcrumbs.length > 0">
                <Breadcrumbs :breadcrumbs="breadcrumbs" />
            </template>
        </div>
        
        <!-- Company Switcher -->
        <div class="flex items-center">
            <CompanySwitcher 
                :current-company="currentCompany" 
                :companies="companies" 
            />
        </div>
    </header>
</template>
