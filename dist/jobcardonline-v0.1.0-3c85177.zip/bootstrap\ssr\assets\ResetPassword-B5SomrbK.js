import { defineComponent, ref, mergeProps, withCtx, unref, createTextVNode, createBlock, createCommentVNode, openBlock, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { a as applyUrlDefaults, q as queryParams } from "./index--D7ld9AJ.js";
import { _ as _sfc_main$4 } from "./InputError-Dsed5rBJ.js";
import { _ as _sfc_main$5 } from "./Footer-Ce4AN4A5.js";
import { _ as _sfc_main$3 } from "./Input-CBU-ZeCu.js";
import { _ as _sfc_main$2 } from "./Label-UEV1cA3u.js";
import { _ as _sfc_main$1 } from "./AuthLayout-CT6aWTFG.js";
import { Head, Form } from "@inertiajs/vue3";
import { LoaderCircle } from "lucide-vue-next";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "@vueuse/core";
const create = (args, options) => ({
  url: create.url(args, options),
  method: "get"
});
create.definition = {
  methods: ["get", "head"],
  url: "/reset-password/{token}"
};
create.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { token: args };
  }
  if (Array.isArray(args)) {
    args = {
      token: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    token: args.token
  };
  return create.definition.url.replace("{token}", parsedArgs.token.toString()).replace(/\/+$/, "") + queryParams(options);
};
create.get = (args, options) => ({
  url: create.url(args, options),
  method: "get"
});
create.head = (args, options) => ({
  url: create.url(args, options),
  method: "head"
});
const createForm = (args, options) => ({
  action: create.url(args, options),
  method: "get"
});
createForm.get = (args, options) => ({
  action: create.url(args, options),
  method: "get"
});
createForm.head = (args, options) => ({
  action: create.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create.form = createForm;
const store = (options) => ({
  url: store.url(options),
  method: "post"
});
store.definition = {
  methods: ["post"],
  url: "/reset-password"
};
store.url = (options) => {
  return store.definition.url + queryParams(options);
};
store.post = (options) => ({
  url: store.url(options),
  method: "post"
});
const storeForm = (options) => ({
  action: store.url(options),
  method: "post"
});
storeForm.post = (options) => ({
  action: store.url(options),
  method: "post"
});
store.form = storeForm;
const NewPasswordController = { create, store };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ResetPassword",
  __ssrInlineRender: true,
  props: {
    token: {},
    email: {}
  },
  setup(__props) {
    const props = __props;
    const inputEmail = ref(props.email);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, mergeProps({
        title: "Reset password",
        description: "Please enter your new password below"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Reset password" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(Form), mergeProps(unref(NewPasswordController).store.form(), {
              transform: (data) => ({ ...data, token: _ctx.token, email: _ctx.email }),
              "reset-on-success": ["password", "password_confirmation"]
            }), {
              default: withCtx(({ errors, processing }, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="grid gap-6"${_scopeId2}><div class="grid gap-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(_sfc_main$2), { for: "email" }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Email`);
                      } else {
                        return [
                          createTextVNode("Email")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(_sfc_main$3), {
                    id: "email",
                    type: "email",
                    name: "email",
                    autocomplete: "email",
                    modelValue: inputEmail.value,
                    "onUpdate:modelValue": ($event) => inputEmail.value = $event,
                    class: "mt-1 block w-full",
                    readonly: ""
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    message: errors.email,
                    class: "mt-2"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="grid gap-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(_sfc_main$2), { for: "password" }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Password`);
                      } else {
                        return [
                          createTextVNode("Password")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(_sfc_main$3), {
                    id: "password",
                    type: "password",
                    name: "password",
                    autocomplete: "new-password",
                    class: "mt-1 block w-full",
                    autofocus: "",
                    placeholder: "Password"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    message: errors.password
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="grid gap-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(_sfc_main$2), { for: "password_confirmation" }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Confirm Password `);
                      } else {
                        return [
                          createTextVNode(" Confirm Password ")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(_sfc_main$3), {
                    id: "password_confirmation",
                    type: "password",
                    name: "password_confirmation",
                    autocomplete: "new-password",
                    class: "mt-1 block w-full",
                    placeholder: "Confirm password"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    message: errors.password_confirmation
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                  _push3(ssrRenderComponent(unref(_sfc_main$5), {
                    type: "submit",
                    class: "mt-4 w-full",
                    disabled: processing,
                    "data-test": "reset-password-button"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (processing) {
                          _push4(ssrRenderComponent(unref(LoaderCircle), { class: "h-4 w-4 animate-spin" }, null, _parent4, _scopeId3));
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(` Reset password `);
                      } else {
                        return [
                          processing ? (openBlock(), createBlock(unref(LoaderCircle), {
                            key: 0,
                            class: "h-4 w-4 animate-spin"
                          })) : createCommentVNode("", true),
                          createTextVNode(" Reset password ")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "grid gap-6" }, [
                      createVNode("div", { class: "grid gap-2" }, [
                        createVNode(unref(_sfc_main$2), { for: "email" }, {
                          default: withCtx(() => [
                            createTextVNode("Email")
                          ]),
                          _: 1
                        }),
                        createVNode(unref(_sfc_main$3), {
                          id: "email",
                          type: "email",
                          name: "email",
                          autocomplete: "email",
                          modelValue: inputEmail.value,
                          "onUpdate:modelValue": ($event) => inputEmail.value = $event,
                          class: "mt-1 block w-full",
                          readonly: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(_sfc_main$4, {
                          message: errors.email,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", { class: "grid gap-2" }, [
                        createVNode(unref(_sfc_main$2), { for: "password" }, {
                          default: withCtx(() => [
                            createTextVNode("Password")
                          ]),
                          _: 1
                        }),
                        createVNode(unref(_sfc_main$3), {
                          id: "password",
                          type: "password",
                          name: "password",
                          autocomplete: "new-password",
                          class: "mt-1 block w-full",
                          autofocus: "",
                          placeholder: "Password"
                        }),
                        createVNode(_sfc_main$4, {
                          message: errors.password
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", { class: "grid gap-2" }, [
                        createVNode(unref(_sfc_main$2), { for: "password_confirmation" }, {
                          default: withCtx(() => [
                            createTextVNode(" Confirm Password ")
                          ]),
                          _: 1
                        }),
                        createVNode(unref(_sfc_main$3), {
                          id: "password_confirmation",
                          type: "password",
                          name: "password_confirmation",
                          autocomplete: "new-password",
                          class: "mt-1 block w-full",
                          placeholder: "Confirm password"
                        }),
                        createVNode(_sfc_main$4, {
                          message: errors.password_confirmation
                        }, null, 8, ["message"])
                      ]),
                      createVNode(unref(_sfc_main$5), {
                        type: "submit",
                        class: "mt-4 w-full",
                        disabled: processing,
                        "data-test": "reset-password-button"
                      }, {
                        default: withCtx(() => [
                          processing ? (openBlock(), createBlock(unref(LoaderCircle), {
                            key: 0,
                            class: "h-4 w-4 animate-spin"
                          })) : createCommentVNode("", true),
                          createTextVNode(" Reset password ")
                        ]),
                        _: 2
                      }, 1032, ["disabled"])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "Reset password" }),
              createVNode(unref(Form), mergeProps(unref(NewPasswordController).store.form(), {
                transform: (data) => ({ ...data, token: _ctx.token, email: _ctx.email }),
                "reset-on-success": ["password", "password_confirmation"]
              }), {
                default: withCtx(({ errors, processing }) => [
                  createVNode("div", { class: "grid gap-6" }, [
                    createVNode("div", { class: "grid gap-2" }, [
                      createVNode(unref(_sfc_main$2), { for: "email" }, {
                        default: withCtx(() => [
                          createTextVNode("Email")
                        ]),
                        _: 1
                      }),
                      createVNode(unref(_sfc_main$3), {
                        id: "email",
                        type: "email",
                        name: "email",
                        autocomplete: "email",
                        modelValue: inputEmail.value,
                        "onUpdate:modelValue": ($event) => inputEmail.value = $event,
                        class: "mt-1 block w-full",
                        readonly: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(_sfc_main$4, {
                        message: errors.email,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", { class: "grid gap-2" }, [
                      createVNode(unref(_sfc_main$2), { for: "password" }, {
                        default: withCtx(() => [
                          createTextVNode("Password")
                        ]),
                        _: 1
                      }),
                      createVNode(unref(_sfc_main$3), {
                        id: "password",
                        type: "password",
                        name: "password",
                        autocomplete: "new-password",
                        class: "mt-1 block w-full",
                        autofocus: "",
                        placeholder: "Password"
                      }),
                      createVNode(_sfc_main$4, {
                        message: errors.password
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", { class: "grid gap-2" }, [
                      createVNode(unref(_sfc_main$2), { for: "password_confirmation" }, {
                        default: withCtx(() => [
                          createTextVNode(" Confirm Password ")
                        ]),
                        _: 1
                      }),
                      createVNode(unref(_sfc_main$3), {
                        id: "password_confirmation",
                        type: "password",
                        name: "password_confirmation",
                        autocomplete: "new-password",
                        class: "mt-1 block w-full",
                        placeholder: "Confirm password"
                      }),
                      createVNode(_sfc_main$4, {
                        message: errors.password_confirmation
                      }, null, 8, ["message"])
                    ]),
                    createVNode(unref(_sfc_main$5), {
                      type: "submit",
                      class: "mt-4 w-full",
                      disabled: processing,
                      "data-test": "reset-password-button"
                    }, {
                      default: withCtx(() => [
                        processing ? (openBlock(), createBlock(unref(LoaderCircle), {
                          key: 0,
                          class: "h-4 w-4 animate-spin"
                        })) : createCommentVNode("", true),
                        createTextVNode(" Reset password ")
                      ]),
                      _: 2
                    }, 1032, ["disabled"])
                  ])
                ]),
                _: 1
              }, 16, ["transform"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/auth/ResetPassword.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
