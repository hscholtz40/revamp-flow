import { defineComponent, unref, withCtx, createTextVNode, createVNode, withModifiers, withDirectives, createBlock, createCommentVNode, vModelText, openBlock, toDisplayString, Fragment, renderList, vModelCheckbox, vModelSelect, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { u as users } from "./index-B7IvN102.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    user: {},
    groups: {},
    companies: {}
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      name: props.user.name ?? "",
      email: props.user.email ?? "",
      password: "",
      groups: (props.user.groups ?? []).map((g) => g.id),
      companies: (props.user.companies ?? []).map((c) => c.id),
      smtp_host: props.user.smtp_host ?? "",
      smtp_port: props.user.smtp_port ?? 587,
      smtp_username: props.user.smtp_username ?? "",
      smtp_password: "",
      smtp_encryption: props.user.smtp_encryption ?? "tls",
      smtp_from_email: props.user.smtp_from_email ?? "",
      smtp_from_name: props.user.smtp_from_name ?? ""
    });
    function submit() {
      form.put(users.update(props.user.id).url);
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Edit User" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [{ title: "Users", href: unref(users).index().url }, { title: "Edit", href: "#" }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="space-y-4 p-4"${_scopeId}><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Name</span><input${ssrRenderAttr("value", unref(form).name)} class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.name) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.name)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Email</span><input${ssrRenderAttr("value", unref(form).email)} type="email" class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.email) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.email)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Password (leave blank to keep)</span><input${ssrRenderAttr("value", unref(form).password)} type="password" class="w-full rounded border px-3 py-2"${_scopeId}></label><div class="rounded border p-4"${_scopeId}><div class="mb-2 font-medium"${_scopeId}>Groups</div><div class="grid gap-2 md:grid-cols-3"${_scopeId}><!--[-->`);
            ssrRenderList(props.groups, (g) => {
              _push2(`<label class="flex items-center gap-2"${_scopeId}><input type="checkbox"${ssrRenderAttr("value", g.id)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).groups) ? ssrLooseContain(unref(form).groups, g.id) : unref(form).groups) ? " checked" : ""}${_scopeId}><span${_scopeId}>${ssrInterpolate(g.name)}</span></label>`);
            });
            _push2(`<!--]--></div></div><div class="rounded border p-4"${_scopeId}><div class="mb-2 font-medium"${_scopeId}>Company Access</div><p class="mb-3 text-sm text-gray-600"${_scopeId}>Select which companies this user can access. If no companies are selected, the user will have access to all companies.</p><div class="grid gap-2 md:grid-cols-2"${_scopeId}><!--[-->`);
            ssrRenderList(props.companies, (company) => {
              _push2(`<label class="flex items-center gap-2"${_scopeId}><input type="checkbox"${ssrRenderAttr("value", company.id)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).companies) ? ssrLooseContain(unref(form).companies, company.id) : unref(form).companies) ? " checked" : ""}${_scopeId}><span${_scopeId}>${ssrInterpolate(company.name)}</span></label>`);
            });
            _push2(`<!--]--></div>`);
            if (unref(form).errors.companies) {
              _push2(`<div class="text-sm text-red-600 mt-2"${_scopeId}>${ssrInterpolate(unref(form).errors.companies)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="rounded border p-4"${_scopeId}><div class="mb-4 font-medium"${_scopeId}>SMTP Settings (Optional)</div><div class="grid gap-4 md:grid-cols-2"${_scopeId}><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>SMTP Host</span><input${ssrRenderAttr("value", unref(form).smtp_host)} type="text" class="w-full rounded border px-3 py-2" placeholder="smtp.gmail.com"${_scopeId}>`);
            if (unref(form).errors.smtp_host) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.smtp_host)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>SMTP Port</span><input${ssrRenderAttr("value", unref(form).smtp_port)} type="number" class="w-full rounded border px-3 py-2" placeholder="587"${_scopeId}>`);
            if (unref(form).errors.smtp_port) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.smtp_port)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>SMTP Username</span><input${ssrRenderAttr("value", unref(form).smtp_username)} type="text" class="w-full rounded border px-3 py-2" placeholder="your-email@gmail.com"${_scopeId}>`);
            if (unref(form).errors.smtp_username) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.smtp_username)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>SMTP Password (leave blank to keep current)</span><input${ssrRenderAttr("value", unref(form).smtp_password)} type="password" class="w-full rounded border px-3 py-2" placeholder="App password or account password"${_scopeId}>`);
            if (unref(form).errors.smtp_password) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.smtp_password)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Encryption</span><select class="w-full rounded border px-3 py-2"${_scopeId}><option value="tls"${ssrIncludeBooleanAttr(Array.isArray(unref(form).smtp_encryption) ? ssrLooseContain(unref(form).smtp_encryption, "tls") : ssrLooseEqual(unref(form).smtp_encryption, "tls")) ? " selected" : ""}${_scopeId}>TLS</option><option value="ssl"${ssrIncludeBooleanAttr(Array.isArray(unref(form).smtp_encryption) ? ssrLooseContain(unref(form).smtp_encryption, "ssl") : ssrLooseEqual(unref(form).smtp_encryption, "ssl")) ? " selected" : ""}${_scopeId}>SSL</option><option value="none"${ssrIncludeBooleanAttr(Array.isArray(unref(form).smtp_encryption) ? ssrLooseContain(unref(form).smtp_encryption, "none") : ssrLooseEqual(unref(form).smtp_encryption, "none")) ? " selected" : ""}${_scopeId}>None</option></select>`);
            if (unref(form).errors.smtp_encryption) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.smtp_encryption)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>From Email</span><input${ssrRenderAttr("value", unref(form).smtp_from_email)} type="email" class="w-full rounded border px-3 py-2" placeholder="noreply@company.com"${_scopeId}>`);
            if (unref(form).errors.smtp_from_email) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.smtp_from_email)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block md:col-span-2"${_scopeId}><span class="mb-1 block"${_scopeId}>From Name</span><input${ssrRenderAttr("value", unref(form).smtp_from_name)} type="text" class="w-full rounded border px-3 py-2" placeholder="Company Name"${_scopeId}>`);
            if (unref(form).errors.smtp_from_name) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.smtp_from_name)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label></div></div><div class="flex items-center gap-3"${_scopeId}><button${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="rounded bg-blue-600 px-4 py-2 text-white"${_scopeId}>Save</button>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(users).index().url,
              class: "rounded border px-4 py-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Cancel`);
                } else {
                  return [
                    createTextVNode("Cancel")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                onSubmit: withModifiers(submit, ["prevent"]),
                class: "space-y-4 p-4"
              }, [
                createVNode("label", { class: "block" }, [
                  createVNode("span", { class: "mb-1 block" }, "Name"),
                  withDirectives(createVNode("input", {
                    "onUpdate:modelValue": ($event) => unref(form).name = $event,
                    class: "w-full rounded border px-3 py-2"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(form).name]
                  ]),
                  unref(form).errors.name ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "text-sm text-red-600"
                  }, toDisplayString(unref(form).errors.name), 1)) : createCommentVNode("", true)
                ]),
                createVNode("label", { class: "block" }, [
                  createVNode("span", { class: "mb-1 block" }, "Email"),
                  withDirectives(createVNode("input", {
                    "onUpdate:modelValue": ($event) => unref(form).email = $event,
                    type: "email",
                    class: "w-full rounded border px-3 py-2"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(form).email]
                  ]),
                  unref(form).errors.email ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "text-sm text-red-600"
                  }, toDisplayString(unref(form).errors.email), 1)) : createCommentVNode("", true)
                ]),
                createVNode("label", { class: "block" }, [
                  createVNode("span", { class: "mb-1 block" }, "Password (leave blank to keep)"),
                  withDirectives(createVNode("input", {
                    "onUpdate:modelValue": ($event) => unref(form).password = $event,
                    type: "password",
                    class: "w-full rounded border px-3 py-2"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(form).password]
                  ])
                ]),
                createVNode("div", { class: "rounded border p-4" }, [
                  createVNode("div", { class: "mb-2 font-medium" }, "Groups"),
                  createVNode("div", { class: "grid gap-2 md:grid-cols-3" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(props.groups, (g) => {
                      return openBlock(), createBlock("label", {
                        key: g.id,
                        class: "flex items-center gap-2"
                      }, [
                        withDirectives(createVNode("input", {
                          type: "checkbox",
                          value: g.id,
                          "onUpdate:modelValue": ($event) => unref(form).groups = $event
                        }, null, 8, ["value", "onUpdate:modelValue"]), [
                          [vModelCheckbox, unref(form).groups]
                        ]),
                        createVNode("span", null, toDisplayString(g.name), 1)
                      ]);
                    }), 128))
                  ])
                ]),
                createVNode("div", { class: "rounded border p-4" }, [
                  createVNode("div", { class: "mb-2 font-medium" }, "Company Access"),
                  createVNode("p", { class: "mb-3 text-sm text-gray-600" }, "Select which companies this user can access. If no companies are selected, the user will have access to all companies."),
                  createVNode("div", { class: "grid gap-2 md:grid-cols-2" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(props.companies, (company) => {
                      return openBlock(), createBlock("label", {
                        key: company.id,
                        class: "flex items-center gap-2"
                      }, [
                        withDirectives(createVNode("input", {
                          type: "checkbox",
                          value: company.id,
                          "onUpdate:modelValue": ($event) => unref(form).companies = $event
                        }, null, 8, ["value", "onUpdate:modelValue"]), [
                          [vModelCheckbox, unref(form).companies]
                        ]),
                        createVNode("span", null, toDisplayString(company.name), 1)
                      ]);
                    }), 128))
                  ]),
                  unref(form).errors.companies ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "text-sm text-red-600 mt-2"
                  }, toDisplayString(unref(form).errors.companies), 1)) : createCommentVNode("", true)
                ]),
                createVNode("div", { class: "rounded border p-4" }, [
                  createVNode("div", { class: "mb-4 font-medium" }, "SMTP Settings (Optional)"),
                  createVNode("div", { class: "grid gap-4 md:grid-cols-2" }, [
                    createVNode("label", { class: "block" }, [
                      createVNode("span", { class: "mb-1 block" }, "SMTP Host"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => unref(form).smtp_host = $event,
                        type: "text",
                        class: "w-full rounded border px-3 py-2",
                        placeholder: "smtp.gmail.com"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).smtp_host]
                      ]),
                      unref(form).errors.smtp_host ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-red-600"
                      }, toDisplayString(unref(form).errors.smtp_host), 1)) : createCommentVNode("", true)
                    ]),
                    createVNode("label", { class: "block" }, [
                      createVNode("span", { class: "mb-1 block" }, "SMTP Port"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => unref(form).smtp_port = $event,
                        type: "number",
                        class: "w-full rounded border px-3 py-2",
                        placeholder: "587"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).smtp_port]
                      ]),
                      unref(form).errors.smtp_port ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-red-600"
                      }, toDisplayString(unref(form).errors.smtp_port), 1)) : createCommentVNode("", true)
                    ]),
                    createVNode("label", { class: "block" }, [
                      createVNode("span", { class: "mb-1 block" }, "SMTP Username"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => unref(form).smtp_username = $event,
                        type: "text",
                        class: "w-full rounded border px-3 py-2",
                        placeholder: "your-email@gmail.com"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).smtp_username]
                      ]),
                      unref(form).errors.smtp_username ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-red-600"
                      }, toDisplayString(unref(form).errors.smtp_username), 1)) : createCommentVNode("", true)
                    ]),
                    createVNode("label", { class: "block" }, [
                      createVNode("span", { class: "mb-1 block" }, "SMTP Password (leave blank to keep current)"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => unref(form).smtp_password = $event,
                        type: "password",
                        class: "w-full rounded border px-3 py-2",
                        placeholder: "App password or account password"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).smtp_password]
                      ]),
                      unref(form).errors.smtp_password ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-red-600"
                      }, toDisplayString(unref(form).errors.smtp_password), 1)) : createCommentVNode("", true)
                    ]),
                    createVNode("label", { class: "block" }, [
                      createVNode("span", { class: "mb-1 block" }, "Encryption"),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => unref(form).smtp_encryption = $event,
                        class: "w-full rounded border px-3 py-2"
                      }, [
                        createVNode("option", { value: "tls" }, "TLS"),
                        createVNode("option", { value: "ssl" }, "SSL"),
                        createVNode("option", { value: "none" }, "None")
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, unref(form).smtp_encryption]
                      ]),
                      unref(form).errors.smtp_encryption ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-red-600"
                      }, toDisplayString(unref(form).errors.smtp_encryption), 1)) : createCommentVNode("", true)
                    ]),
                    createVNode("label", { class: "block" }, [
                      createVNode("span", { class: "mb-1 block" }, "From Email"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => unref(form).smtp_from_email = $event,
                        type: "email",
                        class: "w-full rounded border px-3 py-2",
                        placeholder: "noreply@company.com"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).smtp_from_email]
                      ]),
                      unref(form).errors.smtp_from_email ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-red-600"
                      }, toDisplayString(unref(form).errors.smtp_from_email), 1)) : createCommentVNode("", true)
                    ]),
                    createVNode("label", { class: "block md:col-span-2" }, [
                      createVNode("span", { class: "mb-1 block" }, "From Name"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => unref(form).smtp_from_name = $event,
                        type: "text",
                        class: "w-full rounded border px-3 py-2",
                        placeholder: "Company Name"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).smtp_from_name]
                      ]),
                      unref(form).errors.smtp_from_name ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-red-600"
                      }, toDisplayString(unref(form).errors.smtp_from_name), 1)) : createCommentVNode("", true)
                    ])
                  ])
                ]),
                createVNode("div", { class: "flex items-center gap-3" }, [
                  createVNode("button", {
                    disabled: unref(form).processing,
                    class: "rounded bg-blue-600 px-4 py-2 text-white"
                  }, "Save", 8, ["disabled"]),
                  createVNode(unref(Link), {
                    href: unref(users).index().url,
                    class: "rounded border px-4 py-2"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Cancel")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ])
              ], 32)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/users/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
