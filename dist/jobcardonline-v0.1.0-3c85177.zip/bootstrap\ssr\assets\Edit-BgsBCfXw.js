import { defineComponent, computed, watch, unref, withCtx, createTextVNode, createVNode, toDisplayString, createBlock, createCommentVNode, openBlock, withModifiers, withDirectives, Fragment, renderList, vModelSelect, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderClass, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1, i as invoices } from "./AppLayout-CmGu2Oww.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    invoice: {},
    customers: {},
    products: {},
    users: {},
    currentCompany: {},
    canEditSalesperson: { type: Boolean },
    canEditCompleted: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const canEditSalesperson = computed(() => props.canEditSalesperson);
    const canEditCompleted = computed(() => props.canEditCompleted);
    const isCompleted = computed(() => props.invoice.status === "paid");
    const canEdit = computed(() => !isCompleted.value || canEditCompleted.value);
    const form = useForm({
      title: props.invoice.title,
      description: props.invoice.description || "",
      customer_id: props.invoice.customer_id,
      salesperson_id: props.invoice.salesperson_id || "",
      invoice_date: props.invoice.invoice_date ? new Date(props.invoice.invoice_date).toISOString().split("T")[0] : "",
      due_date: props.invoice.due_date ? new Date(props.invoice.due_date).toISOString().split("T")[0] : "",
      tax_rate: props.invoice.tax_rate,
      discount_amount: props.invoice.discount_amount || 0,
      discount_percentage: props.invoice.discount_percentage || 0,
      notes: props.invoice.notes || "",
      terms: props.invoice.terms || "",
      line_items: props.invoice.line_items.map((item) => ({
        product_id: item.product_id?.toString() || null,
        description: item.description,
        quantity: item.quantity,
        unit_price: item.unit_price,
        total: item.total
      }))
    });
    watch(() => form.customer_id, (newCustomerId) => {
      if (newCustomerId) {
        const customer = props.customers.find((c) => c.id === parseInt(newCustomerId));
        if (customer) {
          form.title = `Invoice for ${customer.name}`;
        }
      }
    });
    watch(() => form.discount_amount, (newAmount) => {
      if (newAmount > 0) {
        form.discount_percentage = 0;
      }
    });
    watch(() => form.discount_percentage, (newPercentage) => {
      if (newPercentage > 0) {
        form.discount_amount = 0;
      }
    });
    const addLineItem = () => {
      form.line_items.push({
        product_id: null,
        description: "",
        quantity: 1,
        unit_price: 0,
        total: 0
      });
    };
    const removeLineItem = (index) => {
      if (form.line_items.length > 1) {
        form.line_items.splice(index, 1);
      }
    };
    const selectProduct = (index, event) => {
      const target = event.target;
      const productId = target.value;
      if (productId) {
        const product = props.products.find((p) => p.id === parseInt(productId));
        if (product) {
          form.line_items[index].product_id = productId;
          form.line_items[index].description = product.name;
          form.line_items[index].unit_price = product.price;
          calculateItemTotal(index);
        }
      } else {
        form.line_items[index].product_id = null;
        form.line_items[index].description = "";
        form.line_items[index].unit_price = 0;
        form.line_items[index].total = 0;
      }
    };
    const calculateItemTotal = (index) => {
      const item = form.line_items[index];
      item.total = item.quantity * item.unit_price;
    };
    const formatCurrency = (amount) => {
      return new Intl.NumberFormat("en-ZA", {
        style: "currency",
        currency: "ZAR"
      }).format(amount || 0);
    };
    const subtotal = computed(() => {
      return form.line_items.reduce((sum, item) => sum + (item.total || 0), 0);
    });
    const discountAmount = computed(() => {
      const amount = Number(form.discount_amount) || 0;
      const percentage = Number(form.discount_percentage) || 0;
      if (percentage > 0) {
        return subtotal.value * (percentage / 100);
      }
      return amount;
    });
    const taxAmount = computed(() => {
      const subtotalAfterDiscount = subtotal.value - discountAmount.value;
      return subtotalAfterDiscount * (form.tax_rate / 100);
    });
    const total = computed(() => {
      const subtotalAfterDiscount = subtotal.value - discountAmount.value;
      return subtotalAfterDiscount + taxAmount.value;
    });
    const submit = () => {
      form.put(invoices.update(props.invoice.id).url);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Edit Invoice ${props.invoice.invoice_number}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Invoices", href: unref(invoices).index().url },
          { title: props.invoice.invoice_number, href: unref(invoices).show(props.invoice.id).url },
          { title: "Edit", href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-blue-50 border-b border-blue-200 px-4 py-3"${_scopeId}><div class="flex items-center gap-2 text-sm text-blue-700"${_scopeId}><span class="font-medium"${_scopeId}>Editing invoice for:</span><span class="font-semibold"${_scopeId}>${ssrInterpolate(props.currentCompany.name)}</span></div></div><div class="p-4"${_scopeId}><div class="flex items-center justify-between gap-3 mb-6"${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>Edit Invoice ${ssrInterpolate(props.invoice.invoice_number)}</h1></div>`);
            if (isCompleted.value && !canEditCompleted.value) {
              _push2(`<div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6"${_scopeId}><div class="flex items-center"${_scopeId}><div class="flex-shrink-0"${_scopeId}><svg class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor"${_scopeId}><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"${_scopeId}></path></svg></div><div class="ml-3"${_scopeId}><h3 class="text-sm font-medium text-yellow-800"${_scopeId}>Invoice is Paid</h3><p class="text-sm text-yellow-700 mt-1"${_scopeId}>This invoice has been paid and cannot be edited. Contact an administrator if changes are needed.</p></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<form class="space-y-6"${_scopeId}><div class="bg-white rounded-lg border p-6"${_scopeId}><h2 class="text-lg font-semibold text-gray-900 mb-4"${_scopeId}>Basic Information</h2><div class="grid grid-cols-1 md:grid-cols-2 gap-6"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Customer *</label><select class="${ssrRenderClass([{ "border-red-500": unref(form).errors.customer_id, "bg-gray-100 cursor-not-allowed": !canEdit.value }, "w-full rounded border px-3 py-2"])}"${ssrIncludeBooleanAttr(!canEdit.value) ? " disabled" : ""} required${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(unref(form).customer_id) ? ssrLooseContain(unref(form).customer_id, "") : ssrLooseEqual(unref(form).customer_id, "")) ? " selected" : ""}${_scopeId}>Select a customer</option><!--[-->`);
            ssrRenderList(props.customers, (customer) => {
              _push2(`<option${ssrRenderAttr("value", customer.id)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).customer_id) ? ssrLooseContain(unref(form).customer_id, customer.id) : ssrLooseEqual(unref(form).customer_id, customer.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(customer.name)}</option>`);
            });
            _push2(`<!--]--></select>`);
            if (unref(form).errors.customer_id) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.customer_id)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Salesperson</label><select class="${ssrRenderClass([{ "border-red-500": unref(form).errors.salesperson_id }, "w-full rounded border px-3 py-2"])}"${ssrIncludeBooleanAttr(!canEditSalesperson.value) ? " disabled" : ""}${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(unref(form).salesperson_id) ? ssrLooseContain(unref(form).salesperson_id, "") : ssrLooseEqual(unref(form).salesperson_id, "")) ? " selected" : ""}${_scopeId}>Select a salesperson</option><!--[-->`);
            ssrRenderList(props.users, (user) => {
              _push2(`<option${ssrRenderAttr("value", user.id)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).salesperson_id) ? ssrLooseContain(unref(form).salesperson_id, user.id) : ssrLooseEqual(unref(form).salesperson_id, user.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(user.name)}</option>`);
            });
            _push2(`<!--]--></select>`);
            if (unref(form).errors.salesperson_id) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.salesperson_id)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (!canEditSalesperson.value) {
              _push2(`<div class="text-gray-500 text-sm mt-1"${_scopeId}> You don&#39;t have permission to edit the salesperson </div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Title *</label><input${ssrRenderAttr("value", unref(form).title)} type="text" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.title }, "w-full rounded border px-3 py-2"])}" required${_scopeId}>`);
            if (unref(form).errors.title) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.title)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Invoice Date *</label><input${ssrRenderAttr("value", unref(form).invoice_date)} type="date" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.invoice_date }, "w-full rounded border px-3 py-2"])}" required${_scopeId}>`);
            if (unref(form).errors.invoice_date) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.invoice_date)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Due Date *</label><input${ssrRenderAttr("value", unref(form).due_date)} type="date" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.due_date }, "w-full rounded border px-3 py-2"])}" required${_scopeId}>`);
            if (unref(form).errors.due_date) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.due_date)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="mt-6"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Description</label><textarea rows="3" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.description }, "w-full rounded border px-3 py-2"])}"${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea>`);
            if (unref(form).errors.description) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.description)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="bg-white rounded-lg border p-6"${_scopeId}><div class="flex items-center justify-between mb-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Line Items</h2><button type="button" class="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"${_scopeId}> Add Item </button></div>`);
            if (unref(form).errors.line_items) {
              _push2(`<div class="text-red-500 text-sm mb-4"${_scopeId}>${ssrInterpolate(unref(form).errors.line_items)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="space-y-4"${_scopeId}><!--[-->`);
            ssrRenderList(unref(form).line_items, (item, index) => {
              _push2(`<div class="border rounded-lg p-4"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-6 gap-4 items-end"${_scopeId}><div class="md:col-span-2"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Product</label><select class="w-full rounded border px-3 py-2"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(item.product_id) ? ssrLooseContain(item.product_id, "") : ssrLooseEqual(item.product_id, "")) ? " selected" : ""}${_scopeId}>Custom Item</option><!--[-->`);
              ssrRenderList(props.products, (product) => {
                _push2(`<option${ssrRenderAttr("value", product.id)}${ssrIncludeBooleanAttr(Array.isArray(item.product_id) ? ssrLooseContain(item.product_id, product.id) : ssrLooseEqual(item.product_id, product.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(product.name)}</option>`);
              });
              _push2(`<!--]--></select></div><div class="md:col-span-2"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Description *</label><input${ssrRenderAttr("value", item.description)} type="text" class="w-full rounded border px-3 py-2" required${_scopeId}></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Quantity *</label><input${ssrRenderAttr("value", item.quantity)} type="number" min="1" class="w-full rounded border px-3 py-2" required${_scopeId}></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Unit Price *</label><input${ssrRenderAttr("value", item.unit_price)} type="number" step="0.01" min="0" class="w-full rounded border px-3 py-2" required${_scopeId}></div></div><div class="flex items-center justify-between mt-4"${_scopeId}><div class="text-sm font-medium text-gray-900"${_scopeId}> Total: ${ssrInterpolate(formatCurrency(item.total))}</div><button type="button" class="text-red-600 hover:text-red-800"${_scopeId}> Remove </button></div></div>`);
            });
            _push2(`<!--]--></div><br${_scopeId}><div class="flex items-center justify-between mb-4"${_scopeId}><button type="button" class="rounded bg-blue-600 px-3 py-2 text-white hover:bg-blue-700"${_scopeId}> + </button></div></div><div class="bg-white rounded-lg border p-6"${_scopeId}><h2 class="text-lg font-semibold text-gray-900 mb-4"${_scopeId}>Totals</h2><div class="space-y-2"${_scopeId}><div class="flex justify-between"${_scopeId}><span class="text-gray-600"${_scopeId}>Subtotal:</span><span class="font-medium"${_scopeId}>${ssrInterpolate(formatCurrency(subtotal.value))}</span></div><div class="flex justify-between"${_scopeId}><span class="text-gray-600"${_scopeId}>Discount:</span><span class="font-medium text-red-600"${_scopeId}>-${ssrInterpolate(formatCurrency(discountAmount.value))}</span></div><div class="flex justify-between"${_scopeId}><span class="text-gray-600"${_scopeId}>Tax (15%):</span><span class="font-medium"${_scopeId}>${ssrInterpolate(formatCurrency(taxAmount.value))}</span></div><div class="flex justify-between text-lg font-semibold border-t pt-2"${_scopeId}><span${_scopeId}>Total:</span><span${_scopeId}>${ssrInterpolate(formatCurrency(total.value))}</span></div></div></div><div class="bg-white rounded-lg border p-6"${_scopeId}><h2 class="text-lg font-semibold text-gray-900 mb-4"${_scopeId}>Additional Information</h2><div class="space-y-6"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Discount Amount (R)</label><input type="number" step="0.01"${ssrRenderAttr("value", unref(form).discount_amount)} class="${ssrRenderClass([{ "border-red-500": unref(form).errors.discount_amount }, "w-full rounded border px-3 py-2"])}" placeholder="0.00"${_scopeId}>`);
            if (unref(form).errors.discount_amount) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.discount_amount)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Discount Percentage (%)</label><input type="number" step="0.01"${ssrRenderAttr("value", unref(form).discount_percentage)} class="${ssrRenderClass([{ "border-red-500": unref(form).errors.discount_percentage }, "w-full rounded border px-3 py-2"])}" placeholder="0.00"${_scopeId}>`);
            if (unref(form).errors.discount_percentage) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.discount_percentage)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="grid grid-cols-1 md:grid-cols-2 gap-6"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Notes</label><textarea rows="4" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.notes }, "w-full rounded border px-3 py-2"])}"${_scopeId}>${ssrInterpolate(unref(form).notes)}</textarea>`);
            if (unref(form).errors.notes) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.notes)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Terms &amp; Conditions</label><textarea rows="4" class="${ssrRenderClass([{ "border-red-500": unref(form).errors.terms }, "w-full rounded border px-3 py-2"])}"${_scopeId}>${ssrInterpolate(unref(form).terms)}</textarea>`);
            if (unref(form).errors.terms) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.terms)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="flex items-center justify-end gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(invoices).show(props.invoice.id).url,
              class: "rounded bg-gray-500 px-4 py-2 text-white hover:bg-gray-600"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Cancel `);
                } else {
                  return [
                    createTextVNode(" Cancel ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<button type="submit"${ssrIncludeBooleanAttr(unref(form).processing || !canEdit.value) ? " disabled" : ""} class="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(form).processing ? "Updating..." : "Update Invoice")}</button></div></form></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-blue-50 border-b border-blue-200 px-4 py-3" }, [
                createVNode("div", { class: "flex items-center gap-2 text-sm text-blue-700" }, [
                  createVNode("span", { class: "font-medium" }, "Editing invoice for:"),
                  createVNode("span", { class: "font-semibold" }, toDisplayString(props.currentCompany.name), 1)
                ])
              ]),
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "flex items-center justify-between gap-3 mb-6" }, [
                  createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "Edit Invoice " + toDisplayString(props.invoice.invoice_number), 1)
                ]),
                isCompleted.value && !canEditCompleted.value ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6"
                }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("div", { class: "flex-shrink-0" }, [
                      (openBlock(), createBlock("svg", {
                        class: "h-5 w-5 text-yellow-400",
                        viewBox: "0 0 20 20",
                        fill: "currentColor"
                      }, [
                        createVNode("path", {
                          "fill-rule": "evenodd",
                          d: "M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z",
                          "clip-rule": "evenodd"
                        })
                      ]))
                    ]),
                    createVNode("div", { class: "ml-3" }, [
                      createVNode("h3", { class: "text-sm font-medium text-yellow-800" }, "Invoice is Paid"),
                      createVNode("p", { class: "text-sm text-yellow-700 mt-1" }, "This invoice has been paid and cannot be edited. Contact an administrator if changes are needed.")
                    ])
                  ])
                ])) : createCommentVNode("", true),
                createVNode("form", {
                  onSubmit: withModifiers(submit, ["prevent"]),
                  class: "space-y-6"
                }, [
                  createVNode("div", { class: "bg-white rounded-lg border p-6" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900 mb-4" }, "Basic Information"),
                    createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-6" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Customer *"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => unref(form).customer_id = $event,
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.customer_id, "bg-gray-100 cursor-not-allowed": !canEdit.value }],
                          disabled: !canEdit.value,
                          required: ""
                        }, [
                          createVNode("option", { value: "" }, "Select a customer"),
                          (openBlock(true), createBlock(Fragment, null, renderList(props.customers, (customer) => {
                            return openBlock(), createBlock("option", {
                              key: customer.id,
                              value: customer.id
                            }, toDisplayString(customer.name), 9, ["value"]);
                          }), 128))
                        ], 10, ["onUpdate:modelValue", "disabled"]), [
                          [vModelSelect, unref(form).customer_id]
                        ]),
                        unref(form).errors.customer_id ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.customer_id), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Salesperson"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => unref(form).salesperson_id = $event,
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.salesperson_id }],
                          disabled: !canEditSalesperson.value
                        }, [
                          createVNode("option", { value: "" }, "Select a salesperson"),
                          (openBlock(true), createBlock(Fragment, null, renderList(props.users, (user) => {
                            return openBlock(), createBlock("option", {
                              key: user.id,
                              value: user.id
                            }, toDisplayString(user.name), 9, ["value"]);
                          }), 128))
                        ], 10, ["onUpdate:modelValue", "disabled"]), [
                          [vModelSelect, unref(form).salesperson_id]
                        ]),
                        unref(form).errors.salesperson_id ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.salesperson_id), 1)) : createCommentVNode("", true),
                        !canEditSalesperson.value ? (openBlock(), createBlock("div", {
                          key: 1,
                          class: "text-gray-500 text-sm mt-1"
                        }, " You don't have permission to edit the salesperson ")) : createCommentVNode("", true)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Title *"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => unref(form).title = $event,
                          type: "text",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.title }],
                          required: ""
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).title]
                        ]),
                        unref(form).errors.title ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.title), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Invoice Date *"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => unref(form).invoice_date = $event,
                          type: "date",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.invoice_date }],
                          required: ""
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).invoice_date]
                        ]),
                        unref(form).errors.invoice_date ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.invoice_date), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Due Date *"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => unref(form).due_date = $event,
                          type: "date",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.due_date }],
                          required: ""
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).due_date]
                        ]),
                        unref(form).errors.due_date ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.due_date), 1)) : createCommentVNode("", true)
                      ])
                    ]),
                    createVNode("div", { class: "mt-6" }, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Description"),
                      withDirectives(createVNode("textarea", {
                        "onUpdate:modelValue": ($event) => unref(form).description = $event,
                        rows: "3",
                        class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.description }]
                      }, null, 10, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).description]
                      ]),
                      unref(form).errors.description ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-red-500 text-sm mt-1"
                      }, toDisplayString(unref(form).errors.description), 1)) : createCommentVNode("", true)
                    ])
                  ]),
                  createVNode("div", { class: "bg-white rounded-lg border p-6" }, [
                    createVNode("div", { class: "flex items-center justify-between mb-4" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Line Items"),
                      createVNode("button", {
                        type: "button",
                        onClick: addLineItem,
                        class: "rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                      }, " Add Item ")
                    ]),
                    unref(form).errors.line_items ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "text-red-500 text-sm mb-4"
                    }, toDisplayString(unref(form).errors.line_items), 1)) : createCommentVNode("", true),
                    createVNode("div", { class: "space-y-4" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(form).line_items, (item, index) => {
                        return openBlock(), createBlock("div", {
                          key: index,
                          class: "border rounded-lg p-4"
                        }, [
                          createVNode("div", { class: "grid grid-cols-1 md:grid-cols-6 gap-4 items-end" }, [
                            createVNode("div", { class: "md:col-span-2" }, [
                              createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Product"),
                              withDirectives(createVNode("select", {
                                "onUpdate:modelValue": ($event) => item.product_id = $event,
                                onChange: ($event) => selectProduct(index, $event),
                                class: "w-full rounded border px-3 py-2"
                              }, [
                                createVNode("option", { value: "" }, "Custom Item"),
                                (openBlock(true), createBlock(Fragment, null, renderList(props.products, (product) => {
                                  return openBlock(), createBlock("option", {
                                    key: product.id,
                                    value: product.id
                                  }, toDisplayString(product.name), 9, ["value"]);
                                }), 128))
                              ], 40, ["onUpdate:modelValue", "onChange"]), [
                                [vModelSelect, item.product_id]
                              ])
                            ]),
                            createVNode("div", { class: "md:col-span-2" }, [
                              createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Description *"),
                              withDirectives(createVNode("input", {
                                "onUpdate:modelValue": ($event) => item.description = $event,
                                type: "text",
                                class: "w-full rounded border px-3 py-2",
                                required: ""
                              }, null, 8, ["onUpdate:modelValue"]), [
                                [vModelText, item.description]
                              ])
                            ]),
                            createVNode("div", null, [
                              createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Quantity *"),
                              withDirectives(createVNode("input", {
                                "onUpdate:modelValue": ($event) => item.quantity = $event,
                                onInput: ($event) => calculateItemTotal(index),
                                type: "number",
                                min: "1",
                                class: "w-full rounded border px-3 py-2",
                                required: ""
                              }, null, 40, ["onUpdate:modelValue", "onInput"]), [
                                [
                                  vModelText,
                                  item.quantity,
                                  void 0,
                                  { number: true }
                                ]
                              ])
                            ]),
                            createVNode("div", null, [
                              createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Unit Price *"),
                              withDirectives(createVNode("input", {
                                "onUpdate:modelValue": ($event) => item.unit_price = $event,
                                onInput: ($event) => calculateItemTotal(index),
                                type: "number",
                                step: "0.01",
                                min: "0",
                                class: "w-full rounded border px-3 py-2",
                                required: ""
                              }, null, 40, ["onUpdate:modelValue", "onInput"]), [
                                [
                                  vModelText,
                                  item.unit_price,
                                  void 0,
                                  { number: true }
                                ]
                              ])
                            ])
                          ]),
                          createVNode("div", { class: "flex items-center justify-between mt-4" }, [
                            createVNode("div", { class: "text-sm font-medium text-gray-900" }, " Total: " + toDisplayString(formatCurrency(item.total)), 1),
                            createVNode("button", {
                              type: "button",
                              onClick: ($event) => removeLineItem(index),
                              class: "text-red-600 hover:text-red-800"
                            }, " Remove ", 8, ["onClick"])
                          ])
                        ]);
                      }), 128))
                    ]),
                    createVNode("br"),
                    createVNode("div", { class: "flex items-center justify-between mb-4" }, [
                      createVNode("button", {
                        type: "button",
                        onClick: addLineItem,
                        class: "rounded bg-blue-600 px-3 py-2 text-white hover:bg-blue-700"
                      }, " + ")
                    ])
                  ]),
                  createVNode("div", { class: "bg-white rounded-lg border p-6" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900 mb-4" }, "Totals"),
                    createVNode("div", { class: "space-y-2" }, [
                      createVNode("div", { class: "flex justify-between" }, [
                        createVNode("span", { class: "text-gray-600" }, "Subtotal:"),
                        createVNode("span", { class: "font-medium" }, toDisplayString(formatCurrency(subtotal.value)), 1)
                      ]),
                      createVNode("div", { class: "flex justify-between" }, [
                        createVNode("span", { class: "text-gray-600" }, "Discount:"),
                        createVNode("span", { class: "font-medium text-red-600" }, "-" + toDisplayString(formatCurrency(discountAmount.value)), 1)
                      ]),
                      createVNode("div", { class: "flex justify-between" }, [
                        createVNode("span", { class: "text-gray-600" }, "Tax (15%):"),
                        createVNode("span", { class: "font-medium" }, toDisplayString(formatCurrency(taxAmount.value)), 1)
                      ]),
                      createVNode("div", { class: "flex justify-between text-lg font-semibold border-t pt-2" }, [
                        createVNode("span", null, "Total:"),
                        createVNode("span", null, toDisplayString(formatCurrency(total.value)), 1)
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "bg-white rounded-lg border p-6" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900 mb-4" }, "Additional Information"),
                    createVNode("div", { class: "space-y-6" }, [
                      createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Discount Amount (R)"),
                          withDirectives(createVNode("input", {
                            type: "number",
                            step: "0.01",
                            "onUpdate:modelValue": ($event) => unref(form).discount_amount = $event,
                            class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.discount_amount }],
                            placeholder: "0.00"
                          }, null, 10, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).discount_amount]
                          ]),
                          unref(form).errors.discount_amount ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(form).errors.discount_amount), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Discount Percentage (%)"),
                          withDirectives(createVNode("input", {
                            type: "number",
                            step: "0.01",
                            "onUpdate:modelValue": ($event) => unref(form).discount_percentage = $event,
                            class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.discount_percentage }],
                            placeholder: "0.00"
                          }, null, 10, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).discount_percentage]
                          ]),
                          unref(form).errors.discount_percentage ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(form).errors.discount_percentage), 1)) : createCommentVNode("", true)
                        ])
                      ]),
                      createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-6" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Notes"),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => unref(form).notes = $event,
                            rows: "4",
                            class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.notes }]
                          }, null, 10, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).notes]
                          ]),
                          unref(form).errors.notes ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(form).errors.notes), 1)) : createCommentVNode("", true)
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Terms & Conditions"),
                        withDirectives(createVNode("textarea", {
                          "onUpdate:modelValue": ($event) => unref(form).terms = $event,
                          rows: "4",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(form).errors.terms }]
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).terms]
                        ]),
                        unref(form).errors.terms ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(form).errors.terms), 1)) : createCommentVNode("", true)
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "flex items-center justify-end gap-3" }, [
                    createVNode(unref(Link), {
                      href: unref(invoices).show(props.invoice.id).url,
                      class: "rounded bg-gray-500 px-4 py-2 text-white hover:bg-gray-600"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Cancel ")
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode("button", {
                      type: "submit",
                      disabled: unref(form).processing || !canEdit.value,
                      class: "rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 disabled:opacity-50"
                    }, toDisplayString(unref(form).processing ? "Updating..." : "Update Invoice"), 9, ["disabled"])
                  ])
                ], 32)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/invoices/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
