import { defineComponent, computed, ref, unref, withCtx, createTextVNode, createVNode, createBlock, createCommentVNode, openBlock, Fragment, renderList, toDisplayString, withModifiers, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1, i as invoices } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link, router } from "@inertiajs/vue3";
import { j as jobcards } from "./_plugin-vue_export-helper-BjD8VFd3.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    jobcard: {},
    canEditCompleted: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const statusOptions = [
      { value: "draft", label: "Draft" },
      { value: "pending", label: "Pending" },
      { value: "in_progress", label: "In Progress" },
      { value: "completed", label: "Completed" },
      { value: "cancelled", label: "Cancelled" }
    ];
    const canEditJobcard = computed(() => {
      if (props.jobcard.status !== "completed") {
        return true;
      }
      return props.canEditCompleted;
    });
    const canDeleteJobcard = computed(() => {
      if (props.jobcard.status !== "completed") {
        return true;
      }
      return props.canEditCompleted;
    });
    const canUpdateStatus = (status) => {
      if (status === props.jobcard.status) {
        return false;
      }
      if (props.jobcard.status === "completed" && !props.canEditCompleted) {
        return false;
      }
      return true;
    };
    const updateStatus = (status) => {
      if (!canUpdateStatus(status)) {
        return;
      }
      router.patch(jobcards.updateStatus(props.jobcard.id).url, {
        status
      }, {
        onSuccess: () => {
        },
        onError: (errors) => {
          console.error("Error updating status:", errors);
        }
      });
    };
    const deleteJobcard = () => {
      if (confirm(`Are you sure you want to delete jobcard ${props.jobcard.job_number}?`)) {
        router.delete(jobcards.destroy(props.jobcard.id).url);
      }
    };
    const getStatusBadgeClass = (status) => {
      if (!status) return "bg-gray-100 text-gray-800";
      const classes = {
        draft: "bg-gray-100 text-gray-800",
        pending: "bg-yellow-100 text-yellow-800",
        in_progress: "bg-blue-100 text-blue-800",
        completed: "bg-green-100 text-green-800",
        cancelled: "bg-red-100 text-red-800"
      };
      return classes[status] || classes.draft;
    };
    const formatStatus = (status) => {
      if (!status) return "";
      return status.replace("_", " ").replace(/\b\w/g, (l) => l.toUpperCase());
    };
    const formatDate = (date) => {
      if (!date) return "";
      return new Date(date).toLocaleDateString();
    };
    const formatDateTime = (dateTime) => {
      if (!dateTime) return "";
      return new Date(dateTime).toLocaleString();
    };
    const showEmailModal = ref(false);
    const showResultDialog = ref(false);
    const emailResult = ref({
      success: false,
      email: "",
      message: ""
    });
    const emailForm = useForm({
      email: props.jobcard.customer?.email || "",
      message: ""
    });
    const downloadPDF = () => {
      window.location.href = jobcards.print(props.jobcard.id).url;
    };
    const convertToInvoice = () => {
      if (confirm("Are you sure you want to convert this jobcard to an invoice?")) {
        router.post(jobcards.convertToInvoice(props.jobcard.id).url);
      }
    };
    const sendEmail = () => {
      emailForm.post(jobcards.email(props.jobcard.id).url, {
        onSuccess: (page) => {
          showEmailModal.value = false;
          emailResult.value = {
            success: true,
            email: emailForm.email,
            message: page.props.flash?.success || "Email sent successfully"
          };
          showResultDialog.value = true;
          emailForm.reset();
        },
        onError: (errors) => {
          showEmailModal.value = false;
          emailResult.value = {
            success: false,
            email: emailForm.email,
            message: errors.email?.[0] || errors.message?.[0] || "An error occurred while sending the email"
          };
          showResultDialog.value = true;
        },
        onFinish: () => {
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Jobcard ${props.jobcard.job_number}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Jobcards", href: unref(jobcards).index().url },
          { title: props.jobcard.job_number, href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="space-y-6 p-4"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Status Management</h2><p class="text-sm text-gray-600"${_scopeId}>Update jobcard status and track progress</p></div><div class="p-6"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div class="flex items-center gap-4"${_scopeId}><span class="text-sm font-medium text-gray-700"${_scopeId}>Current Status:</span><div class="flex items-center gap-2"${_scopeId}><!--[-->`);
            ssrRenderList(statusOptions, (status) => {
              _push2(`<button${ssrIncludeBooleanAttr(!canUpdateStatus(status.value)) ? " disabled" : ""} class="${ssrRenderClass([
                "px-3 py-1 text-sm font-medium rounded-md transition-colors",
                props.jobcard.status === status.value ? "bg-blue-100 text-blue-800 border border-blue-200" : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200",
                !canUpdateStatus(status.value) ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
              ])}"${_scopeId}>${ssrInterpolate(status.label)}</button>`);
            });
            _push2(`<!--]--></div></div><div class="text-sm text-gray-500"${_scopeId}> Last updated: ${ssrInterpolate(formatDateTime(props.jobcard.updated_at))}</div></div></div></div><div class="rounded-lg bg-white border border-gray-200 p-6 shadow-sm"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>${ssrInterpolate(props.jobcard.job_number)}</h1><p class="text-sm text-gray-500 mt-1"${_scopeId}>${ssrInterpolate(props.jobcard.title)}</p></div><div class="flex items-center gap-2"${_scopeId}><span class="${ssrRenderClass([getStatusBadgeClass(props.jobcard.status), "inline-flex px-3 py-1 text-sm font-semibold rounded-full"])}"${_scopeId}>${ssrInterpolate(formatStatus(props.jobcard.status))}</span><button class="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"${_scopeId}> Download PDF </button><button class="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"${_scopeId}> Email </button>`);
            if (!props.jobcard.invoice_id) {
              _push2(`<button class="rounded-md bg-orange-600 px-4 py-2 text-sm font-medium text-white hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2"${_scopeId}> Convert to Invoice </button>`);
            } else {
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(invoices).show(props.jobcard.invoice_id).url,
                class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` View Invoice `);
                  } else {
                    return [
                      createTextVNode(" View Invoice ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            }
            if (canEditJobcard.value) {
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(jobcards).edit(props.jobcard.id).url,
                class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Edit `);
                  } else {
                    return [
                      createTextVNode(" Edit ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<span class="rounded-md bg-gray-400 px-4 py-2 text-sm font-medium text-white cursor-not-allowed" title="Cannot edit completed jobcards without permission"${_scopeId}> Edit </span>`);
            }
            _push2(`</div></div></div><div class="grid grid-cols-1 lg:grid-cols-3 gap-6"${_scopeId}><div class="lg:col-span-2 space-y-6"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Customer Information</h2><p class="text-sm text-gray-600"${_scopeId}>Customer details and contact information</p></div><div class="p-6"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Customer</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.jobcard.customer.name)}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Email</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.jobcard.customer.email)}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Phone</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.jobcard.customer.phone || "-")}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Address</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.jobcard.customer.address || "-")}</p></div></div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Job Details</h2><p class="text-sm text-gray-600"${_scopeId}>Work description and additional notes</p></div><div class="p-6"${_scopeId}><div class="space-y-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Description</label><p class="text-sm text-gray-900 whitespace-pre-wrap bg-gray-50 p-4 rounded-md"${_scopeId}>${ssrInterpolate(props.jobcard.description || "-")}</p></div>`);
            if (props.jobcard.notes) {
              _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Notes</label><p class="text-sm text-gray-900 whitespace-pre-wrap bg-gray-50 p-4 rounded-md"${_scopeId}>${ssrInterpolate(props.jobcard.notes)}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Line Items</h2><p class="text-sm text-gray-600"${_scopeId}>Products and services included in this jobcard</p></div><div class="p-6"${_scopeId}><div class="overflow-x-auto"${_scopeId}><table class="w-full"${_scopeId}><thead class="bg-gray-50"${_scopeId}><tr${_scopeId}><th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Description </th><th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Qty </th><th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Unit Price </th><th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Total </th></tr></thead><tbody class="bg-white divide-y divide-gray-200"${_scopeId}><!--[-->`);
            ssrRenderList(props.jobcard.line_items, (item) => {
              _push2(`<tr${_scopeId}><td class="px-4 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(item.description)}</div></td><td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900"${_scopeId}>${ssrInterpolate(item.quantity)}</td><td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900"${_scopeId}>${ssrInterpolate(item.formatted_unit_price)}</td><td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900"${_scopeId}>${ssrInterpolate(item.formatted_total)}</td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div></div>`);
            if (props.jobcard.terms_conditions) {
              _push2(`<div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Terms &amp; Conditions</h2><p class="text-sm text-gray-600"${_scopeId}>Legal terms and conditions for this jobcard</p></div><div class="p-6"${_scopeId}><p class="text-sm text-gray-900 whitespace-pre-wrap bg-gray-50 p-4 rounded-md"${_scopeId}>${ssrInterpolate(props.jobcard.terms_conditions)}</p></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="space-y-6"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Job Information</h2><p class="text-sm text-gray-600"${_scopeId}>Jobcard details and timeline</p></div><div class="p-6"${_scopeId}><div class="space-y-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Job Number</label><p class="text-sm text-gray-900 font-mono"${_scopeId}>${ssrInterpolate(props.jobcard.job_number)}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Status</label><span class="${ssrRenderClass([getStatusBadgeClass(props.jobcard.status), "inline-flex px-2 py-1 text-xs font-semibold rounded-full"])}"${_scopeId}>${ssrInterpolate(formatStatus(props.jobcard.status))}</span></div>`);
            if (props.jobcard.start_date) {
              _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Start Date</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatDate(props.jobcard.start_date))}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (props.jobcard.due_date) {
              _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Due Date</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatDate(props.jobcard.due_date))}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (props.jobcard.completed_date) {
              _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Completed Date</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatDate(props.jobcard.completed_date))}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Created</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatDateTime(props.jobcard.created_at))}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Last Updated</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatDateTime(props.jobcard.updated_at))}</p></div></div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Pricing Summary</h2><p class="text-sm text-gray-600"${_scopeId}>Cost breakdown and totals</p></div><div class="p-6"${_scopeId}><div class="space-y-3"${_scopeId}><div class="flex justify-between"${_scopeId}><span class="text-sm text-gray-600"${_scopeId}>Subtotal:</span><span class="text-sm font-medium"${_scopeId}>R${ssrInterpolate((Number(props.jobcard.subtotal) || 0).toFixed(2))}</span></div>`);
            if ((Number(props.jobcard.discount_amount) || 0) > 0) {
              _push2(`<div class="flex justify-between"${_scopeId}><span class="text-sm text-gray-600"${_scopeId}>Discount:</span><span class="text-sm font-medium text-red-600"${_scopeId}>-R${ssrInterpolate((Number(props.jobcard.discount_amount) || 0).toFixed(2))}</span></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex justify-between"${_scopeId}><span class="text-sm text-gray-600"${_scopeId}>Tax (${ssrInterpolate(props.jobcard.tax_rate || 0)}%):</span><span class="text-sm font-medium"${_scopeId}>R${ssrInterpolate((Number(props.jobcard.tax_amount) || 0).toFixed(2))}</span></div><div class="flex justify-between border-t pt-3"${_scopeId}><span class="text-base font-semibold"${_scopeId}>Total:</span><span class="text-base font-semibold"${_scopeId}>${ssrInterpolate(props.jobcard.formatted_total)}</span></div></div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Actions</h2><p class="text-sm text-gray-600"${_scopeId}>Manage this jobcard</p></div><div class="p-6"${_scopeId}><div class="space-y-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(jobcards).edit(props.jobcard.id).url,
              class: "block w-full rounded-md bg-blue-600 px-4 py-2 text-center text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Edit Jobcard `);
                } else {
                  return [
                    createTextVNode(" Edit Jobcard ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            if (canDeleteJobcard.value) {
              _push2(`<button class="block w-full rounded-md border border-red-300 px-4 py-2 text-center text-sm font-medium text-red-700 hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"${_scopeId}> Delete Jobcard </button>`);
            } else {
              _push2(`<span class="block w-full rounded-md border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-500 cursor-not-allowed" title="Cannot delete completed jobcards without permission"${_scopeId}> Delete Jobcard </span>`);
            }
            _push2(`</div></div></div></div></div></div>`);
            if (showEmailModal.value) {
              _push2(`<div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50"${_scopeId}><div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white"${_scopeId}><div class="mt-3"${_scopeId}><h3 class="text-lg font-medium text-gray-900 mb-4"${_scopeId}>Email Jobcard</h3><form${_scopeId}><div class="mb-4"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Email Address *</label><input${ssrRenderAttr("value", unref(emailForm).email)} type="email" required class="${ssrRenderClass([{ "border-red-500": unref(emailForm).errors.email }, "w-full rounded border px-3 py-2"])}" placeholder="recipient@example.com"${_scopeId}>`);
              if (unref(emailForm).errors.email) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(emailForm).errors.email)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Message</label><textarea rows="4" class="w-full rounded border px-3 py-2" placeholder="Optional message to include with the jobcard PDF..."${_scopeId}>${ssrInterpolate(unref(emailForm).message)}</textarea><p class="text-xs text-gray-500 mt-1"${_scopeId}>The jobcard will be sent as a PDF attachment.</p></div><div class="flex items-center justify-end gap-3"${_scopeId}><button type="button" class="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"${_scopeId}> Cancel </button><button type="submit"${ssrIncludeBooleanAttr(unref(emailForm).processing) ? " disabled" : ""} class="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(emailForm).processing ? "Sending..." : "Send Email")}</button></div></form></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (showResultDialog.value) {
              _push2(`<div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50"${_scopeId}><div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white"${_scopeId}><div class="mt-3"${_scopeId}><div class="${ssrRenderClass([emailResult.value.success ? "bg-green-100" : "bg-red-100", "flex items-center justify-center w-12 h-12 mx-auto mb-4 rounded-full"])}"${_scopeId}>`);
              if (emailResult.value.success) {
                _push2(`<svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"${_scopeId}></path></svg>`);
              } else {
                _push2(`<svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"${_scopeId}></path></svg>`);
              }
              _push2(`</div><h3 class="text-lg font-medium text-gray-900 mb-2 text-center"${_scopeId}>${ssrInterpolate(emailResult.value.success ? "Email Sent Successfully!" : "Email Failed to Send")}</h3><div class="text-center"${_scopeId}>`);
              if (emailResult.value.success) {
                _push2(`<p class="text-sm text-gray-600 mb-4"${_scopeId}> The jobcard has been sent to <strong${_scopeId}>${ssrInterpolate(emailResult.value.email)}</strong></p>`);
              } else {
                _push2(`<p class="text-sm text-red-600 mb-4"${_scopeId}>${ssrInterpolate(emailResult.value.message)}</p>`);
              }
              _push2(`</div><div class="flex justify-center"${_scopeId}><button class="${ssrRenderClass([emailResult.value.success ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500", "rounded-md px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2"])}"${_scopeId}>${ssrInterpolate(emailResult.value.success ? "Great!" : "Try Again")}</button></div></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              createVNode("div", { class: "space-y-6 p-4" }, [
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                  createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Status Management"),
                    createVNode("p", { class: "text-sm text-gray-600" }, "Update jobcard status and track progress")
                  ]),
                  createVNode("div", { class: "p-6" }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", { class: "flex items-center gap-4" }, [
                        createVNode("span", { class: "text-sm font-medium text-gray-700" }, "Current Status:"),
                        createVNode("div", { class: "flex items-center gap-2" }, [
                          (openBlock(), createBlock(Fragment, null, renderList(statusOptions, (status) => {
                            return createVNode("button", {
                              key: status.value,
                              onClick: ($event) => updateStatus(status.value),
                              disabled: !canUpdateStatus(status.value),
                              class: [
                                "px-3 py-1 text-sm font-medium rounded-md transition-colors",
                                props.jobcard.status === status.value ? "bg-blue-100 text-blue-800 border border-blue-200" : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200",
                                !canUpdateStatus(status.value) ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
                              ]
                            }, toDisplayString(status.label), 11, ["onClick", "disabled"]);
                          }), 64))
                        ])
                      ]),
                      createVNode("div", { class: "text-sm text-gray-500" }, " Last updated: " + toDisplayString(formatDateTime(props.jobcard.updated_at)), 1)
                    ])
                  ])
                ]),
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 p-6 shadow-sm" }, [
                  createVNode("div", { class: "flex items-center justify-between" }, [
                    createVNode("div", null, [
                      createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, toDisplayString(props.jobcard.job_number), 1),
                      createVNode("p", { class: "text-sm text-gray-500 mt-1" }, toDisplayString(props.jobcard.title), 1)
                    ]),
                    createVNode("div", { class: "flex items-center gap-2" }, [
                      createVNode("span", {
                        class: [getStatusBadgeClass(props.jobcard.status), "inline-flex px-3 py-1 text-sm font-semibold rounded-full"]
                      }, toDisplayString(formatStatus(props.jobcard.status)), 3),
                      createVNode("button", {
                        onClick: downloadPDF,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, " Download PDF "),
                      createVNode("button", {
                        onClick: ($event) => showEmailModal.value = true,
                        class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
                      }, " Email ", 8, ["onClick"]),
                      !props.jobcard.invoice_id ? (openBlock(), createBlock("button", {
                        key: 0,
                        onClick: convertToInvoice,
                        class: "rounded-md bg-orange-600 px-4 py-2 text-sm font-medium text-white hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2"
                      }, " Convert to Invoice ")) : (openBlock(), createBlock(unref(Link), {
                        key: 1,
                        href: unref(invoices).show(props.jobcard.invoice_id).url,
                        class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" View Invoice ")
                        ]),
                        _: 1
                      }, 8, ["href"])),
                      canEditJobcard.value ? (openBlock(), createBlock(unref(Link), {
                        key: 2,
                        href: unref(jobcards).edit(props.jobcard.id).url,
                        class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Edit ")
                        ]),
                        _: 1
                      }, 8, ["href"])) : (openBlock(), createBlock("span", {
                        key: 3,
                        class: "rounded-md bg-gray-400 px-4 py-2 text-sm font-medium text-white cursor-not-allowed",
                        title: "Cannot edit completed jobcards without permission"
                      }, " Edit "))
                    ])
                  ])
                ]),
                createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-3 gap-6" }, [
                  createVNode("div", { class: "lg:col-span-2 space-y-6" }, [
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Customer Information"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Customer details and contact information")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Customer"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(props.jobcard.customer.name), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Email"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(props.jobcard.customer.email), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Phone"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(props.jobcard.customer.phone || "-"), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Address"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(props.jobcard.customer.address || "-"), 1)
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Job Details"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Work description and additional notes")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "space-y-4" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Description"),
                            createVNode("p", { class: "text-sm text-gray-900 whitespace-pre-wrap bg-gray-50 p-4 rounded-md" }, toDisplayString(props.jobcard.description || "-"), 1)
                          ]),
                          props.jobcard.notes ? (openBlock(), createBlock("div", { key: 0 }, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Notes"),
                            createVNode("p", { class: "text-sm text-gray-900 whitespace-pre-wrap bg-gray-50 p-4 rounded-md" }, toDisplayString(props.jobcard.notes), 1)
                          ])) : createCommentVNode("", true)
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Line Items"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Products and services included in this jobcard")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "overflow-x-auto" }, [
                          createVNode("table", { class: "w-full" }, [
                            createVNode("thead", { class: "bg-gray-50" }, [
                              createVNode("tr", null, [
                                createVNode("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Description "),
                                createVNode("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Qty "),
                                createVNode("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Unit Price "),
                                createVNode("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Total ")
                              ])
                            ]),
                            createVNode("tbody", { class: "bg-white divide-y divide-gray-200" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(props.jobcard.line_items, (item) => {
                                return openBlock(), createBlock("tr", {
                                  key: item.id
                                }, [
                                  createVNode("td", { class: "px-4 py-4 whitespace-nowrap" }, [
                                    createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(item.description), 1)
                                  ]),
                                  createVNode("td", { class: "px-4 py-4 whitespace-nowrap text-sm text-gray-900" }, toDisplayString(item.quantity), 1),
                                  createVNode("td", { class: "px-4 py-4 whitespace-nowrap text-sm text-gray-900" }, toDisplayString(item.formatted_unit_price), 1),
                                  createVNode("td", { class: "px-4 py-4 whitespace-nowrap text-sm text-gray-900" }, toDisplayString(item.formatted_total), 1)
                                ]);
                              }), 128))
                            ])
                          ])
                        ])
                      ])
                    ]),
                    props.jobcard.terms_conditions ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "rounded-lg bg-white border border-gray-200 shadow-sm"
                    }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Terms & Conditions"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Legal terms and conditions for this jobcard")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("p", { class: "text-sm text-gray-900 whitespace-pre-wrap bg-gray-50 p-4 rounded-md" }, toDisplayString(props.jobcard.terms_conditions), 1)
                      ])
                    ])) : createCommentVNode("", true)
                  ]),
                  createVNode("div", { class: "space-y-6" }, [
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Job Information"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Jobcard details and timeline")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "space-y-4" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Job Number"),
                            createVNode("p", { class: "text-sm text-gray-900 font-mono" }, toDisplayString(props.jobcard.job_number), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Status"),
                            createVNode("span", {
                              class: [getStatusBadgeClass(props.jobcard.status), "inline-flex px-2 py-1 text-xs font-semibold rounded-full"]
                            }, toDisplayString(formatStatus(props.jobcard.status)), 3)
                          ]),
                          props.jobcard.start_date ? (openBlock(), createBlock("div", { key: 0 }, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Start Date"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(formatDate(props.jobcard.start_date)), 1)
                          ])) : createCommentVNode("", true),
                          props.jobcard.due_date ? (openBlock(), createBlock("div", { key: 1 }, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Due Date"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(formatDate(props.jobcard.due_date)), 1)
                          ])) : createCommentVNode("", true),
                          props.jobcard.completed_date ? (openBlock(), createBlock("div", { key: 2 }, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Completed Date"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(formatDate(props.jobcard.completed_date)), 1)
                          ])) : createCommentVNode("", true),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Created"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(formatDateTime(props.jobcard.created_at)), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Last Updated"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(formatDateTime(props.jobcard.updated_at)), 1)
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Pricing Summary"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Cost breakdown and totals")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "space-y-3" }, [
                          createVNode("div", { class: "flex justify-between" }, [
                            createVNode("span", { class: "text-sm text-gray-600" }, "Subtotal:"),
                            createVNode("span", { class: "text-sm font-medium" }, "R" + toDisplayString((Number(props.jobcard.subtotal) || 0).toFixed(2)), 1)
                          ]),
                          (Number(props.jobcard.discount_amount) || 0) > 0 ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "flex justify-between"
                          }, [
                            createVNode("span", { class: "text-sm text-gray-600" }, "Discount:"),
                            createVNode("span", { class: "text-sm font-medium text-red-600" }, "-R" + toDisplayString((Number(props.jobcard.discount_amount) || 0).toFixed(2)), 1)
                          ])) : createCommentVNode("", true),
                          createVNode("div", { class: "flex justify-between" }, [
                            createVNode("span", { class: "text-sm text-gray-600" }, "Tax (" + toDisplayString(props.jobcard.tax_rate || 0) + "%):", 1),
                            createVNode("span", { class: "text-sm font-medium" }, "R" + toDisplayString((Number(props.jobcard.tax_amount) || 0).toFixed(2)), 1)
                          ]),
                          createVNode("div", { class: "flex justify-between border-t pt-3" }, [
                            createVNode("span", { class: "text-base font-semibold" }, "Total:"),
                            createVNode("span", { class: "text-base font-semibold" }, toDisplayString(props.jobcard.formatted_total), 1)
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Actions"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Manage this jobcard")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "space-y-3" }, [
                          createVNode(unref(Link), {
                            href: unref(jobcards).edit(props.jobcard.id).url,
                            class: "block w-full rounded-md bg-blue-600 px-4 py-2 text-center text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Edit Jobcard ")
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          canDeleteJobcard.value ? (openBlock(), createBlock("button", {
                            key: 0,
                            onClick: deleteJobcard,
                            class: "block w-full rounded-md border border-red-300 px-4 py-2 text-center text-sm font-medium text-red-700 hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                          }, " Delete Jobcard ")) : (openBlock(), createBlock("span", {
                            key: 1,
                            class: "block w-full rounded-md border border-gray-300 px-4 py-2 text-center text-sm font-medium text-gray-500 cursor-not-allowed",
                            title: "Cannot delete completed jobcards without permission"
                          }, " Delete Jobcard "))
                        ])
                      ])
                    ])
                  ])
                ])
              ]),
              showEmailModal.value ? (openBlock(), createBlock("div", {
                key: 0,
                class: "fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50"
              }, [
                createVNode("div", { class: "relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white" }, [
                  createVNode("div", { class: "mt-3" }, [
                    createVNode("h3", { class: "text-lg font-medium text-gray-900 mb-4" }, "Email Jobcard"),
                    createVNode("form", {
                      onSubmit: withModifiers(sendEmail, ["prevent"])
                    }, [
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Email Address *"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => unref(emailForm).email = $event,
                          type: "email",
                          required: "",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(emailForm).errors.email }],
                          placeholder: "recipient@example.com"
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(emailForm).email]
                        ]),
                        unref(emailForm).errors.email ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(emailForm).errors.email), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Message"),
                        withDirectives(createVNode("textarea", {
                          "onUpdate:modelValue": ($event) => unref(emailForm).message = $event,
                          rows: "4",
                          class: "w-full rounded border px-3 py-2",
                          placeholder: "Optional message to include with the jobcard PDF..."
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(emailForm).message]
                        ]),
                        createVNode("p", { class: "text-xs text-gray-500 mt-1" }, "The jobcard will be sent as a PDF attachment.")
                      ]),
                      createVNode("div", { class: "flex items-center justify-end gap-3" }, [
                        createVNode("button", {
                          type: "button",
                          onClick: ($event) => showEmailModal.value = false,
                          class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                        }, " Cancel ", 8, ["onClick"]),
                        createVNode("button", {
                          type: "submit",
                          disabled: unref(emailForm).processing,
                          class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50"
                        }, toDisplayString(unref(emailForm).processing ? "Sending..." : "Send Email"), 9, ["disabled"])
                      ])
                    ], 32)
                  ])
                ])
              ])) : createCommentVNode("", true),
              showResultDialog.value ? (openBlock(), createBlock("div", {
                key: 1,
                class: "fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50"
              }, [
                createVNode("div", { class: "relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white" }, [
                  createVNode("div", { class: "mt-3" }, [
                    createVNode("div", {
                      class: ["flex items-center justify-center w-12 h-12 mx-auto mb-4 rounded-full", emailResult.value.success ? "bg-green-100" : "bg-red-100"]
                    }, [
                      emailResult.value.success ? (openBlock(), createBlock("svg", {
                        key: 0,
                        class: "w-6 h-6 text-green-600",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        createVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M5 13l4 4L19 7"
                        })
                      ])) : (openBlock(), createBlock("svg", {
                        key: 1,
                        class: "w-6 h-6 text-red-600",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24"
                      }, [
                        createVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "M6 18L18 6M6 6l12 12"
                        })
                      ]))
                    ], 2),
                    createVNode("h3", { class: "text-lg font-medium text-gray-900 mb-2 text-center" }, toDisplayString(emailResult.value.success ? "Email Sent Successfully!" : "Email Failed to Send"), 1),
                    createVNode("div", { class: "text-center" }, [
                      emailResult.value.success ? (openBlock(), createBlock("p", {
                        key: 0,
                        class: "text-sm text-gray-600 mb-4"
                      }, [
                        createTextVNode(" The jobcard has been sent to "),
                        createVNode("strong", null, toDisplayString(emailResult.value.email), 1)
                      ])) : (openBlock(), createBlock("p", {
                        key: 1,
                        class: "text-sm text-red-600 mb-4"
                      }, toDisplayString(emailResult.value.message), 1))
                    ]),
                    createVNode("div", { class: "flex justify-center" }, [
                      createVNode("button", {
                        onClick: ($event) => showResultDialog.value = false,
                        class: ["rounded-md px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2", emailResult.value.success ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500"]
                      }, toDisplayString(emailResult.value.success ? "Great!" : "Try Again"), 11, ["onClick"])
                    ])
                  ])
                ])
              ])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/jobcards/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
