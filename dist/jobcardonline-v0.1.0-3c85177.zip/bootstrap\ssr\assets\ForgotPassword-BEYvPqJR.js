import { defineComponent, mergeProps, withCtx, unref, createTextVNode, createBlock, createCommentVNode, openBlock, createVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { q as queryParams } from "./index--D7ld9AJ.js";
import { _ as _sfc_main$4 } from "./InputError-Dsed5rBJ.js";
import { _ as _sfc_main$6 } from "./TextLink-DF2ChrHZ.js";
import { _ as _sfc_main$5, l as login } from "./Footer-Ce4AN4A5.js";
import { _ as _sfc_main$3 } from "./Input-CBU-ZeCu.js";
import { _ as _sfc_main$2 } from "./Label-UEV1cA3u.js";
import { _ as _sfc_main$1 } from "./AuthLayout-CT6aWTFG.js";
import { Head, Form } from "@inertiajs/vue3";
import { LoaderCircle } from "lucide-vue-next";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "@vueuse/core";
const create = (options) => ({
  url: create.url(options),
  method: "get"
});
create.definition = {
  methods: ["get", "head"],
  url: "/forgot-password"
};
create.url = (options) => {
  return create.definition.url + queryParams(options);
};
create.get = (options) => ({
  url: create.url(options),
  method: "get"
});
create.head = (options) => ({
  url: create.url(options),
  method: "head"
});
const createForm = (options) => ({
  action: create.url(options),
  method: "get"
});
createForm.get = (options) => ({
  action: create.url(options),
  method: "get"
});
createForm.head = (options) => ({
  action: create.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create.form = createForm;
const store = (options) => ({
  url: store.url(options),
  method: "post"
});
store.definition = {
  methods: ["post"],
  url: "/forgot-password"
};
store.url = (options) => {
  return store.definition.url + queryParams(options);
};
store.post = (options) => ({
  url: store.url(options),
  method: "post"
});
const storeForm = (options) => ({
  action: store.url(options),
  method: "post"
});
storeForm.post = (options) => ({
  action: store.url(options),
  method: "post"
});
store.form = storeForm;
const PasswordResetLinkController = { create, store };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ForgotPassword",
  __ssrInlineRender: true,
  props: {
    status: {}
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, mergeProps({
        title: "Forgot password",
        description: "Enter your email to receive a password reset link"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Forgot password" }, null, _parent2, _scopeId));
            if (_ctx.status) {
              _push2(`<div class="mb-4 text-center text-sm font-medium text-green-600"${_scopeId}>${ssrInterpolate(_ctx.status)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="space-y-6"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Form), unref(PasswordResetLinkController).store.form(), {
              default: withCtx(({ errors, processing }, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="grid gap-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(_sfc_main$2), { for: "email" }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Email address`);
                      } else {
                        return [
                          createTextVNode("Email address")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(_sfc_main$3), {
                    id: "email",
                    type: "email",
                    name: "email",
                    autocomplete: "off",
                    autofocus: "",
                    placeholder: "email@example.com"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    message: errors.email
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="my-6 flex items-center justify-start"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(_sfc_main$5), {
                    class: "w-full",
                    disabled: processing,
                    "data-test": "email-password-reset-link-button"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (processing) {
                          _push4(ssrRenderComponent(unref(LoaderCircle), { class: "h-4 w-4 animate-spin" }, null, _parent4, _scopeId3));
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(` Email password reset link `);
                      } else {
                        return [
                          processing ? (openBlock(), createBlock(unref(LoaderCircle), {
                            key: 0,
                            class: "h-4 w-4 animate-spin"
                          })) : createCommentVNode("", true),
                          createTextVNode(" Email password reset link ")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "grid gap-2" }, [
                      createVNode(unref(_sfc_main$2), { for: "email" }, {
                        default: withCtx(() => [
                          createTextVNode("Email address")
                        ]),
                        _: 1
                      }),
                      createVNode(unref(_sfc_main$3), {
                        id: "email",
                        type: "email",
                        name: "email",
                        autocomplete: "off",
                        autofocus: "",
                        placeholder: "email@example.com"
                      }),
                      createVNode(_sfc_main$4, {
                        message: errors.email
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", { class: "my-6 flex items-center justify-start" }, [
                      createVNode(unref(_sfc_main$5), {
                        class: "w-full",
                        disabled: processing,
                        "data-test": "email-password-reset-link-button"
                      }, {
                        default: withCtx(() => [
                          processing ? (openBlock(), createBlock(unref(LoaderCircle), {
                            key: 0,
                            class: "h-4 w-4 animate-spin"
                          })) : createCommentVNode("", true),
                          createTextVNode(" Email password reset link ")
                        ]),
                        _: 2
                      }, 1032, ["disabled"])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="space-x-1 text-center text-sm text-muted-foreground"${_scopeId}><span${_scopeId}>Or, return to</span>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              href: unref(login)()
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`log in`);
                } else {
                  return [
                    createTextVNode("log in")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode(unref(Head), { title: "Forgot password" }),
              _ctx.status ? (openBlock(), createBlock("div", {
                key: 0,
                class: "mb-4 text-center text-sm font-medium text-green-600"
              }, toDisplayString(_ctx.status), 1)) : createCommentVNode("", true),
              createVNode("div", { class: "space-y-6" }, [
                createVNode(unref(Form), unref(PasswordResetLinkController).store.form(), {
                  default: withCtx(({ errors, processing }) => [
                    createVNode("div", { class: "grid gap-2" }, [
                      createVNode(unref(_sfc_main$2), { for: "email" }, {
                        default: withCtx(() => [
                          createTextVNode("Email address")
                        ]),
                        _: 1
                      }),
                      createVNode(unref(_sfc_main$3), {
                        id: "email",
                        type: "email",
                        name: "email",
                        autocomplete: "off",
                        autofocus: "",
                        placeholder: "email@example.com"
                      }),
                      createVNode(_sfc_main$4, {
                        message: errors.email
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", { class: "my-6 flex items-center justify-start" }, [
                      createVNode(unref(_sfc_main$5), {
                        class: "w-full",
                        disabled: processing,
                        "data-test": "email-password-reset-link-button"
                      }, {
                        default: withCtx(() => [
                          processing ? (openBlock(), createBlock(unref(LoaderCircle), {
                            key: 0,
                            class: "h-4 w-4 animate-spin"
                          })) : createCommentVNode("", true),
                          createTextVNode(" Email password reset link ")
                        ]),
                        _: 2
                      }, 1032, ["disabled"])
                    ])
                  ]),
                  _: 1
                }, 16),
                createVNode("div", { class: "space-x-1 text-center text-sm text-muted-foreground" }, [
                  createVNode("span", null, "Or, return to"),
                  createVNode(_sfc_main$6, {
                    href: unref(login)()
                  }, {
                    default: withCtx(() => [
                      createTextVNode("log in")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/auth/ForgotPassword.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
