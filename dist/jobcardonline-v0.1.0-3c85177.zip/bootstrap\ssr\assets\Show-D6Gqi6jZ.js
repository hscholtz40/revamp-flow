import { defineComponent, unref, withCtx, createTextVNode, createVNode, createBlock, createCommentVNode, toDisplayString, openBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import { Head, Link } from "@inertiajs/vue3";
import { u as users } from "./index-B7IvN102.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    user: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `User • ${props.user.name}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [{ title: "Users", href: unref(users).index().url }, { title: props.user.name, href: "#" }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="space-y-6 p-4"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><h1 class="text-xl font-semibold"${_scopeId}>${ssrInterpolate(props.user.name)}</h1><div class="flex items-center gap-2"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(users).edit(props.user.id).url,
              class: "rounded border px-3 py-1"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Edit`);
                } else {
                  return [
                    createTextVNode("Edit")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(users).index().url,
              class: "rounded border px-3 py-1"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Back`);
                } else {
                  return [
                    createTextVNode("Back")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="rounded border p-4"${_scopeId}><div class="space-y-2"${_scopeId}><div${_scopeId}><span class="font-medium"${_scopeId}>Name:</span> ${ssrInterpolate(props.user.name)}</div><div${_scopeId}><span class="font-medium"${_scopeId}>Email:</span> ${ssrInterpolate(props.user.email)}</div></div></div>`);
            if (props.user.groups && props.user.groups.length > 0) {
              _push2(`<div class="rounded border p-4"${_scopeId}><div class="mb-2 font-medium"${_scopeId}>Groups</div><div class="flex flex-wrap gap-2"${_scopeId}><!--[-->`);
              ssrRenderList(props.user.groups, (group) => {
                _push2(`<span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"${_scopeId}>${ssrInterpolate(group.name)}</span>`);
              });
              _push2(`<!--]--></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (props.user.companies && props.user.companies.length > 0) {
              _push2(`<div class="rounded border p-4"${_scopeId}><div class="mb-2 font-medium"${_scopeId}>Company Access</div><div class="flex flex-wrap gap-2"${_scopeId}><!--[-->`);
              ssrRenderList(props.user.companies, (company) => {
                _push2(`<span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800"${_scopeId}>${ssrInterpolate(company.name)}</span>`);
              });
              _push2(`<!--]--></div></div>`);
            } else {
              _push2(`<div class="rounded border p-4"${_scopeId}><div class="mb-2 font-medium"${_scopeId}>Company Access</div><p class="text-sm text-gray-600"${_scopeId}>This user has access to all companies.</p></div>`);
            }
            _push2(`<div class="text-sm text-gray-500"${_scopeId}><div${_scopeId}>Created: ${ssrInterpolate(props.user.created_at)}</div><div${_scopeId}>Updated: ${ssrInterpolate(props.user.updated_at)}</div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "space-y-6 p-4" }, [
                createVNode("div", { class: "flex items-center justify-between" }, [
                  createVNode("h1", { class: "text-xl font-semibold" }, toDisplayString(props.user.name), 1),
                  createVNode("div", { class: "flex items-center gap-2" }, [
                    createVNode(unref(Link), {
                      href: unref(users).edit(props.user.id).url,
                      class: "rounded border px-3 py-1"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Edit")
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode(unref(Link), {
                      href: unref(users).index().url,
                      class: "rounded border px-3 py-1"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Back")
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ])
                ]),
                createVNode("div", { class: "rounded border p-4" }, [
                  createVNode("div", { class: "space-y-2" }, [
                    createVNode("div", null, [
                      createVNode("span", { class: "font-medium" }, "Name:"),
                      createTextVNode(" " + toDisplayString(props.user.name), 1)
                    ]),
                    createVNode("div", null, [
                      createVNode("span", { class: "font-medium" }, "Email:"),
                      createTextVNode(" " + toDisplayString(props.user.email), 1)
                    ])
                  ])
                ]),
                props.user.groups && props.user.groups.length > 0 ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "rounded border p-4"
                }, [
                  createVNode("div", { class: "mb-2 font-medium" }, "Groups"),
                  createVNode("div", { class: "flex flex-wrap gap-2" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(props.user.groups, (group) => {
                      return openBlock(), createBlock("span", {
                        key: group.id,
                        class: "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                      }, toDisplayString(group.name), 1);
                    }), 128))
                  ])
                ])) : createCommentVNode("", true),
                props.user.companies && props.user.companies.length > 0 ? (openBlock(), createBlock("div", {
                  key: 1,
                  class: "rounded border p-4"
                }, [
                  createVNode("div", { class: "mb-2 font-medium" }, "Company Access"),
                  createVNode("div", { class: "flex flex-wrap gap-2" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(props.user.companies, (company) => {
                      return openBlock(), createBlock("span", {
                        key: company.id,
                        class: "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800"
                      }, toDisplayString(company.name), 1);
                    }), 128))
                  ])
                ])) : (openBlock(), createBlock("div", {
                  key: 2,
                  class: "rounded border p-4"
                }, [
                  createVNode("div", { class: "mb-2 font-medium" }, "Company Access"),
                  createVNode("p", { class: "text-sm text-gray-600" }, "This user has access to all companies.")
                ])),
                createVNode("div", { class: "text-sm text-gray-500" }, [
                  createVNode("div", null, "Created: " + toDisplayString(props.user.created_at), 1),
                  createVNode("div", null, "Updated: " + toDisplayString(props.user.updated_at), 1)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/users/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
