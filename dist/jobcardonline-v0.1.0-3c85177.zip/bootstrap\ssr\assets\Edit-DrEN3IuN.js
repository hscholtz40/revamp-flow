import { defineComponent, ref, computed, unref, withCtx, createVNode, createTextVNode, toDisplayString, withModifiers, createBlock, createCommentVNode, withDirectives, vModelText, openBlock, vModelRadio, Fragment, renderList, vModelSelect, vModelCheckbox, withKeys, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderClass, ssrIncludeBooleanAttr, ssrLooseEqual, ssrLooseContain, ssrRenderList } from "vue/server-renderer";
import { _ as _sfc_main$1, p as products } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { ArrowLeft, Package, Wrench } from "lucide-vue-next";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    product: {},
    categories: {},
    currentCompany: {}
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      name: props.product.name,
      description: props.product.description,
      type: props.product.type,
      sku: props.product.sku,
      price: props.product.price,
      cost: props.product.cost,
      unit: props.product.unit,
      stock_quantity: props.product.stock_quantity,
      min_stock_level: props.product.min_stock_level,
      track_stock: props.product.track_stock,
      is_active: props.product.is_active,
      category: props.product.category,
      tags: [...props.product.tags],
      image_path: props.product.image_path,
      notes: props.product.notes
    });
    const newTag = ref("");
    const isService = computed(() => form.type === "service");
    const commonUnits = [
      "piece",
      "kg",
      "lb",
      "g",
      "oz",
      "liter",
      "gallon",
      "meter",
      "foot",
      "hour",
      "day",
      "month",
      "year"
    ];
    function submit() {
      form.put(products.update(props.product.id).url);
    }
    function addTag() {
      if (newTag.value.trim() && !form.tags.includes(newTag.value.trim())) {
        form.tags.push(newTag.value.trim());
        newTag.value = "";
      }
    }
    function removeTag(tag) {
      form.tags = form.tags.filter((t) => t !== tag);
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Edit ${props.product.name}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Products & Services", href: unref(products).index().url },
          { title: props.product.name, href: unref(products).show(props.product.id).url },
          { title: "Edit", href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-blue-50 border-b border-blue-200 px-4 py-3"${_scopeId}><div class="flex items-center gap-2 text-sm text-blue-700"${_scopeId}><span class="font-medium"${_scopeId}>Editing product for:</span><span class="font-semibold"${_scopeId}>${ssrInterpolate(props.currentCompany.name)}</span></div></div><div class="p-4"${_scopeId}><div class="mb-6 flex items-center gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(products).show(props.product.id).url,
              class: "flex items-center gap-2 text-gray-600 hover:text-gray-900"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(ArrowLeft), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                  _push3(` Back to Product `);
                } else {
                  return [
                    createVNode(unref(ArrowLeft), { class: "h-4 w-4" }),
                    createTextVNode(" Back to Product ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="mx-auto max-w-4xl"${_scopeId}><div class="mb-6"${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>Edit Product/Service</h1><p class="text-gray-600"${_scopeId}>Update the details for ${ssrInterpolate(props.product.name)}</p></div><form class="space-y-8"${_scopeId}><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Basic Information</h2><div class="grid gap-6 md:grid-cols-2"${_scopeId}><div class="md:col-span-2"${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Name * </label><input${ssrRenderAttr("value", unref(form).name)} type="text" required class="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}>`);
            if (unref(form).errors.name) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.name)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Type * </label><div class="mt-2 grid grid-cols-2 gap-3"${_scopeId}><label class="relative cursor-pointer"${_scopeId}><input${ssrIncludeBooleanAttr(ssrLooseEqual(unref(form).type, "product")) ? " checked" : ""} type="radio" value="product" class="sr-only"${_scopeId}><div class="${ssrRenderClass([
              "flex items-center gap-3 rounded-lg border p-4",
              unref(form).type === "product" ? "border-blue-500 bg-blue-50" : "border-gray-300 hover:border-gray-400"
            ])}"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Package), { class: "h-5 w-5 text-blue-600" }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="font-medium text-gray-900"${_scopeId}>Product</div><div class="text-sm text-gray-500"${_scopeId}>Physical items with inventory</div></div></div></label><label class="relative cursor-pointer"${_scopeId}><input${ssrIncludeBooleanAttr(ssrLooseEqual(unref(form).type, "service")) ? " checked" : ""} type="radio" value="service" class="sr-only"${_scopeId}><div class="${ssrRenderClass([
              "flex items-center gap-3 rounded-lg border p-4",
              unref(form).type === "service" ? "border-green-500 bg-green-50" : "border-gray-300 hover:border-gray-400"
            ])}"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Wrench), { class: "h-5 w-5 text-green-600" }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="font-medium text-gray-900"${_scopeId}>Service</div><div class="text-sm text-gray-500"${_scopeId}>Intangible offerings</div></div></div></label></div>`);
            if (unref(form).errors.type) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.type)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Category </label><select class="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(unref(form).category) ? ssrLooseContain(unref(form).category, "") : ssrLooseEqual(unref(form).category, "")) ? " selected" : ""}${_scopeId}>Select a category</option><!--[-->`);
            ssrRenderList(props.categories, (category) => {
              _push2(`<option${ssrRenderAttr("value", category.name)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).category) ? ssrLooseContain(unref(form).category, category.name) : ssrLooseEqual(unref(form).category, category.name)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(category.name)}</option>`);
            });
            _push2(`<!--]--></select>`);
            if (unref(form).errors.category) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.category)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> SKU (Stock Keeping Unit) </label><input${ssrRenderAttr("value", unref(form).sku)} type="text" class="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}>`);
            if (unref(form).errors.sku) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.sku)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Unit * </label><div class="mt-1 flex gap-2"${_scopeId}><select class="flex-1 rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}><!--[-->`);
            ssrRenderList(commonUnits, (unit) => {
              _push2(`<option${ssrRenderAttr("value", unit)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).unit) ? ssrLooseContain(unref(form).unit, unit) : ssrLooseEqual(unref(form).unit, unit)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(unit)}</option>`);
            });
            _push2(`<!--]--></select><input${ssrRenderAttr("value", unref(form).unit)} type="text" placeholder="Custom unit" class="flex-1 rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}></div>`);
            if (unref(form).errors.unit) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.unit)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="md:col-span-2"${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Description </label><textarea rows="3" class="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea>`);
            if (unref(form).errors.description) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.description)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Pricing</h2><div class="grid gap-6 md:grid-cols-2"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Price * </label><div class="mt-1 relative"${_scopeId}><div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"${_scopeId}><span class="text-gray-500 sm:text-sm"${_scopeId}>R</span></div><input${ssrRenderAttr("value", unref(form).price)} type="number" step="0.01" min="0" required class="w-full pl-7 rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}></div>`);
            if (unref(form).errors.price) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.price)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Cost Price </label><div class="mt-1 relative"${_scopeId}><div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"${_scopeId}><span class="text-gray-500 sm:text-sm"${_scopeId}>R</span></div><input${ssrRenderAttr("value", unref(form).cost)} type="number" step="0.01" min="0" class="w-full pl-7 rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}></div>`);
            if (unref(form).errors.cost) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.cost)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<p class="mt-1 text-sm text-gray-500"${_scopeId}>Used for profit margin calculation</p></div></div></div>`);
            if (!isService.value) {
              _push2(`<div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Inventory Management</h2><div class="grid gap-6 md:grid-cols-3"${_scopeId}><div class="md:col-span-3"${_scopeId}><label class="flex items-center gap-2"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).track_stock) ? ssrLooseContain(unref(form).track_stock, null) : unref(form).track_stock) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"${_scopeId}><span class="text-sm font-medium text-gray-700"${_scopeId}>Track inventory for this product</span></label></div>`);
              if (unref(form).track_stock) {
                _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Current Stock </label><input${ssrRenderAttr("value", unref(form).stock_quantity)} type="number" min="0" class="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}>`);
                if (unref(form).errors.stock_quantity) {
                  _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.stock_quantity)}</div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div>`);
              } else {
                _push2(`<!---->`);
              }
              if (unref(form).track_stock) {
                _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Minimum Stock Level </label><input${ssrRenderAttr("value", unref(form).min_stock_level)} type="number" min="0" class="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}>`);
                if (unref(form).errors.min_stock_level) {
                  _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.min_stock_level)}</div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`<p class="mt-1 text-sm text-gray-500"${_scopeId}>Alert when stock falls below this level</p></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Tags</h2><div class="space-y-4"${_scopeId}><div class="flex gap-2"${_scopeId}><input${ssrRenderAttr("value", newTag.value)} type="text" placeholder="Add a tag" class="flex-1 rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}><button type="button" class="rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"${_scopeId}> Add </button></div>`);
            if (unref(form).tags.length > 0) {
              _push2(`<div class="flex flex-wrap gap-2"${_scopeId}><!--[-->`);
              ssrRenderList(unref(form).tags, (tag) => {
                _push2(`<span class="flex items-center gap-1 rounded-full bg-blue-100 px-3 py-1 text-sm text-blue-800"${_scopeId}>${ssrInterpolate(tag)} <button type="button" class="text-blue-600 hover:text-blue-800"${_scopeId}> × </button></span>`);
              });
              _push2(`<!--]--></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Additional Information</h2><div class="space-y-6"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Image Path </label><input${ssrRenderAttr("value", unref(form).image_path)} type="text" placeholder="/images/products/example.jpg" class="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}>`);
            if (unref(form).errors.image_path) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.image_path)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Notes </label><textarea rows="3" class="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}>${ssrInterpolate(unref(form).notes)}</textarea>`);
            if (unref(form).errors.notes) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.notes)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="flex items-center gap-2"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, null) : unref(form).is_active) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"${_scopeId}><span class="text-sm font-medium text-gray-700"${_scopeId}>Active (available for sale)</span></label></div></div></div><div class="flex items-center justify-end gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(products).show(props.product.id).url,
              class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Cancel `);
                } else {
                  return [
                    createTextVNode(" Cancel ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(form).processing ? "Updating..." : "Update Product/Service")}</button></div></form></div></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-blue-50 border-b border-blue-200 px-4 py-3" }, [
                createVNode("div", { class: "flex items-center gap-2 text-sm text-blue-700" }, [
                  createVNode("span", { class: "font-medium" }, "Editing product for:"),
                  createVNode("span", { class: "font-semibold" }, toDisplayString(props.currentCompany.name), 1)
                ])
              ]),
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "mb-6 flex items-center gap-4" }, [
                  createVNode(unref(Link), {
                    href: unref(products).show(props.product.id).url,
                    class: "flex items-center gap-2 text-gray-600 hover:text-gray-900"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(ArrowLeft), { class: "h-4 w-4" }),
                      createTextVNode(" Back to Product ")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ]),
                createVNode("div", { class: "mx-auto max-w-4xl" }, [
                  createVNode("div", { class: "mb-6" }, [
                    createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "Edit Product/Service"),
                    createVNode("p", { class: "text-gray-600" }, "Update the details for " + toDisplayString(props.product.name), 1)
                  ]),
                  createVNode("form", {
                    onSubmit: withModifiers(submit, ["prevent"]),
                    class: "space-y-8"
                  }, [
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Basic Information"),
                      createVNode("div", { class: "grid gap-6 md:grid-cols-2" }, [
                        createVNode("div", { class: "md:col-span-2" }, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Name * "),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            type: "text",
                            required: "",
                            class: "mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).name]
                          ]),
                          unref(form).errors.name ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.name), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Type * "),
                          createVNode("div", { class: "mt-2 grid grid-cols-2 gap-3" }, [
                            createVNode("label", { class: "relative cursor-pointer" }, [
                              withDirectives(createVNode("input", {
                                "onUpdate:modelValue": ($event) => unref(form).type = $event,
                                type: "radio",
                                value: "product",
                                class: "sr-only"
                              }, null, 8, ["onUpdate:modelValue"]), [
                                [vModelRadio, unref(form).type]
                              ]),
                              createVNode("div", {
                                class: [
                                  "flex items-center gap-3 rounded-lg border p-4",
                                  unref(form).type === "product" ? "border-blue-500 bg-blue-50" : "border-gray-300 hover:border-gray-400"
                                ]
                              }, [
                                createVNode(unref(Package), { class: "h-5 w-5 text-blue-600" }),
                                createVNode("div", null, [
                                  createVNode("div", { class: "font-medium text-gray-900" }, "Product"),
                                  createVNode("div", { class: "text-sm text-gray-500" }, "Physical items with inventory")
                                ])
                              ], 2)
                            ]),
                            createVNode("label", { class: "relative cursor-pointer" }, [
                              withDirectives(createVNode("input", {
                                "onUpdate:modelValue": ($event) => unref(form).type = $event,
                                type: "radio",
                                value: "service",
                                class: "sr-only"
                              }, null, 8, ["onUpdate:modelValue"]), [
                                [vModelRadio, unref(form).type]
                              ]),
                              createVNode("div", {
                                class: [
                                  "flex items-center gap-3 rounded-lg border p-4",
                                  unref(form).type === "service" ? "border-green-500 bg-green-50" : "border-gray-300 hover:border-gray-400"
                                ]
                              }, [
                                createVNode(unref(Wrench), { class: "h-5 w-5 text-green-600" }),
                                createVNode("div", null, [
                                  createVNode("div", { class: "font-medium text-gray-900" }, "Service"),
                                  createVNode("div", { class: "text-sm text-gray-500" }, "Intangible offerings")
                                ])
                              ], 2)
                            ])
                          ]),
                          unref(form).errors.type ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.type), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Category "),
                          withDirectives(createVNode("select", {
                            "onUpdate:modelValue": ($event) => unref(form).category = $event,
                            class: "mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          }, [
                            createVNode("option", { value: "" }, "Select a category"),
                            (openBlock(true), createBlock(Fragment, null, renderList(props.categories, (category) => {
                              return openBlock(), createBlock("option", {
                                key: category.id,
                                value: category.name
                              }, toDisplayString(category.name), 9, ["value"]);
                            }), 128))
                          ], 8, ["onUpdate:modelValue"]), [
                            [vModelSelect, unref(form).category]
                          ]),
                          unref(form).errors.category ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.category), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " SKU (Stock Keeping Unit) "),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).sku = $event,
                            type: "text",
                            class: "mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).sku]
                          ]),
                          unref(form).errors.sku ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.sku), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Unit * "),
                          createVNode("div", { class: "mt-1 flex gap-2" }, [
                            withDirectives(createVNode("select", {
                              "onUpdate:modelValue": ($event) => unref(form).unit = $event,
                              class: "flex-1 rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                            }, [
                              (openBlock(), createBlock(Fragment, null, renderList(commonUnits, (unit) => {
                                return createVNode("option", {
                                  key: unit,
                                  value: unit
                                }, toDisplayString(unit), 9, ["value"]);
                              }), 64))
                            ], 8, ["onUpdate:modelValue"]), [
                              [vModelSelect, unref(form).unit]
                            ]),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).unit = $event,
                              type: "text",
                              placeholder: "Custom unit",
                              class: "flex-1 rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).unit]
                            ])
                          ]),
                          unref(form).errors.unit ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.unit), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "md:col-span-2" }, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Description "),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => unref(form).description = $event,
                            rows: "3",
                            class: "mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).description]
                          ]),
                          unref(form).errors.description ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.description), 1)) : createCommentVNode("", true)
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Pricing"),
                      createVNode("div", { class: "grid gap-6 md:grid-cols-2" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Price * "),
                          createVNode("div", { class: "mt-1 relative" }, [
                            createVNode("div", { class: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none" }, [
                              createVNode("span", { class: "text-gray-500 sm:text-sm" }, "R")
                            ]),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).price = $event,
                              type: "number",
                              step: "0.01",
                              min: "0",
                              required: "",
                              class: "w-full pl-7 rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).price]
                            ])
                          ]),
                          unref(form).errors.price ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.price), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Cost Price "),
                          createVNode("div", { class: "mt-1 relative" }, [
                            createVNode("div", { class: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none" }, [
                              createVNode("span", { class: "text-gray-500 sm:text-sm" }, "R")
                            ]),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).cost = $event,
                              type: "number",
                              step: "0.01",
                              min: "0",
                              class: "w-full pl-7 rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).cost]
                            ])
                          ]),
                          unref(form).errors.cost ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.cost), 1)) : createCommentVNode("", true),
                          createVNode("p", { class: "mt-1 text-sm text-gray-500" }, "Used for profit margin calculation")
                        ])
                      ])
                    ]),
                    !isService.value ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "rounded-lg border bg-white p-6"
                    }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Inventory Management"),
                      createVNode("div", { class: "grid gap-6 md:grid-cols-3" }, [
                        createVNode("div", { class: "md:col-span-3" }, [
                          createVNode("label", { class: "flex items-center gap-2" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).track_stock = $event,
                              type: "checkbox",
                              class: "rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelCheckbox, unref(form).track_stock]
                            ]),
                            createVNode("span", { class: "text-sm font-medium text-gray-700" }, "Track inventory for this product")
                          ])
                        ]),
                        unref(form).track_stock ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Current Stock "),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).stock_quantity = $event,
                            type: "number",
                            min: "0",
                            class: "mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).stock_quantity]
                          ]),
                          unref(form).errors.stock_quantity ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.stock_quantity), 1)) : createCommentVNode("", true)
                        ])) : createCommentVNode("", true),
                        unref(form).track_stock ? (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Minimum Stock Level "),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).min_stock_level = $event,
                            type: "number",
                            min: "0",
                            class: "mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).min_stock_level]
                          ]),
                          unref(form).errors.min_stock_level ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.min_stock_level), 1)) : createCommentVNode("", true),
                          createVNode("p", { class: "mt-1 text-sm text-gray-500" }, "Alert when stock falls below this level")
                        ])) : createCommentVNode("", true)
                      ])
                    ])) : createCommentVNode("", true),
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Tags"),
                      createVNode("div", { class: "space-y-4" }, [
                        createVNode("div", { class: "flex gap-2" }, [
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => newTag.value = $event,
                            type: "text",
                            placeholder: "Add a tag",
                            class: "flex-1 rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500",
                            onKeyup: withKeys(addTag, ["enter"])
                          }, null, 40, ["onUpdate:modelValue"]), [
                            [vModelText, newTag.value]
                          ]),
                          createVNode("button", {
                            type: "button",
                            onClick: addTag,
                            class: "rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                          }, " Add ")
                        ]),
                        unref(form).tags.length > 0 ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "flex flex-wrap gap-2"
                        }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(form).tags, (tag) => {
                            return openBlock(), createBlock("span", {
                              key: tag,
                              class: "flex items-center gap-1 rounded-full bg-blue-100 px-3 py-1 text-sm text-blue-800"
                            }, [
                              createTextVNode(toDisplayString(tag) + " ", 1),
                              createVNode("button", {
                                type: "button",
                                onClick: ($event) => removeTag(tag),
                                class: "text-blue-600 hover:text-blue-800"
                              }, " × ", 8, ["onClick"])
                            ]);
                          }), 128))
                        ])) : createCommentVNode("", true)
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Additional Information"),
                      createVNode("div", { class: "space-y-6" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Image Path "),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).image_path = $event,
                            type: "text",
                            placeholder: "/images/products/example.jpg",
                            class: "mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).image_path]
                          ]),
                          unref(form).errors.image_path ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.image_path), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Notes "),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => unref(form).notes = $event,
                            rows: "3",
                            class: "mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).notes]
                          ]),
                          unref(form).errors.notes ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.notes), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "flex items-center gap-2" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).is_active = $event,
                              type: "checkbox",
                              class: "rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelCheckbox, unref(form).is_active]
                            ]),
                            createVNode("span", { class: "text-sm font-medium text-gray-700" }, "Active (available for sale)")
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "flex items-center justify-end gap-4" }, [
                      createVNode(unref(Link), {
                        href: unref(products).show(props.product.id).url,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Cancel ")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createVNode("button", {
                        type: "submit",
                        disabled: unref(form).processing,
                        class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
                      }, toDisplayString(unref(form).processing ? "Updating..." : "Update Product/Service"), 9, ["disabled"])
                    ])
                  ], 32)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/products/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
