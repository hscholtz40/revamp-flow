import { createInertiaApp } from "@inertiajs/vue3";
import createServer from "@inertiajs/vue3/server";
import { createSSRApp, h } from "vue";
import { renderToString } from "vue/server-renderer";
async function resolvePageComponent(path, pages) {
  for (const p of Array.isArray(path) ? path : [path]) {
    const page = pages[p];
    if (typeof page === "undefined") {
      continue;
    }
    return typeof page === "function" ? page() : page;
  }
  throw new Error(`Page not found: ${path}`);
}
const appName = "Laravel";
createServer(
  (page) => createInertiaApp({
    page,
    render: renderToString,
    title: (title) => title ? `${title} - ${appName}` : appName,
    resolve: (name) => resolvePageComponent(
      `./pages/${name}.vue`,
      /* @__PURE__ */ Object.assign({ "./pages/Administration.vue": () => import("./assets/Administration-B3K3zme0.js"), "./pages/Dashboard.vue": () => import("./assets/Dashboard-DO5KnX6_.js"), "./pages/Errors/PermissionDenied.vue": () => import("./assets/PermissionDenied-BsjaKo4y.js"), "./pages/administration/SMSSettings.vue": () => import("./assets/SMSSettings-Bs5ozIcy.js"), "./pages/administration/XeroSettings.vue": () => import("./assets/XeroSettings-DTZWfCIC.js"), "./pages/administration/categories/Create.vue": () => import("./assets/Create-2DKPPYhb.js"), "./pages/administration/categories/Edit.vue": () => import("./assets/Edit-DhsgYUyS.js"), "./pages/administration/categories/Index.vue": () => import("./assets/Index-S1mV6zg8.js"), "./pages/administration/categories/Show.vue": () => import("./assets/Show-5kdSP9jy.js"), "./pages/auth/ConfirmPassword.vue": () => import("./assets/ConfirmPassword-B1Q9iEU_.js"), "./pages/auth/ForgotPassword.vue": () => import("./assets/ForgotPassword-BEYvPqJR.js"), "./pages/auth/Login.vue": () => import("./assets/Login-BGgB5WtY.js"), "./pages/auth/ResetPassword.vue": () => import("./assets/ResetPassword-B5SomrbK.js"), "./pages/auth/TwoFactorChallenge.vue": () => import("./assets/TwoFactorChallenge-B2JGwssH.js"), "./pages/auth/VerifyEmail.vue": () => import("./assets/VerifyEmail-CrRs7yJN.js"), "./pages/company-settings/Create.vue": () => import("./assets/Create-HW2T4LIF.js"), "./pages/company-settings/Edit.vue": () => import("./assets/Edit-B68RgoRt.js"), "./pages/company-settings/Index.vue": () => import("./assets/Index-LpGXgw-0.js"), "./pages/company-settings/Show.vue": () => import("./assets/Show-B2Cly3aS.js"), "./pages/contacts/Create.vue": () => import("./assets/Create-cvJyjxRY.js"), "./pages/contacts/Edit.vue": () => import("./assets/Edit-BpNnPR57.js"), "./pages/contacts/Index.vue": () => import("./assets/Index-D3O5hDBI.js"), "./pages/contacts/Show.vue": () => import("./assets/Show-0ZFzIQcB.js"), "./pages/customers/Create.vue": () => import("./assets/Create-XR9Aa639.js"), "./pages/customers/Edit.vue": () => import("./assets/Edit-DXt5LpZM.js"), "./pages/customers/Index.vue": () => import("./assets/Index-Cu8tUAoQ.js"), "./pages/customers/Show.vue": () => import("./assets/Show-BRV4LThd.js"), "./pages/groups/Create.vue": () => import("./assets/Create-xAApaYP3.js"), "./pages/groups/Edit.vue": () => import("./assets/Edit-BOoYbdvp.js"), "./pages/groups/Index.vue": () => import("./assets/Index-C5XnxVAA.js"), "./pages/invoices/Create.vue": () => import("./assets/Create-DYMUcss6.js"), "./pages/invoices/Edit.vue": () => import("./assets/Edit-BgsBCfXw.js"), "./pages/invoices/Index.vue": () => import("./assets/Index-Boozdb3C.js"), "./pages/invoices/Show.vue": () => import("./assets/Show-CbqXkxjo.js"), "./pages/jobcards/Create.vue": () => import("./assets/Create-CeF3v4EC.js"), "./pages/jobcards/Edit.vue": () => import("./assets/Edit-BqMh2RVC.js"), "./pages/jobcards/Index.vue": () => import("./assets/Index-Cc5q8yBz.js"), "./pages/jobcards/Print.vue": () => import("./assets/Print-D0K9vBLU.js"), "./pages/jobcards/Show.vue": () => import("./assets/Show-DUqxZTqk.js"), "./pages/products/Create.vue": () => import("./assets/Create-C3tanmtt.js"), "./pages/products/Edit.vue": () => import("./assets/Edit-DrEN3IuN.js"), "./pages/products/Index.vue": () => import("./assets/Index-BNWdQP41.js"), "./pages/products/Show.vue": () => import("./assets/Show-DCvIoMHL.js"), "./pages/quotes/Create.vue": () => import("./assets/Create-Dw--lQgf.js"), "./pages/quotes/Edit.vue": () => import("./assets/Edit-Cbpl2Bju.js"), "./pages/quotes/Index.vue": () => import("./assets/Index-Bai46VnP.js"), "./pages/quotes/Show.vue": () => import("./assets/Show-CeWyO5D9.js"), "./pages/settings/Appearance.vue": () => import("./assets/Appearance-Dk1cR3mz.js"), "./pages/settings/Password.vue": () => import("./assets/Password-Cv_oyy8u.js"), "./pages/settings/Profile.vue": () => import("./assets/Profile-D9dafRC8.js"), "./pages/settings/TwoFactor.vue": () => import("./assets/TwoFactor-xIYmhwyo.js"), "./pages/users/Create.vue": () => import("./assets/Create--YWRQy42.js"), "./pages/users/Edit.vue": () => import("./assets/Edit-Dg6SUnfH.js"), "./pages/users/Index.vue": () => import("./assets/Index-DOXkxHHy.js"), "./pages/users/Show.vue": () => import("./assets/Show-D6Gqi6jZ.js") })
    ),
    setup: ({ App, props, plugin }) => createSSRApp({ render: () => h(App, props) }).use(plugin)
  }),
  { cluster: true }
);
