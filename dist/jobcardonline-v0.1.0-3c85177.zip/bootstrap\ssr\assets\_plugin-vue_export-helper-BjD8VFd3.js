import { q as queryParams, a as applyUrlDefaults } from "./index--D7ld9AJ.js";
const index = (options) => ({
  url: index.url(options),
  method: "get"
});
index.definition = {
  methods: ["get", "head"],
  url: "/jobcards"
};
index.url = (options) => {
  return index.definition.url + queryParams(options);
};
index.get = (options) => ({
  url: index.url(options),
  method: "get"
});
index.head = (options) => ({
  url: index.url(options),
  method: "head"
});
const indexForm = (options) => ({
  action: index.url(options),
  method: "get"
});
indexForm.get = (options) => ({
  action: index.url(options),
  method: "get"
});
indexForm.head = (options) => ({
  action: index.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
index.form = indexForm;
const create = (options) => ({
  url: create.url(options),
  method: "get"
});
create.definition = {
  methods: ["get", "head"],
  url: "/jobcards/create"
};
create.url = (options) => {
  return create.definition.url + queryParams(options);
};
create.get = (options) => ({
  url: create.url(options),
  method: "get"
});
create.head = (options) => ({
  url: create.url(options),
  method: "head"
});
const createForm = (options) => ({
  action: create.url(options),
  method: "get"
});
createForm.get = (options) => ({
  action: create.url(options),
  method: "get"
});
createForm.head = (options) => ({
  action: create.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create.form = createForm;
const store = (options) => ({
  url: store.url(options),
  method: "post"
});
store.definition = {
  methods: ["post"],
  url: "/jobcards"
};
store.url = (options) => {
  return store.definition.url + queryParams(options);
};
store.post = (options) => ({
  url: store.url(options),
  method: "post"
});
const storeForm = (options) => ({
  action: store.url(options),
  method: "post"
});
storeForm.post = (options) => ({
  action: store.url(options),
  method: "post"
});
store.form = storeForm;
const show = (args, options) => ({
  url: show.url(args, options),
  method: "get"
});
show.definition = {
  methods: ["get", "head"],
  url: "/jobcards/{jobcard}"
};
show.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { jobcard: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { jobcard: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      jobcard: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    jobcard: typeof args.jobcard === "object" ? args.jobcard.id : args.jobcard
  };
  return show.definition.url.replace("{jobcard}", parsedArgs.jobcard.toString()).replace(/\/+$/, "") + queryParams(options);
};
show.get = (args, options) => ({
  url: show.url(args, options),
  method: "get"
});
show.head = (args, options) => ({
  url: show.url(args, options),
  method: "head"
});
const showForm = (args, options) => ({
  action: show.url(args, options),
  method: "get"
});
showForm.get = (args, options) => ({
  action: show.url(args, options),
  method: "get"
});
showForm.head = (args, options) => ({
  action: show.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
show.form = showForm;
const edit = (args, options) => ({
  url: edit.url(args, options),
  method: "get"
});
edit.definition = {
  methods: ["get", "head"],
  url: "/jobcards/{jobcard}/edit"
};
edit.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { jobcard: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { jobcard: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      jobcard: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    jobcard: typeof args.jobcard === "object" ? args.jobcard.id : args.jobcard
  };
  return edit.definition.url.replace("{jobcard}", parsedArgs.jobcard.toString()).replace(/\/+$/, "") + queryParams(options);
};
edit.get = (args, options) => ({
  url: edit.url(args, options),
  method: "get"
});
edit.head = (args, options) => ({
  url: edit.url(args, options),
  method: "head"
});
const editForm = (args, options) => ({
  action: edit.url(args, options),
  method: "get"
});
editForm.get = (args, options) => ({
  action: edit.url(args, options),
  method: "get"
});
editForm.head = (args, options) => ({
  action: edit.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
edit.form = editForm;
const update = (args, options) => ({
  url: update.url(args, options),
  method: "put"
});
update.definition = {
  methods: ["put"],
  url: "/jobcards/{jobcard}"
};
update.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { jobcard: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { jobcard: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      jobcard: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    jobcard: typeof args.jobcard === "object" ? args.jobcard.id : args.jobcard
  };
  return update.definition.url.replace("{jobcard}", parsedArgs.jobcard.toString()).replace(/\/+$/, "") + queryParams(options);
};
update.put = (args, options) => ({
  url: update.url(args, options),
  method: "put"
});
const updateForm = (args, options) => ({
  action: update.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateForm.put = (args, options) => ({
  action: update.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PUT",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
update.form = updateForm;
const updateStatus = (args, options) => ({
  url: updateStatus.url(args, options),
  method: "patch"
});
updateStatus.definition = {
  methods: ["patch"],
  url: "/jobcards/{jobcard}/status"
};
updateStatus.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { jobcard: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { jobcard: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      jobcard: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    jobcard: typeof args.jobcard === "object" ? args.jobcard.id : args.jobcard
  };
  return updateStatus.definition.url.replace("{jobcard}", parsedArgs.jobcard.toString()).replace(/\/+$/, "") + queryParams(options);
};
updateStatus.patch = (args, options) => ({
  url: updateStatus.url(args, options),
  method: "patch"
});
const updateStatusForm = (args, options) => ({
  action: updateStatus.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PATCH",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateStatusForm.patch = (args, options) => ({
  action: updateStatus.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "PATCH",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
updateStatus.form = updateStatusForm;
const print = (args, options) => ({
  url: print.url(args, options),
  method: "get"
});
print.definition = {
  methods: ["get", "head"],
  url: "/jobcards/{jobcard}/print"
};
print.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { jobcard: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { jobcard: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      jobcard: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    jobcard: typeof args.jobcard === "object" ? args.jobcard.id : args.jobcard
  };
  return print.definition.url.replace("{jobcard}", parsedArgs.jobcard.toString()).replace(/\/+$/, "") + queryParams(options);
};
print.get = (args, options) => ({
  url: print.url(args, options),
  method: "get"
});
print.head = (args, options) => ({
  url: print.url(args, options),
  method: "head"
});
const printForm = (args, options) => ({
  action: print.url(args, options),
  method: "get"
});
printForm.get = (args, options) => ({
  action: print.url(args, options),
  method: "get"
});
printForm.head = (args, options) => ({
  action: print.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
print.form = printForm;
const email = (args, options) => ({
  url: email.url(args, options),
  method: "post"
});
email.definition = {
  methods: ["post"],
  url: "/jobcards/{jobcard}/email"
};
email.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { jobcard: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { jobcard: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      jobcard: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    jobcard: typeof args.jobcard === "object" ? args.jobcard.id : args.jobcard
  };
  return email.definition.url.replace("{jobcard}", parsedArgs.jobcard.toString()).replace(/\/+$/, "") + queryParams(options);
};
email.post = (args, options) => ({
  url: email.url(args, options),
  method: "post"
});
const emailForm = (args, options) => ({
  action: email.url(args, options),
  method: "post"
});
emailForm.post = (args, options) => ({
  action: email.url(args, options),
  method: "post"
});
email.form = emailForm;
const convertToInvoice = (args, options) => ({
  url: convertToInvoice.url(args, options),
  method: "post"
});
convertToInvoice.definition = {
  methods: ["post"],
  url: "/jobcards/{jobcard}/convert-to-invoice"
};
convertToInvoice.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { jobcard: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { jobcard: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      jobcard: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    jobcard: typeof args.jobcard === "object" ? args.jobcard.id : args.jobcard
  };
  return convertToInvoice.definition.url.replace("{jobcard}", parsedArgs.jobcard.toString()).replace(/\/+$/, "") + queryParams(options);
};
convertToInvoice.post = (args, options) => ({
  url: convertToInvoice.url(args, options),
  method: "post"
});
const convertToInvoiceForm = (args, options) => ({
  action: convertToInvoice.url(args, options),
  method: "post"
});
convertToInvoiceForm.post = (args, options) => ({
  action: convertToInvoice.url(args, options),
  method: "post"
});
convertToInvoice.form = convertToInvoiceForm;
const destroy = (args, options) => ({
  url: destroy.url(args, options),
  method: "delete"
});
destroy.definition = {
  methods: ["delete"],
  url: "/jobcards/{jobcard}"
};
destroy.url = (args, options) => {
  if (typeof args === "string" || typeof args === "number") {
    args = { jobcard: args };
  }
  if (typeof args === "object" && !Array.isArray(args) && "id" in args) {
    args = { jobcard: args.id };
  }
  if (Array.isArray(args)) {
    args = {
      jobcard: args[0]
    };
  }
  args = applyUrlDefaults(args);
  const parsedArgs = {
    jobcard: typeof args.jobcard === "object" ? args.jobcard.id : args.jobcard
  };
  return destroy.definition.url.replace("{jobcard}", parsedArgs.jobcard.toString()).replace(/\/+$/, "") + queryParams(options);
};
destroy.delete = (args, options) => ({
  url: destroy.url(args, options),
  method: "delete"
});
const destroyForm = (args, options) => ({
  action: destroy.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroyForm.delete = (args, options) => ({
  action: destroy.url(args, {
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "DELETE",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "post"
});
destroy.form = destroyForm;
const jobcards = {
  index: Object.assign(index, index),
  create: Object.assign(create, create),
  store: Object.assign(store, store),
  show: Object.assign(show, show),
  edit: Object.assign(edit, edit),
  update: Object.assign(update, update),
  updateStatus: Object.assign(updateStatus, updateStatus),
  print: Object.assign(print, print),
  email: Object.assign(email, email),
  convertToInvoice: Object.assign(convertToInvoice, convertToInvoice),
  destroy: Object.assign(destroy, destroy)
};
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
export {
  _export_sfc as _,
  jobcards as j
};
