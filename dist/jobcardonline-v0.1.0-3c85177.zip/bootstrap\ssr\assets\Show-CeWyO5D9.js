import { defineComponent, ref, computed, unref, withCtx, createTextVNode, createVNode, createBlock, createCommentVNode, openBlock, Fragment, renderList, toDisplayString, withModifiers, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _sfc_main$1, q as quotes, i as invoices } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link, router } from "@inertiajs/vue3";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    quote: {},
    canEditCompleted: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const showEmailModal = ref(false);
    const showResultDialog = ref(false);
    const emailResult = ref({
      success: false,
      email: "",
      message: ""
    });
    const canEditQuote = computed(() => {
      if (props.quote.status !== "accepted") {
        return true;
      }
      return props.canEditCompleted;
    });
    const emailForm = useForm({
      email: props.quote.customer?.email || "",
      message: ""
    });
    const statusOptions = [
      { value: "draft", label: "Draft" },
      { value: "sent", label: "Sent" },
      { value: "accepted", label: "Accepted" },
      { value: "rejected", label: "Rejected" },
      { value: "expired", label: "Expired" }
    ];
    const updateStatus = (status) => {
      router.patch(quotes.updateStatus(props.quote.id).url, {
        status
      }, {
        preserveScroll: true
      });
    };
    const downloadPDF = () => {
      window.open(quotes.downloadPdf(props.quote.id).url, "_blank");
    };
    const sendEmail = () => {
      emailForm.post(quotes.email(props.quote.id).url, {
        onSuccess: (page) => {
          showEmailModal.value = false;
          emailResult.value = {
            success: true,
            email: emailForm.email,
            message: page.props.flash?.success || "Email sent successfully"
          };
          showResultDialog.value = true;
          emailForm.reset();
        },
        onError: (errors) => {
          showEmailModal.value = false;
          emailResult.value = {
            success: false,
            email: emailForm.email,
            message: errors.message || "Failed to send email"
          };
          showResultDialog.value = true;
        }
      });
    };
    const convertToJobcard = () => {
      if (confirm("Are you sure you want to convert this quote to a jobcard?")) {
        router.post(quotes.convertToJobcard(props.quote.id).url);
      }
    };
    const convertToInvoice = () => {
      if (confirm("Are you sure you want to convert this quote to an invoice?")) {
        router.post(quotes.convertToInvoice(props.quote.id).url);
      }
    };
    const getStatusBadgeClass = (status) => {
      const classes = {
        draft: "bg-gray-100 text-gray-800",
        sent: "bg-blue-100 text-blue-800",
        accepted: "bg-green-100 text-green-800",
        rejected: "bg-red-100 text-red-800",
        expired: "bg-yellow-100 text-yellow-800"
      };
      return classes[status] || "bg-gray-100 text-gray-800";
    };
    const formatStatus = (status) => {
      return status.replace("_", " ").toUpperCase();
    };
    const formatDate = (dateString) => {
      return new Date(dateString).toLocaleDateString();
    };
    const formatCurrency = (value) => {
      const numValue = Number(value) || 0;
      return numValue.toFixed(2);
    };
    const formatDateTime = (dateString) => {
      return new Date(dateString).toLocaleString();
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Quote ${props.quote.quote_number}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Quotes", href: unref(quotes).index().url },
          { title: props.quote.quote_number, href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="space-y-6 p-4"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Status Management</h2><p class="text-sm text-gray-600"${_scopeId}>Update quote status and track progress</p></div><div class="p-6"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div class="flex items-center gap-4"${_scopeId}><span class="text-sm font-medium text-gray-700"${_scopeId}>Current Status:</span><div class="flex items-center gap-2"${_scopeId}><!--[-->`);
            ssrRenderList(statusOptions, (status) => {
              _push2(`<button class="${ssrRenderClass([
                "px-3 py-1 text-sm font-medium rounded-md transition-colors",
                props.quote.status === status.value ? "bg-blue-100 text-blue-800 border border-blue-200" : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200"
              ])}"${_scopeId}>${ssrInterpolate(status.label)}</button>`);
            });
            _push2(`<!--]--></div></div><div class="text-sm text-gray-500"${_scopeId}> Last updated: ${ssrInterpolate(formatDateTime(props.quote.updated_at))}</div></div></div></div><div class="rounded-lg bg-white border border-gray-200 p-6 shadow-sm"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>${ssrInterpolate(props.quote.quote_number)}</h1><p class="text-sm text-gray-500 mt-1"${_scopeId}>${ssrInterpolate(props.quote.title)}</p></div><div class="flex items-center gap-2"${_scopeId}><span class="${ssrRenderClass([getStatusBadgeClass(props.quote.status), "inline-flex px-3 py-1 text-sm font-semibold rounded-full"])}"${_scopeId}>${ssrInterpolate(formatStatus(props.quote.status))}</span><button class="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"${_scopeId}> Download PDF </button><button class="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"${_scopeId}> Email </button><button class="rounded-md bg-purple-600 px-4 py-2 text-sm font-medium text-white hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2"${_scopeId}> Convert to Jobcard </button>`);
            if (!props.quote.invoice_id) {
              _push2(`<button class="rounded-md bg-orange-600 px-4 py-2 text-sm font-medium text-white hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2"${_scopeId}> Convert to Invoice </button>`);
            } else {
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(invoices).show(props.quote.invoice_id).url,
                class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` View Invoice `);
                  } else {
                    return [
                      createTextVNode(" View Invoice ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            }
            if (canEditQuote.value) {
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(quotes).edit(props.quote.id).url,
                class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Edit `);
                  } else {
                    return [
                      createTextVNode(" Edit ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<span class="rounded-md bg-gray-400 px-4 py-2 text-sm font-medium text-white cursor-not-allowed" title="Cannot edit accepted quotes without permission"${_scopeId}> Edit </span>`);
            }
            _push2(`</div></div></div><div class="grid grid-cols-1 lg:grid-cols-3 gap-6"${_scopeId}><div class="lg:col-span-2 space-y-6"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Customer Information</h2><p class="text-sm text-gray-600"${_scopeId}>Customer details and contact information</p></div><div class="p-6"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Customer Name</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.quote.customer?.name)}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Email</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.quote.customer?.email || "-")}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Phone</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.quote.customer?.phone || "-")}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Address</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.quote.customer?.address || "-")}</p></div></div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Line Items</h2><p class="text-sm text-gray-600"${_scopeId}>Products and services included in this quote</p></div><div class="overflow-x-auto"${_scopeId}><table class="w-full"${_scopeId}><thead class="bg-gray-50"${_scopeId}><tr${_scopeId}><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Description </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Quantity </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Unit Price </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Total </th></tr></thead><tbody class="bg-white divide-y divide-gray-200"${_scopeId}><!--[-->`);
            ssrRenderList(props.quote.line_items, (item) => {
              _push2(`<tr${_scopeId}><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(item.description)}</div>`);
              if (item.product) {
                _push2(`<div class="text-xs text-gray-500"${_scopeId}> Product: ${ssrInterpolate(item.product.name)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"${_scopeId}>${ssrInterpolate(item.quantity)}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"${_scopeId}>${ssrInterpolate(item.formatted_unit_price)}</td><td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(item.formatted_total)}</td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div>`);
            if (props.quote.notes || props.quote.terms_conditions) {
              _push2(`<div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Additional Information</h2><p class="text-sm text-gray-600"${_scopeId}>Notes and terms &amp; conditions</p></div><div class="p-6 space-y-4"${_scopeId}>`);
              if (props.quote.notes) {
                _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Notes</label><p class="mt-1 text-sm text-gray-900 whitespace-pre-wrap"${_scopeId}>${ssrInterpolate(props.quote.notes)}</p></div>`);
              } else {
                _push2(`<!---->`);
              }
              if (props.quote.terms_conditions) {
                _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Terms &amp; Conditions</label><p class="mt-1 text-sm text-gray-900 whitespace-pre-wrap"${_scopeId}>${ssrInterpolate(props.quote.terms_conditions)}</p></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="space-y-6"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Quote Details</h2><p class="text-sm text-gray-600"${_scopeId}>Key information about this quote</p></div><div class="p-6 space-y-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Quote Number</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.quote.quote_number)}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Created Date</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatDate(props.quote.created_at))}</p></div>`);
            if (props.quote.expiry_date) {
              _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Expiry Date</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatDate(props.quote.expiry_date))}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Description</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.quote.description || "-")}</p></div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Financial Summary</h2><p class="text-sm text-gray-600"${_scopeId}>Cost breakdown and totals</p></div><div class="p-6 space-y-3"${_scopeId}><div class="flex justify-between"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Subtotal:</span><span class="text-sm font-medium text-gray-900"${_scopeId}>R${ssrInterpolate(formatCurrency(props.quote.subtotal))}</span></div>`);
            if ((Number(props.quote.discount_amount) || 0) > 0) {
              _push2(`<div class="flex justify-between"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Discount:</span><span class="text-sm font-medium text-red-600"${_scopeId}>-R${ssrInterpolate(formatCurrency(props.quote.discount_amount))}</span></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex justify-between"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Tax (${ssrInterpolate(props.quote.tax_rate || 0)}%):</span><span class="text-sm font-medium text-gray-900"${_scopeId}>R${ssrInterpolate(formatCurrency(props.quote.tax_amount))}</span></div><div class="border-t border-gray-200 pt-3"${_scopeId}><div class="flex justify-between"${_scopeId}><span class="text-base font-semibold text-gray-900"${_scopeId}>Total:</span><span class="text-base font-semibold text-gray-900"${_scopeId}>R${ssrInterpolate(formatCurrency(props.quote.total))}</span></div></div></div></div></div></div></div>`);
            if (showEmailModal.value) {
              _push2(`<div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50"${_scopeId}><div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white"${_scopeId}><div class="mt-3"${_scopeId}><h3 class="text-lg font-medium text-gray-900 mb-4"${_scopeId}>Email Quote</h3><form${_scopeId}><div class="mb-4"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Email Address *</label><input${ssrRenderAttr("value", unref(emailForm).email)} type="email" class="${ssrRenderClass([{ "border-red-500": unref(emailForm).errors.email }, "w-full rounded border px-3 py-2"])}" required${_scopeId}>`);
              if (unref(emailForm).errors.email) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(emailForm).errors.email)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Message</label><textarea rows="3" class="w-full rounded border px-3 py-2" placeholder="Optional message to include with the quote..."${_scopeId}>${ssrInterpolate(unref(emailForm).message)}</textarea></div><div class="flex items-center justify-end gap-3"${_scopeId}><button type="button" class="rounded border border-gray-300 px-4 py-2 text-gray-700 hover:bg-gray-50"${_scopeId}> Cancel </button><button type="submit"${ssrIncludeBooleanAttr(unref(emailForm).processing) ? " disabled" : ""} class="rounded bg-green-600 px-4 py-2 text-white hover:bg-green-700 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(emailForm).processing ? "Sending..." : "Send Email")}</button></div></form></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (showResultDialog.value) {
              _push2(`<div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50"${_scopeId}><div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white"${_scopeId}><div class="mt-3"${_scopeId}><h3 class="text-lg font-medium text-gray-900 mb-2 text-center"${_scopeId}>${ssrInterpolate(emailResult.value.success ? "Email Sent Successfully!" : "Email Failed to Send")}</h3><div class="text-center"${_scopeId}>`);
              if (emailResult.value.success) {
                _push2(`<p class="text-sm text-gray-600 mb-4"${_scopeId}> The quote has been sent to <strong${_scopeId}>${ssrInterpolate(emailResult.value.email)}</strong></p>`);
              } else {
                _push2(`<p class="text-sm text-red-600 mb-4"${_scopeId}>${ssrInterpolate(emailResult.value.message)}</p>`);
              }
              _push2(`</div><div class="flex justify-center"${_scopeId}><button class="${ssrRenderClass([emailResult.value.success ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500", "rounded-md px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2"])}"${_scopeId}>${ssrInterpolate(emailResult.value.success ? "Great!" : "Try Again")}</button></div></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              createVNode("div", { class: "space-y-6 p-4" }, [
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                  createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Status Management"),
                    createVNode("p", { class: "text-sm text-gray-600" }, "Update quote status and track progress")
                  ]),
                  createVNode("div", { class: "p-6" }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", { class: "flex items-center gap-4" }, [
                        createVNode("span", { class: "text-sm font-medium text-gray-700" }, "Current Status:"),
                        createVNode("div", { class: "flex items-center gap-2" }, [
                          (openBlock(), createBlock(Fragment, null, renderList(statusOptions, (status) => {
                            return createVNode("button", {
                              key: status.value,
                              onClick: ($event) => updateStatus(status.value),
                              class: [
                                "px-3 py-1 text-sm font-medium rounded-md transition-colors",
                                props.quote.status === status.value ? "bg-blue-100 text-blue-800 border border-blue-200" : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200"
                              ]
                            }, toDisplayString(status.label), 11, ["onClick"]);
                          }), 64))
                        ])
                      ]),
                      createVNode("div", { class: "text-sm text-gray-500" }, " Last updated: " + toDisplayString(formatDateTime(props.quote.updated_at)), 1)
                    ])
                  ])
                ]),
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 p-6 shadow-sm" }, [
                  createVNode("div", { class: "flex items-center justify-between" }, [
                    createVNode("div", null, [
                      createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, toDisplayString(props.quote.quote_number), 1),
                      createVNode("p", { class: "text-sm text-gray-500 mt-1" }, toDisplayString(props.quote.title), 1)
                    ]),
                    createVNode("div", { class: "flex items-center gap-2" }, [
                      createVNode("span", {
                        class: [getStatusBadgeClass(props.quote.status), "inline-flex px-3 py-1 text-sm font-semibold rounded-full"]
                      }, toDisplayString(formatStatus(props.quote.status)), 3),
                      createVNode("button", {
                        onClick: downloadPDF,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, " Download PDF "),
                      createVNode("button", {
                        onClick: ($event) => showEmailModal.value = true,
                        class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
                      }, " Email ", 8, ["onClick"]),
                      createVNode("button", {
                        onClick: convertToJobcard,
                        class: "rounded-md bg-purple-600 px-4 py-2 text-sm font-medium text-white hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2"
                      }, " Convert to Jobcard "),
                      !props.quote.invoice_id ? (openBlock(), createBlock("button", {
                        key: 0,
                        onClick: convertToInvoice,
                        class: "rounded-md bg-orange-600 px-4 py-2 text-sm font-medium text-white hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2"
                      }, " Convert to Invoice ")) : (openBlock(), createBlock(unref(Link), {
                        key: 1,
                        href: unref(invoices).show(props.quote.invoice_id).url,
                        class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" View Invoice ")
                        ]),
                        _: 1
                      }, 8, ["href"])),
                      canEditQuote.value ? (openBlock(), createBlock(unref(Link), {
                        key: 2,
                        href: unref(quotes).edit(props.quote.id).url,
                        class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Edit ")
                        ]),
                        _: 1
                      }, 8, ["href"])) : (openBlock(), createBlock("span", {
                        key: 3,
                        class: "rounded-md bg-gray-400 px-4 py-2 text-sm font-medium text-white cursor-not-allowed",
                        title: "Cannot edit accepted quotes without permission"
                      }, " Edit "))
                    ])
                  ])
                ]),
                createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-3 gap-6" }, [
                  createVNode("div", { class: "lg:col-span-2 space-y-6" }, [
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Customer Information"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Customer details and contact information")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Customer Name"),
                            createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(props.quote.customer?.name), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Email"),
                            createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(props.quote.customer?.email || "-"), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Phone"),
                            createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(props.quote.customer?.phone || "-"), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Address"),
                            createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(props.quote.customer?.address || "-"), 1)
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Line Items"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Products and services included in this quote")
                      ]),
                      createVNode("div", { class: "overflow-x-auto" }, [
                        createVNode("table", { class: "w-full" }, [
                          createVNode("thead", { class: "bg-gray-50" }, [
                            createVNode("tr", null, [
                              createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Description "),
                              createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Quantity "),
                              createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Unit Price "),
                              createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Total ")
                            ])
                          ]),
                          createVNode("tbody", { class: "bg-white divide-y divide-gray-200" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(props.quote.line_items, (item) => {
                              return openBlock(), createBlock("tr", {
                                key: item.id
                              }, [
                                createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                                  createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(item.description), 1),
                                  item.product ? (openBlock(), createBlock("div", {
                                    key: 0,
                                    class: "text-xs text-gray-500"
                                  }, " Product: " + toDisplayString(item.product.name), 1)) : createCommentVNode("", true)
                                ]),
                                createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm text-gray-900" }, toDisplayString(item.quantity), 1),
                                createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm text-gray-900" }, toDisplayString(item.formatted_unit_price), 1),
                                createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900" }, toDisplayString(item.formatted_total), 1)
                              ]);
                            }), 128))
                          ])
                        ])
                      ])
                    ]),
                    props.quote.notes || props.quote.terms_conditions ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "rounded-lg bg-white border border-gray-200 shadow-sm"
                    }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Additional Information"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Notes and terms & conditions")
                      ]),
                      createVNode("div", { class: "p-6 space-y-4" }, [
                        props.quote.notes ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Notes"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-900 whitespace-pre-wrap" }, toDisplayString(props.quote.notes), 1)
                        ])) : createCommentVNode("", true),
                        props.quote.terms_conditions ? (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Terms & Conditions"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-900 whitespace-pre-wrap" }, toDisplayString(props.quote.terms_conditions), 1)
                        ])) : createCommentVNode("", true)
                      ])
                    ])) : createCommentVNode("", true)
                  ]),
                  createVNode("div", { class: "space-y-6" }, [
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Quote Details"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Key information about this quote")
                      ]),
                      createVNode("div", { class: "p-6 space-y-4" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Quote Number"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(props.quote.quote_number), 1)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Created Date"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(formatDate(props.quote.created_at)), 1)
                        ]),
                        props.quote.expiry_date ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Expiry Date"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(formatDate(props.quote.expiry_date)), 1)
                        ])) : createCommentVNode("", true),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Description"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(props.quote.description || "-"), 1)
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Financial Summary"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Cost breakdown and totals")
                      ]),
                      createVNode("div", { class: "p-6 space-y-3" }, [
                        createVNode("div", { class: "flex justify-between" }, [
                          createVNode("span", { class: "text-sm text-gray-500" }, "Subtotal:"),
                          createVNode("span", { class: "text-sm font-medium text-gray-900" }, "R" + toDisplayString(formatCurrency(props.quote.subtotal)), 1)
                        ]),
                        (Number(props.quote.discount_amount) || 0) > 0 ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "flex justify-between"
                        }, [
                          createVNode("span", { class: "text-sm text-gray-500" }, "Discount:"),
                          createVNode("span", { class: "text-sm font-medium text-red-600" }, "-R" + toDisplayString(formatCurrency(props.quote.discount_amount)), 1)
                        ])) : createCommentVNode("", true),
                        createVNode("div", { class: "flex justify-between" }, [
                          createVNode("span", { class: "text-sm text-gray-500" }, "Tax (" + toDisplayString(props.quote.tax_rate || 0) + "%):", 1),
                          createVNode("span", { class: "text-sm font-medium text-gray-900" }, "R" + toDisplayString(formatCurrency(props.quote.tax_amount)), 1)
                        ]),
                        createVNode("div", { class: "border-t border-gray-200 pt-3" }, [
                          createVNode("div", { class: "flex justify-between" }, [
                            createVNode("span", { class: "text-base font-semibold text-gray-900" }, "Total:"),
                            createVNode("span", { class: "text-base font-semibold text-gray-900" }, "R" + toDisplayString(formatCurrency(props.quote.total)), 1)
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ]),
              showEmailModal.value ? (openBlock(), createBlock("div", {
                key: 0,
                class: "fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50"
              }, [
                createVNode("div", { class: "relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white" }, [
                  createVNode("div", { class: "mt-3" }, [
                    createVNode("h3", { class: "text-lg font-medium text-gray-900 mb-4" }, "Email Quote"),
                    createVNode("form", {
                      onSubmit: withModifiers(sendEmail, ["prevent"])
                    }, [
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Email Address *"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => unref(emailForm).email = $event,
                          type: "email",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(emailForm).errors.email }],
                          required: ""
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(emailForm).email]
                        ]),
                        unref(emailForm).errors.email ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(emailForm).errors.email), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Message"),
                        withDirectives(createVNode("textarea", {
                          "onUpdate:modelValue": ($event) => unref(emailForm).message = $event,
                          rows: "3",
                          class: "w-full rounded border px-3 py-2",
                          placeholder: "Optional message to include with the quote..."
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(emailForm).message]
                        ])
                      ]),
                      createVNode("div", { class: "flex items-center justify-end gap-3" }, [
                        createVNode("button", {
                          type: "button",
                          onClick: ($event) => showEmailModal.value = false,
                          class: "rounded border border-gray-300 px-4 py-2 text-gray-700 hover:bg-gray-50"
                        }, " Cancel ", 8, ["onClick"]),
                        createVNode("button", {
                          type: "submit",
                          disabled: unref(emailForm).processing,
                          class: "rounded bg-green-600 px-4 py-2 text-white hover:bg-green-700 disabled:opacity-50"
                        }, toDisplayString(unref(emailForm).processing ? "Sending..." : "Send Email"), 9, ["disabled"])
                      ])
                    ], 32)
                  ])
                ])
              ])) : createCommentVNode("", true),
              showResultDialog.value ? (openBlock(), createBlock("div", {
                key: 1,
                class: "fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50"
              }, [
                createVNode("div", { class: "relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white" }, [
                  createVNode("div", { class: "mt-3" }, [
                    createVNode("h3", { class: "text-lg font-medium text-gray-900 mb-2 text-center" }, toDisplayString(emailResult.value.success ? "Email Sent Successfully!" : "Email Failed to Send"), 1),
                    createVNode("div", { class: "text-center" }, [
                      emailResult.value.success ? (openBlock(), createBlock("p", {
                        key: 0,
                        class: "text-sm text-gray-600 mb-4"
                      }, [
                        createTextVNode(" The quote has been sent to "),
                        createVNode("strong", null, toDisplayString(emailResult.value.email), 1)
                      ])) : (openBlock(), createBlock("p", {
                        key: 1,
                        class: "text-sm text-red-600 mb-4"
                      }, toDisplayString(emailResult.value.message), 1))
                    ]),
                    createVNode("div", { class: "flex justify-center" }, [
                      createVNode("button", {
                        onClick: ($event) => showResultDialog.value = false,
                        class: ["rounded-md px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2", emailResult.value.success ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500"]
                      }, toDisplayString(emailResult.value.success ? "Great!" : "Try Again"), 11, ["onClick"])
                    ])
                  ])
                ])
              ])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/quotes/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
