import { defineComponent, unref, withCtx, createTextVNode, createVNode, withModifiers, withDirectives, vModelText, vModelCheckbox, createBlock, openBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrIncludeBooleanAttr, ssrLooseContain, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { g as groups } from "./index-TOLxu5Uw.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const modules = [
  { key: "customers", label: "Customers" },
  { key: "users", label: "Users" },
  { key: "groups", label: "Groups" },
  { key: "contacts", label: "Contacts" },
  { key: "products", label: "Products & Services" },
  { key: "jobcards", label: "Jobcards" },
  { key: "quotes", label: "Quotes" },
  { key: "invoices", label: "Invoices" }
];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    group: {}
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      name: props.group.name,
      description: props.group.description || "",
      is_administrator: props.group.is_administrator || false,
      permissions: modules.map((m) => {
        const existing = props.group.permissions.find((p) => p.module === m.key) || {};
        return {
          module: m.key,
          can_view: !!existing.can_view,
          can_list: !!existing.can_list,
          can_create: !!existing.can_create,
          can_edit: !!existing.can_edit,
          can_delete: !!existing.can_delete,
          can_edit_completed: !!existing.can_edit_completed,
          can_edit_salesperson: !!existing.can_edit_salesperson
        };
      })
    });
    function saveDetails() {
      form.put(groups.update(props.group.id).url, { preserveScroll: true });
    }
    function savePermissions() {
      form.transform((d) => ({ permissions: d.permissions })).put(groups.permissions(props.group.id).url, { preserveScroll: true });
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Edit ${props.group.name}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [{ title: "Groups", href: unref(groups).index().url }, { title: "Edit", href: "#" }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="space-y-6 p-4"${_scopeId}><form class="space-y-4"${_scopeId}><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Name</span><input${ssrRenderAttr("value", unref(form).name)} class="w-full rounded border px-3 py-2" required${_scopeId}></label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Description</span><textarea class="w-full rounded border px-3 py-2" rows="3"${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea></label><label class="flex items-center space-x-2"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_administrator) ? ssrLooseContain(unref(form).is_administrator, null) : unref(form).is_administrator) ? " checked" : ""} class="rounded border-gray-300"${_scopeId}><span class="text-sm font-medium"${_scopeId}>Administrator Group</span></label><p class="text-xs text-gray-600"${_scopeId}> Administrator groups have access to all administration functions and system settings. </p><button${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="rounded bg-blue-600 px-4 py-2 text-white"${_scopeId}>Save Details</button></form><div class="rounded border"${_scopeId}><div class="border-b p-3 font-medium"${_scopeId}>Permissions</div><form class="space-y-3 p-3"${_scopeId}><table class="min-w-full"${_scopeId}><thead${_scopeId}><tr class="text-left"${_scopeId}><th class="p-2"${_scopeId}>Module</th><th class="p-2"${_scopeId}>List</th><th class="p-2"${_scopeId}>View</th><th class="p-2"${_scopeId}>Create</th><th class="p-2"${_scopeId}>Edit</th><th class="p-2"${_scopeId}>Delete</th><th class="p-2"${_scopeId}>Edit Completed</th><th class="p-2"${_scopeId}>Edit Salesperson</th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(unref(form).permissions, (perm, i) => {
              _push2(`<tr class="border-t"${_scopeId}><td class="p-2"${_scopeId}>${ssrInterpolate(unref(modules).find((m) => m.key === perm.module)?.label)}</td><td class="p-2"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).permissions[i].can_list) ? ssrLooseContain(unref(form).permissions[i].can_list, null) : unref(form).permissions[i].can_list) ? " checked" : ""}${_scopeId}></td><td class="p-2"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).permissions[i].can_view) ? ssrLooseContain(unref(form).permissions[i].can_view, null) : unref(form).permissions[i].can_view) ? " checked" : ""}${_scopeId}></td><td class="p-2"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).permissions[i].can_create) ? ssrLooseContain(unref(form).permissions[i].can_create, null) : unref(form).permissions[i].can_create) ? " checked" : ""}${_scopeId}></td><td class="p-2"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).permissions[i].can_edit) ? ssrLooseContain(unref(form).permissions[i].can_edit, null) : unref(form).permissions[i].can_edit) ? " checked" : ""}${_scopeId}></td><td class="p-2"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).permissions[i].can_delete) ? ssrLooseContain(unref(form).permissions[i].can_delete, null) : unref(form).permissions[i].can_delete) ? " checked" : ""}${_scopeId}></td><td class="p-2"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).permissions[i].can_edit_completed) ? ssrLooseContain(unref(form).permissions[i].can_edit_completed, null) : unref(form).permissions[i].can_edit_completed) ? " checked" : ""}${ssrIncludeBooleanAttr(!["jobcards", "invoices", "quotes"].includes(perm.module)) ? " disabled" : ""} class="${ssrRenderClass({ "opacity-50 cursor-not-allowed": !["jobcards", "invoices", "quotes"].includes(perm.module) })}"${_scopeId}></td><td class="p-2"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).permissions[i].can_edit_salesperson) ? ssrLooseContain(unref(form).permissions[i].can_edit_salesperson, null) : unref(form).permissions[i].can_edit_salesperson) ? " checked" : ""}${ssrIncludeBooleanAttr(perm.module !== "invoices") ? " disabled" : ""} class="${ssrRenderClass({ "opacity-50 cursor-not-allowed": perm.module !== "invoices" })}"${_scopeId}></td></tr>`);
            });
            _push2(`<!--]--></tbody></table><div${_scopeId}><button${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="rounded bg-blue-600 px-4 py-2 text-white"${_scopeId}>Save Permissions</button>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(groups).index().url,
              class: "ml-3 rounded border px-4 py-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Back`);
                } else {
                  return [
                    createTextVNode("Back")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form></div></div>`);
          } else {
            return [
              createVNode("div", { class: "space-y-6 p-4" }, [
                createVNode("form", {
                  onSubmit: withModifiers(saveDetails, ["prevent"]),
                  class: "space-y-4"
                }, [
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Name"),
                    withDirectives(createVNode("input", {
                      "onUpdate:modelValue": ($event) => unref(form).name = $event,
                      class: "w-full rounded border px-3 py-2",
                      required: ""
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).name]
                    ])
                  ]),
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Description"),
                    withDirectives(createVNode("textarea", {
                      "onUpdate:modelValue": ($event) => unref(form).description = $event,
                      class: "w-full rounded border px-3 py-2",
                      rows: "3"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).description]
                    ])
                  ]),
                  createVNode("label", { class: "flex items-center space-x-2" }, [
                    withDirectives(createVNode("input", {
                      type: "checkbox",
                      "onUpdate:modelValue": ($event) => unref(form).is_administrator = $event,
                      class: "rounded border-gray-300"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelCheckbox, unref(form).is_administrator]
                    ]),
                    createVNode("span", { class: "text-sm font-medium" }, "Administrator Group")
                  ]),
                  createVNode("p", { class: "text-xs text-gray-600" }, " Administrator groups have access to all administration functions and system settings. "),
                  createVNode("button", {
                    disabled: unref(form).processing,
                    class: "rounded bg-blue-600 px-4 py-2 text-white"
                  }, "Save Details", 8, ["disabled"])
                ], 32),
                createVNode("div", { class: "rounded border" }, [
                  createVNode("div", { class: "border-b p-3 font-medium" }, "Permissions"),
                  createVNode("form", {
                    onSubmit: withModifiers(savePermissions, ["prevent"]),
                    class: "space-y-3 p-3"
                  }, [
                    createVNode("table", { class: "min-w-full" }, [
                      createVNode("thead", null, [
                        createVNode("tr", { class: "text-left" }, [
                          createVNode("th", { class: "p-2" }, "Module"),
                          createVNode("th", { class: "p-2" }, "List"),
                          createVNode("th", { class: "p-2" }, "View"),
                          createVNode("th", { class: "p-2" }, "Create"),
                          createVNode("th", { class: "p-2" }, "Edit"),
                          createVNode("th", { class: "p-2" }, "Delete"),
                          createVNode("th", { class: "p-2" }, "Edit Completed"),
                          createVNode("th", { class: "p-2" }, "Edit Salesperson")
                        ])
                      ]),
                      createVNode("tbody", null, [
                        (openBlock(true), createBlock(Fragment, null, renderList(unref(form).permissions, (perm, i) => {
                          return openBlock(), createBlock("tr", {
                            key: perm.module,
                            class: "border-t"
                          }, [
                            createVNode("td", { class: "p-2" }, toDisplayString(unref(modules).find((m) => m.key === perm.module)?.label), 1),
                            createVNode("td", { class: "p-2" }, [
                              withDirectives(createVNode("input", {
                                type: "checkbox",
                                "onUpdate:modelValue": ($event) => unref(form).permissions[i].can_list = $event
                              }, null, 8, ["onUpdate:modelValue"]), [
                                [vModelCheckbox, unref(form).permissions[i].can_list]
                              ])
                            ]),
                            createVNode("td", { class: "p-2" }, [
                              withDirectives(createVNode("input", {
                                type: "checkbox",
                                "onUpdate:modelValue": ($event) => unref(form).permissions[i].can_view = $event
                              }, null, 8, ["onUpdate:modelValue"]), [
                                [vModelCheckbox, unref(form).permissions[i].can_view]
                              ])
                            ]),
                            createVNode("td", { class: "p-2" }, [
                              withDirectives(createVNode("input", {
                                type: "checkbox",
                                "onUpdate:modelValue": ($event) => unref(form).permissions[i].can_create = $event
                              }, null, 8, ["onUpdate:modelValue"]), [
                                [vModelCheckbox, unref(form).permissions[i].can_create]
                              ])
                            ]),
                            createVNode("td", { class: "p-2" }, [
                              withDirectives(createVNode("input", {
                                type: "checkbox",
                                "onUpdate:modelValue": ($event) => unref(form).permissions[i].can_edit = $event
                              }, null, 8, ["onUpdate:modelValue"]), [
                                [vModelCheckbox, unref(form).permissions[i].can_edit]
                              ])
                            ]),
                            createVNode("td", { class: "p-2" }, [
                              withDirectives(createVNode("input", {
                                type: "checkbox",
                                "onUpdate:modelValue": ($event) => unref(form).permissions[i].can_delete = $event
                              }, null, 8, ["onUpdate:modelValue"]), [
                                [vModelCheckbox, unref(form).permissions[i].can_delete]
                              ])
                            ]),
                            createVNode("td", { class: "p-2" }, [
                              withDirectives(createVNode("input", {
                                type: "checkbox",
                                "onUpdate:modelValue": ($event) => unref(form).permissions[i].can_edit_completed = $event,
                                disabled: !["jobcards", "invoices", "quotes"].includes(perm.module),
                                class: { "opacity-50 cursor-not-allowed": !["jobcards", "invoices", "quotes"].includes(perm.module) }
                              }, null, 10, ["onUpdate:modelValue", "disabled"]), [
                                [vModelCheckbox, unref(form).permissions[i].can_edit_completed]
                              ])
                            ]),
                            createVNode("td", { class: "p-2" }, [
                              withDirectives(createVNode("input", {
                                type: "checkbox",
                                "onUpdate:modelValue": ($event) => unref(form).permissions[i].can_edit_salesperson = $event,
                                disabled: perm.module !== "invoices",
                                class: { "opacity-50 cursor-not-allowed": perm.module !== "invoices" }
                              }, null, 10, ["onUpdate:modelValue", "disabled"]), [
                                [vModelCheckbox, unref(form).permissions[i].can_edit_salesperson]
                              ])
                            ])
                          ]);
                        }), 128))
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("button", {
                        disabled: unref(form).processing,
                        class: "rounded bg-blue-600 px-4 py-2 text-white"
                      }, "Save Permissions", 8, ["disabled"]),
                      createVNode(unref(Link), {
                        href: unref(groups).index().url,
                        class: "ml-3 rounded border px-4 py-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Back")
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ])
                  ], 32)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/groups/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
