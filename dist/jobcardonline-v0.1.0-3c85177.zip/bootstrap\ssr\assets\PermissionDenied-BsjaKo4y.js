import { defineComponent, unref, withCtx, createVNode, createTextVNode, toDisplayString, createBlock, createCommentVNode, openBlock, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import { Head, Link } from "@inertiajs/vue3";
import { ShieldX, ArrowLeft } from "lucide-vue-next";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PermissionDenied",
  __ssrInlineRender: true,
  props: {
    module: {},
    ability: {},
    message: {},
    user: {},
    requestedUrl: {}
  },
  setup(__props) {
    const props = __props;
    const getModuleDisplayName = (module) => {
      const moduleNames = {
        "customers": "Customers",
        "users": "Users",
        "groups": "Groups",
        "contacts": "Contacts",
        "products": "Products & Services",
        "jobcards": "Jobcards",
        "quotes": "Quotes",
        "invoices": "Invoices"
      };
      return moduleNames[module] || module.charAt(0).toUpperCase() + module.slice(1);
    };
    const getAbilityDisplayName = (ability) => {
      const abilityNames = {
        "list": "view the list of",
        "view": "view",
        "create": "create",
        "edit": "edit",
        "delete": "delete",
        "edit_completed": "edit completed",
        "edit_salesperson": "edit salesperson"
      };
      return abilityNames[ability] || ability;
    };
    const moduleDisplayName = getModuleDisplayName(props.module);
    const abilityDisplayName = getAbilityDisplayName(props.ability);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Access Denied" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex min-h-[60vh] items-center justify-center p-4"${_scopeId}><div class="max-w-md text-center"${_scopeId}><div class="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-red-100"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ShieldX), { class: "h-10 w-10 text-red-600" }, null, _parent2, _scopeId));
            _push2(`</div><h1 class="mb-4 text-2xl font-bold text-gray-900"${_scopeId}>Access Denied</h1><p class="mb-6 text-gray-600"${_scopeId}> You don&#39;t have permission to ${ssrInterpolate(unref(abilityDisplayName))} ${ssrInterpolate(unref(moduleDisplayName))}. </p><div class="mb-8 rounded-lg bg-yellow-50 border border-yellow-200 p-4"${_scopeId}><p class="text-sm text-yellow-800"${_scopeId}><strong${_scopeId}>Need access?</strong> Contact your administrator to request permission for this feature. </p></div><div class="flex flex-col gap-3 sm:flex-row sm:justify-center"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: "/dashboard",
              class: "inline-flex items-center justify-center rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(ArrowLeft), { class: "mr-2 h-4 w-4" }, null, _parent3, _scopeId2));
                  _push3(` Go to Dashboard `);
                } else {
                  return [
                    createVNode(unref(ArrowLeft), { class: "mr-2 h-4 w-4" }),
                    createTextVNode(" Go to Dashboard ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<button class="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"${_scopeId}> Try Again </button></div><details class="mt-8 text-left"${_scopeId}><summary class="cursor-pointer text-sm text-gray-500 hover:text-gray-700"${_scopeId}> Technical Details </summary><div class="mt-2 rounded bg-gray-100 p-3 text-xs text-gray-600"${_scopeId}><p${_scopeId}><strong${_scopeId}>Module:</strong> ${ssrInterpolate(_ctx.module)}</p><p${_scopeId}><strong${_scopeId}>Ability:</strong> ${ssrInterpolate(_ctx.ability)}</p><p${_scopeId}><strong${_scopeId}>Message:</strong> ${ssrInterpolate(_ctx.message)}</p>`);
            if (_ctx.requestedUrl) {
              _push2(`<p${_scopeId}><strong${_scopeId}>Requested URL:</strong> ${ssrInterpolate(_ctx.requestedUrl)}</p>`);
            } else {
              _push2(`<!---->`);
            }
            if (_ctx.user) {
              _push2(`<p${_scopeId}><strong${_scopeId}>User:</strong> ${ssrInterpolate(_ctx.user.name)} (${ssrInterpolate(_ctx.user.email)})</p>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></details></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex min-h-[60vh] items-center justify-center p-4" }, [
                createVNode("div", { class: "max-w-md text-center" }, [
                  createVNode("div", { class: "mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-red-100" }, [
                    createVNode(unref(ShieldX), { class: "h-10 w-10 text-red-600" })
                  ]),
                  createVNode("h1", { class: "mb-4 text-2xl font-bold text-gray-900" }, "Access Denied"),
                  createVNode("p", { class: "mb-6 text-gray-600" }, " You don't have permission to " + toDisplayString(unref(abilityDisplayName)) + " " + toDisplayString(unref(moduleDisplayName)) + ". ", 1),
                  createVNode("div", { class: "mb-8 rounded-lg bg-yellow-50 border border-yellow-200 p-4" }, [
                    createVNode("p", { class: "text-sm text-yellow-800" }, [
                      createVNode("strong", null, "Need access?"),
                      createTextVNode(" Contact your administrator to request permission for this feature. ")
                    ])
                  ]),
                  createVNode("div", { class: "flex flex-col gap-3 sm:flex-row sm:justify-center" }, [
                    createVNode(unref(Link), {
                      href: "/dashboard",
                      class: "inline-flex items-center justify-center rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(ArrowLeft), { class: "mr-2 h-4 w-4" }),
                        createTextVNode(" Go to Dashboard ")
                      ]),
                      _: 1
                    }),
                    createVNode("button", {
                      onClick: ($event) => _ctx.$inertia.reload(),
                      class: "inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                    }, " Try Again ", 8, ["onClick"])
                  ]),
                  createVNode("details", { class: "mt-8 text-left" }, [
                    createVNode("summary", { class: "cursor-pointer text-sm text-gray-500 hover:text-gray-700" }, " Technical Details "),
                    createVNode("div", { class: "mt-2 rounded bg-gray-100 p-3 text-xs text-gray-600" }, [
                      createVNode("p", null, [
                        createVNode("strong", null, "Module:"),
                        createTextVNode(" " + toDisplayString(_ctx.module), 1)
                      ]),
                      createVNode("p", null, [
                        createVNode("strong", null, "Ability:"),
                        createTextVNode(" " + toDisplayString(_ctx.ability), 1)
                      ]),
                      createVNode("p", null, [
                        createVNode("strong", null, "Message:"),
                        createTextVNode(" " + toDisplayString(_ctx.message), 1)
                      ]),
                      _ctx.requestedUrl ? (openBlock(), createBlock("p", { key: 0 }, [
                        createVNode("strong", null, "Requested URL:"),
                        createTextVNode(" " + toDisplayString(_ctx.requestedUrl), 1)
                      ])) : createCommentVNode("", true),
                      _ctx.user ? (openBlock(), createBlock("p", { key: 1 }, [
                        createVNode("strong", null, "User:"),
                        createTextVNode(" " + toDisplayString(_ctx.user.name) + " (" + toDisplayString(_ctx.user.email) + ")", 1)
                      ])) : createCommentVNode("", true)
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/Errors/PermissionDenied.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
