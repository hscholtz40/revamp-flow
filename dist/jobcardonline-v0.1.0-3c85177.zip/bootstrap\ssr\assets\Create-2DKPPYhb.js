import { defineComponent, unref, withCtx, createVNode, createTextVNode, withModifiers, withDirectives, createBlock, createCommentVNode, vModelText, openBlock, toDisplayString, Fragment, renderList, vModelRadio, vModelCheckbox, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrRenderClass, ssrRenderStyle, ssrIncludeBooleanAttr, ssrLooseEqual, ssrLooseContain } from "vue/server-renderer";
import { _ as _sfc_main$1, a as administration } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { ArrowLeft } from "lucide-vue-next";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Create",
  __ssrInlineRender: true,
  setup(__props) {
    const form = useForm({
      name: "",
      description: "",
      color: "#3B82F6",
      is_active: true,
      sort_order: 0
    });
    const colorOptions = [
      { name: "Blue", value: "#3B82F6" },
      { name: "Green", value: "#10B981" },
      { name: "Yellow", value: "#F59E0B" },
      { name: "Purple", value: "#8B5CF6" },
      { name: "Cyan", value: "#06B6D4" },
      { name: "Lime", value: "#84CC16" },
      { name: "Orange", value: "#F97316" },
      { name: "Pink", value: "#EC4899" },
      { name: "Red", value: "#EF4444" },
      { name: "Indigo", value: "#6366F1" }
    ];
    function submit() {
      form.post(administration.categories.store().url);
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Create Category" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Administration", href: unref(administration).index().url },
          { title: "Categories", href: unref(administration).categories.index().url },
          { title: "Create", href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-4"${_scopeId}><div class="mb-6 flex items-center gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(administration).categories.index().url,
              class: "flex items-center gap-2 text-gray-600 hover:text-gray-900"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(ArrowLeft), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                  _push3(` Back to Categories `);
                } else {
                  return [
                    createVNode(unref(ArrowLeft), { class: "h-4 w-4" }),
                    createTextVNode(" Back to Categories ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="mx-auto max-w-2xl"${_scopeId}><div class="mb-6"${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>Create New Category</h1><p class="text-gray-600"${_scopeId}>Add a new category for organizing products and services</p></div><form class="space-y-6"${_scopeId}><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Basic Information</h2><div class="space-y-6"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Name * </label><input${ssrRenderAttr("value", unref(form).name)} type="text" required class="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}>`);
            if (unref(form).errors.name) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.name)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Description </label><textarea rows="3" class="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea>`);
            if (unref(form).errors.description) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.description)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Appearance</h2><div class="space-y-6"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Color * </label><div class="mt-2 grid grid-cols-5 gap-3"${_scopeId}><!--[-->`);
            ssrRenderList(colorOptions, (color) => {
              _push2(`<label class="relative cursor-pointer"${_scopeId}><input${ssrIncludeBooleanAttr(ssrLooseEqual(unref(form).color, color.value)) ? " checked" : ""} type="radio"${ssrRenderAttr("value", color.value)} class="sr-only"${_scopeId}><div class="${ssrRenderClass([
                "flex h-12 w-full items-center justify-center rounded-lg border-2",
                unref(form).color === color.value ? "border-gray-900" : "border-gray-300 hover:border-gray-400"
              ])}" style="${ssrRenderStyle({ backgroundColor: color.value })}"${_scopeId}><span class="text-xs font-medium text-white mix-blend-difference"${_scopeId}>${ssrInterpolate(color.name)}</span></div></label>`);
            });
            _push2(`<!--]--></div>`);
            if (unref(form).errors.color) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.color)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="rounded-lg border bg-white p-6"${_scopeId}><h2 class="mb-4 text-lg font-semibold text-gray-900"${_scopeId}>Settings</h2><div class="space-y-6"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}> Sort Order </label><input${ssrRenderAttr("value", unref(form).sort_order)} type="number" min="0" class="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"${_scopeId}><p class="mt-1 text-sm text-gray-500"${_scopeId}>Lower numbers appear first in lists</p>`);
            if (unref(form).errors.sort_order) {
              _push2(`<div class="mt-1 text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.sort_order)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><label class="flex items-center gap-2"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, null) : unref(form).is_active) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"${_scopeId}><span class="text-sm font-medium text-gray-700"${_scopeId}>Active (available for selection)</span></label></div></div></div><div class="flex items-center justify-end gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(administration).categories.index().url,
              class: "rounded-md border border-gray-300 px-4 py-2 text-gray-700 hover:bg-gray-50"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Cancel `);
                } else {
                  return [
                    createTextVNode(" Cancel ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(form).processing ? "Creating..." : "Create Category")}</button></div></form></div></div>`);
          } else {
            return [
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "mb-6 flex items-center gap-4" }, [
                  createVNode(unref(Link), {
                    href: unref(administration).categories.index().url,
                    class: "flex items-center gap-2 text-gray-600 hover:text-gray-900"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(ArrowLeft), { class: "h-4 w-4" }),
                      createTextVNode(" Back to Categories ")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ]),
                createVNode("div", { class: "mx-auto max-w-2xl" }, [
                  createVNode("div", { class: "mb-6" }, [
                    createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "Create New Category"),
                    createVNode("p", { class: "text-gray-600" }, "Add a new category for organizing products and services")
                  ]),
                  createVNode("form", {
                    onSubmit: withModifiers(submit, ["prevent"]),
                    class: "space-y-6"
                  }, [
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Basic Information"),
                      createVNode("div", { class: "space-y-6" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Name * "),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            type: "text",
                            required: "",
                            class: "mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).name]
                          ]),
                          unref(form).errors.name ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.name), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Description "),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => unref(form).description = $event,
                            rows: "3",
                            class: "mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).description]
                          ]),
                          unref(form).errors.description ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.description), 1)) : createCommentVNode("", true)
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Appearance"),
                      createVNode("div", { class: "space-y-6" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Color * "),
                          createVNode("div", { class: "mt-2 grid grid-cols-5 gap-3" }, [
                            (openBlock(), createBlock(Fragment, null, renderList(colorOptions, (color) => {
                              return createVNode("label", {
                                key: color.value,
                                class: "relative cursor-pointer"
                              }, [
                                withDirectives(createVNode("input", {
                                  "onUpdate:modelValue": ($event) => unref(form).color = $event,
                                  type: "radio",
                                  value: color.value,
                                  class: "sr-only"
                                }, null, 8, ["onUpdate:modelValue", "value"]), [
                                  [vModelRadio, unref(form).color]
                                ]),
                                createVNode("div", {
                                  class: [
                                    "flex h-12 w-full items-center justify-center rounded-lg border-2",
                                    unref(form).color === color.value ? "border-gray-900" : "border-gray-300 hover:border-gray-400"
                                  ],
                                  style: { backgroundColor: color.value }
                                }, [
                                  createVNode("span", { class: "text-xs font-medium text-white mix-blend-difference" }, toDisplayString(color.name), 1)
                                ], 6)
                              ]);
                            }), 64))
                          ]),
                          unref(form).errors.color ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.color), 1)) : createCommentVNode("", true)
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg border bg-white p-6" }, [
                      createVNode("h2", { class: "mb-4 text-lg font-semibold text-gray-900" }, "Settings"),
                      createVNode("div", { class: "space-y-6" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-700" }, " Sort Order "),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => unref(form).sort_order = $event,
                            type: "number",
                            min: "0",
                            class: "mt-1 w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).sort_order]
                          ]),
                          createVNode("p", { class: "mt-1 text-sm text-gray-500" }, "Lower numbers appear first in lists"),
                          unref(form).errors.sort_order ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mt-1 text-sm text-red-600"
                          }, toDisplayString(unref(form).errors.sort_order), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "flex items-center gap-2" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => unref(form).is_active = $event,
                              type: "checkbox",
                              class: "rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelCheckbox, unref(form).is_active]
                            ]),
                            createVNode("span", { class: "text-sm font-medium text-gray-700" }, "Active (available for selection)")
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "flex items-center justify-end gap-4" }, [
                      createVNode(unref(Link), {
                        href: unref(administration).categories.index().url,
                        class: "rounded-md border border-gray-300 px-4 py-2 text-gray-700 hover:bg-gray-50"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Cancel ")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createVNode("button", {
                        type: "submit",
                        disabled: unref(form).processing,
                        class: "rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 disabled:opacity-50"
                      }, toDisplayString(unref(form).processing ? "Creating..." : "Create Category"), 9, ["disabled"])
                    ])
                  ], 32)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/administration/categories/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
