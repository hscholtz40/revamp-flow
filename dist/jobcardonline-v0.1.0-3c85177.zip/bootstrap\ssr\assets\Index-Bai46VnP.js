import { defineComponent, ref, watch, unref, withCtx, createTextVNode, createVNode, toDisplayString, withDirectives, vModelText, vModelSelect, createBlock, openBlock, Fragment, renderList, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import { q as quotes, _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import { router, Head, Link } from "@inertiajs/vue3";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    quotes: {},
    customers: {},
    filters: {},
    currentCompany: {},
    canEditCompleted: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const search = ref(props.filters.search);
    const status = ref(props.filters.status);
    const customerId = ref(props.filters.customer_id);
    const canEditQuote = (quote) => {
      if (quote.status !== "accepted") {
        return true;
      }
      return props.canEditCompleted;
    };
    const canDeleteQuote = (quote) => {
      if (quote.status !== "accepted") {
        return true;
      }
      return props.canEditCompleted;
    };
    const clearFilters = () => {
      search.value = "";
      status.value = "";
      customerId.value = "";
    };
    const deleteQuote = (quote) => {
      if (confirm(`Are you sure you want to delete quote ${quote.quote_number}?`)) {
        router.delete(quotes.destroy(quote.id).url);
      }
    };
    const getStatusBadgeClass = (status2) => {
      const classes = {
        draft: "bg-gray-100 text-gray-800",
        sent: "bg-blue-100 text-blue-800",
        accepted: "bg-green-100 text-green-800",
        rejected: "bg-red-100 text-red-800",
        expired: "bg-yellow-100 text-yellow-800"
      };
      return classes[status2] || "bg-gray-100 text-gray-800";
    };
    const formatDate = (dateString) => {
      return new Date(dateString).toLocaleDateString();
    };
    watch([search, status, customerId], () => {
      router.get(quotes.index().url, {
        search: search.value,
        status: status.value,
        customer_id: customerId.value
      }, {
        preserveState: true,
        replace: true
      });
    }, { debounce: 300 });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Quotes" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [{ title: "Quotes", href: unref(quotes).index().url }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-blue-50 border-b border-blue-200 px-4 py-3"${_scopeId}><div class="flex items-center gap-2 text-sm text-blue-700"${_scopeId}><span class="font-medium"${_scopeId}>Viewing quotes for:</span><span class="font-semibold"${_scopeId}>${ssrInterpolate(props.currentCompany.name)}</span></div></div><div class="p-4"${_scopeId}><div class="flex items-center justify-between gap-3 mb-6"${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>Quotes</h1>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(quotes).create().url,
              class: "rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` New Quote `);
                } else {
                  return [
                    createTextVNode(" New Quote ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="bg-white rounded-lg border p-4 mb-6"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-4 gap-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Search</label><input${ssrRenderAttr("value", search.value)} type="search" placeholder="Search quotes..." class="w-full rounded border px-3 py-2"${_scopeId}></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Status</label><select class="w-full rounded border px-3 py-2"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "") : ssrLooseEqual(status.value, "")) ? " selected" : ""}${_scopeId}>All Statuses</option><option value="draft"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "draft") : ssrLooseEqual(status.value, "draft")) ? " selected" : ""}${_scopeId}>Draft</option><option value="sent"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "sent") : ssrLooseEqual(status.value, "sent")) ? " selected" : ""}${_scopeId}>Sent</option><option value="accepted"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "accepted") : ssrLooseEqual(status.value, "accepted")) ? " selected" : ""}${_scopeId}>Accepted</option><option value="rejected"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "rejected") : ssrLooseEqual(status.value, "rejected")) ? " selected" : ""}${_scopeId}>Rejected</option><option value="expired"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain(status.value, "expired") : ssrLooseEqual(status.value, "expired")) ? " selected" : ""}${_scopeId}>Expired</option></select></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Customer</label><select class="w-full rounded border px-3 py-2"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(customerId.value) ? ssrLooseContain(customerId.value, "") : ssrLooseEqual(customerId.value, "")) ? " selected" : ""}${_scopeId}>All Customers</option><!--[-->`);
            ssrRenderList(props.customers, (customer) => {
              _push2(`<option${ssrRenderAttr("value", customer.id)}${ssrIncludeBooleanAttr(Array.isArray(customerId.value) ? ssrLooseContain(customerId.value, customer.id) : ssrLooseEqual(customerId.value, customer.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(customer.name)}</option>`);
            });
            _push2(`<!--]--></select></div><div class="flex items-end"${_scopeId}><button class="w-full rounded border border-gray-300 px-3 py-2 text-gray-700 hover:bg-gray-50"${_scopeId}> Clear Filters </button></div></div></div><div class="bg-white rounded-lg border overflow-hidden"${_scopeId}><div class="overflow-x-auto"${_scopeId}><table class="w-full"${_scopeId}><thead class="bg-gray-50"${_scopeId}><tr${_scopeId}><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Quote Number </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Title </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Customer </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Status </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Expiry Date </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Total </th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}> Actions </th></tr></thead><tbody class="bg-white divide-y divide-gray-200"${_scopeId}><!--[-->`);
            ssrRenderList(props.quotes.data, (quote) => {
              _push2(`<tr class="hover:bg-gray-50"${_scopeId}><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(quote.quote_number)}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(quote.title)}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(quote.customer?.name)}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><span class="${ssrRenderClass([getStatusBadgeClass(quote.status), "inline-flex px-2 py-1 text-xs font-semibold rounded-full"])}"${_scopeId}>${ssrInterpolate(quote.status.replace("_", " ").toUpperCase())}</span></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(quote.expiry_date ? formatDate(quote.expiry_date) : "-")}</div></td><td class="px-6 py-4 whitespace-nowrap"${_scopeId}><div class="text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(quote.formatted_total)}</div></td><td class="px-6 py-4 whitespace-nowrap text-sm font-medium"${_scopeId}><div class="flex items-center gap-2"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(quotes).show(quote.id).url,
                class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` View `);
                  } else {
                    return [
                      createTextVNode(" View ")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              if (canEditQuote(quote)) {
                _push2(ssrRenderComponent(unref(Link), {
                  href: unref(quotes).edit(quote.id).url,
                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` Edit `);
                    } else {
                      return [
                        createTextVNode(" Edit ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              } else {
                _push2(`<span class="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed" title="Cannot edit accepted quotes without permission"${_scopeId}> Edit </span>`);
              }
              if (canDeleteQuote(quote)) {
                _push2(`<button class="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-red-700 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"${_scopeId}> Delete </button>`);
              } else {
                _push2(`<span class="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed" title="Cannot delete accepted quotes without permission"${_scopeId}> Delete </span>`);
              }
              _push2(`</div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div>`);
            if (props.quotes.links) {
              _push2(`<div class="bg-white px-4 py-3 border-t border-gray-200 sm:px-6"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div class="flex-1 flex justify-between sm:hidden"${_scopeId}>`);
              if (props.quotes.prev_page_url) {
                _push2(ssrRenderComponent(unref(Link), {
                  href: props.quotes.prev_page_url,
                  class: "relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` Previous `);
                    } else {
                      return [
                        createTextVNode(" Previous ")
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              if (props.quotes.next_page_url) {
                _push2(ssrRenderComponent(unref(Link), {
                  href: props.quotes.next_page_url,
                  class: "ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` Next `);
                    } else {
                      return [
                        createTextVNode(" Next ")
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between"${_scopeId}><div${_scopeId}><p class="text-sm text-gray-700"${_scopeId}> Showing <span class="font-medium"${_scopeId}>${ssrInterpolate(props.quotes.from)}</span> to <span class="font-medium"${_scopeId}>${ssrInterpolate(props.quotes.to)}</span> of <span class="font-medium"${_scopeId}>${ssrInterpolate(props.quotes.total)}</span> results </p></div><div${_scopeId}><nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination"${_scopeId}><!--[-->`);
              ssrRenderList(props.quotes.links, (link) => {
                _push2(ssrRenderComponent(unref(Link), {
                  key: link.label,
                  href: link.url || "#",
                  class: [
                    "px-3 py-1 text-sm rounded-md",
                    link.url ? "bg-white text-gray-700 hover:bg-gray-50 border border-gray-300" : "bg-gray-100 text-gray-400 cursor-not-allowed"
                  ]
                }, null, _parent2, _scopeId));
              });
              _push2(`<!--]--></nav></div></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-blue-50 border-b border-blue-200 px-4 py-3" }, [
                createVNode("div", { class: "flex items-center gap-2 text-sm text-blue-700" }, [
                  createVNode("span", { class: "font-medium" }, "Viewing quotes for:"),
                  createVNode("span", { class: "font-semibold" }, toDisplayString(props.currentCompany.name), 1)
                ])
              ]),
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "flex items-center justify-between gap-3 mb-6" }, [
                  createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "Quotes"),
                  createVNode(unref(Link), {
                    href: unref(quotes).create().url,
                    class: "rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" New Quote ")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ]),
                createVNode("div", { class: "bg-white rounded-lg border p-4 mb-6" }, [
                  createVNode("div", { class: "grid grid-cols-1 md:grid-cols-4 gap-4" }, [
                    createVNode("div", null, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Search"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => search.value = $event,
                        type: "search",
                        placeholder: "Search quotes...",
                        class: "w-full rounded border px-3 py-2"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, search.value]
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Status"),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => status.value = $event,
                        class: "w-full rounded border px-3 py-2"
                      }, [
                        createVNode("option", { value: "" }, "All Statuses"),
                        createVNode("option", { value: "draft" }, "Draft"),
                        createVNode("option", { value: "sent" }, "Sent"),
                        createVNode("option", { value: "accepted" }, "Accepted"),
                        createVNode("option", { value: "rejected" }, "Rejected"),
                        createVNode("option", { value: "expired" }, "Expired")
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, status.value]
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Customer"),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => customerId.value = $event,
                        class: "w-full rounded border px-3 py-2"
                      }, [
                        createVNode("option", { value: "" }, "All Customers"),
                        (openBlock(true), createBlock(Fragment, null, renderList(props.customers, (customer) => {
                          return openBlock(), createBlock("option", {
                            key: customer.id,
                            value: customer.id
                          }, toDisplayString(customer.name), 9, ["value"]);
                        }), 128))
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, customerId.value]
                      ])
                    ]),
                    createVNode("div", { class: "flex items-end" }, [
                      createVNode("button", {
                        onClick: clearFilters,
                        class: "w-full rounded border border-gray-300 px-3 py-2 text-gray-700 hover:bg-gray-50"
                      }, " Clear Filters ")
                    ])
                  ])
                ]),
                createVNode("div", { class: "bg-white rounded-lg border overflow-hidden" }, [
                  createVNode("div", { class: "overflow-x-auto" }, [
                    createVNode("table", { class: "w-full" }, [
                      createVNode("thead", { class: "bg-gray-50" }, [
                        createVNode("tr", null, [
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Quote Number "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Title "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Customer "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Status "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Expiry Date "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Total "),
                          createVNode("th", { class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, " Actions ")
                        ])
                      ]),
                      createVNode("tbody", { class: "bg-white divide-y divide-gray-200" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(props.quotes.data, (quote) => {
                          return openBlock(), createBlock("tr", {
                            key: quote.id,
                            class: "hover:bg-gray-50"
                          }, [
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm font-medium text-gray-900" }, toDisplayString(quote.quote_number), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(quote.title), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(quote.customer?.name), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("span", {
                                class: [getStatusBadgeClass(quote.status), "inline-flex px-2 py-1 text-xs font-semibold rounded-full"]
                              }, toDisplayString(quote.status.replace("_", " ").toUpperCase()), 3)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm text-gray-900" }, toDisplayString(quote.expiry_date ? formatDate(quote.expiry_date) : "-"), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap" }, [
                              createVNode("div", { class: "text-sm font-medium text-gray-900" }, toDisplayString(quote.formatted_total), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm font-medium" }, [
                              createVNode("div", { class: "flex items-center gap-2" }, [
                                createVNode(unref(Link), {
                                  href: unref(quotes).show(quote.id).url,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" View ")
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                canEditQuote(quote) ? (openBlock(), createBlock(unref(Link), {
                                  key: 0,
                                  href: unref(quotes).edit(quote.id).url,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Edit ")
                                  ]),
                                  _: 1
                                }, 8, ["href"])) : (openBlock(), createBlock("span", {
                                  key: 1,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed",
                                  title: "Cannot edit accepted quotes without permission"
                                }, " Edit ")),
                                canDeleteQuote(quote) ? (openBlock(), createBlock("button", {
                                  key: 2,
                                  onClick: ($event) => deleteQuote(quote),
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-red-700 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                                }, " Delete ", 8, ["onClick"])) : (openBlock(), createBlock("span", {
                                  key: 3,
                                  class: "inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed",
                                  title: "Cannot delete accepted quotes without permission"
                                }, " Delete "))
                              ])
                            ])
                          ]);
                        }), 128))
                      ])
                    ])
                  ]),
                  props.quotes.links ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "bg-white px-4 py-3 border-t border-gray-200 sm:px-6"
                  }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", { class: "flex-1 flex justify-between sm:hidden" }, [
                        props.quotes.prev_page_url ? (openBlock(), createBlock(unref(Link), {
                          key: 0,
                          href: props.quotes.prev_page_url,
                          class: "relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Previous ")
                          ]),
                          _: 1
                        }, 8, ["href"])) : createCommentVNode("", true),
                        props.quotes.next_page_url ? (openBlock(), createBlock(unref(Link), {
                          key: 1,
                          href: props.quotes.next_page_url,
                          class: "ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Next ")
                          ]),
                          _: 1
                        }, 8, ["href"])) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "hidden sm:flex-1 sm:flex sm:items-center sm:justify-between" }, [
                        createVNode("div", null, [
                          createVNode("p", { class: "text-sm text-gray-700" }, [
                            createTextVNode(" Showing "),
                            createVNode("span", { class: "font-medium" }, toDisplayString(props.quotes.from), 1),
                            createTextVNode(" to "),
                            createVNode("span", { class: "font-medium" }, toDisplayString(props.quotes.to), 1),
                            createTextVNode(" of "),
                            createVNode("span", { class: "font-medium" }, toDisplayString(props.quotes.total), 1),
                            createTextVNode(" results ")
                          ])
                        ]),
                        createVNode("div", null, [
                          createVNode("nav", {
                            class: "relative z-0 inline-flex rounded-md shadow-sm -space-x-px",
                            "aria-label": "Pagination"
                          }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(props.quotes.links, (link) => {
                              return openBlock(), createBlock(unref(Link), {
                                key: link.label,
                                href: link.url || "#",
                                innerHTML: link.label,
                                class: [
                                  "px-3 py-1 text-sm rounded-md",
                                  link.url ? "bg-white text-gray-700 hover:bg-gray-50 border border-gray-300" : "bg-gray-100 text-gray-400 cursor-not-allowed"
                                ]
                              }, null, 8, ["href", "innerHTML", "class"]);
                            }), 128))
                          ])
                        ])
                      ])
                    ])
                  ])) : createCommentVNode("", true)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/quotes/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
