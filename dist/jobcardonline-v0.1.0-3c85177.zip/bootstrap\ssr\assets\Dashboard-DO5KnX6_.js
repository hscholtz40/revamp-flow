import { defineComponent, unref, withCtx, createTextVNode, createVNode, toDisplayString, createBlock, openBlock, Fragment, renderList, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderStyle, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1, q as quotes, i as invoices, b as customers } from "./AppLayout-CmGu2Oww.js";
import { d as dashboard, _ as _sfc_main$7 } from "./Footer-Ce4AN4A5.js";
import { j as jobcards, _ as _export_sfc } from "./_plugin-vue_export-helper-BjD8VFd3.js";
import { Head, Link } from "@inertiajs/vue3";
import { _ as _sfc_main$2, a as _sfc_main$3, b as _sfc_main$4, c as _sfc_main$5, d as _sfc_main$6, e as _sfc_main$8 } from "./index-CaDnlGjE.js";
import { FileText, Receipt, Wrench, UserPlus, TrendingUp } from "lucide-vue-next";
import "class-variance-authority";
import "reka-ui";
import "@vueuse/core";
import "./Input-CBU-ZeCu.js";
import "./index--D7ld9AJ.js";
import "clsx";
import "tailwind-merge";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Dashboard",
  __ssrInlineRender: true,
  props: {
    stats: {},
    revenueStats: {},
    userMonthlyRevenue: {},
    recentActivity: {},
    overdueItems: {},
    lowStockProducts: {},
    topCustomers: {},
    monthlyRevenue: {},
    statusCharts: {},
    currentCompany: {}
  },
  setup(__props) {
    const props = __props;
    const breadcrumbs = [
      {
        title: "Dashboard",
        href: dashboard().url
      }
    ];
    const formatCurrency = (amount) => {
      return new Intl.NumberFormat("en-ZA", {
        style: "currency",
        currency: "ZAR"
      }).format(amount);
    };
    const getBarHeight = (revenue) => {
      if (!props.userMonthlyRevenue || props.userMonthlyRevenue.length === 0) return 8;
      const maxRevenue = Math.max(...props.userMonthlyRevenue.map((item) => item.revenue));
      if (maxRevenue === 0) return 8;
      if (revenue === 0) return 8;
      const maxHeight = 100;
      const height = revenue / maxRevenue * maxHeight;
      return Math.max(height, 8);
    };
    const getStatusColor = (status) => {
      switch (status?.toLowerCase()) {
        case "paid":
          return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300";
        case "pending":
          return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300";
        case "overdue":
          return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300";
        case "draft":
          return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300";
        default:
          return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300";
      }
    };
    const createPieChartPath = (data, colors, labels) => {
      const total = data.reduce((sum, item) => sum + item, 0);
      if (total === 0) return [];
      const radius = 45;
      const centerX = 50;
      const centerY = 50;
      const innerRadius = 15;
      let currentAngle = -90;
      return data.map((value, index) => {
        if (value === 0) return null;
        const percentage = value / total;
        const angle = percentage * 360;
        const startAngle = currentAngle;
        const endAngle = currentAngle + angle;
        if (angle >= 360) {
          const pathData2 = [
            `M ${centerX} ${centerY - radius}`,
            `A ${radius} ${radius} 0 1 1 ${centerX} ${centerY + radius}`,
            `A ${radius} ${radius} 0 1 1 ${centerX} ${centerY - radius}`,
            `M ${centerX} ${centerY - innerRadius}`,
            `A ${innerRadius} ${innerRadius} 0 1 0 ${centerX} ${centerY + innerRadius}`,
            `A ${innerRadius} ${innerRadius} 0 1 0 ${centerX} ${centerY - innerRadius}`,
            "Z"
          ].join(" ");
          return {
            path: pathData2,
            color: colors[index],
            value,
            label: labels[index],
            percentage: Math.round(percentage * 100)
          };
        }
        const x1 = centerX + radius * Math.cos(startAngle * Math.PI / 180);
        const y1 = centerY + radius * Math.sin(startAngle * Math.PI / 180);
        const x2 = centerX + radius * Math.cos(endAngle * Math.PI / 180);
        const y2 = centerY + radius * Math.sin(endAngle * Math.PI / 180);
        const x3 = centerX + innerRadius * Math.cos(endAngle * Math.PI / 180);
        const y3 = centerY + innerRadius * Math.sin(endAngle * Math.PI / 180);
        const x4 = centerX + innerRadius * Math.cos(startAngle * Math.PI / 180);
        const y4 = centerY + innerRadius * Math.sin(startAngle * Math.PI / 180);
        const largeArcFlag = angle > 180 ? 1 : 0;
        const pathData = [
          `M ${x1} ${y1}`,
          `A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2}`,
          `L ${x3} ${y3}`,
          `A ${innerRadius} ${innerRadius} 0 ${largeArcFlag} 0 ${x4} ${y4}`,
          "Z"
        ].join(" ");
        currentAngle += angle;
        return {
          path: pathData,
          color: colors[index],
          value,
          label: labels[index],
          percentage: Math.round(percentage * 100)
        };
      }).filter(Boolean);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, { breadcrumbs }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex h-full flex-1 flex-col gap-6 overflow-x-auto p-6" data-v-034be482${_scopeId}><div class="flex items-center justify-between" data-v-034be482${_scopeId}><div data-v-034be482${_scopeId}><h1 class="text-3xl font-bold tracking-tight" data-v-034be482${_scopeId}>Dashboard</h1><p class="text-muted-foreground" data-v-034be482${_scopeId}> Welcome back! Here&#39;s what&#39;s happening with your business. </p></div></div>`);
            _push2(ssrRenderComponent(unref(_sfc_main$2), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(_sfc_main$3), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(_sfc_main$4), null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Quick Actions`);
                            } else {
                              return [
                                createTextVNode("Quick Actions")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(unref(_sfc_main$5), null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Create new items quickly`);
                            } else {
                              return [
                                createTextVNode("Create new items quickly")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(_sfc_main$4), null, {
                            default: withCtx(() => [
                              createTextVNode("Quick Actions")
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$5), null, {
                            default: withCtx(() => [
                              createTextVNode("Create new items quickly")
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(_sfc_main$6), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="grid gap-2 md:grid-cols-4" data-v-034be482${_scopeId3}>`);
                        _push4(ssrRenderComponent(unref(_sfc_main$7), {
                          "as-child": "",
                          class: "w-full justify-start"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(Link), {
                                href: unref(quotes).create().url
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(unref(FileText), { class: "mr-2 h-4 w-4" }, null, _parent6, _scopeId5));
                                    _push6(` New Quote `);
                                  } else {
                                    return [
                                      createVNode(unref(FileText), { class: "mr-2 h-4 w-4" }),
                                      createTextVNode(" New Quote ")
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(unref(Link), {
                                  href: unref(quotes).create().url
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(FileText), { class: "mr-2 h-4 w-4" }),
                                    createTextVNode(" New Quote ")
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(unref(_sfc_main$7), {
                          "as-child": "",
                          class: "w-full justify-start",
                          variant: "outline"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(Link), {
                                href: unref(invoices).create().url
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(unref(Receipt), { class: "mr-2 h-4 w-4" }, null, _parent6, _scopeId5));
                                    _push6(` New Invoice `);
                                  } else {
                                    return [
                                      createVNode(unref(Receipt), { class: "mr-2 h-4 w-4" }),
                                      createTextVNode(" New Invoice ")
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(unref(Link), {
                                  href: unref(invoices).create().url
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(Receipt), { class: "mr-2 h-4 w-4" }),
                                    createTextVNode(" New Invoice ")
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(unref(_sfc_main$7), {
                          "as-child": "",
                          class: "w-full justify-start",
                          variant: "outline"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(Link), {
                                href: unref(jobcards).create().url
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(unref(Wrench), { class: "mr-2 h-4 w-4" }, null, _parent6, _scopeId5));
                                    _push6(` New Jobcard `);
                                  } else {
                                    return [
                                      createVNode(unref(Wrench), { class: "mr-2 h-4 w-4" }),
                                      createTextVNode(" New Jobcard ")
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(unref(Link), {
                                  href: unref(jobcards).create().url
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(Wrench), { class: "mr-2 h-4 w-4" }),
                                    createTextVNode(" New Jobcard ")
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(unref(_sfc_main$7), {
                          "as-child": "",
                          class: "w-full justify-start",
                          variant: "outline"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(Link), {
                                href: unref(customers).create().url
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(unref(UserPlus), { class: "mr-2 h-4 w-4" }, null, _parent6, _scopeId5));
                                    _push6(` New Customer `);
                                  } else {
                                    return [
                                      createVNode(unref(UserPlus), { class: "mr-2 h-4 w-4" }),
                                      createTextVNode(" New Customer ")
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(unref(Link), {
                                  href: unref(customers).create().url
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(UserPlus), { class: "mr-2 h-4 w-4" }),
                                    createTextVNode(" New Customer ")
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode("div", { class: "grid gap-2 md:grid-cols-4" }, [
                            createVNode(unref(_sfc_main$7), {
                              "as-child": "",
                              class: "w-full justify-start"
                            }, {
                              default: withCtx(() => [
                                createVNode(unref(Link), {
                                  href: unref(quotes).create().url
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(FileText), { class: "mr-2 h-4 w-4" }),
                                    createTextVNode(" New Quote ")
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ]),
                              _: 1
                            }),
                            createVNode(unref(_sfc_main$7), {
                              "as-child": "",
                              class: "w-full justify-start",
                              variant: "outline"
                            }, {
                              default: withCtx(() => [
                                createVNode(unref(Link), {
                                  href: unref(invoices).create().url
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(Receipt), { class: "mr-2 h-4 w-4" }),
                                    createTextVNode(" New Invoice ")
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ]),
                              _: 1
                            }),
                            createVNode(unref(_sfc_main$7), {
                              "as-child": "",
                              class: "w-full justify-start",
                              variant: "outline"
                            }, {
                              default: withCtx(() => [
                                createVNode(unref(Link), {
                                  href: unref(jobcards).create().url
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(Wrench), { class: "mr-2 h-4 w-4" }),
                                    createTextVNode(" New Jobcard ")
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ]),
                              _: 1
                            }),
                            createVNode(unref(_sfc_main$7), {
                              "as-child": "",
                              class: "w-full justify-start",
                              variant: "outline"
                            }, {
                              default: withCtx(() => [
                                createVNode(unref(Link), {
                                  href: unref(customers).create().url
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(UserPlus), { class: "mr-2 h-4 w-4" }),
                                    createTextVNode(" New Customer ")
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ]),
                              _: 1
                            })
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(_sfc_main$3), null, {
                      default: withCtx(() => [
                        createVNode(unref(_sfc_main$4), null, {
                          default: withCtx(() => [
                            createTextVNode("Quick Actions")
                          ]),
                          _: 1
                        }),
                        createVNode(unref(_sfc_main$5), null, {
                          default: withCtx(() => [
                            createTextVNode("Create new items quickly")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(_sfc_main$6), null, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid gap-2 md:grid-cols-4" }, [
                          createVNode(unref(_sfc_main$7), {
                            "as-child": "",
                            class: "w-full justify-start"
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: unref(quotes).create().url
                              }, {
                                default: withCtx(() => [
                                  createVNode(unref(FileText), { class: "mr-2 h-4 w-4" }),
                                  createTextVNode(" New Quote ")
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$7), {
                            "as-child": "",
                            class: "w-full justify-start",
                            variant: "outline"
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: unref(invoices).create().url
                              }, {
                                default: withCtx(() => [
                                  createVNode(unref(Receipt), { class: "mr-2 h-4 w-4" }),
                                  createTextVNode(" New Invoice ")
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$7), {
                            "as-child": "",
                            class: "w-full justify-start",
                            variant: "outline"
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: unref(jobcards).create().url
                              }, {
                                default: withCtx(() => [
                                  createVNode(unref(Wrench), { class: "mr-2 h-4 w-4" }),
                                  createTextVNode(" New Jobcard ")
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$7), {
                            "as-child": "",
                            class: "w-full justify-start",
                            variant: "outline"
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: unref(customers).create().url
                              }, {
                                default: withCtx(() => [
                                  createVNode(unref(UserPlus), { class: "mr-2 h-4 w-4" }),
                                  createTextVNode(" New Customer ")
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(_sfc_main$2), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(_sfc_main$3), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="flex items-center justify-between" data-v-034be482${_scopeId3}><div data-v-034be482${_scopeId3}>`);
                        _push4(ssrRenderComponent(unref(_sfc_main$4), { class: "text-lg font-semibold" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Your Sales Performance`);
                            } else {
                              return [
                                createTextVNode("Your Sales Performance")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(unref(_sfc_main$5), null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Current month revenue and 12-month trend`);
                            } else {
                              return [
                                createTextVNode("Current month revenue and 12-month trend")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(`</div>`);
                        _push4(ssrRenderComponent(unref(TrendingUp), { class: "h-5 w-5 text-muted-foreground" }, null, _parent4, _scopeId3));
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode("div", { class: "flex items-center justify-between" }, [
                            createVNode("div", null, [
                              createVNode(unref(_sfc_main$4), { class: "text-lg font-semibold" }, {
                                default: withCtx(() => [
                                  createTextVNode("Your Sales Performance")
                                ]),
                                _: 1
                              }),
                              createVNode(unref(_sfc_main$5), null, {
                                default: withCtx(() => [
                                  createTextVNode("Current month revenue and 12-month trend")
                                ]),
                                _: 1
                              })
                            ]),
                            createVNode(unref(TrendingUp), { class: "h-5 w-5 text-muted-foreground" })
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(_sfc_main$6), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="grid gap-2 md:grid-cols-4" data-v-034be482${_scopeId3}><div class="space-y-1" data-v-034be482${_scopeId3}><div data-v-034be482${_scopeId3}><div class="text-3xl font-bold" data-v-034be482${_scopeId3}>${ssrInterpolate(formatCurrency(_ctx.revenueStats.current_month_revenue))}</div><p class="text-sm text-muted-foreground" data-v-034be482${_scopeId3}>Current Month Revenue</p></div></div><div class="md:col-span-3" data-v-034be482${_scopeId3}><h4 class="text-sm font-medium mb-2" data-v-034be482${_scopeId3}>12-Month Revenue Trend</h4>`);
                        if (_ctx.userMonthlyRevenue && _ctx.userMonthlyRevenue.length > 0) {
                          _push4(`<div class="h-28 flex items-end justify-between gap-2" data-v-034be482${_scopeId3}><!--[-->`);
                          ssrRenderList(_ctx.userMonthlyRevenue, (data, index) => {
                            _push4(`<div class="flex flex-col items-center flex-1" data-v-034be482${_scopeId3}><div class="text-xs text-muted-foreground mb-1" data-v-034be482${_scopeId3}>${ssrInterpolate(data.month)}</div><div class="w-full bg-blue-500 rounded-t transition-all duration-300 hover:bg-blue-600 cursor-pointer" style="${ssrRenderStyle({ height: getBarHeight(data.revenue) + "px", minHeight: "8px" })}"${ssrRenderAttr("title", formatCurrency(data.revenue))} data-v-034be482${_scopeId3}></div><div class="text-xs text-muted-foreground mt-1 text-center" data-v-034be482${_scopeId3}>${ssrInterpolate(formatCurrency(data.revenue))}</div></div>`);
                          });
                          _push4(`<!--]--></div>`);
                        } else {
                          _push4(`<div class="h-28 flex items-center justify-center text-muted-foreground border-2 border-dashed border-gray-300 rounded-lg" data-v-034be482${_scopeId3}><div class="text-center" data-v-034be482${_scopeId3}><div class="text-sm font-medium" data-v-034be482${_scopeId3}>No revenue data</div><div class="text-xs" data-v-034be482${_scopeId3}>Create and mark invoices as paid to see trends</div></div></div>`);
                        }
                        _push4(`<div class="mt-2 text-xs text-muted-foreground text-center" data-v-034be482${_scopeId3}> Hover over bars to see exact amounts </div></div></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "grid gap-2 md:grid-cols-4" }, [
                            createVNode("div", { class: "space-y-1" }, [
                              createVNode("div", null, [
                                createVNode("div", { class: "text-3xl font-bold" }, toDisplayString(formatCurrency(_ctx.revenueStats.current_month_revenue)), 1),
                                createVNode("p", { class: "text-sm text-muted-foreground" }, "Current Month Revenue")
                              ])
                            ]),
                            createVNode("div", { class: "md:col-span-3" }, [
                              createVNode("h4", { class: "text-sm font-medium mb-2" }, "12-Month Revenue Trend"),
                              _ctx.userMonthlyRevenue && _ctx.userMonthlyRevenue.length > 0 ? (openBlock(), createBlock("div", {
                                key: 0,
                                class: "h-28 flex items-end justify-between gap-2"
                              }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(_ctx.userMonthlyRevenue, (data, index) => {
                                  return openBlock(), createBlock("div", {
                                    key: index,
                                    class: "flex flex-col items-center flex-1"
                                  }, [
                                    createVNode("div", { class: "text-xs text-muted-foreground mb-1" }, toDisplayString(data.month), 1),
                                    createVNode("div", {
                                      class: "w-full bg-blue-500 rounded-t transition-all duration-300 hover:bg-blue-600 cursor-pointer",
                                      style: { height: getBarHeight(data.revenue) + "px", minHeight: "8px" },
                                      title: formatCurrency(data.revenue)
                                    }, null, 12, ["title"]),
                                    createVNode("div", { class: "text-xs text-muted-foreground mt-1 text-center" }, toDisplayString(formatCurrency(data.revenue)), 1)
                                  ]);
                                }), 128))
                              ])) : (openBlock(), createBlock("div", {
                                key: 1,
                                class: "h-28 flex items-center justify-center text-muted-foreground border-2 border-dashed border-gray-300 rounded-lg"
                              }, [
                                createVNode("div", { class: "text-center" }, [
                                  createVNode("div", { class: "text-sm font-medium" }, "No revenue data"),
                                  createVNode("div", { class: "text-xs" }, "Create and mark invoices as paid to see trends")
                                ])
                              ])),
                              createVNode("div", { class: "mt-2 text-xs text-muted-foreground text-center" }, " Hover over bars to see exact amounts ")
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(_sfc_main$3), null, {
                      default: withCtx(() => [
                        createVNode("div", { class: "flex items-center justify-between" }, [
                          createVNode("div", null, [
                            createVNode(unref(_sfc_main$4), { class: "text-lg font-semibold" }, {
                              default: withCtx(() => [
                                createTextVNode("Your Sales Performance")
                              ]),
                              _: 1
                            }),
                            createVNode(unref(_sfc_main$5), null, {
                              default: withCtx(() => [
                                createTextVNode("Current month revenue and 12-month trend")
                              ]),
                              _: 1
                            })
                          ]),
                          createVNode(unref(TrendingUp), { class: "h-5 w-5 text-muted-foreground" })
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(unref(_sfc_main$6), null, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid gap-2 md:grid-cols-4" }, [
                          createVNode("div", { class: "space-y-1" }, [
                            createVNode("div", null, [
                              createVNode("div", { class: "text-3xl font-bold" }, toDisplayString(formatCurrency(_ctx.revenueStats.current_month_revenue)), 1),
                              createVNode("p", { class: "text-sm text-muted-foreground" }, "Current Month Revenue")
                            ])
                          ]),
                          createVNode("div", { class: "md:col-span-3" }, [
                            createVNode("h4", { class: "text-sm font-medium mb-2" }, "12-Month Revenue Trend"),
                            _ctx.userMonthlyRevenue && _ctx.userMonthlyRevenue.length > 0 ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "h-28 flex items-end justify-between gap-2"
                            }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.userMonthlyRevenue, (data, index) => {
                                return openBlock(), createBlock("div", {
                                  key: index,
                                  class: "flex flex-col items-center flex-1"
                                }, [
                                  createVNode("div", { class: "text-xs text-muted-foreground mb-1" }, toDisplayString(data.month), 1),
                                  createVNode("div", {
                                    class: "w-full bg-blue-500 rounded-t transition-all duration-300 hover:bg-blue-600 cursor-pointer",
                                    style: { height: getBarHeight(data.revenue) + "px", minHeight: "8px" },
                                    title: formatCurrency(data.revenue)
                                  }, null, 12, ["title"]),
                                  createVNode("div", { class: "text-xs text-muted-foreground mt-1 text-center" }, toDisplayString(formatCurrency(data.revenue)), 1)
                                ]);
                              }), 128))
                            ])) : (openBlock(), createBlock("div", {
                              key: 1,
                              class: "h-28 flex items-center justify-center text-muted-foreground border-2 border-dashed border-gray-300 rounded-lg"
                            }, [
                              createVNode("div", { class: "text-center" }, [
                                createVNode("div", { class: "text-sm font-medium" }, "No revenue data"),
                                createVNode("div", { class: "text-xs" }, "Create and mark invoices as paid to see trends")
                              ])
                            ])),
                            createVNode("div", { class: "mt-2 text-xs text-muted-foreground text-center" }, " Hover over bars to see exact amounts ")
                          ])
                        ])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(_sfc_main$2), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(_sfc_main$3), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(_sfc_main$4), null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Recent Activity`);
                            } else {
                              return [
                                createTextVNode("Recent Activity")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(unref(_sfc_main$5), null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Latest quotes, invoices, and jobcards`);
                            } else {
                              return [
                                createTextVNode("Latest quotes, invoices, and jobcards")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(_sfc_main$4), null, {
                            default: withCtx(() => [
                              createTextVNode("Recent Activity")
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$5), null, {
                            default: withCtx(() => [
                              createTextVNode("Latest quotes, invoices, and jobcards")
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(_sfc_main$6), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="grid gap-6 md:grid-cols-3" data-v-034be482${_scopeId3}>`);
                        if (_ctx.recentActivity.recent_quotes.length > 0) {
                          _push4(`<div data-v-034be482${_scopeId3}><h4 class="text-sm font-medium mb-2" data-v-034be482${_scopeId3}>Recent Quotes</h4><div class="space-y-2" data-v-034be482${_scopeId3}><!--[-->`);
                          ssrRenderList(_ctx.recentActivity.recent_quotes, (quote) => {
                            _push4(ssrRenderComponent(unref(Link), {
                              key: quote.id,
                              href: unref(quotes).show(quote.id).url,
                              class: "flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-colors duration-200 cursor-pointer"
                            }, {
                              default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                                if (_push5) {
                                  _push5(`<div class="flex items-center space-x-3" data-v-034be482${_scopeId4}>`);
                                  _push5(ssrRenderComponent(unref(FileText), { class: "h-4 w-4 text-blue-500" }, null, _parent5, _scopeId4));
                                  _push5(`<div data-v-034be482${_scopeId4}><p class="text-sm font-medium" data-v-034be482${_scopeId4}>${ssrInterpolate(quote.quote_number)}</p><p class="text-xs text-muted-foreground" data-v-034be482${_scopeId4}>${ssrInterpolate(quote.customer?.name)}</p></div></div><div class="text-right" data-v-034be482${_scopeId4}><p class="text-sm font-medium" data-v-034be482${_scopeId4}>${ssrInterpolate(formatCurrency(quote.total))}</p>`);
                                  _push5(ssrRenderComponent(unref(_sfc_main$8), {
                                    class: getStatusColor(quote.status)
                                  }, {
                                    default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                      if (_push6) {
                                        _push6(`${ssrInterpolate(quote.status)}`);
                                      } else {
                                        return [
                                          createTextVNode(toDisplayString(quote.status), 1)
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent5, _scopeId4));
                                  _push5(`</div>`);
                                } else {
                                  return [
                                    createVNode("div", { class: "flex items-center space-x-3" }, [
                                      createVNode(unref(FileText), { class: "h-4 w-4 text-blue-500" }),
                                      createVNode("div", null, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(quote.quote_number), 1),
                                        createVNode("p", { class: "text-xs text-muted-foreground" }, toDisplayString(quote.customer?.name), 1)
                                      ])
                                    ]),
                                    createVNode("div", { class: "text-right" }, [
                                      createVNode("p", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(quote.total)), 1),
                                      createVNode(unref(_sfc_main$8), {
                                        class: getStatusColor(quote.status)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(quote.status), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["class"])
                                    ])
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent4, _scopeId3));
                          });
                          _push4(`<!--]--></div></div>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        if (_ctx.recentActivity.recent_invoices.length > 0) {
                          _push4(`<div data-v-034be482${_scopeId3}><h4 class="text-sm font-medium mb-2" data-v-034be482${_scopeId3}>Recent Invoices</h4><div class="space-y-2" data-v-034be482${_scopeId3}><!--[-->`);
                          ssrRenderList(_ctx.recentActivity.recent_invoices, (invoice) => {
                            _push4(ssrRenderComponent(unref(Link), {
                              key: invoice.id,
                              href: unref(invoices).show(invoice.id).url,
                              class: "flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-colors duration-200 cursor-pointer"
                            }, {
                              default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                                if (_push5) {
                                  _push5(`<div class="flex items-center space-x-3" data-v-034be482${_scopeId4}>`);
                                  _push5(ssrRenderComponent(unref(Receipt), { class: "h-4 w-4 text-green-500" }, null, _parent5, _scopeId4));
                                  _push5(`<div data-v-034be482${_scopeId4}><p class="text-sm font-medium" data-v-034be482${_scopeId4}>${ssrInterpolate(invoice.invoice_number)}</p><p class="text-xs text-muted-foreground" data-v-034be482${_scopeId4}>${ssrInterpolate(invoice.customer?.name)}</p></div></div><div class="text-right" data-v-034be482${_scopeId4}><p class="text-sm font-medium" data-v-034be482${_scopeId4}>${ssrInterpolate(formatCurrency(invoice.total))}</p>`);
                                  _push5(ssrRenderComponent(unref(_sfc_main$8), {
                                    class: getStatusColor(invoice.status)
                                  }, {
                                    default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                      if (_push6) {
                                        _push6(`${ssrInterpolate(invoice.status)}`);
                                      } else {
                                        return [
                                          createTextVNode(toDisplayString(invoice.status), 1)
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent5, _scopeId4));
                                  _push5(`</div>`);
                                } else {
                                  return [
                                    createVNode("div", { class: "flex items-center space-x-3" }, [
                                      createVNode(unref(Receipt), { class: "h-4 w-4 text-green-500" }),
                                      createVNode("div", null, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(invoice.invoice_number), 1),
                                        createVNode("p", { class: "text-xs text-muted-foreground" }, toDisplayString(invoice.customer?.name), 1)
                                      ])
                                    ]),
                                    createVNode("div", { class: "text-right" }, [
                                      createVNode("p", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(invoice.total)), 1),
                                      createVNode(unref(_sfc_main$8), {
                                        class: getStatusColor(invoice.status)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(invoice.status), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["class"])
                                    ])
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent4, _scopeId3));
                          });
                          _push4(`<!--]--></div></div>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        if (_ctx.recentActivity.recent_jobcards.length > 0) {
                          _push4(`<div data-v-034be482${_scopeId3}><h4 class="text-sm font-medium mb-2" data-v-034be482${_scopeId3}>Recent Jobcards</h4><div class="space-y-2" data-v-034be482${_scopeId3}><!--[-->`);
                          ssrRenderList(_ctx.recentActivity.recent_jobcards, (jobcard) => {
                            _push4(ssrRenderComponent(unref(Link), {
                              key: jobcard.id,
                              href: unref(jobcards).show(jobcard.id).url,
                              class: "flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-colors duration-200 cursor-pointer"
                            }, {
                              default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                                if (_push5) {
                                  _push5(`<div class="flex items-center space-x-3" data-v-034be482${_scopeId4}>`);
                                  _push5(ssrRenderComponent(unref(Wrench), { class: "h-4 w-4 text-orange-500" }, null, _parent5, _scopeId4));
                                  _push5(`<div data-v-034be482${_scopeId4}><p class="text-sm font-medium" data-v-034be482${_scopeId4}>${ssrInterpolate(jobcard.jobcard_number)}</p><p class="text-xs text-muted-foreground" data-v-034be482${_scopeId4}>${ssrInterpolate(jobcard.customer?.name)}</p></div></div><div class="text-right" data-v-034be482${_scopeId4}><p class="text-sm font-medium" data-v-034be482${_scopeId4}>${ssrInterpolate(formatCurrency(jobcard.total))}</p>`);
                                  _push5(ssrRenderComponent(unref(_sfc_main$8), {
                                    class: getStatusColor(jobcard.status)
                                  }, {
                                    default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                      if (_push6) {
                                        _push6(`${ssrInterpolate(jobcard.status)}`);
                                      } else {
                                        return [
                                          createTextVNode(toDisplayString(jobcard.status), 1)
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent5, _scopeId4));
                                  _push5(`</div>`);
                                } else {
                                  return [
                                    createVNode("div", { class: "flex items-center space-x-3" }, [
                                      createVNode(unref(Wrench), { class: "h-4 w-4 text-orange-500" }),
                                      createVNode("div", null, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(jobcard.jobcard_number), 1),
                                        createVNode("p", { class: "text-xs text-muted-foreground" }, toDisplayString(jobcard.customer?.name), 1)
                                      ])
                                    ]),
                                    createVNode("div", { class: "text-right" }, [
                                      createVNode("p", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(jobcard.total)), 1),
                                      createVNode(unref(_sfc_main$8), {
                                        class: getStatusColor(jobcard.status)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(jobcard.status), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["class"])
                                    ])
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent4, _scopeId3));
                          });
                          _push4(`<!--]--></div></div>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode("div", { class: "grid gap-6 md:grid-cols-3" }, [
                            _ctx.recentActivity.recent_quotes.length > 0 ? (openBlock(), createBlock("div", { key: 0 }, [
                              createVNode("h4", { class: "text-sm font-medium mb-2" }, "Recent Quotes"),
                              createVNode("div", { class: "space-y-2" }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(_ctx.recentActivity.recent_quotes, (quote) => {
                                  return openBlock(), createBlock(unref(Link), {
                                    key: quote.id,
                                    href: unref(quotes).show(quote.id).url,
                                    class: "flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-colors duration-200 cursor-pointer"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("div", { class: "flex items-center space-x-3" }, [
                                        createVNode(unref(FileText), { class: "h-4 w-4 text-blue-500" }),
                                        createVNode("div", null, [
                                          createVNode("p", { class: "text-sm font-medium" }, toDisplayString(quote.quote_number), 1),
                                          createVNode("p", { class: "text-xs text-muted-foreground" }, toDisplayString(quote.customer?.name), 1)
                                        ])
                                      ]),
                                      createVNode("div", { class: "text-right" }, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(quote.total)), 1),
                                        createVNode(unref(_sfc_main$8), {
                                          class: getStatusColor(quote.status)
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(quote.status), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["class"])
                                      ])
                                    ]),
                                    _: 2
                                  }, 1032, ["href"]);
                                }), 128))
                              ])
                            ])) : createCommentVNode("", true),
                            _ctx.recentActivity.recent_invoices.length > 0 ? (openBlock(), createBlock("div", { key: 1 }, [
                              createVNode("h4", { class: "text-sm font-medium mb-2" }, "Recent Invoices"),
                              createVNode("div", { class: "space-y-2" }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(_ctx.recentActivity.recent_invoices, (invoice) => {
                                  return openBlock(), createBlock(unref(Link), {
                                    key: invoice.id,
                                    href: unref(invoices).show(invoice.id).url,
                                    class: "flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-colors duration-200 cursor-pointer"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("div", { class: "flex items-center space-x-3" }, [
                                        createVNode(unref(Receipt), { class: "h-4 w-4 text-green-500" }),
                                        createVNode("div", null, [
                                          createVNode("p", { class: "text-sm font-medium" }, toDisplayString(invoice.invoice_number), 1),
                                          createVNode("p", { class: "text-xs text-muted-foreground" }, toDisplayString(invoice.customer?.name), 1)
                                        ])
                                      ]),
                                      createVNode("div", { class: "text-right" }, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(invoice.total)), 1),
                                        createVNode(unref(_sfc_main$8), {
                                          class: getStatusColor(invoice.status)
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(invoice.status), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["class"])
                                      ])
                                    ]),
                                    _: 2
                                  }, 1032, ["href"]);
                                }), 128))
                              ])
                            ])) : createCommentVNode("", true),
                            _ctx.recentActivity.recent_jobcards.length > 0 ? (openBlock(), createBlock("div", { key: 2 }, [
                              createVNode("h4", { class: "text-sm font-medium mb-2" }, "Recent Jobcards"),
                              createVNode("div", { class: "space-y-2" }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(_ctx.recentActivity.recent_jobcards, (jobcard) => {
                                  return openBlock(), createBlock(unref(Link), {
                                    key: jobcard.id,
                                    href: unref(jobcards).show(jobcard.id).url,
                                    class: "flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-colors duration-200 cursor-pointer"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("div", { class: "flex items-center space-x-3" }, [
                                        createVNode(unref(Wrench), { class: "h-4 w-4 text-orange-500" }),
                                        createVNode("div", null, [
                                          createVNode("p", { class: "text-sm font-medium" }, toDisplayString(jobcard.jobcard_number), 1),
                                          createVNode("p", { class: "text-xs text-muted-foreground" }, toDisplayString(jobcard.customer?.name), 1)
                                        ])
                                      ]),
                                      createVNode("div", { class: "text-right" }, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(jobcard.total)), 1),
                                        createVNode(unref(_sfc_main$8), {
                                          class: getStatusColor(jobcard.status)
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(jobcard.status), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["class"])
                                      ])
                                    ]),
                                    _: 2
                                  }, 1032, ["href"]);
                                }), 128))
                              ])
                            ])) : createCommentVNode("", true)
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(_sfc_main$3), null, {
                      default: withCtx(() => [
                        createVNode(unref(_sfc_main$4), null, {
                          default: withCtx(() => [
                            createTextVNode("Recent Activity")
                          ]),
                          _: 1
                        }),
                        createVNode(unref(_sfc_main$5), null, {
                          default: withCtx(() => [
                            createTextVNode("Latest quotes, invoices, and jobcards")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(_sfc_main$6), null, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid gap-6 md:grid-cols-3" }, [
                          _ctx.recentActivity.recent_quotes.length > 0 ? (openBlock(), createBlock("div", { key: 0 }, [
                            createVNode("h4", { class: "text-sm font-medium mb-2" }, "Recent Quotes"),
                            createVNode("div", { class: "space-y-2" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.recentActivity.recent_quotes, (quote) => {
                                return openBlock(), createBlock(unref(Link), {
                                  key: quote.id,
                                  href: unref(quotes).show(quote.id).url,
                                  class: "flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-colors duration-200 cursor-pointer"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "flex items-center space-x-3" }, [
                                      createVNode(unref(FileText), { class: "h-4 w-4 text-blue-500" }),
                                      createVNode("div", null, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(quote.quote_number), 1),
                                        createVNode("p", { class: "text-xs text-muted-foreground" }, toDisplayString(quote.customer?.name), 1)
                                      ])
                                    ]),
                                    createVNode("div", { class: "text-right" }, [
                                      createVNode("p", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(quote.total)), 1),
                                      createVNode(unref(_sfc_main$8), {
                                        class: getStatusColor(quote.status)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(quote.status), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["class"])
                                    ])
                                  ]),
                                  _: 2
                                }, 1032, ["href"]);
                              }), 128))
                            ])
                          ])) : createCommentVNode("", true),
                          _ctx.recentActivity.recent_invoices.length > 0 ? (openBlock(), createBlock("div", { key: 1 }, [
                            createVNode("h4", { class: "text-sm font-medium mb-2" }, "Recent Invoices"),
                            createVNode("div", { class: "space-y-2" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.recentActivity.recent_invoices, (invoice) => {
                                return openBlock(), createBlock(unref(Link), {
                                  key: invoice.id,
                                  href: unref(invoices).show(invoice.id).url,
                                  class: "flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-colors duration-200 cursor-pointer"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "flex items-center space-x-3" }, [
                                      createVNode(unref(Receipt), { class: "h-4 w-4 text-green-500" }),
                                      createVNode("div", null, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(invoice.invoice_number), 1),
                                        createVNode("p", { class: "text-xs text-muted-foreground" }, toDisplayString(invoice.customer?.name), 1)
                                      ])
                                    ]),
                                    createVNode("div", { class: "text-right" }, [
                                      createVNode("p", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(invoice.total)), 1),
                                      createVNode(unref(_sfc_main$8), {
                                        class: getStatusColor(invoice.status)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(invoice.status), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["class"])
                                    ])
                                  ]),
                                  _: 2
                                }, 1032, ["href"]);
                              }), 128))
                            ])
                          ])) : createCommentVNode("", true),
                          _ctx.recentActivity.recent_jobcards.length > 0 ? (openBlock(), createBlock("div", { key: 2 }, [
                            createVNode("h4", { class: "text-sm font-medium mb-2" }, "Recent Jobcards"),
                            createVNode("div", { class: "space-y-2" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.recentActivity.recent_jobcards, (jobcard) => {
                                return openBlock(), createBlock(unref(Link), {
                                  key: jobcard.id,
                                  href: unref(jobcards).show(jobcard.id).url,
                                  class: "flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-colors duration-200 cursor-pointer"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "flex items-center space-x-3" }, [
                                      createVNode(unref(Wrench), { class: "h-4 w-4 text-orange-500" }),
                                      createVNode("div", null, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(jobcard.jobcard_number), 1),
                                        createVNode("p", { class: "text-xs text-muted-foreground" }, toDisplayString(jobcard.customer?.name), 1)
                                      ])
                                    ]),
                                    createVNode("div", { class: "text-right" }, [
                                      createVNode("p", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(jobcard.total)), 1),
                                      createVNode(unref(_sfc_main$8), {
                                        class: getStatusColor(jobcard.status)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(jobcard.status), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["class"])
                                    ])
                                  ]),
                                  _: 2
                                }, 1032, ["href"]);
                              }), 128))
                            ])
                          ])) : createCommentVNode("", true)
                        ])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="grid gap-6 md:grid-cols-3" data-v-034be482${_scopeId}>`);
            _push2(ssrRenderComponent(unref(_sfc_main$2), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(_sfc_main$3), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(_sfc_main$4), null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Quote Status`);
                            } else {
                              return [
                                createTextVNode("Quote Status")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(unref(_sfc_main$5), null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Distribution of quote statuses`);
                            } else {
                              return [
                                createTextVNode("Distribution of quote statuses")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(_sfc_main$4), null, {
                            default: withCtx(() => [
                              createTextVNode("Quote Status")
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$5), null, {
                            default: withCtx(() => [
                              createTextVNode("Distribution of quote statuses")
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(_sfc_main$6), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (_ctx.statusCharts && _ctx.statusCharts.quote_status) {
                          _push4(`<div class="space-y-6" data-v-034be482${_scopeId3}><div class="flex justify-center" data-v-034be482${_scopeId3}><div class="relative w-40 h-40 group" data-v-034be482${_scopeId3}><svg class="w-40 h-40" viewBox="0 0 100 100" data-v-034be482${_scopeId3}><!--[-->`);
                          ssrRenderList(createPieChartPath(_ctx.statusCharts.quote_status.data, _ctx.statusCharts.quote_status.colors, _ctx.statusCharts.quote_status.labels), (segment, index) => {
                            _push4(`<path${ssrRenderAttr("d", segment.path)}${ssrRenderAttr("fill", segment.color)} class="chart-segment cursor-pointer" style="${ssrRenderStyle({
                              transformOrigin: "50% 50%",
                              animationDelay: `${index * 100}ms`
                            })}" data-v-034be482${_scopeId3}></path>`);
                          });
                          _push4(`<!--]--></svg><div class="absolute inset-0 flex flex-col items-center justify-center" data-v-034be482${_scopeId3}><span class="text-lg font-bold text-foreground" data-v-034be482${_scopeId3}>${ssrInterpolate(_ctx.statusCharts.quote_status.data.reduce((a, b) => a + b, 0))}</span><span class="text-xs text-muted-foreground font-medium" data-v-034be482${_scopeId3}>Total</span></div></div></div><div class="space-y-3" data-v-034be482${_scopeId3}><!--[-->`);
                          ssrRenderList(_ctx.statusCharts.quote_status.labels, (label, index) => {
                            _push4(`<div class="legend-item flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200" data-v-034be482${_scopeId3}><div class="flex items-center space-x-3" data-v-034be482${_scopeId3}><div class="w-3 h-3 rounded-full" style="${ssrRenderStyle({ backgroundColor: _ctx.statusCharts.quote_status.colors[index] })}" data-v-034be482${_scopeId3}></div><span class="text-sm font-medium text-foreground" data-v-034be482${_scopeId3}>${ssrInterpolate(label)}</span></div><div class="flex items-center space-x-2" data-v-034be482${_scopeId3}><span class="text-sm font-bold text-foreground" data-v-034be482${_scopeId3}>${ssrInterpolate(_ctx.statusCharts.quote_status.data[index])}</span><span class="text-xs text-muted-foreground" data-v-034be482${_scopeId3}> (${ssrInterpolate(Math.round(_ctx.statusCharts.quote_status.data[index] / _ctx.statusCharts.quote_status.data.reduce((a, b) => a + b, 0) * 100))}%) </span></div></div>`);
                          });
                          _push4(`<!--]--></div></div>`);
                        } else {
                          _push4(`<div class="text-center py-8 text-muted-foreground" data-v-034be482${_scopeId3}><p data-v-034be482${_scopeId3}>No quote data available</p><p class="text-xs mt-1" data-v-034be482${_scopeId3}>Create some quotes to see status distribution</p></div>`);
                        }
                      } else {
                        return [
                          _ctx.statusCharts && _ctx.statusCharts.quote_status ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "space-y-6"
                          }, [
                            createVNode("div", { class: "flex justify-center" }, [
                              createVNode("div", { class: "relative w-40 h-40 group" }, [
                                (openBlock(), createBlock("svg", {
                                  class: "w-40 h-40",
                                  viewBox: "0 0 100 100"
                                }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(createPieChartPath(_ctx.statusCharts.quote_status.data, _ctx.statusCharts.quote_status.colors, _ctx.statusCharts.quote_status.labels), (segment, index) => {
                                    return openBlock(), createBlock("path", {
                                      key: index,
                                      d: segment.path,
                                      fill: segment.color,
                                      class: "chart-segment cursor-pointer",
                                      style: {
                                        transformOrigin: "50% 50%",
                                        animationDelay: `${index * 100}ms`
                                      }
                                    }, null, 12, ["d", "fill"]);
                                  }), 128))
                                ])),
                                createVNode("div", { class: "absolute inset-0 flex flex-col items-center justify-center" }, [
                                  createVNode("span", { class: "text-lg font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.quote_status.data.reduce((a, b) => a + b, 0)), 1),
                                  createVNode("span", { class: "text-xs text-muted-foreground font-medium" }, "Total")
                                ])
                              ])
                            ]),
                            createVNode("div", { class: "space-y-3" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.statusCharts.quote_status.labels, (label, index) => {
                                return openBlock(), createBlock("div", {
                                  key: index,
                                  class: "legend-item flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200"
                                }, [
                                  createVNode("div", { class: "flex items-center space-x-3" }, [
                                    createVNode("div", {
                                      class: "w-3 h-3 rounded-full",
                                      style: { backgroundColor: _ctx.statusCharts.quote_status.colors[index] }
                                    }, null, 4),
                                    createVNode("span", { class: "text-sm font-medium text-foreground" }, toDisplayString(label), 1)
                                  ]),
                                  createVNode("div", { class: "flex items-center space-x-2" }, [
                                    createVNode("span", { class: "text-sm font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.quote_status.data[index]), 1),
                                    createVNode("span", { class: "text-xs text-muted-foreground" }, " (" + toDisplayString(Math.round(_ctx.statusCharts.quote_status.data[index] / _ctx.statusCharts.quote_status.data.reduce((a, b) => a + b, 0) * 100)) + "%) ", 1)
                                  ])
                                ]);
                              }), 128))
                            ])
                          ])) : (openBlock(), createBlock("div", {
                            key: 1,
                            class: "text-center py-8 text-muted-foreground"
                          }, [
                            createVNode("p", null, "No quote data available"),
                            createVNode("p", { class: "text-xs mt-1" }, "Create some quotes to see status distribution")
                          ]))
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(_sfc_main$3), null, {
                      default: withCtx(() => [
                        createVNode(unref(_sfc_main$4), null, {
                          default: withCtx(() => [
                            createTextVNode("Quote Status")
                          ]),
                          _: 1
                        }),
                        createVNode(unref(_sfc_main$5), null, {
                          default: withCtx(() => [
                            createTextVNode("Distribution of quote statuses")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(_sfc_main$6), null, {
                      default: withCtx(() => [
                        _ctx.statusCharts && _ctx.statusCharts.quote_status ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "space-y-6"
                        }, [
                          createVNode("div", { class: "flex justify-center" }, [
                            createVNode("div", { class: "relative w-40 h-40 group" }, [
                              (openBlock(), createBlock("svg", {
                                class: "w-40 h-40",
                                viewBox: "0 0 100 100"
                              }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(createPieChartPath(_ctx.statusCharts.quote_status.data, _ctx.statusCharts.quote_status.colors, _ctx.statusCharts.quote_status.labels), (segment, index) => {
                                  return openBlock(), createBlock("path", {
                                    key: index,
                                    d: segment.path,
                                    fill: segment.color,
                                    class: "chart-segment cursor-pointer",
                                    style: {
                                      transformOrigin: "50% 50%",
                                      animationDelay: `${index * 100}ms`
                                    }
                                  }, null, 12, ["d", "fill"]);
                                }), 128))
                              ])),
                              createVNode("div", { class: "absolute inset-0 flex flex-col items-center justify-center" }, [
                                createVNode("span", { class: "text-lg font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.quote_status.data.reduce((a, b) => a + b, 0)), 1),
                                createVNode("span", { class: "text-xs text-muted-foreground font-medium" }, "Total")
                              ])
                            ])
                          ]),
                          createVNode("div", { class: "space-y-3" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(_ctx.statusCharts.quote_status.labels, (label, index) => {
                              return openBlock(), createBlock("div", {
                                key: index,
                                class: "legend-item flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200"
                              }, [
                                createVNode("div", { class: "flex items-center space-x-3" }, [
                                  createVNode("div", {
                                    class: "w-3 h-3 rounded-full",
                                    style: { backgroundColor: _ctx.statusCharts.quote_status.colors[index] }
                                  }, null, 4),
                                  createVNode("span", { class: "text-sm font-medium text-foreground" }, toDisplayString(label), 1)
                                ]),
                                createVNode("div", { class: "flex items-center space-x-2" }, [
                                  createVNode("span", { class: "text-sm font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.quote_status.data[index]), 1),
                                  createVNode("span", { class: "text-xs text-muted-foreground" }, " (" + toDisplayString(Math.round(_ctx.statusCharts.quote_status.data[index] / _ctx.statusCharts.quote_status.data.reduce((a, b) => a + b, 0) * 100)) + "%) ", 1)
                                ])
                              ]);
                            }), 128))
                          ])
                        ])) : (openBlock(), createBlock("div", {
                          key: 1,
                          class: "text-center py-8 text-muted-foreground"
                        }, [
                          createVNode("p", null, "No quote data available"),
                          createVNode("p", { class: "text-xs mt-1" }, "Create some quotes to see status distribution")
                        ]))
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(_sfc_main$2), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(_sfc_main$3), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(_sfc_main$4), null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Invoice Status`);
                            } else {
                              return [
                                createTextVNode("Invoice Status")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(unref(_sfc_main$5), null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Distribution of invoice statuses`);
                            } else {
                              return [
                                createTextVNode("Distribution of invoice statuses")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(_sfc_main$4), null, {
                            default: withCtx(() => [
                              createTextVNode("Invoice Status")
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$5), null, {
                            default: withCtx(() => [
                              createTextVNode("Distribution of invoice statuses")
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(_sfc_main$6), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (_ctx.statusCharts && _ctx.statusCharts.invoice_status) {
                          _push4(`<div class="space-y-6" data-v-034be482${_scopeId3}><div class="flex justify-center" data-v-034be482${_scopeId3}><div class="relative w-40 h-40 group" data-v-034be482${_scopeId3}><svg class="w-40 h-40" viewBox="0 0 100 100" data-v-034be482${_scopeId3}><!--[-->`);
                          ssrRenderList(createPieChartPath(_ctx.statusCharts.invoice_status.data, _ctx.statusCharts.invoice_status.colors, _ctx.statusCharts.invoice_status.labels), (segment, index) => {
                            _push4(`<path${ssrRenderAttr("d", segment.path)}${ssrRenderAttr("fill", segment.color)} class="chart-segment cursor-pointer" style="${ssrRenderStyle({
                              transformOrigin: "50% 50%",
                              animationDelay: `${index * 100}ms`
                            })}" data-v-034be482${_scopeId3}></path>`);
                          });
                          _push4(`<!--]--></svg><div class="absolute inset-0 flex flex-col items-center justify-center" data-v-034be482${_scopeId3}><span class="text-lg font-bold text-foreground" data-v-034be482${_scopeId3}>${ssrInterpolate(_ctx.statusCharts.invoice_status.data.reduce((a, b) => a + b, 0))}</span><span class="text-xs text-muted-foreground font-medium" data-v-034be482${_scopeId3}>Total</span></div></div></div><div class="space-y-3" data-v-034be482${_scopeId3}><!--[-->`);
                          ssrRenderList(_ctx.statusCharts.invoice_status.labels, (label, index) => {
                            _push4(`<div class="legend-item flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200" data-v-034be482${_scopeId3}><div class="flex items-center space-x-3" data-v-034be482${_scopeId3}><div class="w-3 h-3 rounded-full" style="${ssrRenderStyle({ backgroundColor: _ctx.statusCharts.invoice_status.colors[index] })}" data-v-034be482${_scopeId3}></div><span class="text-sm font-medium text-foreground" data-v-034be482${_scopeId3}>${ssrInterpolate(label)}</span></div><div class="flex items-center space-x-2" data-v-034be482${_scopeId3}><span class="text-sm font-bold text-foreground" data-v-034be482${_scopeId3}>${ssrInterpolate(_ctx.statusCharts.invoice_status.data[index])}</span><span class="text-xs text-muted-foreground" data-v-034be482${_scopeId3}> (${ssrInterpolate(Math.round(_ctx.statusCharts.invoice_status.data[index] / _ctx.statusCharts.invoice_status.data.reduce((a, b) => a + b, 0) * 100))}%) </span></div></div>`);
                          });
                          _push4(`<!--]--></div></div>`);
                        } else {
                          _push4(`<div class="text-center py-8 text-muted-foreground" data-v-034be482${_scopeId3}><p data-v-034be482${_scopeId3}>No invoice data available</p><p class="text-xs mt-1" data-v-034be482${_scopeId3}>Create some invoices to see status distribution</p></div>`);
                        }
                      } else {
                        return [
                          _ctx.statusCharts && _ctx.statusCharts.invoice_status ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "space-y-6"
                          }, [
                            createVNode("div", { class: "flex justify-center" }, [
                              createVNode("div", { class: "relative w-40 h-40 group" }, [
                                (openBlock(), createBlock("svg", {
                                  class: "w-40 h-40",
                                  viewBox: "0 0 100 100"
                                }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(createPieChartPath(_ctx.statusCharts.invoice_status.data, _ctx.statusCharts.invoice_status.colors, _ctx.statusCharts.invoice_status.labels), (segment, index) => {
                                    return openBlock(), createBlock("path", {
                                      key: index,
                                      d: segment.path,
                                      fill: segment.color,
                                      class: "chart-segment cursor-pointer",
                                      style: {
                                        transformOrigin: "50% 50%",
                                        animationDelay: `${index * 100}ms`
                                      }
                                    }, null, 12, ["d", "fill"]);
                                  }), 128))
                                ])),
                                createVNode("div", { class: "absolute inset-0 flex flex-col items-center justify-center" }, [
                                  createVNode("span", { class: "text-lg font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.invoice_status.data.reduce((a, b) => a + b, 0)), 1),
                                  createVNode("span", { class: "text-xs text-muted-foreground font-medium" }, "Total")
                                ])
                              ])
                            ]),
                            createVNode("div", { class: "space-y-3" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.statusCharts.invoice_status.labels, (label, index) => {
                                return openBlock(), createBlock("div", {
                                  key: index,
                                  class: "legend-item flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200"
                                }, [
                                  createVNode("div", { class: "flex items-center space-x-3" }, [
                                    createVNode("div", {
                                      class: "w-3 h-3 rounded-full",
                                      style: { backgroundColor: _ctx.statusCharts.invoice_status.colors[index] }
                                    }, null, 4),
                                    createVNode("span", { class: "text-sm font-medium text-foreground" }, toDisplayString(label), 1)
                                  ]),
                                  createVNode("div", { class: "flex items-center space-x-2" }, [
                                    createVNode("span", { class: "text-sm font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.invoice_status.data[index]), 1),
                                    createVNode("span", { class: "text-xs text-muted-foreground" }, " (" + toDisplayString(Math.round(_ctx.statusCharts.invoice_status.data[index] / _ctx.statusCharts.invoice_status.data.reduce((a, b) => a + b, 0) * 100)) + "%) ", 1)
                                  ])
                                ]);
                              }), 128))
                            ])
                          ])) : (openBlock(), createBlock("div", {
                            key: 1,
                            class: "text-center py-8 text-muted-foreground"
                          }, [
                            createVNode("p", null, "No invoice data available"),
                            createVNode("p", { class: "text-xs mt-1" }, "Create some invoices to see status distribution")
                          ]))
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(_sfc_main$3), null, {
                      default: withCtx(() => [
                        createVNode(unref(_sfc_main$4), null, {
                          default: withCtx(() => [
                            createTextVNode("Invoice Status")
                          ]),
                          _: 1
                        }),
                        createVNode(unref(_sfc_main$5), null, {
                          default: withCtx(() => [
                            createTextVNode("Distribution of invoice statuses")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(_sfc_main$6), null, {
                      default: withCtx(() => [
                        _ctx.statusCharts && _ctx.statusCharts.invoice_status ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "space-y-6"
                        }, [
                          createVNode("div", { class: "flex justify-center" }, [
                            createVNode("div", { class: "relative w-40 h-40 group" }, [
                              (openBlock(), createBlock("svg", {
                                class: "w-40 h-40",
                                viewBox: "0 0 100 100"
                              }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(createPieChartPath(_ctx.statusCharts.invoice_status.data, _ctx.statusCharts.invoice_status.colors, _ctx.statusCharts.invoice_status.labels), (segment, index) => {
                                  return openBlock(), createBlock("path", {
                                    key: index,
                                    d: segment.path,
                                    fill: segment.color,
                                    class: "chart-segment cursor-pointer",
                                    style: {
                                      transformOrigin: "50% 50%",
                                      animationDelay: `${index * 100}ms`
                                    }
                                  }, null, 12, ["d", "fill"]);
                                }), 128))
                              ])),
                              createVNode("div", { class: "absolute inset-0 flex flex-col items-center justify-center" }, [
                                createVNode("span", { class: "text-lg font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.invoice_status.data.reduce((a, b) => a + b, 0)), 1),
                                createVNode("span", { class: "text-xs text-muted-foreground font-medium" }, "Total")
                              ])
                            ])
                          ]),
                          createVNode("div", { class: "space-y-3" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(_ctx.statusCharts.invoice_status.labels, (label, index) => {
                              return openBlock(), createBlock("div", {
                                key: index,
                                class: "legend-item flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200"
                              }, [
                                createVNode("div", { class: "flex items-center space-x-3" }, [
                                  createVNode("div", {
                                    class: "w-3 h-3 rounded-full",
                                    style: { backgroundColor: _ctx.statusCharts.invoice_status.colors[index] }
                                  }, null, 4),
                                  createVNode("span", { class: "text-sm font-medium text-foreground" }, toDisplayString(label), 1)
                                ]),
                                createVNode("div", { class: "flex items-center space-x-2" }, [
                                  createVNode("span", { class: "text-sm font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.invoice_status.data[index]), 1),
                                  createVNode("span", { class: "text-xs text-muted-foreground" }, " (" + toDisplayString(Math.round(_ctx.statusCharts.invoice_status.data[index] / _ctx.statusCharts.invoice_status.data.reduce((a, b) => a + b, 0) * 100)) + "%) ", 1)
                                ])
                              ]);
                            }), 128))
                          ])
                        ])) : (openBlock(), createBlock("div", {
                          key: 1,
                          class: "text-center py-8 text-muted-foreground"
                        }, [
                          createVNode("p", null, "No invoice data available"),
                          createVNode("p", { class: "text-xs mt-1" }, "Create some invoices to see status distribution")
                        ]))
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(_sfc_main$2), null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(_sfc_main$3), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(_sfc_main$4), null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Jobcard Status`);
                            } else {
                              return [
                                createTextVNode("Jobcard Status")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(unref(_sfc_main$5), null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Distribution of jobcard statuses`);
                            } else {
                              return [
                                createTextVNode("Distribution of jobcard statuses")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(_sfc_main$4), null, {
                            default: withCtx(() => [
                              createTextVNode("Jobcard Status")
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$5), null, {
                            default: withCtx(() => [
                              createTextVNode("Distribution of jobcard statuses")
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(_sfc_main$6), null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (_ctx.statusCharts && _ctx.statusCharts.jobcard_status) {
                          _push4(`<div class="space-y-6" data-v-034be482${_scopeId3}><div class="flex justify-center" data-v-034be482${_scopeId3}><div class="relative w-40 h-40 group" data-v-034be482${_scopeId3}><svg class="w-40 h-40" viewBox="0 0 100 100" data-v-034be482${_scopeId3}><!--[-->`);
                          ssrRenderList(createPieChartPath(_ctx.statusCharts.jobcard_status.data, _ctx.statusCharts.jobcard_status.colors, _ctx.statusCharts.jobcard_status.labels), (segment, index) => {
                            _push4(`<path${ssrRenderAttr("d", segment.path)}${ssrRenderAttr("fill", segment.color)} class="chart-segment cursor-pointer" style="${ssrRenderStyle({
                              transformOrigin: "50% 50%",
                              animationDelay: `${index * 100}ms`
                            })}" data-v-034be482${_scopeId3}></path>`);
                          });
                          _push4(`<!--]--></svg><div class="absolute inset-0 flex flex-col items-center justify-center" data-v-034be482${_scopeId3}><span class="text-lg font-bold text-foreground" data-v-034be482${_scopeId3}>${ssrInterpolate(_ctx.statusCharts.jobcard_status.data.reduce((a, b) => a + b, 0))}</span><span class="text-xs text-muted-foreground font-medium" data-v-034be482${_scopeId3}>Total</span></div></div></div><div class="space-y-3" data-v-034be482${_scopeId3}><!--[-->`);
                          ssrRenderList(_ctx.statusCharts.jobcard_status.labels, (label, index) => {
                            _push4(`<div class="legend-item flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200" data-v-034be482${_scopeId3}><div class="flex items-center space-x-3" data-v-034be482${_scopeId3}><div class="w-3 h-3 rounded-full" style="${ssrRenderStyle({ backgroundColor: _ctx.statusCharts.jobcard_status.colors[index] })}" data-v-034be482${_scopeId3}></div><span class="text-sm font-medium text-foreground" data-v-034be482${_scopeId3}>${ssrInterpolate(label)}</span></div><div class="flex items-center space-x-2" data-v-034be482${_scopeId3}><span class="text-sm font-bold text-foreground" data-v-034be482${_scopeId3}>${ssrInterpolate(_ctx.statusCharts.jobcard_status.data[index])}</span><span class="text-xs text-muted-foreground" data-v-034be482${_scopeId3}> (${ssrInterpolate(Math.round(_ctx.statusCharts.jobcard_status.data[index] / _ctx.statusCharts.jobcard_status.data.reduce((a, b) => a + b, 0) * 100))}%) </span></div></div>`);
                          });
                          _push4(`<!--]--></div></div>`);
                        } else {
                          _push4(`<div class="text-center py-8 text-muted-foreground" data-v-034be482${_scopeId3}><p data-v-034be482${_scopeId3}>No jobcard data available</p><p class="text-xs mt-1" data-v-034be482${_scopeId3}>Create some jobcards to see status distribution</p></div>`);
                        }
                      } else {
                        return [
                          _ctx.statusCharts && _ctx.statusCharts.jobcard_status ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "space-y-6"
                          }, [
                            createVNode("div", { class: "flex justify-center" }, [
                              createVNode("div", { class: "relative w-40 h-40 group" }, [
                                (openBlock(), createBlock("svg", {
                                  class: "w-40 h-40",
                                  viewBox: "0 0 100 100"
                                }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(createPieChartPath(_ctx.statusCharts.jobcard_status.data, _ctx.statusCharts.jobcard_status.colors, _ctx.statusCharts.jobcard_status.labels), (segment, index) => {
                                    return openBlock(), createBlock("path", {
                                      key: index,
                                      d: segment.path,
                                      fill: segment.color,
                                      class: "chart-segment cursor-pointer",
                                      style: {
                                        transformOrigin: "50% 50%",
                                        animationDelay: `${index * 100}ms`
                                      }
                                    }, null, 12, ["d", "fill"]);
                                  }), 128))
                                ])),
                                createVNode("div", { class: "absolute inset-0 flex flex-col items-center justify-center" }, [
                                  createVNode("span", { class: "text-lg font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.jobcard_status.data.reduce((a, b) => a + b, 0)), 1),
                                  createVNode("span", { class: "text-xs text-muted-foreground font-medium" }, "Total")
                                ])
                              ])
                            ]),
                            createVNode("div", { class: "space-y-3" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.statusCharts.jobcard_status.labels, (label, index) => {
                                return openBlock(), createBlock("div", {
                                  key: index,
                                  class: "legend-item flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200"
                                }, [
                                  createVNode("div", { class: "flex items-center space-x-3" }, [
                                    createVNode("div", {
                                      class: "w-3 h-3 rounded-full",
                                      style: { backgroundColor: _ctx.statusCharts.jobcard_status.colors[index] }
                                    }, null, 4),
                                    createVNode("span", { class: "text-sm font-medium text-foreground" }, toDisplayString(label), 1)
                                  ]),
                                  createVNode("div", { class: "flex items-center space-x-2" }, [
                                    createVNode("span", { class: "text-sm font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.jobcard_status.data[index]), 1),
                                    createVNode("span", { class: "text-xs text-muted-foreground" }, " (" + toDisplayString(Math.round(_ctx.statusCharts.jobcard_status.data[index] / _ctx.statusCharts.jobcard_status.data.reduce((a, b) => a + b, 0) * 100)) + "%) ", 1)
                                  ])
                                ]);
                              }), 128))
                            ])
                          ])) : (openBlock(), createBlock("div", {
                            key: 1,
                            class: "text-center py-8 text-muted-foreground"
                          }, [
                            createVNode("p", null, "No jobcard data available"),
                            createVNode("p", { class: "text-xs mt-1" }, "Create some jobcards to see status distribution")
                          ]))
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(_sfc_main$3), null, {
                      default: withCtx(() => [
                        createVNode(unref(_sfc_main$4), null, {
                          default: withCtx(() => [
                            createTextVNode("Jobcard Status")
                          ]),
                          _: 1
                        }),
                        createVNode(unref(_sfc_main$5), null, {
                          default: withCtx(() => [
                            createTextVNode("Distribution of jobcard statuses")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(_sfc_main$6), null, {
                      default: withCtx(() => [
                        _ctx.statusCharts && _ctx.statusCharts.jobcard_status ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "space-y-6"
                        }, [
                          createVNode("div", { class: "flex justify-center" }, [
                            createVNode("div", { class: "relative w-40 h-40 group" }, [
                              (openBlock(), createBlock("svg", {
                                class: "w-40 h-40",
                                viewBox: "0 0 100 100"
                              }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(createPieChartPath(_ctx.statusCharts.jobcard_status.data, _ctx.statusCharts.jobcard_status.colors, _ctx.statusCharts.jobcard_status.labels), (segment, index) => {
                                  return openBlock(), createBlock("path", {
                                    key: index,
                                    d: segment.path,
                                    fill: segment.color,
                                    class: "chart-segment cursor-pointer",
                                    style: {
                                      transformOrigin: "50% 50%",
                                      animationDelay: `${index * 100}ms`
                                    }
                                  }, null, 12, ["d", "fill"]);
                                }), 128))
                              ])),
                              createVNode("div", { class: "absolute inset-0 flex flex-col items-center justify-center" }, [
                                createVNode("span", { class: "text-lg font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.jobcard_status.data.reduce((a, b) => a + b, 0)), 1),
                                createVNode("span", { class: "text-xs text-muted-foreground font-medium" }, "Total")
                              ])
                            ])
                          ]),
                          createVNode("div", { class: "space-y-3" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(_ctx.statusCharts.jobcard_status.labels, (label, index) => {
                              return openBlock(), createBlock("div", {
                                key: index,
                                class: "legend-item flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200"
                              }, [
                                createVNode("div", { class: "flex items-center space-x-3" }, [
                                  createVNode("div", {
                                    class: "w-3 h-3 rounded-full",
                                    style: { backgroundColor: _ctx.statusCharts.jobcard_status.colors[index] }
                                  }, null, 4),
                                  createVNode("span", { class: "text-sm font-medium text-foreground" }, toDisplayString(label), 1)
                                ]),
                                createVNode("div", { class: "flex items-center space-x-2" }, [
                                  createVNode("span", { class: "text-sm font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.jobcard_status.data[index]), 1),
                                  createVNode("span", { class: "text-xs text-muted-foreground" }, " (" + toDisplayString(Math.round(_ctx.statusCharts.jobcard_status.data[index] / _ctx.statusCharts.jobcard_status.data.reduce((a, b) => a + b, 0) * 100)) + "%) ", 1)
                                ])
                              ]);
                            }), 128))
                          ])
                        ])) : (openBlock(), createBlock("div", {
                          key: 1,
                          class: "text-center py-8 text-muted-foreground"
                        }, [
                          createVNode("p", null, "No jobcard data available"),
                          createVNode("p", { class: "text-xs mt-1" }, "Create some jobcards to see status distribution")
                        ]))
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex h-full flex-1 flex-col gap-6 overflow-x-auto p-6" }, [
                createVNode("div", { class: "flex items-center justify-between" }, [
                  createVNode("div", null, [
                    createVNode("h1", { class: "text-3xl font-bold tracking-tight" }, "Dashboard"),
                    createVNode("p", { class: "text-muted-foreground" }, " Welcome back! Here's what's happening with your business. ")
                  ])
                ]),
                createVNode(unref(_sfc_main$2), null, {
                  default: withCtx(() => [
                    createVNode(unref(_sfc_main$3), null, {
                      default: withCtx(() => [
                        createVNode(unref(_sfc_main$4), null, {
                          default: withCtx(() => [
                            createTextVNode("Quick Actions")
                          ]),
                          _: 1
                        }),
                        createVNode(unref(_sfc_main$5), null, {
                          default: withCtx(() => [
                            createTextVNode("Create new items quickly")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(_sfc_main$6), null, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid gap-2 md:grid-cols-4" }, [
                          createVNode(unref(_sfc_main$7), {
                            "as-child": "",
                            class: "w-full justify-start"
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: unref(quotes).create().url
                              }, {
                                default: withCtx(() => [
                                  createVNode(unref(FileText), { class: "mr-2 h-4 w-4" }),
                                  createTextVNode(" New Quote ")
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$7), {
                            "as-child": "",
                            class: "w-full justify-start",
                            variant: "outline"
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: unref(invoices).create().url
                              }, {
                                default: withCtx(() => [
                                  createVNode(unref(Receipt), { class: "mr-2 h-4 w-4" }),
                                  createTextVNode(" New Invoice ")
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$7), {
                            "as-child": "",
                            class: "w-full justify-start",
                            variant: "outline"
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: unref(jobcards).create().url
                              }, {
                                default: withCtx(() => [
                                  createVNode(unref(Wrench), { class: "mr-2 h-4 w-4" }),
                                  createTextVNode(" New Jobcard ")
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$7), {
                            "as-child": "",
                            class: "w-full justify-start",
                            variant: "outline"
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: unref(customers).create().url
                              }, {
                                default: withCtx(() => [
                                  createVNode(unref(UserPlus), { class: "mr-2 h-4 w-4" }),
                                  createTextVNode(" New Customer ")
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(unref(_sfc_main$2), null, {
                  default: withCtx(() => [
                    createVNode(unref(_sfc_main$3), null, {
                      default: withCtx(() => [
                        createVNode("div", { class: "flex items-center justify-between" }, [
                          createVNode("div", null, [
                            createVNode(unref(_sfc_main$4), { class: "text-lg font-semibold" }, {
                              default: withCtx(() => [
                                createTextVNode("Your Sales Performance")
                              ]),
                              _: 1
                            }),
                            createVNode(unref(_sfc_main$5), null, {
                              default: withCtx(() => [
                                createTextVNode("Current month revenue and 12-month trend")
                              ]),
                              _: 1
                            })
                          ]),
                          createVNode(unref(TrendingUp), { class: "h-5 w-5 text-muted-foreground" })
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(unref(_sfc_main$6), null, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid gap-2 md:grid-cols-4" }, [
                          createVNode("div", { class: "space-y-1" }, [
                            createVNode("div", null, [
                              createVNode("div", { class: "text-3xl font-bold" }, toDisplayString(formatCurrency(_ctx.revenueStats.current_month_revenue)), 1),
                              createVNode("p", { class: "text-sm text-muted-foreground" }, "Current Month Revenue")
                            ])
                          ]),
                          createVNode("div", { class: "md:col-span-3" }, [
                            createVNode("h4", { class: "text-sm font-medium mb-2" }, "12-Month Revenue Trend"),
                            _ctx.userMonthlyRevenue && _ctx.userMonthlyRevenue.length > 0 ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "h-28 flex items-end justify-between gap-2"
                            }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.userMonthlyRevenue, (data, index) => {
                                return openBlock(), createBlock("div", {
                                  key: index,
                                  class: "flex flex-col items-center flex-1"
                                }, [
                                  createVNode("div", { class: "text-xs text-muted-foreground mb-1" }, toDisplayString(data.month), 1),
                                  createVNode("div", {
                                    class: "w-full bg-blue-500 rounded-t transition-all duration-300 hover:bg-blue-600 cursor-pointer",
                                    style: { height: getBarHeight(data.revenue) + "px", minHeight: "8px" },
                                    title: formatCurrency(data.revenue)
                                  }, null, 12, ["title"]),
                                  createVNode("div", { class: "text-xs text-muted-foreground mt-1 text-center" }, toDisplayString(formatCurrency(data.revenue)), 1)
                                ]);
                              }), 128))
                            ])) : (openBlock(), createBlock("div", {
                              key: 1,
                              class: "h-28 flex items-center justify-center text-muted-foreground border-2 border-dashed border-gray-300 rounded-lg"
                            }, [
                              createVNode("div", { class: "text-center" }, [
                                createVNode("div", { class: "text-sm font-medium" }, "No revenue data"),
                                createVNode("div", { class: "text-xs" }, "Create and mark invoices as paid to see trends")
                              ])
                            ])),
                            createVNode("div", { class: "mt-2 text-xs text-muted-foreground text-center" }, " Hover over bars to see exact amounts ")
                          ])
                        ])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(unref(_sfc_main$2), null, {
                  default: withCtx(() => [
                    createVNode(unref(_sfc_main$3), null, {
                      default: withCtx(() => [
                        createVNode(unref(_sfc_main$4), null, {
                          default: withCtx(() => [
                            createTextVNode("Recent Activity")
                          ]),
                          _: 1
                        }),
                        createVNode(unref(_sfc_main$5), null, {
                          default: withCtx(() => [
                            createTextVNode("Latest quotes, invoices, and jobcards")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(_sfc_main$6), null, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid gap-6 md:grid-cols-3" }, [
                          _ctx.recentActivity.recent_quotes.length > 0 ? (openBlock(), createBlock("div", { key: 0 }, [
                            createVNode("h4", { class: "text-sm font-medium mb-2" }, "Recent Quotes"),
                            createVNode("div", { class: "space-y-2" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.recentActivity.recent_quotes, (quote) => {
                                return openBlock(), createBlock(unref(Link), {
                                  key: quote.id,
                                  href: unref(quotes).show(quote.id).url,
                                  class: "flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-colors duration-200 cursor-pointer"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "flex items-center space-x-3" }, [
                                      createVNode(unref(FileText), { class: "h-4 w-4 text-blue-500" }),
                                      createVNode("div", null, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(quote.quote_number), 1),
                                        createVNode("p", { class: "text-xs text-muted-foreground" }, toDisplayString(quote.customer?.name), 1)
                                      ])
                                    ]),
                                    createVNode("div", { class: "text-right" }, [
                                      createVNode("p", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(quote.total)), 1),
                                      createVNode(unref(_sfc_main$8), {
                                        class: getStatusColor(quote.status)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(quote.status), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["class"])
                                    ])
                                  ]),
                                  _: 2
                                }, 1032, ["href"]);
                              }), 128))
                            ])
                          ])) : createCommentVNode("", true),
                          _ctx.recentActivity.recent_invoices.length > 0 ? (openBlock(), createBlock("div", { key: 1 }, [
                            createVNode("h4", { class: "text-sm font-medium mb-2" }, "Recent Invoices"),
                            createVNode("div", { class: "space-y-2" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.recentActivity.recent_invoices, (invoice) => {
                                return openBlock(), createBlock(unref(Link), {
                                  key: invoice.id,
                                  href: unref(invoices).show(invoice.id).url,
                                  class: "flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-colors duration-200 cursor-pointer"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "flex items-center space-x-3" }, [
                                      createVNode(unref(Receipt), { class: "h-4 w-4 text-green-500" }),
                                      createVNode("div", null, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(invoice.invoice_number), 1),
                                        createVNode("p", { class: "text-xs text-muted-foreground" }, toDisplayString(invoice.customer?.name), 1)
                                      ])
                                    ]),
                                    createVNode("div", { class: "text-right" }, [
                                      createVNode("p", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(invoice.total)), 1),
                                      createVNode(unref(_sfc_main$8), {
                                        class: getStatusColor(invoice.status)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(invoice.status), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["class"])
                                    ])
                                  ]),
                                  _: 2
                                }, 1032, ["href"]);
                              }), 128))
                            ])
                          ])) : createCommentVNode("", true),
                          _ctx.recentActivity.recent_jobcards.length > 0 ? (openBlock(), createBlock("div", { key: 2 }, [
                            createVNode("h4", { class: "text-sm font-medium mb-2" }, "Recent Jobcards"),
                            createVNode("div", { class: "space-y-2" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.recentActivity.recent_jobcards, (jobcard) => {
                                return openBlock(), createBlock(unref(Link), {
                                  key: jobcard.id,
                                  href: unref(jobcards).show(jobcard.id).url,
                                  class: "flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-colors duration-200 cursor-pointer"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "flex items-center space-x-3" }, [
                                      createVNode(unref(Wrench), { class: "h-4 w-4 text-orange-500" }),
                                      createVNode("div", null, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(jobcard.jobcard_number), 1),
                                        createVNode("p", { class: "text-xs text-muted-foreground" }, toDisplayString(jobcard.customer?.name), 1)
                                      ])
                                    ]),
                                    createVNode("div", { class: "text-right" }, [
                                      createVNode("p", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(jobcard.total)), 1),
                                      createVNode(unref(_sfc_main$8), {
                                        class: getStatusColor(jobcard.status)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(jobcard.status), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["class"])
                                    ])
                                  ]),
                                  _: 2
                                }, 1032, ["href"]);
                              }), 128))
                            ])
                          ])) : createCommentVNode("", true)
                        ])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "grid gap-6 md:grid-cols-3" }, [
                  createVNode(unref(_sfc_main$2), null, {
                    default: withCtx(() => [
                      createVNode(unref(_sfc_main$3), null, {
                        default: withCtx(() => [
                          createVNode(unref(_sfc_main$4), null, {
                            default: withCtx(() => [
                              createTextVNode("Quote Status")
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$5), null, {
                            default: withCtx(() => [
                              createTextVNode("Distribution of quote statuses")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(unref(_sfc_main$6), null, {
                        default: withCtx(() => [
                          _ctx.statusCharts && _ctx.statusCharts.quote_status ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "space-y-6"
                          }, [
                            createVNode("div", { class: "flex justify-center" }, [
                              createVNode("div", { class: "relative w-40 h-40 group" }, [
                                (openBlock(), createBlock("svg", {
                                  class: "w-40 h-40",
                                  viewBox: "0 0 100 100"
                                }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(createPieChartPath(_ctx.statusCharts.quote_status.data, _ctx.statusCharts.quote_status.colors, _ctx.statusCharts.quote_status.labels), (segment, index) => {
                                    return openBlock(), createBlock("path", {
                                      key: index,
                                      d: segment.path,
                                      fill: segment.color,
                                      class: "chart-segment cursor-pointer",
                                      style: {
                                        transformOrigin: "50% 50%",
                                        animationDelay: `${index * 100}ms`
                                      }
                                    }, null, 12, ["d", "fill"]);
                                  }), 128))
                                ])),
                                createVNode("div", { class: "absolute inset-0 flex flex-col items-center justify-center" }, [
                                  createVNode("span", { class: "text-lg font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.quote_status.data.reduce((a, b) => a + b, 0)), 1),
                                  createVNode("span", { class: "text-xs text-muted-foreground font-medium" }, "Total")
                                ])
                              ])
                            ]),
                            createVNode("div", { class: "space-y-3" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.statusCharts.quote_status.labels, (label, index) => {
                                return openBlock(), createBlock("div", {
                                  key: index,
                                  class: "legend-item flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200"
                                }, [
                                  createVNode("div", { class: "flex items-center space-x-3" }, [
                                    createVNode("div", {
                                      class: "w-3 h-3 rounded-full",
                                      style: { backgroundColor: _ctx.statusCharts.quote_status.colors[index] }
                                    }, null, 4),
                                    createVNode("span", { class: "text-sm font-medium text-foreground" }, toDisplayString(label), 1)
                                  ]),
                                  createVNode("div", { class: "flex items-center space-x-2" }, [
                                    createVNode("span", { class: "text-sm font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.quote_status.data[index]), 1),
                                    createVNode("span", { class: "text-xs text-muted-foreground" }, " (" + toDisplayString(Math.round(_ctx.statusCharts.quote_status.data[index] / _ctx.statusCharts.quote_status.data.reduce((a, b) => a + b, 0) * 100)) + "%) ", 1)
                                  ])
                                ]);
                              }), 128))
                            ])
                          ])) : (openBlock(), createBlock("div", {
                            key: 1,
                            class: "text-center py-8 text-muted-foreground"
                          }, [
                            createVNode("p", null, "No quote data available"),
                            createVNode("p", { class: "text-xs mt-1" }, "Create some quotes to see status distribution")
                          ]))
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(unref(_sfc_main$2), null, {
                    default: withCtx(() => [
                      createVNode(unref(_sfc_main$3), null, {
                        default: withCtx(() => [
                          createVNode(unref(_sfc_main$4), null, {
                            default: withCtx(() => [
                              createTextVNode("Invoice Status")
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$5), null, {
                            default: withCtx(() => [
                              createTextVNode("Distribution of invoice statuses")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(unref(_sfc_main$6), null, {
                        default: withCtx(() => [
                          _ctx.statusCharts && _ctx.statusCharts.invoice_status ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "space-y-6"
                          }, [
                            createVNode("div", { class: "flex justify-center" }, [
                              createVNode("div", { class: "relative w-40 h-40 group" }, [
                                (openBlock(), createBlock("svg", {
                                  class: "w-40 h-40",
                                  viewBox: "0 0 100 100"
                                }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(createPieChartPath(_ctx.statusCharts.invoice_status.data, _ctx.statusCharts.invoice_status.colors, _ctx.statusCharts.invoice_status.labels), (segment, index) => {
                                    return openBlock(), createBlock("path", {
                                      key: index,
                                      d: segment.path,
                                      fill: segment.color,
                                      class: "chart-segment cursor-pointer",
                                      style: {
                                        transformOrigin: "50% 50%",
                                        animationDelay: `${index * 100}ms`
                                      }
                                    }, null, 12, ["d", "fill"]);
                                  }), 128))
                                ])),
                                createVNode("div", { class: "absolute inset-0 flex flex-col items-center justify-center" }, [
                                  createVNode("span", { class: "text-lg font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.invoice_status.data.reduce((a, b) => a + b, 0)), 1),
                                  createVNode("span", { class: "text-xs text-muted-foreground font-medium" }, "Total")
                                ])
                              ])
                            ]),
                            createVNode("div", { class: "space-y-3" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.statusCharts.invoice_status.labels, (label, index) => {
                                return openBlock(), createBlock("div", {
                                  key: index,
                                  class: "legend-item flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200"
                                }, [
                                  createVNode("div", { class: "flex items-center space-x-3" }, [
                                    createVNode("div", {
                                      class: "w-3 h-3 rounded-full",
                                      style: { backgroundColor: _ctx.statusCharts.invoice_status.colors[index] }
                                    }, null, 4),
                                    createVNode("span", { class: "text-sm font-medium text-foreground" }, toDisplayString(label), 1)
                                  ]),
                                  createVNode("div", { class: "flex items-center space-x-2" }, [
                                    createVNode("span", { class: "text-sm font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.invoice_status.data[index]), 1),
                                    createVNode("span", { class: "text-xs text-muted-foreground" }, " (" + toDisplayString(Math.round(_ctx.statusCharts.invoice_status.data[index] / _ctx.statusCharts.invoice_status.data.reduce((a, b) => a + b, 0) * 100)) + "%) ", 1)
                                  ])
                                ]);
                              }), 128))
                            ])
                          ])) : (openBlock(), createBlock("div", {
                            key: 1,
                            class: "text-center py-8 text-muted-foreground"
                          }, [
                            createVNode("p", null, "No invoice data available"),
                            createVNode("p", { class: "text-xs mt-1" }, "Create some invoices to see status distribution")
                          ]))
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(unref(_sfc_main$2), null, {
                    default: withCtx(() => [
                      createVNode(unref(_sfc_main$3), null, {
                        default: withCtx(() => [
                          createVNode(unref(_sfc_main$4), null, {
                            default: withCtx(() => [
                              createTextVNode("Jobcard Status")
                            ]),
                            _: 1
                          }),
                          createVNode(unref(_sfc_main$5), null, {
                            default: withCtx(() => [
                              createTextVNode("Distribution of jobcard statuses")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(unref(_sfc_main$6), null, {
                        default: withCtx(() => [
                          _ctx.statusCharts && _ctx.statusCharts.jobcard_status ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "space-y-6"
                          }, [
                            createVNode("div", { class: "flex justify-center" }, [
                              createVNode("div", { class: "relative w-40 h-40 group" }, [
                                (openBlock(), createBlock("svg", {
                                  class: "w-40 h-40",
                                  viewBox: "0 0 100 100"
                                }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(createPieChartPath(_ctx.statusCharts.jobcard_status.data, _ctx.statusCharts.jobcard_status.colors, _ctx.statusCharts.jobcard_status.labels), (segment, index) => {
                                    return openBlock(), createBlock("path", {
                                      key: index,
                                      d: segment.path,
                                      fill: segment.color,
                                      class: "chart-segment cursor-pointer",
                                      style: {
                                        transformOrigin: "50% 50%",
                                        animationDelay: `${index * 100}ms`
                                      }
                                    }, null, 12, ["d", "fill"]);
                                  }), 128))
                                ])),
                                createVNode("div", { class: "absolute inset-0 flex flex-col items-center justify-center" }, [
                                  createVNode("span", { class: "text-lg font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.jobcard_status.data.reduce((a, b) => a + b, 0)), 1),
                                  createVNode("span", { class: "text-xs text-muted-foreground font-medium" }, "Total")
                                ])
                              ])
                            ]),
                            createVNode("div", { class: "space-y-3" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.statusCharts.jobcard_status.labels, (label, index) => {
                                return openBlock(), createBlock("div", {
                                  key: index,
                                  class: "legend-item flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200"
                                }, [
                                  createVNode("div", { class: "flex items-center space-x-3" }, [
                                    createVNode("div", {
                                      class: "w-3 h-3 rounded-full",
                                      style: { backgroundColor: _ctx.statusCharts.jobcard_status.colors[index] }
                                    }, null, 4),
                                    createVNode("span", { class: "text-sm font-medium text-foreground" }, toDisplayString(label), 1)
                                  ]),
                                  createVNode("div", { class: "flex items-center space-x-2" }, [
                                    createVNode("span", { class: "text-sm font-bold text-foreground" }, toDisplayString(_ctx.statusCharts.jobcard_status.data[index]), 1),
                                    createVNode("span", { class: "text-xs text-muted-foreground" }, " (" + toDisplayString(Math.round(_ctx.statusCharts.jobcard_status.data[index] / _ctx.statusCharts.jobcard_status.data.reduce((a, b) => a + b, 0) * 100)) + "%) ", 1)
                                  ])
                                ]);
                              }), 128))
                            ])
                          ])) : (openBlock(), createBlock("div", {
                            key: 1,
                            class: "text-center py-8 text-muted-foreground"
                          }, [
                            createVNode("p", null, "No jobcard data available"),
                            createVNode("p", { class: "text-xs mt-1" }, "Create some jobcards to see status distribution")
                          ]))
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Dashboard = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-034be482"]]);
export {
  Dashboard as default
};
