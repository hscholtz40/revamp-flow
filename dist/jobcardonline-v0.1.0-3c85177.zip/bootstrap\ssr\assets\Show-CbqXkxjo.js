import { defineComponent, ref, computed, unref, withCtx, createTextVNode, createVNode, createBlock, createCommentVNode, openBlock, Fragment, renderList, toDisplayString, withModifiers, withDirectives, vModelText, vModelSelect, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrRenderStyle, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { useForm, Head, Link, router } from "@inertiajs/vue3";
import { _ as _sfc_main$1, i as invoices, q as quotes } from "./AppLayout-CmGu2Oww.js";
import { j as jobcards } from "./_plugin-vue_export-helper-BjD8VFd3.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    invoice: {},
    canEditCompleted: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const showEmailModal = ref(false);
    const showResultDialog = ref(false);
    const showPaymentModal = ref(false);
    const emailResult = ref({
      success: false,
      email: "",
      message: ""
    });
    const canEditInvoice = computed(() => {
      if (props.invoice.status !== "paid") {
        return true;
      }
      return props.canEditCompleted;
    });
    const emailForm = useForm({
      email: props.invoice.customer?.email || "",
      customMessage: ""
    });
    const statusOptions = [
      { value: "draft", label: "Draft" },
      { value: "sent", label: "Sent" },
      { value: "paid", label: "Paid" },
      { value: "overdue", label: "Overdue" },
      { value: "cancelled", label: "Cancelled" }
    ];
    const formatDate = (date) => {
      return new Date(date).toLocaleDateString();
    };
    const formatDateTime = (date) => {
      return new Date(date).toLocaleString();
    };
    const formatCurrency = (amount) => {
      return new Intl.NumberFormat("en-ZA", {
        style: "currency",
        currency: "ZAR"
      }).format(amount || 0);
    };
    const formatStatus = (status) => {
      return status.charAt(0).toUpperCase() + status.slice(1).replace("_", " ");
    };
    const getStatusBadgeClass = (status) => {
      const classes = {
        draft: "bg-gray-100 text-gray-800",
        sent: "bg-blue-100 text-blue-800",
        paid: "bg-green-100 text-green-800",
        overdue: "bg-red-100 text-red-800",
        cancelled: "bg-gray-100 text-gray-800"
      };
      return classes[status] || "bg-gray-100 text-gray-800";
    };
    const updateStatus = (status) => {
      router.patch(invoices.updateStatus(props.invoice.id).url, { status });
    };
    const downloadPDF = () => {
      window.open(invoices.downloadPdf(props.invoice.id).url, "_blank");
    };
    const sendEmail = () => {
      emailForm.post(invoices.email(props.invoice.id).url, {
        onSuccess: (page) => {
          showEmailModal.value = false;
          emailResult.value = {
            success: true,
            email: emailForm.email,
            message: page.props.flash?.success || "Email sent successfully"
          };
          showResultDialog.value = true;
          emailForm.reset();
        },
        onError: (errors) => {
          showEmailModal.value = false;
          emailResult.value = {
            success: false,
            email: emailForm.email,
            message: errors.message || "Failed to send email"
          };
          showResultDialog.value = true;
        }
      });
    };
    const paymentForm = useForm({
      invoice_id: props.invoice.id,
      amount: (props.invoice.remaining_balance || props.invoice.total).toString(),
      payment_method: "",
      payment_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      // Today's date
      notes: ""
    });
    const addPayment = () => {
      paymentForm.post("/payments", {
        onSuccess: () => {
          paymentForm.reset();
          paymentForm.invoice_id = props.invoice.id;
          paymentForm.amount = (props.invoice.remaining_balance || props.invoice.total).toString();
          paymentForm.payment_date = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
          showPaymentModal.value = false;
          router.visit(window.location.pathname, { method: "get" });
        }
      });
    };
    const removePayment = (paymentId) => {
      if (confirm("Are you sure you want to remove this payment?")) {
        router.delete(`/payments/${paymentId}`, {
          onSuccess: () => {
            router.visit(window.location.pathname, { method: "get" });
          }
        });
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Invoice ${props.invoice.invoice_number}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [
          { title: "Invoices", href: unref(invoices).index().url },
          { title: props.invoice.invoice_number, href: "#" }
        ]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="space-y-6 p-4"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Status Management</h2><p class="text-sm text-gray-600"${_scopeId}>Update invoice status and track progress</p></div><div class="p-6"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div class="flex items-center gap-4"${_scopeId}><span class="text-sm font-medium text-gray-700"${_scopeId}>Current Status:</span><div class="flex items-center gap-2"${_scopeId}><!--[-->`);
            ssrRenderList(statusOptions, (status) => {
              _push2(`<button class="${ssrRenderClass([
                "px-3 py-1 text-sm font-medium rounded-md transition-colors",
                props.invoice.status === status.value ? "bg-blue-100 text-blue-800 border border-blue-200" : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200"
              ])}"${_scopeId}>${ssrInterpolate(status.label)}</button>`);
            });
            _push2(`<!--]--></div></div><div class="text-sm text-gray-500"${_scopeId}> Last updated: ${ssrInterpolate(formatDateTime(props.invoice.updated_at))}</div></div></div></div><div class="rounded-lg bg-white border border-gray-200 p-6 shadow-sm"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>${ssrInterpolate(props.invoice.invoice_number)}</h1><p class="text-sm text-gray-500 mt-1"${_scopeId}>${ssrInterpolate(props.invoice.title)}</p></div><div class="flex items-center gap-2"${_scopeId}><span class="${ssrRenderClass([getStatusBadgeClass(props.invoice.status), "inline-flex px-3 py-1 text-sm font-semibold rounded-full"])}"${_scopeId}>${ssrInterpolate(formatStatus(props.invoice.status))}</span><button class="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"${_scopeId}> Download PDF </button><button class="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"${_scopeId}> Email </button>`);
            if ((props.invoice.remaining_balance || props.invoice.total) > 0) {
              _push2(`<button class="rounded-md bg-purple-600 px-4 py-2 text-sm font-medium text-white hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2"${_scopeId}> Add Payment </button>`);
            } else {
              _push2(`<!---->`);
            }
            if (canEditInvoice.value) {
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(invoices).edit(props.invoice.id).url,
                class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Edit `);
                  } else {
                    return [
                      createTextVNode(" Edit ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<span class="rounded-md bg-gray-400 px-4 py-2 text-sm font-medium text-white cursor-not-allowed" title="Cannot edit paid invoices without permission"${_scopeId}> Edit </span>`);
            }
            _push2(`</div></div></div><div class="grid grid-cols-1 lg:grid-cols-3 gap-6"${_scopeId}><div class="lg:col-span-2 space-y-6"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Customer Information</h2><p class="text-sm text-gray-600"${_scopeId}>Customer details and contact information</p></div><div class="p-6"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Customer</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.invoice.customer?.name)}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Email</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.invoice.customer?.email || "-")}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Phone</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.invoice.customer?.phone || "-")}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Address</label><p class="text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.invoice.customer?.address || "-")}</p></div></div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Line Items</h2><p class="text-sm text-gray-600"${_scopeId}>Invoice line items and pricing details</p></div><div class="p-6"${_scopeId}><div class="overflow-x-auto"${_scopeId}><table class="w-full"${_scopeId}><thead class="bg-gray-50"${_scopeId}><tr${_scopeId}><th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}>Description</th><th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}>Quantity</th><th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}>Unit Price</th><th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"${_scopeId}>Total</th></tr></thead><tbody class="bg-white divide-y divide-gray-200"${_scopeId}><!--[-->`);
            ssrRenderList(props.invoice.line_items, (item) => {
              _push2(`<tr${_scopeId}><td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900"${_scopeId}>${ssrInterpolate(item.description)}</td><td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900"${_scopeId}>${ssrInterpolate(item.quantity)}</td><td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatCurrency(item.unit_price))}</td><td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900"${_scopeId}>${ssrInterpolate(formatCurrency(item.total))}</td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div></div>`);
            if (props.invoice.notes || props.invoice.terms) {
              _push2(`<div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Additional Information</h2><p class="text-sm text-gray-600"${_scopeId}>Notes and terms for this invoice</p></div><div class="p-6"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-2 gap-6"${_scopeId}>`);
              if (props.invoice.notes) {
                _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Notes</label><p class="text-sm text-gray-600 whitespace-pre-wrap"${_scopeId}>${ssrInterpolate(props.invoice.notes)}</p></div>`);
              } else {
                _push2(`<!---->`);
              }
              if (props.invoice.terms) {
                _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-700"${_scopeId}>Terms &amp; Conditions</label><p class="text-sm text-gray-600 whitespace-pre-wrap"${_scopeId}>${ssrInterpolate(props.invoice.terms)}</p></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="space-y-6"${_scopeId}><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Invoice Details</h2><p class="text-sm text-gray-600"${_scopeId}>Key information about this invoice</p></div><div class="p-6 space-y-4"${_scopeId}><div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Invoice Number</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.invoice.invoice_number)}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Invoice Date</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatDate(props.invoice.invoice_date))}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Due Date</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatDate(props.invoice.due_date))}</p></div><div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Status</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(formatStatus(props.invoice.status))}</p></div>`);
            if (props.invoice.salesperson) {
              _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Salesperson</label><p class="mt-1 text-sm text-gray-900"${_scopeId}>${ssrInterpolate(props.invoice.salesperson.name)}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (props.invoice.description) {
              _push2(`<div${_scopeId}><label class="block text-sm font-medium text-gray-500"${_scopeId}>Description</label><p class="mt-1 text-sm text-gray-600"${_scopeId}>${ssrInterpolate(props.invoice.description)}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Totals</h2><p class="text-sm text-gray-600"${_scopeId}>Invoice totals and calculations</p></div><div class="p-6"${_scopeId}><div class="space-y-2"${_scopeId}><div class="flex justify-between"${_scopeId}><span class="text-gray-600"${_scopeId}>Subtotal:</span><span class="font-medium"${_scopeId}>${ssrInterpolate(formatCurrency(props.invoice.subtotal))}</span></div>`);
            if ((Number(props.invoice.discount_amount) || 0) > 0) {
              _push2(`<div class="flex justify-between"${_scopeId}><span class="text-gray-600"${_scopeId}>Discount:</span><span class="font-medium text-red-600"${_scopeId}>-${ssrInterpolate(formatCurrency(props.invoice.discount_amount))}</span></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex justify-between"${_scopeId}><span class="text-gray-600"${_scopeId}>Tax (${ssrInterpolate(props.invoice.tax_rate)}%):</span><span class="font-medium"${_scopeId}>${ssrInterpolate(formatCurrency(props.invoice.tax_amount))}</span></div><div class="flex justify-between text-lg font-semibold border-t pt-2"${_scopeId}><span${_scopeId}>Total:</span><span${_scopeId}>${ssrInterpolate(formatCurrency(props.invoice.total))}</span></div></div></div></div><div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Payments</h2><p class="text-sm text-gray-600"${_scopeId}>Payment history and balance</p></div><div class="p-6"${_scopeId}><div class="mb-4 space-y-2"${_scopeId}><div class="flex justify-between"${_scopeId}><span class="text-sm font-medium text-gray-700"${_scopeId}>Total Amount:</span><span class="text-sm font-medium"${_scopeId}>${ssrInterpolate(formatCurrency(props.invoice.total))}</span></div><div class="flex justify-between"${_scopeId}><span class="text-sm font-medium text-gray-700"${_scopeId}>Total Paid:</span><span class="text-sm font-medium text-green-600"${_scopeId}>${ssrInterpolate(formatCurrency(props.invoice.total_paid || 0))}</span></div><div class="flex justify-between border-t pt-2"${_scopeId}><span class="text-sm font-semibold text-gray-900"${_scopeId}>Remaining Balance:</span><span class="${ssrRenderClass([(props.invoice.remaining_balance || props.invoice.total) > 0 ? "text-red-600" : "text-green-600", "text-sm font-semibold"])}"${_scopeId}>${ssrInterpolate(formatCurrency(props.invoice.remaining_balance || props.invoice.total))}</span></div></div>`);
            if (props.invoice.payments && props.invoice.payments.length > 0) {
              _push2(`<div${_scopeId}><h3 class="text-sm font-medium text-gray-900 mb-3"${_scopeId}>Payment History</h3><div class="space-y-2"${_scopeId}><!--[-->`);
              ssrRenderList(props.invoice.payments, (payment) => {
                _push2(`<div class="flex items-center justify-between p-3 bg-white border border-gray-200 rounded-lg"${_scopeId}><div class="flex-1"${_scopeId}><div class="flex items-center gap-2"${_scopeId}><span class="text-sm font-medium"${_scopeId}>${ssrInterpolate(formatCurrency(payment.amount))}</span><span class="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-700"${_scopeId}>${ssrInterpolate(payment.payment_method.toUpperCase())}</span></div><div class="text-xs text-gray-500 mt-1"${_scopeId}>${ssrInterpolate(formatDate(payment.payment_date))} `);
                if (payment.notes) {
                  _push2(`<span class="ml-2"${_scopeId}>• ${ssrInterpolate(payment.notes)}</span>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div></div><button class="text-red-600 hover:text-red-800 text-xs" title="Remove Payment"${_scopeId}> Remove </button></div>`);
              });
              _push2(`<!--]--></div></div>`);
            } else {
              _push2(`<div class="text-center py-4 text-sm text-gray-500"${_scopeId}> No payments recorded </div>`);
            }
            _push2(`</div></div>`);
            if (props.invoice.source) {
              _push2(`<div class="rounded-lg bg-white border border-gray-200 shadow-sm"${_scopeId}><div class="border-b border-gray-200 bg-gray-50 px-6 py-4"${_scopeId}><h2 class="text-lg font-semibold text-gray-900"${_scopeId}>Source</h2><p class="text-sm text-gray-600"${_scopeId}>Original document this invoice was created from</p></div><div class="p-6"${_scopeId}><div class="text-sm"${_scopeId}><div${_scopeId}><span class="font-medium"${_scopeId}>Type:</span> ${ssrInterpolate(props.invoice.source_type)}</div>`);
              if (props.invoice.source_type === "quote") {
                _push2(`<div${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: unref(quotes).show(props.invoice.source_id).url,
                  class: "text-blue-600 hover:text-blue-800"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` View Original Quote `);
                    } else {
                      return [
                        createTextVNode(" View Original Quote ")
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
                _push2(`</div>`);
              } else if (props.invoice.source_type === "jobcard") {
                _push2(`<div${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: unref(jobcards).show(props.invoice.source_id).url,
                  class: "text-blue-600 hover:text-blue-800"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` View Original Jobcard `);
                    } else {
                      return [
                        createTextVNode(" View Original Jobcard ")
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div>`);
            if (showEmailModal.value) {
              _push2(`<div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50"${_scopeId}><div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white"${_scopeId}><div class="mt-3"${_scopeId}><h3 class="text-lg font-medium text-gray-900 mb-4"${_scopeId}>Email Invoice</h3><form${_scopeId}><div class="mb-4"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Email Address *</label><input${ssrRenderAttr("value", unref(emailForm).email)} type="email" class="${ssrRenderClass([{ "border-red-500": unref(emailForm).errors.email }, "w-full rounded border px-3 py-2"])}" required${_scopeId}>`);
              if (unref(emailForm).errors.email) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(emailForm).errors.email)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4"${_scopeId}><label class="block text-sm font-medium text-gray-700 mb-1"${_scopeId}>Message</label><textarea rows="3" class="w-full rounded border px-3 py-2" placeholder="Optional message to include with the invoice..."${_scopeId}>${ssrInterpolate(unref(emailForm).customMessage)}</textarea></div><div class="flex items-center justify-end gap-3"${_scopeId}><button type="button" class="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"${_scopeId}> Cancel </button><button type="submit"${ssrIncludeBooleanAttr(unref(emailForm).processing) ? " disabled" : ""} class="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"${_scopeId}>${ssrInterpolate(unref(emailForm).processing ? "Sending..." : "Send Email")}</button></div></form></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (showResultDialog.value) {
              _push2(`<div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50"${_scopeId}><div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white"${_scopeId}><div class="mt-3"${_scopeId}><h3 class="text-lg font-medium text-gray-900 mb-2 text-center"${_scopeId}>${ssrInterpolate(emailResult.value.success ? "Email Sent Successfully!" : "Email Failed to Send")}</h3><div class="text-center"${_scopeId}>`);
              if (emailResult.value.success) {
                _push2(`<p class="text-sm text-gray-600 mb-4"${_scopeId}> The invoice has been sent to <strong${_scopeId}>${ssrInterpolate(emailResult.value.email)}</strong></p>`);
              } else {
                _push2(`<p class="text-sm text-red-600 mb-4"${_scopeId}>${ssrInterpolate(emailResult.value.message)}</p>`);
              }
              _push2(`</div><div class="flex justify-center"${_scopeId}><button class="${ssrRenderClass([emailResult.value.success ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500", "rounded-md px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2"])}"${_scopeId}>${ssrInterpolate(emailResult.value.success ? "Great!" : "Try Again")}</button></div></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (showPaymentModal.value) {
              _push2(`<div style="${ssrRenderStyle({ "position": "fixed", "top": "0", "left": "0", "width": "100%", "height": "100%", "background": "rgba(0,0,0,0.5)", "z-index": "9999", "display": "flex", "align-items": "center", "justify-content": "center" })}"${_scopeId}><div style="${ssrRenderStyle({ "background": "white", "padding": "20px", "border-radius": "8px", "max-width": "500px", "width": "90%" })}"${_scopeId}><h3 style="${ssrRenderStyle({ "font-size": "18px", "font-weight": "600", "margin-bottom": "16px", "color": "#111827" })}"${_scopeId}> Add Payment </h3><form style="${ssrRenderStyle({ "display": "flex", "flex-direction": "column", "gap": "16px" })}"${_scopeId}><div style="${ssrRenderStyle({ "display": "grid", "grid-template-columns": "1fr 1fr", "gap": "16px" })}"${_scopeId}><div${_scopeId}><label style="${ssrRenderStyle({ "display": "block", "font-size": "14px", "font-weight": "500", "color": "#374151", "margin-bottom": "4px" })}"${_scopeId}>Amount</label><input${ssrRenderAttr("value", unref(paymentForm).amount)} type="number" step="0.01" min="0.01"${ssrRenderAttr("max", props.invoice.remaining_balance || props.invoice.total)} style="${ssrRenderStyle([{ "width": "100%", "border": "1px solid #d1d5db", "border-radius": "4px", "padding": "8px 12px", "font-size": "14px" }, { "border-color": unref(paymentForm).errors.amount ? "#ef4444" : "#d1d5db" }])}" required${_scopeId}><div style="${ssrRenderStyle({ "font-size": "12px", "color": "#6b7280", "margin-top": "4px" })}"${_scopeId}> Auto-filled with remaining balance </div>`);
              if (unref(paymentForm).errors.amount) {
                _push2(`<div style="${ssrRenderStyle({ "color": "#ef4444", "font-size": "12px", "margin-top": "4px" })}"${_scopeId}>${ssrInterpolate(unref(paymentForm).errors.amount)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div${_scopeId}><label style="${ssrRenderStyle({ "display": "block", "font-size": "14px", "font-weight": "500", "color": "#374151", "margin-bottom": "4px" })}"${_scopeId}>Payment Method</label><select style="${ssrRenderStyle([{ "width": "100%", "border": "1px solid #d1d5db", "border-radius": "4px", "padding": "8px 12px", "font-size": "14px" }, { "border-color": unref(paymentForm).errors.payment_method ? "#ef4444" : "#d1d5db" }])}" required${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(unref(paymentForm).payment_method) ? ssrLooseContain(unref(paymentForm).payment_method, "") : ssrLooseEqual(unref(paymentForm).payment_method, "")) ? " selected" : ""}${_scopeId}>Select Method</option><option value="cash"${ssrIncludeBooleanAttr(Array.isArray(unref(paymentForm).payment_method) ? ssrLooseContain(unref(paymentForm).payment_method, "cash") : ssrLooseEqual(unref(paymentForm).payment_method, "cash")) ? " selected" : ""}${_scopeId}>Cash</option><option value="card"${ssrIncludeBooleanAttr(Array.isArray(unref(paymentForm).payment_method) ? ssrLooseContain(unref(paymentForm).payment_method, "card") : ssrLooseEqual(unref(paymentForm).payment_method, "card")) ? " selected" : ""}${_scopeId}>Card</option><option value="eft"${ssrIncludeBooleanAttr(Array.isArray(unref(paymentForm).payment_method) ? ssrLooseContain(unref(paymentForm).payment_method, "eft") : ssrLooseEqual(unref(paymentForm).payment_method, "eft")) ? " selected" : ""}${_scopeId}>EFT</option></select>`);
              if (unref(paymentForm).errors.payment_method) {
                _push2(`<div style="${ssrRenderStyle({ "color": "#ef4444", "font-size": "12px", "margin-top": "4px" })}"${_scopeId}>${ssrInterpolate(unref(paymentForm).errors.payment_method)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div><div${_scopeId}><label style="${ssrRenderStyle({ "display": "block", "font-size": "14px", "font-weight": "500", "color": "#374151", "margin-bottom": "4px" })}"${_scopeId}>Payment Date</label><input${ssrRenderAttr("value", unref(paymentForm).payment_date)} type="date" style="${ssrRenderStyle([{ "width": "100%", "border": "1px solid #d1d5db", "border-radius": "4px", "padding": "8px 12px", "font-size": "14px" }, { "border-color": unref(paymentForm).errors.payment_date ? "#ef4444" : "#d1d5db" }])}" required${_scopeId}>`);
              if (unref(paymentForm).errors.payment_date) {
                _push2(`<div style="${ssrRenderStyle({ "color": "#ef4444", "font-size": "12px", "margin-top": "4px" })}"${_scopeId}>${ssrInterpolate(unref(paymentForm).errors.payment_date)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div${_scopeId}><label style="${ssrRenderStyle({ "display": "block", "font-size": "14px", "font-weight": "500", "color": "#374151", "margin-bottom": "4px" })}"${_scopeId}>Notes (Optional)</label><textarea rows="3" style="${ssrRenderStyle([{ "width": "100%", "border": "1px solid #d1d5db", "border-radius": "4px", "padding": "8px 12px", "font-size": "14px", "resize": "vertical" }, { "border-color": unref(paymentForm).errors.notes ? "#ef4444" : "#d1d5db" }])}" placeholder="Add any additional notes about this payment..."${_scopeId}>${ssrInterpolate(unref(paymentForm).notes)}</textarea>`);
              if (unref(paymentForm).errors.notes) {
                _push2(`<div style="${ssrRenderStyle({ "color": "#ef4444", "font-size": "12px", "margin-top": "4px" })}"${_scopeId}>${ssrInterpolate(unref(paymentForm).errors.notes)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></form><div style="${ssrRenderStyle({ "display": "flex", "gap": "12px", "margin-top": "20px", "justify-content": "flex-end" })}"${_scopeId}><button${ssrIncludeBooleanAttr(unref(paymentForm).processing) ? " disabled" : ""} style="${ssrRenderStyle([{ "padding": "8px 16px", "border": "1px solid #d1d5db", "border-radius": "4px", "background": "white", "color": "#374151", "font-size": "14px", "font-weight": "500", "cursor": "pointer" }, { "opacity": unref(paymentForm).processing ? "0.5" : "1" }])}"${_scopeId}> Cancel </button><button${ssrIncludeBooleanAttr(unref(paymentForm).processing) ? " disabled" : ""} style="${ssrRenderStyle([{ "padding": "8px 16px", "border": "none", "border-radius": "4px", "background": "#2563eb", "color": "white", "font-size": "14px", "font-weight": "500", "cursor": "pointer" }, { "opacity": unref(paymentForm).processing ? "0.5" : "1" }])}"${_scopeId}>${ssrInterpolate(unref(paymentForm).processing ? "Adding..." : "Add Payment")}</button></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              createVNode("div", { class: "space-y-6 p-4" }, [
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                  createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Status Management"),
                    createVNode("p", { class: "text-sm text-gray-600" }, "Update invoice status and track progress")
                  ]),
                  createVNode("div", { class: "p-6" }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", { class: "flex items-center gap-4" }, [
                        createVNode("span", { class: "text-sm font-medium text-gray-700" }, "Current Status:"),
                        createVNode("div", { class: "flex items-center gap-2" }, [
                          (openBlock(), createBlock(Fragment, null, renderList(statusOptions, (status) => {
                            return createVNode("button", {
                              key: status.value,
                              onClick: ($event) => updateStatus(status.value),
                              class: [
                                "px-3 py-1 text-sm font-medium rounded-md transition-colors",
                                props.invoice.status === status.value ? "bg-blue-100 text-blue-800 border border-blue-200" : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200"
                              ]
                            }, toDisplayString(status.label), 11, ["onClick"]);
                          }), 64))
                        ])
                      ]),
                      createVNode("div", { class: "text-sm text-gray-500" }, " Last updated: " + toDisplayString(formatDateTime(props.invoice.updated_at)), 1)
                    ])
                  ])
                ]),
                createVNode("div", { class: "rounded-lg bg-white border border-gray-200 p-6 shadow-sm" }, [
                  createVNode("div", { class: "flex items-center justify-between" }, [
                    createVNode("div", null, [
                      createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, toDisplayString(props.invoice.invoice_number), 1),
                      createVNode("p", { class: "text-sm text-gray-500 mt-1" }, toDisplayString(props.invoice.title), 1)
                    ]),
                    createVNode("div", { class: "flex items-center gap-2" }, [
                      createVNode("span", {
                        class: [getStatusBadgeClass(props.invoice.status), "inline-flex px-3 py-1 text-sm font-semibold rounded-full"]
                      }, toDisplayString(formatStatus(props.invoice.status)), 3),
                      createVNode("button", {
                        onClick: downloadPDF,
                        class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, " Download PDF "),
                      createVNode("button", {
                        onClick: ($event) => showEmailModal.value = true,
                        class: "rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
                      }, " Email ", 8, ["onClick"]),
                      (props.invoice.remaining_balance || props.invoice.total) > 0 ? (openBlock(), createBlock("button", {
                        key: 0,
                        onClick: ($event) => showPaymentModal.value = true,
                        class: "rounded-md bg-purple-600 px-4 py-2 text-sm font-medium text-white hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2"
                      }, " Add Payment ", 8, ["onClick"])) : createCommentVNode("", true),
                      canEditInvoice.value ? (openBlock(), createBlock(unref(Link), {
                        key: 1,
                        href: unref(invoices).edit(props.invoice.id).url,
                        class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Edit ")
                        ]),
                        _: 1
                      }, 8, ["href"])) : (openBlock(), createBlock("span", {
                        key: 2,
                        class: "rounded-md bg-gray-400 px-4 py-2 text-sm font-medium text-white cursor-not-allowed",
                        title: "Cannot edit paid invoices without permission"
                      }, " Edit "))
                    ])
                  ])
                ]),
                createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-3 gap-6" }, [
                  createVNode("div", { class: "lg:col-span-2 space-y-6" }, [
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Customer Information"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Customer details and contact information")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Customer"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(props.invoice.customer?.name), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Email"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(props.invoice.customer?.email || "-"), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Phone"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(props.invoice.customer?.phone || "-"), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Address"),
                            createVNode("p", { class: "text-sm text-gray-900" }, toDisplayString(props.invoice.customer?.address || "-"), 1)
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Line Items"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Invoice line items and pricing details")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "overflow-x-auto" }, [
                          createVNode("table", { class: "w-full" }, [
                            createVNode("thead", { class: "bg-gray-50" }, [
                              createVNode("tr", null, [
                                createVNode("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, "Description"),
                                createVNode("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, "Quantity"),
                                createVNode("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, "Unit Price"),
                                createVNode("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" }, "Total")
                              ])
                            ]),
                            createVNode("tbody", { class: "bg-white divide-y divide-gray-200" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(props.invoice.line_items, (item) => {
                                return openBlock(), createBlock("tr", {
                                  key: item.id
                                }, [
                                  createVNode("td", { class: "px-4 py-4 whitespace-nowrap text-sm text-gray-900" }, toDisplayString(item.description), 1),
                                  createVNode("td", { class: "px-4 py-4 whitespace-nowrap text-sm text-gray-900" }, toDisplayString(item.quantity), 1),
                                  createVNode("td", { class: "px-4 py-4 whitespace-nowrap text-sm text-gray-900" }, toDisplayString(formatCurrency(item.unit_price)), 1),
                                  createVNode("td", { class: "px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900" }, toDisplayString(formatCurrency(item.total)), 1)
                                ]);
                              }), 128))
                            ])
                          ])
                        ])
                      ])
                    ]),
                    props.invoice.notes || props.invoice.terms ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "rounded-lg bg-white border border-gray-200 shadow-sm"
                    }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Additional Information"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Notes and terms for this invoice")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-6" }, [
                          props.invoice.notes ? (openBlock(), createBlock("div", { key: 0 }, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Notes"),
                            createVNode("p", { class: "text-sm text-gray-600 whitespace-pre-wrap" }, toDisplayString(props.invoice.notes), 1)
                          ])) : createCommentVNode("", true),
                          props.invoice.terms ? (openBlock(), createBlock("div", { key: 1 }, [
                            createVNode("label", { class: "block text-sm font-medium text-gray-700" }, "Terms & Conditions"),
                            createVNode("p", { class: "text-sm text-gray-600 whitespace-pre-wrap" }, toDisplayString(props.invoice.terms), 1)
                          ])) : createCommentVNode("", true)
                        ])
                      ])
                    ])) : createCommentVNode("", true)
                  ]),
                  createVNode("div", { class: "space-y-6" }, [
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Invoice Details"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Key information about this invoice")
                      ]),
                      createVNode("div", { class: "p-6 space-y-4" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Invoice Number"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(props.invoice.invoice_number), 1)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Invoice Date"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(formatDate(props.invoice.invoice_date)), 1)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Due Date"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(formatDate(props.invoice.due_date)), 1)
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Status"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(formatStatus(props.invoice.status)), 1)
                        ]),
                        props.invoice.salesperson ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Salesperson"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-900" }, toDisplayString(props.invoice.salesperson.name), 1)
                        ])) : createCommentVNode("", true),
                        props.invoice.description ? (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode("label", { class: "block text-sm font-medium text-gray-500" }, "Description"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-600" }, toDisplayString(props.invoice.description), 1)
                        ])) : createCommentVNode("", true)
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Totals"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Invoice totals and calculations")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "space-y-2" }, [
                          createVNode("div", { class: "flex justify-between" }, [
                            createVNode("span", { class: "text-gray-600" }, "Subtotal:"),
                            createVNode("span", { class: "font-medium" }, toDisplayString(formatCurrency(props.invoice.subtotal)), 1)
                          ]),
                          (Number(props.invoice.discount_amount) || 0) > 0 ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "flex justify-between"
                          }, [
                            createVNode("span", { class: "text-gray-600" }, "Discount:"),
                            createVNode("span", { class: "font-medium text-red-600" }, "-" + toDisplayString(formatCurrency(props.invoice.discount_amount)), 1)
                          ])) : createCommentVNode("", true),
                          createVNode("div", { class: "flex justify-between" }, [
                            createVNode("span", { class: "text-gray-600" }, "Tax (" + toDisplayString(props.invoice.tax_rate) + "%):", 1),
                            createVNode("span", { class: "font-medium" }, toDisplayString(formatCurrency(props.invoice.tax_amount)), 1)
                          ]),
                          createVNode("div", { class: "flex justify-between text-lg font-semibold border-t pt-2" }, [
                            createVNode("span", null, "Total:"),
                            createVNode("span", null, toDisplayString(formatCurrency(props.invoice.total)), 1)
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "rounded-lg bg-white border border-gray-200 shadow-sm" }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Payments"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Payment history and balance")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "mb-4 space-y-2" }, [
                          createVNode("div", { class: "flex justify-between" }, [
                            createVNode("span", { class: "text-sm font-medium text-gray-700" }, "Total Amount:"),
                            createVNode("span", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(props.invoice.total)), 1)
                          ]),
                          createVNode("div", { class: "flex justify-between" }, [
                            createVNode("span", { class: "text-sm font-medium text-gray-700" }, "Total Paid:"),
                            createVNode("span", { class: "text-sm font-medium text-green-600" }, toDisplayString(formatCurrency(props.invoice.total_paid || 0)), 1)
                          ]),
                          createVNode("div", { class: "flex justify-between border-t pt-2" }, [
                            createVNode("span", { class: "text-sm font-semibold text-gray-900" }, "Remaining Balance:"),
                            createVNode("span", {
                              class: ["text-sm font-semibold", (props.invoice.remaining_balance || props.invoice.total) > 0 ? "text-red-600" : "text-green-600"]
                            }, toDisplayString(formatCurrency(props.invoice.remaining_balance || props.invoice.total)), 3)
                          ])
                        ]),
                        props.invoice.payments && props.invoice.payments.length > 0 ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("h3", { class: "text-sm font-medium text-gray-900 mb-3" }, "Payment History"),
                          createVNode("div", { class: "space-y-2" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(props.invoice.payments, (payment) => {
                              return openBlock(), createBlock("div", {
                                key: payment.id,
                                class: "flex items-center justify-between p-3 bg-white border border-gray-200 rounded-lg"
                              }, [
                                createVNode("div", { class: "flex-1" }, [
                                  createVNode("div", { class: "flex items-center gap-2" }, [
                                    createVNode("span", { class: "text-sm font-medium" }, toDisplayString(formatCurrency(payment.amount)), 1),
                                    createVNode("span", { class: "text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-700" }, toDisplayString(payment.payment_method.toUpperCase()), 1)
                                  ]),
                                  createVNode("div", { class: "text-xs text-gray-500 mt-1" }, [
                                    createTextVNode(toDisplayString(formatDate(payment.payment_date)) + " ", 1),
                                    payment.notes ? (openBlock(), createBlock("span", {
                                      key: 0,
                                      class: "ml-2"
                                    }, "• " + toDisplayString(payment.notes), 1)) : createCommentVNode("", true)
                                  ])
                                ]),
                                createVNode("button", {
                                  onClick: ($event) => removePayment(payment.id),
                                  class: "text-red-600 hover:text-red-800 text-xs",
                                  title: "Remove Payment"
                                }, " Remove ", 8, ["onClick"])
                              ]);
                            }), 128))
                          ])
                        ])) : (openBlock(), createBlock("div", {
                          key: 1,
                          class: "text-center py-4 text-sm text-gray-500"
                        }, " No payments recorded "))
                      ])
                    ]),
                    props.invoice.source ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "rounded-lg bg-white border border-gray-200 shadow-sm"
                    }, [
                      createVNode("div", { class: "border-b border-gray-200 bg-gray-50 px-6 py-4" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900" }, "Source"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Original document this invoice was created from")
                      ]),
                      createVNode("div", { class: "p-6" }, [
                        createVNode("div", { class: "text-sm" }, [
                          createVNode("div", null, [
                            createVNode("span", { class: "font-medium" }, "Type:"),
                            createTextVNode(" " + toDisplayString(props.invoice.source_type), 1)
                          ]),
                          props.invoice.source_type === "quote" ? (openBlock(), createBlock("div", { key: 0 }, [
                            createVNode(unref(Link), {
                              href: unref(quotes).show(props.invoice.source_id).url,
                              class: "text-blue-600 hover:text-blue-800"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" View Original Quote ")
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ])) : props.invoice.source_type === "jobcard" ? (openBlock(), createBlock("div", { key: 1 }, [
                            createVNode(unref(Link), {
                              href: unref(jobcards).show(props.invoice.source_id).url,
                              class: "text-blue-600 hover:text-blue-800"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" View Original Jobcard ")
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ])) : createCommentVNode("", true)
                        ])
                      ])
                    ])) : createCommentVNode("", true)
                  ])
                ])
              ]),
              showEmailModal.value ? (openBlock(), createBlock("div", {
                key: 0,
                class: "fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50"
              }, [
                createVNode("div", { class: "relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white" }, [
                  createVNode("div", { class: "mt-3" }, [
                    createVNode("h3", { class: "text-lg font-medium text-gray-900 mb-4" }, "Email Invoice"),
                    createVNode("form", {
                      onSubmit: withModifiers(sendEmail, ["prevent"])
                    }, [
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Email Address *"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => unref(emailForm).email = $event,
                          type: "email",
                          class: ["w-full rounded border px-3 py-2", { "border-red-500": unref(emailForm).errors.email }],
                          required: ""
                        }, null, 10, ["onUpdate:modelValue"]), [
                          [vModelText, unref(emailForm).email]
                        ]),
                        unref(emailForm).errors.email ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "text-red-500 text-sm mt-1"
                        }, toDisplayString(unref(emailForm).errors.email), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", { class: "block text-sm font-medium text-gray-700 mb-1" }, "Message"),
                        withDirectives(createVNode("textarea", {
                          "onUpdate:modelValue": ($event) => unref(emailForm).customMessage = $event,
                          rows: "3",
                          class: "w-full rounded border px-3 py-2",
                          placeholder: "Optional message to include with the invoice..."
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(emailForm).customMessage]
                        ])
                      ]),
                      createVNode("div", { class: "flex items-center justify-end gap-3" }, [
                        createVNode("button", {
                          type: "button",
                          onClick: ($event) => showEmailModal.value = false,
                          class: "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                        }, " Cancel ", 8, ["onClick"]),
                        createVNode("button", {
                          type: "submit",
                          disabled: unref(emailForm).processing,
                          class: "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
                        }, toDisplayString(unref(emailForm).processing ? "Sending..." : "Send Email"), 9, ["disabled"])
                      ])
                    ], 32)
                  ])
                ])
              ])) : createCommentVNode("", true),
              showResultDialog.value ? (openBlock(), createBlock("div", {
                key: 1,
                class: "fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50"
              }, [
                createVNode("div", { class: "relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white" }, [
                  createVNode("div", { class: "mt-3" }, [
                    createVNode("h3", { class: "text-lg font-medium text-gray-900 mb-2 text-center" }, toDisplayString(emailResult.value.success ? "Email Sent Successfully!" : "Email Failed to Send"), 1),
                    createVNode("div", { class: "text-center" }, [
                      emailResult.value.success ? (openBlock(), createBlock("p", {
                        key: 0,
                        class: "text-sm text-gray-600 mb-4"
                      }, [
                        createTextVNode(" The invoice has been sent to "),
                        createVNode("strong", null, toDisplayString(emailResult.value.email), 1)
                      ])) : (openBlock(), createBlock("p", {
                        key: 1,
                        class: "text-sm text-red-600 mb-4"
                      }, toDisplayString(emailResult.value.message), 1))
                    ]),
                    createVNode("div", { class: "flex justify-center" }, [
                      createVNode("button", {
                        onClick: ($event) => showResultDialog.value = false,
                        class: ["rounded-md px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2", emailResult.value.success ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500"]
                      }, toDisplayString(emailResult.value.success ? "Great!" : "Try Again"), 11, ["onClick"])
                    ])
                  ])
                ])
              ])) : createCommentVNode("", true),
              showPaymentModal.value ? (openBlock(), createBlock("div", {
                key: 2,
                style: { "position": "fixed", "top": "0", "left": "0", "width": "100%", "height": "100%", "background": "rgba(0,0,0,0.5)", "z-index": "9999", "display": "flex", "align-items": "center", "justify-content": "center" },
                onClick: ($event) => showPaymentModal.value = false
              }, [
                createVNode("div", {
                  style: { "background": "white", "padding": "20px", "border-radius": "8px", "max-width": "500px", "width": "90%" },
                  onClick: withModifiers(() => {
                  }, ["stop"])
                }, [
                  createVNode("h3", { style: { "font-size": "18px", "font-weight": "600", "margin-bottom": "16px", "color": "#111827" } }, " Add Payment "),
                  createVNode("form", {
                    onSubmit: withModifiers(addPayment, ["prevent"]),
                    style: { "display": "flex", "flex-direction": "column", "gap": "16px" }
                  }, [
                    createVNode("div", { style: { "display": "grid", "grid-template-columns": "1fr 1fr", "gap": "16px" } }, [
                      createVNode("div", null, [
                        createVNode("label", { style: { "display": "block", "font-size": "14px", "font-weight": "500", "color": "#374151", "margin-bottom": "4px" } }, "Amount"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => unref(paymentForm).amount = $event,
                          type: "number",
                          step: "0.01",
                          min: "0.01",
                          max: props.invoice.remaining_balance || props.invoice.total,
                          style: [{ "width": "100%", "border": "1px solid #d1d5db", "border-radius": "4px", "padding": "8px 12px", "font-size": "14px" }, { "border-color": unref(paymentForm).errors.amount ? "#ef4444" : "#d1d5db" }],
                          required: ""
                        }, null, 12, ["onUpdate:modelValue", "max"]), [
                          [vModelText, unref(paymentForm).amount]
                        ]),
                        createVNode("div", { style: { "font-size": "12px", "color": "#6b7280", "margin-top": "4px" } }, " Auto-filled with remaining balance "),
                        unref(paymentForm).errors.amount ? (openBlock(), createBlock("div", {
                          key: 0,
                          style: { "color": "#ef4444", "font-size": "12px", "margin-top": "4px" }
                        }, toDisplayString(unref(paymentForm).errors.amount), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { style: { "display": "block", "font-size": "14px", "font-weight": "500", "color": "#374151", "margin-bottom": "4px" } }, "Payment Method"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => unref(paymentForm).payment_method = $event,
                          style: [{ "width": "100%", "border": "1px solid #d1d5db", "border-radius": "4px", "padding": "8px 12px", "font-size": "14px" }, { "border-color": unref(paymentForm).errors.payment_method ? "#ef4444" : "#d1d5db" }],
                          required: ""
                        }, [
                          createVNode("option", { value: "" }, "Select Method"),
                          createVNode("option", { value: "cash" }, "Cash"),
                          createVNode("option", { value: "card" }, "Card"),
                          createVNode("option", { value: "eft" }, "EFT")
                        ], 12, ["onUpdate:modelValue"]), [
                          [vModelSelect, unref(paymentForm).payment_method]
                        ]),
                        unref(paymentForm).errors.payment_method ? (openBlock(), createBlock("div", {
                          key: 0,
                          style: { "color": "#ef4444", "font-size": "12px", "margin-top": "4px" }
                        }, toDisplayString(unref(paymentForm).errors.payment_method), 1)) : createCommentVNode("", true)
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", { style: { "display": "block", "font-size": "14px", "font-weight": "500", "color": "#374151", "margin-bottom": "4px" } }, "Payment Date"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => unref(paymentForm).payment_date = $event,
                        type: "date",
                        style: [{ "width": "100%", "border": "1px solid #d1d5db", "border-radius": "4px", "padding": "8px 12px", "font-size": "14px" }, { "border-color": unref(paymentForm).errors.payment_date ? "#ef4444" : "#d1d5db" }],
                        required: ""
                      }, null, 12, ["onUpdate:modelValue"]), [
                        [vModelText, unref(paymentForm).payment_date]
                      ]),
                      unref(paymentForm).errors.payment_date ? (openBlock(), createBlock("div", {
                        key: 0,
                        style: { "color": "#ef4444", "font-size": "12px", "margin-top": "4px" }
                      }, toDisplayString(unref(paymentForm).errors.payment_date), 1)) : createCommentVNode("", true)
                    ]),
                    createVNode("div", null, [
                      createVNode("label", { style: { "display": "block", "font-size": "14px", "font-weight": "500", "color": "#374151", "margin-bottom": "4px" } }, "Notes (Optional)"),
                      withDirectives(createVNode("textarea", {
                        "onUpdate:modelValue": ($event) => unref(paymentForm).notes = $event,
                        rows: "3",
                        style: [{ "width": "100%", "border": "1px solid #d1d5db", "border-radius": "4px", "padding": "8px 12px", "font-size": "14px", "resize": "vertical" }, { "border-color": unref(paymentForm).errors.notes ? "#ef4444" : "#d1d5db" }],
                        placeholder: "Add any additional notes about this payment..."
                      }, null, 12, ["onUpdate:modelValue"]), [
                        [vModelText, unref(paymentForm).notes]
                      ]),
                      unref(paymentForm).errors.notes ? (openBlock(), createBlock("div", {
                        key: 0,
                        style: { "color": "#ef4444", "font-size": "12px", "margin-top": "4px" }
                      }, toDisplayString(unref(paymentForm).errors.notes), 1)) : createCommentVNode("", true)
                    ])
                  ], 32),
                  createVNode("div", { style: { "display": "flex", "gap": "12px", "margin-top": "20px", "justify-content": "flex-end" } }, [
                    createVNode("button", {
                      onClick: ($event) => showPaymentModal.value = false,
                      disabled: unref(paymentForm).processing,
                      style: [{ "padding": "8px 16px", "border": "1px solid #d1d5db", "border-radius": "4px", "background": "white", "color": "#374151", "font-size": "14px", "font-weight": "500", "cursor": "pointer" }, { "opacity": unref(paymentForm).processing ? "0.5" : "1" }]
                    }, " Cancel ", 12, ["onClick", "disabled"]),
                    createVNode("button", {
                      onClick: addPayment,
                      disabled: unref(paymentForm).processing,
                      style: [{ "padding": "8px 16px", "border": "none", "border-radius": "4px", "background": "#2563eb", "color": "white", "font-size": "14px", "font-weight": "500", "cursor": "pointer" }, { "opacity": unref(paymentForm).processing ? "0.5" : "1" }]
                    }, toDisplayString(unref(paymentForm).processing ? "Adding..." : "Add Payment"), 13, ["disabled"])
                  ])
                ], 8, ["onClick"])
              ], 8, ["onClick"])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/invoices/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
