import { defineComponent, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-BjD8VFd3.js";
import "@inertiajs/vue3";
import "./index--D7ld9AJ.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Print",
  __ssrInlineRender: true,
  props: {
    jobcard: {},
    currentCompany: {}
  },
  setup(__props) {
    const props = __props;
    const formatStatus = (status) => {
      return status.charAt(0).toUpperCase() + status.slice(1).replace("_", " ");
    };
    const formatDate = (date) => {
      if (!date) return "";
      return new Date(date).toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric"
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "print-container" }, _attrs))} data-v-34895232><div class="print-header" data-v-34895232><div class="company-info" data-v-34895232><div class="company-name" data-v-34895232>${ssrInterpolate(props.currentCompany.name)}</div>`);
      if (props.currentCompany.email) {
        _push(`<div data-v-34895232>${ssrInterpolate(props.currentCompany.email)}</div>`);
      } else {
        _push(`<!---->`);
      }
      if (props.currentCompany.phone) {
        _push(`<div data-v-34895232>${ssrInterpolate(props.currentCompany.phone)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="jobcard-title" data-v-34895232>${ssrInterpolate(props.jobcard.title)}</div><div class="jobcard-number" data-v-34895232>Jobcard #${ssrInterpolate(props.jobcard.job_number)}</div></div><div class="info-grid" data-v-34895232><div class="info-section" data-v-34895232><h3 data-v-34895232>Customer Information</h3><p data-v-34895232><strong data-v-34895232>${ssrInterpolate(props.jobcard.customer.name)}</strong></p>`);
      if (props.jobcard.customer.email) {
        _push(`<p data-v-34895232>${ssrInterpolate(props.jobcard.customer.email)}</p>`);
      } else {
        _push(`<!---->`);
      }
      if (props.jobcard.customer.phone) {
        _push(`<p data-v-34895232>${ssrInterpolate(props.jobcard.customer.phone)}</p>`);
      } else {
        _push(`<!---->`);
      }
      if (props.jobcard.customer.address) {
        _push(`<p data-v-34895232>${ssrInterpolate(props.jobcard.customer.address)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="info-section" data-v-34895232><h3 data-v-34895232>Jobcard Details</h3><p data-v-34895232><strong data-v-34895232>Status:</strong> ${ssrInterpolate(formatStatus(props.jobcard.status))}</p>`);
      if (props.jobcard.start_date) {
        _push(`<p data-v-34895232><strong data-v-34895232>Start Date:</strong> ${ssrInterpolate(formatDate(props.jobcard.start_date))}</p>`);
      } else {
        _push(`<!---->`);
      }
      if (props.jobcard.due_date) {
        _push(`<p data-v-34895232><strong data-v-34895232>Due Date:</strong> ${ssrInterpolate(formatDate(props.jobcard.due_date))}</p>`);
      } else {
        _push(`<!---->`);
      }
      if (props.jobcard.completed_date) {
        _push(`<p data-v-34895232><strong data-v-34895232>Completed:</strong> ${ssrInterpolate(formatDate(props.jobcard.completed_date))}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (props.jobcard.description) {
        _push(`<div class="description-section" data-v-34895232><h3 data-v-34895232>Description</h3><p data-v-34895232>${ssrInterpolate(props.jobcard.description)}</p></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="line-items" data-v-34895232><h3 data-v-34895232>Line Items</h3><table data-v-34895232><thead data-v-34895232><tr data-v-34895232><th data-v-34895232>Description</th><th class="text-right" data-v-34895232>Qty</th><th class="text-right" data-v-34895232>Unit Price</th><th class="text-right" data-v-34895232>Total</th></tr></thead><tbody data-v-34895232><!--[-->`);
      ssrRenderList(props.jobcard.line_items, (item) => {
        _push(`<tr data-v-34895232><td data-v-34895232>${ssrInterpolate(item.description)}</td><td class="text-right" data-v-34895232>${ssrInterpolate(item.quantity)}</td><td class="text-right" data-v-34895232>R${ssrInterpolate(Number(item.unit_price).toFixed(2))}</td><td class="text-right" data-v-34895232>R${ssrInterpolate(Number(item.total).toFixed(2))}</td></tr>`);
      });
      _push(`<!--]--></tbody></table><div class="totals" data-v-34895232><div class="total-row" data-v-34895232><span data-v-34895232>Subtotal:</span><span data-v-34895232>R${ssrInterpolate(Number(props.jobcard.subtotal || 0).toFixed(2))}</span></div>`);
      if (props.jobcard.tax_rate > 0) {
        _push(`<div class="total-row" data-v-34895232><span data-v-34895232>Tax (${ssrInterpolate(props.jobcard.tax_rate)}%):</span><span data-v-34895232>R${ssrInterpolate(Number(props.jobcard.tax_amount || 0).toFixed(2))}</span></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="total-row final" data-v-34895232><span data-v-34895232>Total:</span><span data-v-34895232>R${ssrInterpolate(Number(props.jobcard.total || 0).toFixed(2))}</span></div></div></div>`);
      if (props.jobcard.notes) {
        _push(`<div class="notes-section" data-v-34895232><h3 data-v-34895232>Notes</h3><p data-v-34895232>${ssrInterpolate(props.jobcard.notes)}</p></div>`);
      } else {
        _push(`<!---->`);
      }
      if (props.jobcard.terms_conditions) {
        _push(`<div class="terms-section" data-v-34895232><h3 data-v-34895232>Terms &amp; Conditions</h3><p data-v-34895232>${ssrInterpolate(props.jobcard.terms_conditions)}</p></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="print-actions" data-v-34895232><button class="print-btn" data-v-34895232>Print</button><button class="back-btn" data-v-34895232>Back to Jobcard</button></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/jobcards/Print.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Print = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-34895232"]]);
export {
  Print as default
};
