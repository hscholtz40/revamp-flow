import { defineComponent, unref, withCtx, createVNode, createTextVNode, createBlock, openBlock, toDisplayString, Fragment, renderList, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderClass, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1, c as companySettings } from "./AppLayout-CmGu2Oww.js";
import { Head, Link, router } from "@inertiajs/vue3";
import { Plus, Building2, Star, Eye, Edit, Trash2 } from "lucide-vue-next";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    companies: {},
    currentCompany: {}
  },
  setup(__props) {
    const props = __props;
    function deleteCompany(company) {
      if (confirm(`Are you sure you want to delete "${company.name}"?`)) {
        router.delete(companySettings.destroy(company.id).url);
      }
    }
    function setAsDefault(company) {
      router.post(companySettings.setDefault(company.id).url);
    }
    function switchToCompany(company) {
      router.post(companySettings.switch(company.id).url);
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Company Settings" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, { breadcrumbs: [
        { title: "Administration", href: "/administration" },
        { title: "Company Settings", href: "#" }
      ] }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-4"${_scopeId}><div class="mb-6 flex items-center justify-between"${_scopeId}><div${_scopeId}><h1 class="text-2xl font-bold text-gray-900"${_scopeId}>Company Settings</h1><p class="text-gray-600"${_scopeId}>Manage your companies and organization information</p>`);
            if (props.currentCompany) {
              _push2(`<div class="mt-2"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Current Company: </span><span class="text-sm font-medium text-blue-600"${_scopeId}>${ssrInterpolate(props.currentCompany.name)}</span></div>`);
            } else {
              _push2(`<div class="mt-2"${_scopeId}><span class="text-sm text-red-600"${_scopeId}>No accessible companies found</span></div>`);
            }
            _push2(`</div>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(companySettings).create().url,
              class: "flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Plus), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                  _push3(` Add Company `);
                } else {
                  return [
                    createVNode(unref(Plus), { class: "h-4 w-4" }),
                    createTextVNode(" Add Company ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
            if (props.companies.length === 0) {
              _push2(`<div class="rounded-lg border bg-white p-8 text-center"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Building2), { class: "mx-auto h-12 w-12 text-gray-400" }, null, _parent2, _scopeId));
              _push2(`<h3 class="mt-2 text-lg font-medium text-gray-900"${_scopeId}>No accessible companies</h3><p class="mt-1 text-gray-500"${_scopeId}>You don&#39;t have access to any companies or no companies are active.</p><p class="mt-2 text-sm text-gray-400"${_scopeId}>Contact an administrator to get access to companies.</p><div class="mt-6"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(companySettings).create().url,
                class: "inline-flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(unref(Plus), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                    _push3(` Add Company `);
                  } else {
                    return [
                      createVNode(unref(Plus), { class: "h-4 w-4" }),
                      createTextVNode(" Add Company ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div></div>`);
            } else {
              _push2(`<div class="grid gap-6 md:grid-cols-2 lg:grid-cols-3"${_scopeId}><!--[-->`);
              ssrRenderList(props.companies, (company) => {
                _push2(`<div class="rounded-lg border bg-white p-6 shadow-sm hover:shadow-md transition-shadow"${_scopeId}><div class="mb-4 flex items-start justify-between"${_scopeId}><div class="flex items-center gap-3"${_scopeId}><div class="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Building2), { class: "h-6 w-6 text-blue-600" }, null, _parent2, _scopeId));
                _push2(`</div><div${_scopeId}><div class="flex items-center gap-2"${_scopeId}><h3 class="font-semibold text-gray-900"${_scopeId}>${ssrInterpolate(company.name)}</h3>`);
                if (company.is_default) {
                  _push2(ssrRenderComponent(unref(Star), { class: "h-4 w-4 text-yellow-500 fill-current" }, null, _parent2, _scopeId));
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div><p class="text-sm text-gray-500"${_scopeId}>${ssrInterpolate(company.city)}, ${ssrInterpolate(company.country)}</p></div></div><span class="${ssrRenderClass([
                  "rounded-full px-2 py-1 text-xs font-medium",
                  company.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                ])}"${_scopeId}>${ssrInterpolate(company.is_active ? "Active" : "Inactive")}</span></div><div class="mb-4 space-y-2 text-sm text-gray-600"${_scopeId}>`);
                if (company.email) {
                  _push2(`<div class="flex items-center gap-2"${_scopeId}><span class="font-medium"${_scopeId}>Email:</span><span${_scopeId}>${ssrInterpolate(company.email)}</span></div>`);
                } else {
                  _push2(`<!---->`);
                }
                if (company.phone) {
                  _push2(`<div class="flex items-center gap-2"${_scopeId}><span class="font-medium"${_scopeId}>Phone:</span><span${_scopeId}>${ssrInterpolate(company.phone)}</span></div>`);
                } else {
                  _push2(`<!---->`);
                }
                if (company.website) {
                  _push2(`<div class="flex items-center gap-2"${_scopeId}><span class="font-medium"${_scopeId}>Website:</span><a${ssrRenderAttr("href", company.website)} target="_blank" class="text-blue-600 hover:underline"${_scopeId}>${ssrInterpolate(company.website)}</a></div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div>`);
                if (company.description) {
                  _push2(`<p class="mb-4 text-sm text-gray-600 line-clamp-2"${_scopeId}>${ssrInterpolate(company.description)}</p>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`<div class="flex items-center gap-2"${_scopeId}>`);
                if (props.currentCompany && props.currentCompany.id !== company.id) {
                  _push2(`<button class="flex items-center gap-1 rounded border border-blue-300 px-3 py-1 text-sm text-blue-700 hover:bg-blue-50"${_scopeId}>`);
                  _push2(ssrRenderComponent(unref(Building2), { class: "h-3 w-3" }, null, _parent2, _scopeId));
                  _push2(` Switch To </button>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(ssrRenderComponent(unref(Link), {
                  href: unref(companySettings).show(company.id).url,
                  class: "flex items-center gap-1 rounded border px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(Eye), { class: "h-3 w-3" }, null, _parent3, _scopeId2));
                      _push3(` View `);
                    } else {
                      return [
                        createVNode(unref(Eye), { class: "h-3 w-3" }),
                        createTextVNode(" View ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(ssrRenderComponent(unref(Link), {
                  href: unref(companySettings).edit(company.id).url,
                  class: "flex items-center gap-1 rounded border px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(Edit), { class: "h-3 w-3" }, null, _parent3, _scopeId2));
                      _push3(` Edit `);
                    } else {
                      return [
                        createVNode(unref(Edit), { class: "h-3 w-3" }),
                        createTextVNode(" Edit ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                if (!company.is_default) {
                  _push2(`<button class="flex items-center gap-1 rounded border border-yellow-300 px-3 py-1 text-sm text-yellow-700 hover:bg-yellow-50"${_scopeId}>`);
                  _push2(ssrRenderComponent(unref(Star), { class: "h-3 w-3" }, null, _parent2, _scopeId));
                  _push2(` Set Default </button>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`<button class="flex items-center gap-1 rounded border border-red-300 px-3 py-1 text-sm text-red-700 hover:bg-red-50"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Trash2), { class: "h-3 w-3" }, null, _parent2, _scopeId));
                _push2(` Delete </button></div></div>`);
              });
              _push2(`<!--]--></div>`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "p-4" }, [
                createVNode("div", { class: "mb-6 flex items-center justify-between" }, [
                  createVNode("div", null, [
                    createVNode("h1", { class: "text-2xl font-bold text-gray-900" }, "Company Settings"),
                    createVNode("p", { class: "text-gray-600" }, "Manage your companies and organization information"),
                    props.currentCompany ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "mt-2"
                    }, [
                      createVNode("span", { class: "text-sm text-gray-500" }, "Current Company: "),
                      createVNode("span", { class: "text-sm font-medium text-blue-600" }, toDisplayString(props.currentCompany.name), 1)
                    ])) : (openBlock(), createBlock("div", {
                      key: 1,
                      class: "mt-2"
                    }, [
                      createVNode("span", { class: "text-sm text-red-600" }, "No accessible companies found")
                    ]))
                  ]),
                  createVNode(unref(Link), {
                    href: unref(companySettings).create().url,
                    class: "flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(Plus), { class: "h-4 w-4" }),
                      createTextVNode(" Add Company ")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ]),
                props.companies.length === 0 ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "rounded-lg border bg-white p-8 text-center"
                }, [
                  createVNode(unref(Building2), { class: "mx-auto h-12 w-12 text-gray-400" }),
                  createVNode("h3", { class: "mt-2 text-lg font-medium text-gray-900" }, "No accessible companies"),
                  createVNode("p", { class: "mt-1 text-gray-500" }, "You don't have access to any companies or no companies are active."),
                  createVNode("p", { class: "mt-2 text-sm text-gray-400" }, "Contact an administrator to get access to companies."),
                  createVNode("div", { class: "mt-6" }, [
                    createVNode(unref(Link), {
                      href: unref(companySettings).create().url,
                      class: "inline-flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(Plus), { class: "h-4 w-4" }),
                        createTextVNode(" Add Company ")
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ])
                ])) : (openBlock(), createBlock("div", {
                  key: 1,
                  class: "grid gap-6 md:grid-cols-2 lg:grid-cols-3"
                }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(props.companies, (company) => {
                    return openBlock(), createBlock("div", {
                      key: company.id,
                      class: "rounded-lg border bg-white p-6 shadow-sm hover:shadow-md transition-shadow"
                    }, [
                      createVNode("div", { class: "mb-4 flex items-start justify-between" }, [
                        createVNode("div", { class: "flex items-center gap-3" }, [
                          createVNode("div", { class: "flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100" }, [
                            createVNode(unref(Building2), { class: "h-6 w-6 text-blue-600" })
                          ]),
                          createVNode("div", null, [
                            createVNode("div", { class: "flex items-center gap-2" }, [
                              createVNode("h3", { class: "font-semibold text-gray-900" }, toDisplayString(company.name), 1),
                              company.is_default ? (openBlock(), createBlock(unref(Star), {
                                key: 0,
                                class: "h-4 w-4 text-yellow-500 fill-current"
                              })) : createCommentVNode("", true)
                            ]),
                            createVNode("p", { class: "text-sm text-gray-500" }, toDisplayString(company.city) + ", " + toDisplayString(company.country), 1)
                          ])
                        ]),
                        createVNode("span", {
                          class: [
                            "rounded-full px-2 py-1 text-xs font-medium",
                            company.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                          ]
                        }, toDisplayString(company.is_active ? "Active" : "Inactive"), 3)
                      ]),
                      createVNode("div", { class: "mb-4 space-y-2 text-sm text-gray-600" }, [
                        company.email ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "flex items-center gap-2"
                        }, [
                          createVNode("span", { class: "font-medium" }, "Email:"),
                          createVNode("span", null, toDisplayString(company.email), 1)
                        ])) : createCommentVNode("", true),
                        company.phone ? (openBlock(), createBlock("div", {
                          key: 1,
                          class: "flex items-center gap-2"
                        }, [
                          createVNode("span", { class: "font-medium" }, "Phone:"),
                          createVNode("span", null, toDisplayString(company.phone), 1)
                        ])) : createCommentVNode("", true),
                        company.website ? (openBlock(), createBlock("div", {
                          key: 2,
                          class: "flex items-center gap-2"
                        }, [
                          createVNode("span", { class: "font-medium" }, "Website:"),
                          createVNode("a", {
                            href: company.website,
                            target: "_blank",
                            class: "text-blue-600 hover:underline"
                          }, toDisplayString(company.website), 9, ["href"])
                        ])) : createCommentVNode("", true)
                      ]),
                      company.description ? (openBlock(), createBlock("p", {
                        key: 0,
                        class: "mb-4 text-sm text-gray-600 line-clamp-2"
                      }, toDisplayString(company.description), 1)) : createCommentVNode("", true),
                      createVNode("div", { class: "flex items-center gap-2" }, [
                        props.currentCompany && props.currentCompany.id !== company.id ? (openBlock(), createBlock("button", {
                          key: 0,
                          onClick: ($event) => switchToCompany(company),
                          class: "flex items-center gap-1 rounded border border-blue-300 px-3 py-1 text-sm text-blue-700 hover:bg-blue-50"
                        }, [
                          createVNode(unref(Building2), { class: "h-3 w-3" }),
                          createTextVNode(" Switch To ")
                        ], 8, ["onClick"])) : createCommentVNode("", true),
                        createVNode(unref(Link), {
                          href: unref(companySettings).show(company.id).url,
                          class: "flex items-center gap-1 rounded border px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(Eye), { class: "h-3 w-3" }),
                            createTextVNode(" View ")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode(unref(Link), {
                          href: unref(companySettings).edit(company.id).url,
                          class: "flex items-center gap-1 rounded border px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(Edit), { class: "h-3 w-3" }),
                            createTextVNode(" Edit ")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        !company.is_default ? (openBlock(), createBlock("button", {
                          key: 1,
                          onClick: ($event) => setAsDefault(company),
                          class: "flex items-center gap-1 rounded border border-yellow-300 px-3 py-1 text-sm text-yellow-700 hover:bg-yellow-50"
                        }, [
                          createVNode(unref(Star), { class: "h-3 w-3" }),
                          createTextVNode(" Set Default ")
                        ], 8, ["onClick"])) : createCommentVNode("", true),
                        createVNode("button", {
                          onClick: ($event) => deleteCompany(company),
                          class: "flex items-center gap-1 rounded border border-red-300 px-3 py-1 text-sm text-red-700 hover:bg-red-50"
                        }, [
                          createVNode(unref(Trash2), { class: "h-3 w-3" }),
                          createTextVNode(" Delete ")
                        ], 8, ["onClick"])
                      ])
                    ]);
                  }), 128))
                ]))
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/company-settings/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
