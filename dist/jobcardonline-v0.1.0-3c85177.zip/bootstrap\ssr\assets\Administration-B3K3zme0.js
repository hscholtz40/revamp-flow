import { defineComponent, unref, withCtx, createTextVNode, createVNode, toDisplayString, createBlock, createCommentVNode, openBlock, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1, a as administration, c as companySettings } from "./AppLayout-CmGu2Oww.js";
import { Head, Link } from "@inertiajs/vue3";
import { u as users } from "./index-B7IvN102.js";
import { g as groups } from "./index-TOLxu5Uw.js";
import { s as smsSettings } from "./index-B_1IrT3r.js";
import { Users, Shield, Tag, Building2, MessageSquare, Zap } from "lucide-vue-next";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Administration",
  __ssrInlineRender: true,
  props: {
    stats: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Administration" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [{ title: "Administration", href: unref(administration).index().url }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-4"${_scopeId}><h1 class="mb-6 text-2xl font-bold"${_scopeId}>Administration</h1><div class="grid gap-6 md:grid-cols-2 lg:grid-cols-4"${_scopeId}><div class="rounded-lg border bg-white p-6 shadow-sm"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h2 class="text-lg font-semibold"${_scopeId}>Users</h2><p class="text-sm text-gray-600"${_scopeId}>Manage user accounts and permissions</p><p class="mt-2 text-2xl font-bold text-blue-600"${_scopeId}>${ssrInterpolate(props.stats.users_count)}</p></div><div class="rounded-full bg-blue-100 p-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Users), { class: "h-6 w-6 text-blue-600" }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="mt-4 flex gap-2"${_scopeId}>`);
            if (_ctx.$page.props.auth?.abilities?.users?.list) {
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(users).index().url,
                class: "rounded bg-blue-600 px-3 py-2 text-sm text-white hover:bg-blue-700"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` View Users `);
                  } else {
                    return [
                      createTextVNode(" View Users ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (_ctx.$page.props.auth?.abilities?.users?.create) {
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(users).create().url,
                class: "rounded border px-3 py-2 text-sm hover:bg-gray-50"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Add User `);
                  } else {
                    return [
                      createTextVNode(" Add User ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="rounded-lg border bg-white p-6 shadow-sm"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h2 class="text-lg font-semibold"${_scopeId}>Groups</h2><p class="text-sm text-gray-600"${_scopeId}>Manage user groups and permissions</p><p class="mt-2 text-2xl font-bold text-green-600"${_scopeId}>${ssrInterpolate(props.stats.groups_count)}</p></div><div class="rounded-full bg-green-100 p-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Shield), { class: "h-6 w-6 text-green-600" }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="mt-4 flex gap-2"${_scopeId}>`);
            if (_ctx.$page.props.auth?.abilities?.groups?.list) {
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(groups).index().url,
                class: "rounded bg-green-600 px-3 py-2 text-sm text-white hover:bg-green-700"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` View Groups `);
                  } else {
                    return [
                      createTextVNode(" View Groups ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (_ctx.$page.props.auth?.abilities?.groups?.create) {
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(groups).create().url,
                class: "rounded border px-3 py-2 text-sm hover:bg-gray-50"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Add Group `);
                  } else {
                    return [
                      createTextVNode(" Add Group ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="rounded-lg border bg-white p-6 shadow-sm"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h2 class="text-lg font-semibold"${_scopeId}>Categories</h2><p class="text-sm text-gray-600"${_scopeId}>Manage product and service categories</p></div><div class="rounded-full bg-purple-100 p-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Tag), { class: "h-6 w-6 text-purple-600" }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="mt-4"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(administration).categories.index().url,
              class: "rounded bg-purple-600 px-3 py-2 text-sm text-white hover:bg-purple-700"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Manage Categories `);
                } else {
                  return [
                    createTextVNode(" Manage Categories ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="rounded-lg border bg-white p-6 shadow-sm"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h2 class="text-lg font-semibold"${_scopeId}>Companies</h2><p class="text-sm text-gray-600"${_scopeId}>Manage company information and branding</p></div><div class="rounded-full bg-purple-100 p-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Building2), { class: "h-6 w-6 text-purple-600" }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="mt-4"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(companySettings).index().url,
              class: "rounded bg-purple-600 px-3 py-2 text-sm text-white hover:bg-purple-700"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Manage Companies `);
                } else {
                  return [
                    createTextVNode(" Manage Companies ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="rounded-lg border bg-white p-6 shadow-sm"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h2 class="text-lg font-semibold"${_scopeId}>SMS Settings</h2><p class="text-sm text-gray-600"${_scopeId}>Configure BulkSMS for customer messaging</p></div><div class="rounded-full bg-green-100 p-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(MessageSquare), { class: "h-6 w-6 text-green-600" }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="mt-4"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(smsSettings).index().url,
              class: "rounded bg-green-600 px-3 py-2 text-sm text-white hover:bg-green-700"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Configure SMS `);
                } else {
                  return [
                    createTextVNode(" Configure SMS ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="rounded-lg border bg-white p-6 shadow-sm"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div${_scopeId}><h2 class="text-lg font-semibold"${_scopeId}>Xero Integration</h2><p class="text-sm text-gray-600"${_scopeId}>Sync customers, products, and invoices with Xero</p></div><div class="rounded-full bg-orange-100 p-3"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Zap), { class: "h-6 w-6 text-orange-600" }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="mt-4"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: "/administration/xero-settings",
              class: "rounded bg-orange-600 px-3 py-2 text-sm text-white hover:bg-orange-700"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Configure Xero `);
                } else {
                  return [
                    createTextVNode(" Configure Xero ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "p-4" }, [
                createVNode("h1", { class: "mb-6 text-2xl font-bold" }, "Administration"),
                createVNode("div", { class: "grid gap-6 md:grid-cols-2 lg:grid-cols-4" }, [
                  createVNode("div", { class: "rounded-lg border bg-white p-6 shadow-sm" }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", null, [
                        createVNode("h2", { class: "text-lg font-semibold" }, "Users"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Manage user accounts and permissions"),
                        createVNode("p", { class: "mt-2 text-2xl font-bold text-blue-600" }, toDisplayString(props.stats.users_count), 1)
                      ]),
                      createVNode("div", { class: "rounded-full bg-blue-100 p-3" }, [
                        createVNode(unref(Users), { class: "h-6 w-6 text-blue-600" })
                      ])
                    ]),
                    createVNode("div", { class: "mt-4 flex gap-2" }, [
                      _ctx.$page.props.auth?.abilities?.users?.list ? (openBlock(), createBlock(unref(Link), {
                        key: 0,
                        href: unref(users).index().url,
                        class: "rounded bg-blue-600 px-3 py-2 text-sm text-white hover:bg-blue-700"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" View Users ")
                        ]),
                        _: 1
                      }, 8, ["href"])) : createCommentVNode("", true),
                      _ctx.$page.props.auth?.abilities?.users?.create ? (openBlock(), createBlock(unref(Link), {
                        key: 1,
                        href: unref(users).create().url,
                        class: "rounded border px-3 py-2 text-sm hover:bg-gray-50"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Add User ")
                        ]),
                        _: 1
                      }, 8, ["href"])) : createCommentVNode("", true)
                    ])
                  ]),
                  createVNode("div", { class: "rounded-lg border bg-white p-6 shadow-sm" }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", null, [
                        createVNode("h2", { class: "text-lg font-semibold" }, "Groups"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Manage user groups and permissions"),
                        createVNode("p", { class: "mt-2 text-2xl font-bold text-green-600" }, toDisplayString(props.stats.groups_count), 1)
                      ]),
                      createVNode("div", { class: "rounded-full bg-green-100 p-3" }, [
                        createVNode(unref(Shield), { class: "h-6 w-6 text-green-600" })
                      ])
                    ]),
                    createVNode("div", { class: "mt-4 flex gap-2" }, [
                      _ctx.$page.props.auth?.abilities?.groups?.list ? (openBlock(), createBlock(unref(Link), {
                        key: 0,
                        href: unref(groups).index().url,
                        class: "rounded bg-green-600 px-3 py-2 text-sm text-white hover:bg-green-700"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" View Groups ")
                        ]),
                        _: 1
                      }, 8, ["href"])) : createCommentVNode("", true),
                      _ctx.$page.props.auth?.abilities?.groups?.create ? (openBlock(), createBlock(unref(Link), {
                        key: 1,
                        href: unref(groups).create().url,
                        class: "rounded border px-3 py-2 text-sm hover:bg-gray-50"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Add Group ")
                        ]),
                        _: 1
                      }, 8, ["href"])) : createCommentVNode("", true)
                    ])
                  ]),
                  createVNode("div", { class: "rounded-lg border bg-white p-6 shadow-sm" }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", null, [
                        createVNode("h2", { class: "text-lg font-semibold" }, "Categories"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Manage product and service categories")
                      ]),
                      createVNode("div", { class: "rounded-full bg-purple-100 p-3" }, [
                        createVNode(unref(Tag), { class: "h-6 w-6 text-purple-600" })
                      ])
                    ]),
                    createVNode("div", { class: "mt-4" }, [
                      createVNode(unref(Link), {
                        href: unref(administration).categories.index().url,
                        class: "rounded bg-purple-600 px-3 py-2 text-sm text-white hover:bg-purple-700"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Manage Categories ")
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ])
                  ]),
                  createVNode("div", { class: "rounded-lg border bg-white p-6 shadow-sm" }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", null, [
                        createVNode("h2", { class: "text-lg font-semibold" }, "Companies"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Manage company information and branding")
                      ]),
                      createVNode("div", { class: "rounded-full bg-purple-100 p-3" }, [
                        createVNode(unref(Building2), { class: "h-6 w-6 text-purple-600" })
                      ])
                    ]),
                    createVNode("div", { class: "mt-4" }, [
                      createVNode(unref(Link), {
                        href: unref(companySettings).index().url,
                        class: "rounded bg-purple-600 px-3 py-2 text-sm text-white hover:bg-purple-700"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Manage Companies ")
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ])
                  ]),
                  createVNode("div", { class: "rounded-lg border bg-white p-6 shadow-sm" }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", null, [
                        createVNode("h2", { class: "text-lg font-semibold" }, "SMS Settings"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Configure BulkSMS for customer messaging")
                      ]),
                      createVNode("div", { class: "rounded-full bg-green-100 p-3" }, [
                        createVNode(unref(MessageSquare), { class: "h-6 w-6 text-green-600" })
                      ])
                    ]),
                    createVNode("div", { class: "mt-4" }, [
                      createVNode(unref(Link), {
                        href: unref(smsSettings).index().url,
                        class: "rounded bg-green-600 px-3 py-2 text-sm text-white hover:bg-green-700"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Configure SMS ")
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ])
                  ]),
                  createVNode("div", { class: "rounded-lg border bg-white p-6 shadow-sm" }, [
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("div", null, [
                        createVNode("h2", { class: "text-lg font-semibold" }, "Xero Integration"),
                        createVNode("p", { class: "text-sm text-gray-600" }, "Sync customers, products, and invoices with Xero")
                      ]),
                      createVNode("div", { class: "rounded-full bg-orange-100 p-3" }, [
                        createVNode(unref(Zap), { class: "h-6 w-6 text-orange-600" })
                      ])
                    ]),
                    createVNode("div", { class: "mt-4" }, [
                      createVNode(unref(Link), {
                        href: "/administration/xero-settings",
                        class: "rounded bg-orange-600 px-3 py-2 text-sm text-white hover:bg-orange-700"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Configure Xero ")
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/Administration.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
