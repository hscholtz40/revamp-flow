import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import categories from './categories'
import xeroSettings610994 from './xero-settings'
/**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/administration',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdministrationController::index
 * @see app/Http/Controllers/AdministrationController.php:14
 * @route '/administration'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\XeroSettingsController::xeroSettings
 * @see app/Http/Controllers/XeroSettingsController.php:11
 * @route '/administration/xero-settings'
 */
export const xeroSettings = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: xeroSettings.url(options),
    method: 'get',
})

xeroSettings.definition = {
    methods: ["get","head"],
    url: '/administration/xero-settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\XeroSettingsController::xeroSettings
 * @see app/Http/Controllers/XeroSettingsController.php:11
 * @route '/administration/xero-settings'
 */
xeroSettings.url = (options?: RouteQueryOptions) => {
    return xeroSettings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\XeroSettingsController::xeroSettings
 * @see app/Http/Controllers/XeroSettingsController.php:11
 * @route '/administration/xero-settings'
 */
xeroSettings.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: xeroSettings.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\XeroSettingsController::xeroSettings
 * @see app/Http/Controllers/XeroSettingsController.php:11
 * @route '/administration/xero-settings'
 */
xeroSettings.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: xeroSettings.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\XeroSettingsController::xeroSettings
 * @see app/Http/Controllers/XeroSettingsController.php:11
 * @route '/administration/xero-settings'
 */
    const xeroSettingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: xeroSettings.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\XeroSettingsController::xeroSettings
 * @see app/Http/Controllers/XeroSettingsController.php:11
 * @route '/administration/xero-settings'
 */
        xeroSettingsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: xeroSettings.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\XeroSettingsController::xeroSettings
 * @see app/Http/Controllers/XeroSettingsController.php:11
 * @route '/administration/xero-settings'
 */
        xeroSettingsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: xeroSettings.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    xeroSettings.form = xeroSettingsForm
const administration = {
    categories: Object.assign(categories, categories),
index: Object.assign(index, index),
xeroSettings: Object.assign(xeroSettings, xeroSettings610994),
}

export default administration