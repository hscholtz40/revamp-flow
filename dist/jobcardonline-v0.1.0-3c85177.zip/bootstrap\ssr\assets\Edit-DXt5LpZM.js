import { defineComponent, unref, withCtx, createTextVNode, createVNode, withModifiers, withDirectives, createBlock, createCommentVNode, vModelText, openBlock, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _sfc_main$1, b as customers } from "./AppLayout-CmGu2Oww.js";
import { useForm, Head, Link } from "@inertiajs/vue3";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    customer: {}
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      name: props.customer.name ?? "",
      email: props.customer.email ?? "",
      phone: props.customer.phone ?? "",
      address: props.customer.address ?? "",
      city: props.customer.city ?? "",
      country: props.customer.country ?? "",
      notes: props.customer.notes ?? ""
    });
    function submit() {
      form.put(customers.update(props.customer.id).url);
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Edit Customer" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [{ title: "Customers", href: unref(customers).index().url }, { title: "Edit", href: "#" }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="space-y-4 p-4"${_scopeId}><div class="grid gap-4 md:grid-cols-2"${_scopeId}><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Name</span><input${ssrRenderAttr("value", unref(form).name)} class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.name) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.name)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Email</span><input${ssrRenderAttr("value", unref(form).email)} type="email" class="w-full rounded border px-3 py-2"${_scopeId}>`);
            if (unref(form).errors.email) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.email)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Phone</span><input${ssrRenderAttr("value", unref(form).phone)} class="w-full rounded border px-3 py-2"${_scopeId}></label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Address</span><input${ssrRenderAttr("value", unref(form).address)} class="w-full rounded border px-3 py-2"${_scopeId}></label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>City</span><input${ssrRenderAttr("value", unref(form).city)} class="w-full rounded border px-3 py-2"${_scopeId}></label><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Country</span><input${ssrRenderAttr("value", unref(form).country)} class="w-full rounded border px-3 py-2"${_scopeId}></label></div><label class="block"${_scopeId}><span class="mb-1 block"${_scopeId}>Notes</span><textarea class="w-full rounded border px-3 py-2"${_scopeId}>${ssrInterpolate(unref(form).notes)}</textarea></label><div class="flex items-center gap-3"${_scopeId}><button${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="rounded bg-blue-600 px-4 py-2 text-white"${_scopeId}>Save</button>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(customers).index().url,
              class: "rounded border px-4 py-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Cancel`);
                } else {
                  return [
                    createTextVNode("Cancel")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                onSubmit: withModifiers(submit, ["prevent"]),
                class: "space-y-4 p-4"
              }, [
                createVNode("div", { class: "grid gap-4 md:grid-cols-2" }, [
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Name"),
                    withDirectives(createVNode("input", {
                      "onUpdate:modelValue": ($event) => unref(form).name = $event,
                      class: "w-full rounded border px-3 py-2"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).name]
                    ]),
                    unref(form).errors.name ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "text-sm text-red-600"
                    }, toDisplayString(unref(form).errors.name), 1)) : createCommentVNode("", true)
                  ]),
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Email"),
                    withDirectives(createVNode("input", {
                      "onUpdate:modelValue": ($event) => unref(form).email = $event,
                      type: "email",
                      class: "w-full rounded border px-3 py-2"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).email]
                    ]),
                    unref(form).errors.email ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "text-sm text-red-600"
                    }, toDisplayString(unref(form).errors.email), 1)) : createCommentVNode("", true)
                  ]),
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Phone"),
                    withDirectives(createVNode("input", {
                      "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                      class: "w-full rounded border px-3 py-2"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).phone]
                    ])
                  ]),
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Address"),
                    withDirectives(createVNode("input", {
                      "onUpdate:modelValue": ($event) => unref(form).address = $event,
                      class: "w-full rounded border px-3 py-2"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).address]
                    ])
                  ]),
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "City"),
                    withDirectives(createVNode("input", {
                      "onUpdate:modelValue": ($event) => unref(form).city = $event,
                      class: "w-full rounded border px-3 py-2"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).city]
                    ])
                  ]),
                  createVNode("label", { class: "block" }, [
                    createVNode("span", { class: "mb-1 block" }, "Country"),
                    withDirectives(createVNode("input", {
                      "onUpdate:modelValue": ($event) => unref(form).country = $event,
                      class: "w-full rounded border px-3 py-2"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).country]
                    ])
                  ])
                ]),
                createVNode("label", { class: "block" }, [
                  createVNode("span", { class: "mb-1 block" }, "Notes"),
                  withDirectives(createVNode("textarea", {
                    "onUpdate:modelValue": ($event) => unref(form).notes = $event,
                    class: "w-full rounded border px-3 py-2"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(form).notes]
                  ])
                ]),
                createVNode("div", { class: "flex items-center gap-3" }, [
                  createVNode("button", {
                    disabled: unref(form).processing,
                    class: "rounded bg-blue-600 px-4 py-2 text-white"
                  }, "Save", 8, ["disabled"]),
                  createVNode(unref(Link), {
                    href: unref(customers).index().url,
                    class: "rounded border px-4 py-2"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Cancel")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ])
              ], 32)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/customers/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
