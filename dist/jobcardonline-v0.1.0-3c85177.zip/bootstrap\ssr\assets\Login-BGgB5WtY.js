import { defineComponent, computed, unref, mergeProps, withCtx, renderSlot, createVNode, useSSRContext, createTextVNode, createBlock, createCommentVNode, openBlock, toDisplayString } from "vue";
import { ssrRenderComponent, ssrRenderSlot, ssrInterpolate } from "vue/server-renderer";
import { q as queryParams } from "./index--D7ld9AJ.js";
import { _ as _sfc_main$5 } from "./InputError-Dsed5rBJ.js";
import { _ as _sfc_main$6 } from "./TextLink-DF2ChrHZ.js";
import { c as cn, _ as _sfc_main$7 } from "./Footer-Ce4AN4A5.js";
import { Check, LoaderCircle } from "lucide-vue-next";
import { useForwardPropsEmits, CheckboxRoot, CheckboxIndicator } from "reka-ui";
import { _ as _sfc_main$4 } from "./Input-CBU-ZeCu.js";
import { _ as _sfc_main$3 } from "./Label-UEV1cA3u.js";
import { _ as _sfc_main$2 } from "./AuthLayout-CT6aWTFG.js";
import { r as request } from "./index-BTa1VWYT.js";
import { Head, Form } from "@inertiajs/vue3";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@vueuse/core";
import "./index-DFfij-Hh.js";
const create = (options) => ({
  url: create.url(options),
  method: "get"
});
create.definition = {
  methods: ["get", "head"],
  url: "/login"
};
create.url = (options) => {
  return create.definition.url + queryParams(options);
};
create.get = (options) => ({
  url: create.url(options),
  method: "get"
});
create.head = (options) => ({
  url: create.url(options),
  method: "head"
});
const createForm = (options) => ({
  action: create.url(options),
  method: "get"
});
createForm.get = (options) => ({
  action: create.url(options),
  method: "get"
});
createForm.head = (options) => ({
  action: create.url({
    [options?.mergeQuery ? "mergeQuery" : "query"]: {
      _method: "HEAD",
      ...options?.query ?? options?.mergeQuery ?? {}
    }
  }),
  method: "get"
});
create.form = createForm;
const store = (options) => ({
  url: store.url(options),
  method: "post"
});
store.definition = {
  methods: ["post"],
  url: "/login"
};
store.url = (options) => {
  return store.definition.url + queryParams(options);
};
store.post = (options) => ({
  url: store.url(options),
  method: "post"
});
const storeForm = (options) => ({
  action: store.url(options),
  method: "post"
});
storeForm.post = (options) => ({
  action: store.url(options),
  method: "post"
});
store.form = storeForm;
const destroy = (options) => ({
  url: destroy.url(options),
  method: "post"
});
destroy.definition = {
  methods: ["post"],
  url: "/logout"
};
destroy.url = (options) => {
  return destroy.definition.url + queryParams(options);
};
destroy.post = (options) => ({
  url: destroy.url(options),
  method: "post"
});
const destroyForm = (options) => ({
  action: destroy.url(options),
  method: "post"
});
destroyForm.post = (options) => ({
  action: destroy.url(options),
  method: "post"
});
destroy.form = destroyForm;
const AuthenticatedSessionController = { create, store, destroy };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Checkbox",
  __ssrInlineRender: true,
  props: {
    defaultValue: { type: [Boolean, String] },
    modelValue: { type: [Boolean, String, null] },
    disabled: { type: Boolean },
    value: {},
    id: {},
    asChild: { type: Boolean },
    as: {},
    name: {},
    required: { type: Boolean },
    class: {}
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const delegatedProps = computed(() => {
      const { class: _, ...delegated } = props;
      return delegated;
    });
    const forwarded = useForwardPropsEmits(delegatedProps, emits);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(CheckboxRoot), mergeProps({ "data-slot": "checkbox" }, unref(forwarded), {
        class: unref(cn)(
          "peer border-input data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground data-[state=checked]:border-primary focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive size-4 shrink-0 rounded-[4px] border shadow-xs transition-shadow outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50",
          props.class
        )
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(CheckboxIndicator), {
              "data-slot": "checkbox-indicator",
              class: "flex items-center justify-center text-current transition-none"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  ssrRenderSlot(_ctx.$slots, "default", {}, () => {
                    _push3(ssrRenderComponent(unref(Check), { class: "size-3.5" }, null, _parent3, _scopeId2));
                  }, _push3, _parent3, _scopeId2);
                } else {
                  return [
                    renderSlot(_ctx.$slots, "default", {}, () => [
                      createVNode(unref(Check), { class: "size-3.5" })
                    ])
                  ];
                }
              }),
              _: 3
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(CheckboxIndicator), {
                "data-slot": "checkbox-indicator",
                class: "flex items-center justify-center text-current transition-none"
              }, {
                default: withCtx(() => [
                  renderSlot(_ctx.$slots, "default", {}, () => [
                    createVNode(unref(Check), { class: "size-3.5" })
                  ])
                ]),
                _: 3
              })
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/components/ui/checkbox/Checkbox.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Login",
  __ssrInlineRender: true,
  props: {
    status: {},
    canResetPassword: { type: Boolean }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$2, mergeProps({
        title: "Log in to your account",
        description: "Enter your email and password below to log in"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Log in" }, null, _parent2, _scopeId));
            if (_ctx.status) {
              _push2(`<div class="mb-4 text-center text-sm font-medium text-green-600"${_scopeId}>${ssrInterpolate(_ctx.status)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(unref(Form), mergeProps(unref(AuthenticatedSessionController).store.form(), {
              "reset-on-success": ["password"],
              class: "flex flex-col gap-6"
            }), {
              default: withCtx(({ errors, processing }, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="grid gap-6"${_scopeId2}><div class="grid gap-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(_sfc_main$3), { for: "email" }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Email address`);
                      } else {
                        return [
                          createTextVNode("Email address")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(_sfc_main$4), {
                    id: "email",
                    type: "email",
                    name: "email",
                    required: "",
                    autofocus: "",
                    tabindex: 1,
                    autocomplete: "email",
                    placeholder: "email@example.com"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$5, {
                    message: errors.email
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="grid gap-2"${_scopeId2}><div class="flex items-center justify-between"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(_sfc_main$3), { for: "password" }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Password`);
                      } else {
                        return [
                          createTextVNode("Password")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  if (_ctx.canResetPassword) {
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      href: unref(request)(),
                      class: "text-sm",
                      tabindex: 5
                    }, {
                      default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Forgot password? `);
                        } else {
                          return [
                            createTextVNode(" Forgot password? ")
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div>`);
                  _push3(ssrRenderComponent(unref(_sfc_main$4), {
                    id: "password",
                    type: "password",
                    name: "password",
                    required: "",
                    tabindex: 2,
                    autocomplete: "current-password",
                    placeholder: "Password"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$5, {
                    message: errors.password
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="flex items-center justify-between"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(_sfc_main$3), {
                    for: "remember",
                    class: "flex items-center space-x-3"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(_sfc_main$1), {
                          id: "remember",
                          name: "remember",
                          tabindex: 3
                        }, null, _parent4, _scopeId3));
                        _push4(`<span${_scopeId3}>Remember me</span>`);
                      } else {
                        return [
                          createVNode(unref(_sfc_main$1), {
                            id: "remember",
                            name: "remember",
                            tabindex: 3
                          }),
                          createVNode("span", null, "Remember me")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                  _push3(ssrRenderComponent(unref(_sfc_main$7), {
                    type: "submit",
                    class: "mt-4 w-full",
                    tabindex: 4,
                    disabled: processing,
                    "data-test": "login-button"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (processing) {
                          _push4(ssrRenderComponent(unref(LoaderCircle), { class: "h-4 w-4 animate-spin" }, null, _parent4, _scopeId3));
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(` Log in `);
                      } else {
                        return [
                          processing ? (openBlock(), createBlock(unref(LoaderCircle), {
                            key: 0,
                            class: "h-4 w-4 animate-spin"
                          })) : createCommentVNode("", true),
                          createTextVNode(" Log in ")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "grid gap-6" }, [
                      createVNode("div", { class: "grid gap-2" }, [
                        createVNode(unref(_sfc_main$3), { for: "email" }, {
                          default: withCtx(() => [
                            createTextVNode("Email address")
                          ]),
                          _: 1
                        }),
                        createVNode(unref(_sfc_main$4), {
                          id: "email",
                          type: "email",
                          name: "email",
                          required: "",
                          autofocus: "",
                          tabindex: 1,
                          autocomplete: "email",
                          placeholder: "email@example.com"
                        }),
                        createVNode(_sfc_main$5, {
                          message: errors.email
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", { class: "grid gap-2" }, [
                        createVNode("div", { class: "flex items-center justify-between" }, [
                          createVNode(unref(_sfc_main$3), { for: "password" }, {
                            default: withCtx(() => [
                              createTextVNode("Password")
                            ]),
                            _: 1
                          }),
                          _ctx.canResetPassword ? (openBlock(), createBlock(_sfc_main$6, {
                            key: 0,
                            href: unref(request)(),
                            class: "text-sm",
                            tabindex: 5
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Forgot password? ")
                            ]),
                            _: 1
                          }, 8, ["href"])) : createCommentVNode("", true)
                        ]),
                        createVNode(unref(_sfc_main$4), {
                          id: "password",
                          type: "password",
                          name: "password",
                          required: "",
                          tabindex: 2,
                          autocomplete: "current-password",
                          placeholder: "Password"
                        }),
                        createVNode(_sfc_main$5, {
                          message: errors.password
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", { class: "flex items-center justify-between" }, [
                        createVNode(unref(_sfc_main$3), {
                          for: "remember",
                          class: "flex items-center space-x-3"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(_sfc_main$1), {
                              id: "remember",
                              name: "remember",
                              tabindex: 3
                            }),
                            createVNode("span", null, "Remember me")
                          ]),
                          _: 1
                        })
                      ]),
                      createVNode(unref(_sfc_main$7), {
                        type: "submit",
                        class: "mt-4 w-full",
                        tabindex: 4,
                        disabled: processing,
                        "data-test": "login-button"
                      }, {
                        default: withCtx(() => [
                          processing ? (openBlock(), createBlock(unref(LoaderCircle), {
                            key: 0,
                            class: "h-4 w-4 animate-spin"
                          })) : createCommentVNode("", true),
                          createTextVNode(" Log in ")
                        ]),
                        _: 2
                      }, 1032, ["disabled"])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "Log in" }),
              _ctx.status ? (openBlock(), createBlock("div", {
                key: 0,
                class: "mb-4 text-center text-sm font-medium text-green-600"
              }, toDisplayString(_ctx.status), 1)) : createCommentVNode("", true),
              createVNode(unref(Form), mergeProps(unref(AuthenticatedSessionController).store.form(), {
                "reset-on-success": ["password"],
                class: "flex flex-col gap-6"
              }), {
                default: withCtx(({ errors, processing }) => [
                  createVNode("div", { class: "grid gap-6" }, [
                    createVNode("div", { class: "grid gap-2" }, [
                      createVNode(unref(_sfc_main$3), { for: "email" }, {
                        default: withCtx(() => [
                          createTextVNode("Email address")
                        ]),
                        _: 1
                      }),
                      createVNode(unref(_sfc_main$4), {
                        id: "email",
                        type: "email",
                        name: "email",
                        required: "",
                        autofocus: "",
                        tabindex: 1,
                        autocomplete: "email",
                        placeholder: "email@example.com"
                      }),
                      createVNode(_sfc_main$5, {
                        message: errors.email
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", { class: "grid gap-2" }, [
                      createVNode("div", { class: "flex items-center justify-between" }, [
                        createVNode(unref(_sfc_main$3), { for: "password" }, {
                          default: withCtx(() => [
                            createTextVNode("Password")
                          ]),
                          _: 1
                        }),
                        _ctx.canResetPassword ? (openBlock(), createBlock(_sfc_main$6, {
                          key: 0,
                          href: unref(request)(),
                          class: "text-sm",
                          tabindex: 5
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Forgot password? ")
                          ]),
                          _: 1
                        }, 8, ["href"])) : createCommentVNode("", true)
                      ]),
                      createVNode(unref(_sfc_main$4), {
                        id: "password",
                        type: "password",
                        name: "password",
                        required: "",
                        tabindex: 2,
                        autocomplete: "current-password",
                        placeholder: "Password"
                      }),
                      createVNode(_sfc_main$5, {
                        message: errors.password
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode(unref(_sfc_main$3), {
                        for: "remember",
                        class: "flex items-center space-x-3"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(_sfc_main$1), {
                            id: "remember",
                            name: "remember",
                            tabindex: 3
                          }),
                          createVNode("span", null, "Remember me")
                        ]),
                        _: 1
                      })
                    ]),
                    createVNode(unref(_sfc_main$7), {
                      type: "submit",
                      class: "mt-4 w-full",
                      tabindex: 4,
                      disabled: processing,
                      "data-test": "login-button"
                    }, {
                      default: withCtx(() => [
                        processing ? (openBlock(), createBlock(unref(LoaderCircle), {
                          key: 0,
                          class: "h-4 w-4 animate-spin"
                        })) : createCommentVNode("", true),
                        createTextVNode(" Log in ")
                      ]),
                      _: 2
                    }, 1032, ["disabled"])
                  ])
                ]),
                _: 1
              }, 16)
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/auth/Login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
