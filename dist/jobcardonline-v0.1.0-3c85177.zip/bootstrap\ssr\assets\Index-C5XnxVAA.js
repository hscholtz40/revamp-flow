import { defineComponent, unref, withCtx, createTextVNode, createVNode, createBlock, openBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AppLayout-CmGu2Oww.js";
import { Head, Link } from "@inertiajs/vue3";
import { g as groups } from "./index-TOLxu5Uw.js";
import "class-variance-authority";
import "./Footer-Ce4AN4A5.js";
import "clsx";
import "tailwind-merge";
import "reka-ui";
import "./index--D7ld9AJ.js";
import "@vueuse/core";
import "lucide-vue-next";
import "./Input-CBU-ZeCu.js";
import "./_plugin-vue_export-helper-BjD8VFd3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    groups: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Groups" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        breadcrumbs: [{ title: "Groups", href: unref(groups).index().url }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex items-center justify-between gap-3 p-4"${_scopeId}><div${_scopeId}></div>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: unref(groups).create().url,
              class: "rounded bg-blue-600 px-3 py-2 text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`New Group`);
                } else {
                  return [
                    createTextVNode("New Group")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="p-4"${_scopeId}><table class="min-w-full border"${_scopeId}><thead${_scopeId}><tr class="bg-gray-50"${_scopeId}><th class="p-2 text-left"${_scopeId}>Name</th><th class="p-2 text-left"${_scopeId}>Description</th><th class="p-2 text-left"${_scopeId}>Type</th><th class="p-2 text-left"${_scopeId}>Users</th><th class="p-2 text-right"${_scopeId}>Actions</th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(props.groups, (g) => {
              _push2(`<tr class="border-t"${_scopeId}><td class="p-2 font-medium"${_scopeId}>${ssrInterpolate(g.name)}</td><td class="p-2 text-sm text-gray-600"${_scopeId}>${ssrInterpolate(g.description || "-")}</td><td class="p-2"${_scopeId}>`);
              if (g.is_administrator) {
                _push2(`<span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800"${_scopeId}> Administrator </span>`);
              } else {
                _push2(`<span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800"${_scopeId}> Standard </span>`);
              }
              _push2(`</td><td class="p-2"${_scopeId}>${ssrInterpolate(g.users_count)}</td><td class="p-2 text-right"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: unref(groups).edit(g.id).url,
                class: "rounded border px-2 py-1"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Edit`);
                  } else {
                    return [
                      createTextVNode("Edit")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center justify-between gap-3 p-4" }, [
                createVNode("div"),
                createVNode(unref(Link), {
                  href: unref(groups).create().url,
                  class: "rounded bg-blue-600 px-3 py-2 text-white"
                }, {
                  default: withCtx(() => [
                    createTextVNode("New Group")
                  ]),
                  _: 1
                }, 8, ["href"])
              ]),
              createVNode("div", { class: "p-4" }, [
                createVNode("table", { class: "min-w-full border" }, [
                  createVNode("thead", null, [
                    createVNode("tr", { class: "bg-gray-50" }, [
                      createVNode("th", { class: "p-2 text-left" }, "Name"),
                      createVNode("th", { class: "p-2 text-left" }, "Description"),
                      createVNode("th", { class: "p-2 text-left" }, "Type"),
                      createVNode("th", { class: "p-2 text-left" }, "Users"),
                      createVNode("th", { class: "p-2 text-right" }, "Actions")
                    ])
                  ]),
                  createVNode("tbody", null, [
                    (openBlock(true), createBlock(Fragment, null, renderList(props.groups, (g) => {
                      return openBlock(), createBlock("tr", {
                        key: g.id,
                        class: "border-t"
                      }, [
                        createVNode("td", { class: "p-2 font-medium" }, toDisplayString(g.name), 1),
                        createVNode("td", { class: "p-2 text-sm text-gray-600" }, toDisplayString(g.description || "-"), 1),
                        createVNode("td", { class: "p-2" }, [
                          g.is_administrator ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800"
                          }, " Administrator ")) : (openBlock(), createBlock("span", {
                            key: 1,
                            class: "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
                          }, " Standard "))
                        ]),
                        createVNode("td", { class: "p-2" }, toDisplayString(g.users_count), 1),
                        createVNode("td", { class: "p-2 text-right" }, [
                          createVNode(unref(Link), {
                            href: unref(groups).edit(g.id).url,
                            class: "rounded border px-2 py-1"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Edit")
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ])
                      ]);
                    }), 128))
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/pages/groups/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
